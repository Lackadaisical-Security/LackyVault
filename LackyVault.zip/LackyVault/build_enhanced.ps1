# =====================================================
# LackyVault Enhanced Build Script
# Comprehensive build system for zero-dependency crypto wallet
# =====================================================

param (
    [switch]$Release = $false,
    [switch]$Debug = $false,
    [switch]$Clean = $false,
    [switch]$Test = $false,
    [switch]$Installer = $false,
    [switch]$Benchmark = $false,
    [switch]$Docs = $false,
    [switch]$All = $false,
    [switch]$Help = $false
)

# Configuration
$ProjectName = "LackyVault"
$BuildDir = "build"
$ObjDir = "$BuildDir\obj"
$BinDir = "$BuildDir\bin"
$DocsDir = "docs"
$TestDir = "tests"
$InstallerDir = "installer"
$SrcDir = "src"

# Compiler settings
$Nasm = "nasm"
$Gcc = "gcc"
$ResourceCompiler = "windres"
$MinGW = "C:\mingw-w64\x86_64-8.1.0-win32-seh-rt_v6-rev0\mingw64\bin"
$WixToolset = "C:\Program Files (x86)\WiX Toolset v3.11\bin"

# Add MinGW to path if it exists
if (Test-Path $MinGW) {
    $env:PATH = "$MinGW;$env:PATH"
}

# Add WiX Toolset to path if it exists
if (Test-Path $WixToolset) {
    $env:PATH = "$WixToolset;$env:PATH"
}

# Build configurations
$DebugFlags = "-g -O0 -DDEBUG"
$ReleaseFlags = "-O2 -DNDEBUG"
$CommonFlags = "-Wall -Wextra -std=c11 -m64 -I./include"
$LinkerFlags = "-static -luser32 -lgdi32 -lws2_32 -lwininet -lcrypt32 -lsetupapi -lhid -lbcrypt"
$NasmFlags = "-f win64"

# Display help
function Show-Help {
    Write-Host "LackyVault Enhanced Build System"
    Write-Host "--------------------------------"
    Write-Host "Usage: .\build_enhanced.ps1 [options]"
    Write-Host ""
    Write-Host "Options:"
    Write-Host "  -Debug      Build with debug information"
    Write-Host "  -Release    Build optimized release version"
    Write-Host "  -Clean      Clean build artifacts"
    Write-Host "  -Test       Build and run tests"
    Write-Host "  -Installer  Create MSI installer"
    Write-Host "  -Benchmark  Run performance benchmarks"
    Write-Host "  -Docs       Generate documentation"
    Write-Host "  -All        Build everything"
    Write-Host "  -Help       Display this help message"
}

# Check dependencies
function Check-Dependencies {
    Write-Host "Checking build dependencies..."
    
    $Missing = $false
    
    # Check NASM
    try {
        $NasmVersion = & $Nasm -v
        if ($NasmVersion -match "NASM version") {
            Write-Host "  NASM: $($NasmVersion -split '\n' | Select-Object -First 1)" -ForegroundColor Green
        } else {
            $Missing = $true
            Write-Host "  NASM: Not found or invalid version" -ForegroundColor Red
        }
    } catch {
        $Missing = $true
        Write-Host "  NASM: Not found in PATH" -ForegroundColor Red
    }
    
    # Check GCC
    try {
        $GccVersion = & $Gcc --version
        if ($GccVersion -match "gcc") {
            Write-Host "  GCC: $($GccVersion -split '\n' | Select-Object -First 1)" -ForegroundColor Green
        } else {
            $Missing = $true
            Write-Host "  GCC: Not found or invalid version" -ForegroundColor Red
        }
    } catch {
        $Missing = $true
        Write-Host "  GCC: Not found in PATH" -ForegroundColor Red
    }
    
    # Check windres
    try {
        $WindresVersion = & $ResourceCompiler --version
        if ($WindresVersion -match "GNU windres") {
            Write-Host "  Windres: $($WindresVersion -split '\n' | Select-Object -First 1)" -ForegroundColor Green
        } else {
            $Missing = $true
            Write-Host "  Windres: Not found or invalid version" -ForegroundColor Red
        }
    } catch {
        $Missing = $true
        Write-Host "  Windres: Not found in PATH" -ForegroundColor Red
    }
    
    # Check WiX Toolset if building installer
    if ($Installer -or $All) {
        try {
            $CandleVersion = & candle -?
            if ($CandleVersion -match "Windows Installer XML") {
                Write-Host "  WiX Toolset: Found" -ForegroundColor Green
            } else {
                Write-Host "  WiX Toolset: Not found (required for installer)" -ForegroundColor Yellow
            }
        } catch {
            Write-Host "  WiX Toolset: Not found (required for installer)" -ForegroundColor Yellow
        }
    }
    
    if ($Missing) {
        Write-Host "Missing dependencies. Please install required tools." -ForegroundColor Red
        exit 1
    }
    
    Write-Host "All dependencies satisfied." -ForegroundColor Green
}

# Create build directories
function Create-Directories {
    if (-not (Test-Path $BuildDir)) {
        New-Item -ItemType Directory -Path $BuildDir | Out-Null
    }
    if (-not (Test-Path $ObjDir)) {
        New-Item -ItemType Directory -Path $ObjDir | Out-Null
    }
    if (-not (Test-Path $BinDir)) {
        New-Item -ItemType Directory -Path $BinDir | Out-Null
    }
}

# Clean build artifacts
function Clean-Build {
    Write-Host "Cleaning build artifacts..."
    
    if (Test-Path $BuildDir) {
        Remove-Item -Path $BuildDir -Recurse -Force
        Write-Host "  Removed $BuildDir directory" -ForegroundColor Green
    } else {
        Write-Host "  $BuildDir directory not found, nothing to clean" -ForegroundColor Yellow
    }
    
    # Clean installer artifacts
    if (Test-Path "$InstallerDir\*.wixobj") {
        Remove-Item -Path "$InstallerDir\*.wixobj" -Force
        Write-Host "  Removed WiX object files" -ForegroundColor Green
    }
    if (Test-Path "$InstallerDir\*.wixpdb") {
        Remove-Item -Path "$InstallerDir\*.wixpdb" -Force
        Write-Host "  Removed WiX debug files" -ForegroundColor Green
    }
    if (Test-Path "$InstallerDir\*.msi") {
        Remove-Item -Path "$InstallerDir\*.msi" -Force
        Write-Host "  Removed MSI installer files" -ForegroundColor Green
    }
}

# Compile assembly files
function Compile-Assembly {
    Write-Host "Compiling assembly files..."
    
    $AsmFiles = Get-ChildItem -Path "$SrcDir\asm" -Filter "*.asm" -Recurse
    
    foreach ($File in $AsmFiles) {
        $OutputObj = "$ObjDir\$($File.BaseName).obj"
        
        Write-Host "  Compiling $($File.Name)..."
        
        & $Nasm $NasmFlags -o $OutputObj $File.FullName
        
        if ($LASTEXITCODE -ne 0) {
            Write-Host "  Failed to compile $($File.Name)" -ForegroundColor Red
            exit 1
        }
    }
    
    Write-Host "Assembly compilation complete." -ForegroundColor Green
}

# Compile C files
function Compile-C {
    param (
        [string]$BuildType
    )
    
    $Flags = if ($BuildType -eq "debug") { $DebugFlags } else { $ReleaseFlags }
    
    Write-Host "Compiling C files ($BuildType build)..."
    
    $CFiles = Get-ChildItem -Path "$SrcDir\c" -Filter "*.c" -Recurse
    
    foreach ($File in $CFiles) {
        $OutputObj = "$ObjDir\$($File.BaseName).obj"
        
        Write-Host "  Compiling $($File.Name)..."
        
        & $Gcc -c $CommonFlags $Flags -o $OutputObj $File.FullName
        
        if ($LASTEXITCODE -ne 0) {
            Write-Host "  Failed to compile $($File.Name)" -ForegroundColor Red
            exit 1
        }
    }
    
    Write-Host "C compilation complete." -ForegroundColor Green
}

# Compile resources
function Compile-Resources {
    Write-Host "Compiling resources..."
    
    if (Test-Path "$SrcDir\resources\resources.rc") {
        $OutputObj = "$ObjDir\resources.res"
        
        & $ResourceCompiler -i "$SrcDir\resources\resources.rc" -o $OutputObj
        
        if ($LASTEXITCODE -ne 0) {
            Write-Host "  Failed to compile resources" -ForegroundColor Red
            exit 1
        }
        
        Write-Host "Resources compilation complete." -ForegroundColor Green
    } else {
        Write-Host "No resource file found, skipping." -ForegroundColor Yellow
    }
}

# Link the executable
function Link-Executable {
    param (
        [string]$BuildType
    )
    
    Write-Host "Linking executable ($BuildType)..."
    
    $OutputExe = "$BinDir\$ProjectName-$BuildType.exe"
    $ObjFiles = Get-ChildItem -Path $ObjDir -Filter "*.obj" | ForEach-Object { $_.FullName }
    $ResFiles = Get-ChildItem -Path $ObjDir -Filter "*.res" | ForEach-Object { $_.FullName }
    
    $AllFiles = $ObjFiles + $ResFiles
    
    & $Gcc -o $OutputExe $AllFiles $LinkerFlags
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "  Failed to link executable" -ForegroundColor Red
        exit 1
    }
    
    Write-Host "Linking complete. Executable created at $OutputExe" -ForegroundColor Green
}

# Build the project
function Build-Project {
    param (
        [string]$BuildType
    )
    
    Create-Directories
    Compile-Assembly
    Compile-C -BuildType $BuildType
    Compile-Resources
    Link-Executable -BuildType $BuildType
}

# Build and run tests
function Build-And-Run-Tests {
    Write-Host "Building and running tests..."
    
    Create-Directories
    
    # Compile test files
    $TestFiles = Get-ChildItem -Path $TestDir -Filter "*.c" -Recurse
    
    foreach ($File in $TestFiles) {
        $OutputObj = "$ObjDir\$($File.BaseName).obj"
        
        Write-Host "  Compiling test $($File.Name)..."
        
        & $Gcc -c $CommonFlags $DebugFlags -o $OutputObj $File.FullName
        
        if ($LASTEXITCODE -ne 0) {
            Write-Host "  Failed to compile test $($File.Name)" -ForegroundColor Red
            exit 1
        }
    }
    
    # Compile main project files needed by tests
    $CryptoFiles = Get-ChildItem -Path "$SrcDir\c\crypto" -Filter "*.c" -Recurse
    
    foreach ($File in $CryptoFiles) {
        $OutputObj = "$ObjDir\$($File.BaseName).obj"
        
        Write-Host "  Compiling dependency $($File.Name)..."
        
        & $Gcc -c $CommonFlags $DebugFlags -o $OutputObj $File.FullName
        
        if ($LASTEXITCODE -ne 0) {
            Write-Host "  Failed to compile $($File.Name)" -ForegroundColor Red
            exit 1
        }
    }
    
    # Link test executable
    $OutputExe = "$BinDir\$ProjectName-test.exe"
    $ObjFiles = Get-ChildItem -Path $ObjDir -Filter "*.obj" | ForEach-Object { $_.FullName }
    
    & $Gcc -o $OutputExe $ObjFiles $LinkerFlags
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "  Failed to link test executable" -ForegroundColor Red
        exit 1
    }
    
    # Run tests
    Write-Host "Running tests..."
    & $OutputExe
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Tests failed with exit code $LASTEXITCODE" -ForegroundColor Red
    } else {
        Write-Host "All tests passed successfully." -ForegroundColor Green
    }
}

# Build installer
function Build-Installer {
    Write-Host "Building MSI installer..."
    
    if (-not (Test-Path "$BinDir\$ProjectName-release.exe")) {
        Write-Host "  Release build not found. Building release first..." -ForegroundColor Yellow
        Build-Project -BuildType "release"
    }
    
    # Check if WiX tools are available
    try {
        $null = & candle -?
    } catch {
        Write-Host "  WiX Toolset not found. Cannot build installer." -ForegroundColor Red
        return
    }
    
    # Copy release executable to installer staging
    if (-not (Test-Path "$InstallerDir\files")) {
        New-Item -ItemType Directory -Path "$InstallerDir\files" | Out-Null
    }
    
    Copy-Item -Path "$BinDir\$ProjectName-release.exe" -Destination "$InstallerDir\files\$ProjectName.exe" -Force
    
    # Build WiX installer
    & candle -ext WixUtilExtension "$InstallerDir\$ProjectName.wxs" -out "$InstallerDir\$ProjectName.wixobj"
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "  Failed to compile WiX source" -ForegroundColor Red
        exit 1
    }
    
    & light -ext WixUIExtension -ext WixUtilExtension "$InstallerDir\$ProjectName.wixobj" -out "$InstallerDir\$ProjectName.msi"
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "  Failed to link WiX installer" -ForegroundColor Red
        exit 1
    }
    
    Write-Host "Installer built successfully: $InstallerDir\$ProjectName.msi" -ForegroundColor Green
}

# Run benchmarks
function Run-Benchmarks {
    Write-Host "Running performance benchmarks..."
    
    if (-not (Test-Path "$BinDir\$ProjectName-test.exe")) {
        Write-Host "  Test executable not found. Building tests first..." -ForegroundColor Yellow
        Build-And-Run-Tests
    }
    
    # Run benchmarks
    & "$BinDir\$ProjectName-test.exe" -b
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Benchmarks failed with exit code $LASTEXITCODE" -ForegroundColor Red
    } else {
        Write-Host "Benchmarks completed successfully." -ForegroundColor Green
    }
}

# Generate documentation
function Generate-Documentation {
    Write-Host "Generating documentation..."
    
    # Check if Doxygen is available
    try {
        $DoxygenVersion = & doxygen --version
        Write-Host "  Using Doxygen version $DoxygenVersion" -ForegroundColor Green
    } catch {
        Write-Host "  Doxygen not found. Cannot generate documentation." -ForegroundColor Red
        return
    }
    
    if (Test-Path "Doxyfile") {
        & doxygen Doxyfile
        
        if ($LASTEXITCODE -ne 0) {
            Write-Host "  Failed to generate documentation" -ForegroundColor Red
        } else {
            Write-Host "Documentation generated successfully." -ForegroundColor Green
        }
    } else {
        Write-Host "  Doxyfile not found. Cannot generate documentation." -ForegroundColor Red
    }
}

# Main build logic
if ($Help) {
    Show-Help
    exit 0
}

# Display build banner
Write-Host "┌───────────────────────────────────────────┐"
Write-Host "│        LackyVault Enhanced Builder        │"
Write-Host "│       Zero Dependencies, Maximum Pain     │"
Write-Host "└───────────────────────────────────────────┘"
Write-Host ""

# Check dependencies
Check-Dependencies

# Process clean first if requested
if ($Clean -or $All) {
    Clean-Build
}

# Build debug version
if ($Debug -or $All) {
    Build-Project -BuildType "debug"
}

# Build release version
if ($Release -or $All) {
    Build-Project -BuildType "release"
}

# Build and run tests
if ($Test -or $All) {
    Build-And-Run-Tests
}

# Build installer
if ($Installer -or $All) {
    Build-Installer
}

# Run benchmarks
if ($Benchmark -or $All) {
    Run-Benchmarks
}

# Generate documentation
if ($Docs -or $All) {
    Generate-Documentation
}

# If no specific actions were requested, build release by default
if (-not ($Debug -or $Release -or $Clean -or $Test -or $Installer -or $Benchmark -or $Docs -or $All)) {
    Write-Host "No specific build action requested. Building release by default." -ForegroundColor Yellow
    Build-Project -BuildType "release"
}

Write-Host ""
Write-Host "Build process completed." -ForegroundColor Green 