# =====================================================
# LackyVault Simple Build System
# Windows PowerShell build without GNU Make dependency
# =====================================================

param(
    [ValidateSet("debug", "release", "test", "installer", "package", "clean", "help")]
    [string]$Target = "release",
    [switch]$Verbose = $false,
    [switch]$InstallDeps = $false
)

# Configuration
$ProjectName = "LackyVault"
$Version = "2.0.0"
$BuildDir = "build"
$SrcDir = "src"
$IncludeDir = "include"
$OutputDir = "output"

# Tool detection
$Tools = @{
    NASM = ""
    GCC = ""
    Windres = ""
    Candle = ""
    Light = ""
}

# Compiler flags
$NasmFlags = "-f win64 -g -F dwarf"
$GccFlags = "-std=c11 -Wall -Wextra -I$IncludeDir -DUNICODE -D_UNICODE -DWIN32_LEAN_AND_MEAN"
$DebugFlags = "-g -O0 -DDEBUG"
$ReleaseFlags = "-O2 -DNDEBUG"
$LinkerFlags = "-static-libgcc -Wl,--subsystem,windows"
$Libraries = "-luser32 -lkernel32 -lgdi32 -lcomctl32 -ladvapi32 -lshell32 -lole32 -lwininet -lws2_32 -lcrypt32 -lbcrypt"

# Utility functions
function Write-Step { param([string]$Message); Write-Host "[STEP] $Message" -ForegroundColor Green }
function Write-Info { param([string]$Message); Write-Host "[INFO] $Message" -ForegroundColor White }
function Write-Warning { param([string]$Message); Write-Host "[WARN] $Message" -ForegroundColor Yellow }
function Write-Error-Custom { param([string]$Message); Write-Host "[ERROR] $Message" -ForegroundColor Red }
function Write-Success { param([string]$Message); Write-Host "[SUCCESS] $Message" -ForegroundColor Green }

function Write-Banner {
    param([string]$Message)
    Write-Host ""
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host "  $Message" -ForegroundColor Yellow
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host ""
}

# Tool detection
function Find-Tools {
    Write-Step "Detecting build tools..."
    
    # Find NASM
    $nasmPaths = @("nasm.exe", "C:\Program Files\NASM\nasm.exe")
    foreach ($path in $nasmPaths) {
        try {
            $result = Get-Command $path -ErrorAction SilentlyContinue
            if ($result) {
                $Tools.NASM = $result.Source
                Write-Info "✓ NASM found: $($Tools.NASM)"
                break
            }
        } catch { }
    }
    
    # Find GCC
    $gccPaths = @("gcc.exe", "C:\msys64\mingw64\bin\gcc.exe", "C:\MinGW\bin\gcc.exe")
    foreach ($path in $gccPaths) {
        try {
            $result = Get-Command $path -ErrorAction SilentlyContinue
            if ($result) {
                $Tools.GCC = $result.Source
                Write-Info "✓ GCC found: $($Tools.GCC)"
                
                # Find windres in same directory
                $windresPath = Join-Path (Split-Path $Tools.GCC) "windres.exe"
                if (Test-Path $windresPath) {
                    $Tools.Windres = $windresPath
                    Write-Info "✓ Windres found: $($Tools.Windres)"
                }
                break
            }
        } catch { }
    }
    
    # Find WiX
    $wixPaths = @(
        "C:\Program Files (x86)\WiX Toolset v3.14\bin",
        "C:\Program Files (x86)\WiX Toolset v3.11\bin"
    )
    
    foreach ($path in $wixPaths) {
        $candlePath = Join-Path $path "candle.exe"
        $lightPath = Join-Path $path "light.exe"
        
        if ((Test-Path $candlePath) -and (Test-Path $lightPath)) {
            $Tools.Candle = $candlePath
            $Tools.Light = $lightPath
            Write-Info "✓ WiX Toolset found: $path"
            break
        }
    }
    
    # Check required tools
    $missing = @()
    if (-not $Tools.NASM) { $missing += "NASM" }
    if (-not $Tools.GCC) { $missing += "GCC/MinGW-w64" }
    
    if ($missing.Count -gt 0) {
        Write-Warning "Missing required tools: $($missing -join ', ')"
        Write-Info "Run with -InstallDeps to install missing dependencies"
        return $false
    }
    
    return $true
}

# Install dependencies
function Install-Dependencies {
    Write-Banner "Installing Build Dependencies"
    
    if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
        Write-Warning "Administrator privileges required for dependency installation"
        Write-Info "Requesting elevation..."
        
        $arguments = "-ExecutionPolicy Bypass -File `"$PSCommandPath`" -Target $Target -InstallDeps"
        Start-Process powershell -ArgumentList $arguments -Verb RunAs
        exit
    }
    
    Write-Step "Installing dependencies via winget..."
    
    try {
        Write-Info "Installing NASM..."
        winget install NASM.NASM --accept-package-agreements --accept-source-agreements
        
        Write-Info "Installing MSYS2 (for MinGW-w64)..."
        winget install msys2.msys2 --accept-package-agreements --accept-source-agreements
        
        Write-Success "Dependencies installed successfully!"
        Write-Info "Please restart your terminal and run:"
        Write-Host "  C:\msys64\msys2.exe" -ForegroundColor Yellow
        Write-Host "  pacman -S mingw-w64-x86_64-gcc mingw-w64-x86_64-make" -ForegroundColor Yellow
        
    } catch {
        Write-Error-Custom "Failed to install dependencies: $($_.Exception.Message)"
    }
}

# Directory management
function Initialize-Directories {
    Write-Step "Creating build directories..."
    
    $dirs = @(
        $BuildDir,
        "$BuildDir\obj",
        "$BuildDir\obj\core",
        "$BuildDir\obj\ui", 
        "$BuildDir\obj\crypto",
        "$BuildDir\obj\network",
        "$BuildDir\obj\storage",
        "$BuildDir\obj\blockchain",
        "$BuildDir\obj\security",
        "$BuildDir\obj\asm",
        "$BuildDir\resources",
        $OutputDir
    )
    
    foreach ($dir in $dirs) {
        if (-not (Test-Path $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
            if ($Verbose) { Write-Info "Created directory: $dir" }
        }
    }
}

function Clean-Build {
    Write-Step "Cleaning build artifacts..."
    
    if (Test-Path $BuildDir) {
        Remove-Item -Path $BuildDir -Recurse -Force
        Write-Info "Removed build directory"
    }
    
    if (Test-Path $OutputDir) {
        Remove-Item -Path $OutputDir -Recurse -Force  
        Write-Info "Removed output directory"
    }
}

# Compilation functions
function Compile-Assembly {
    Write-Step "Compiling assembly files..."
    
    $asmFiles = Get-ChildItem -Path "$SrcDir\asm" -Filter "*.asm" | Select-Object -First 5  # Limit for initial test
    $compiled = 0
    $failed = 0
    
    foreach ($file in $asmFiles) {
        $objFile = "$BuildDir\obj\asm\$($file.BaseName).obj"
        
        if ($Verbose) { Write-Info "Assembling $($file.Name)..." }
        
        $arguments = @($NasmFlags.Split(' '), "-o", "`"$objFile`"", "`"$($file.FullName)`"")
        
        try {
            $process = Start-Process -FilePath $Tools.NASM -ArgumentList $arguments -Wait -PassThru -NoNewWindow
            
            if ($process.ExitCode -eq 0) {
                $compiled++
                if ($Verbose) { Write-Info "✓ $($file.Name)" }
            } else {
                $failed++
                Write-Warning "✗ Failed to assemble $($file.Name)"
            }
        } catch {
            $failed++
            Write-Warning "✗ Exception assembling $($file.Name): $($_.Exception.Message)"
        }
    }
    
    Write-Info "Assembly compilation: $compiled compiled, $failed failed"
    return $failed -eq 0
}

function Compile-C-Sources {
    param([string]$BuildType)
    
    Write-Step "Compiling C source files ($BuildType)..."
    
    $flags = $GccFlags
    if ($BuildType -eq "debug") {
        $flags += " $DebugFlags"
    } else {
        $flags += " $ReleaseFlags"
    }
    
    # Get C source files from each directory
    $sourceGroups = @{
        "core" = Get-ChildItem -Path "$SrcDir\c\core" -Filter "*.c" -ErrorAction SilentlyContinue
        "ui" = Get-ChildItem -Path "$SrcDir\c\ui" -Filter "*.c" -ErrorAction SilentlyContinue
        "crypto" = Get-ChildItem -Path "$SrcDir\c\crypto" -Filter "*.c" -ErrorAction SilentlyContinue
        "security" = Get-ChildItem -Path "$SrcDir\c\security" -Filter "*.c" -ErrorAction SilentlyContinue
    }
    
    $compiled = 0
    $failed = 0
    
    foreach ($group in $sourceGroups.GetEnumerator()) {
        if ($group.Value) {
            foreach ($file in $group.Value) {
                $objFile = "$BuildDir\obj\$($group.Key)\$($file.BaseName).obj"
                
                if ($Verbose) { Write-Info "Compiling $($group.Key)/$($file.Name)..." }
                
                $arguments = @($flags.Split(' '), "-c", "-o", "`"$objFile`"", "`"$($file.FullName)`"")
                
                try {
                    $process = Start-Process -FilePath $Tools.GCC -ArgumentList $arguments -Wait -PassThru -NoNewWindow
                    
                    if ($process.ExitCode -eq 0) {
                        $compiled++
                        if ($Verbose) { Write-Info "✓ $($group.Key)/$($file.Name)" }
                    } else {
                        $failed++
                        Write-Warning "✗ Failed to compile $($group.Key)/$($file.Name)"
                    }
                } catch {
                    $failed++
                    Write-Warning "✗ Exception compiling $($group.Key)/$($file.Name): $($_.Exception.Message)"
                }
            }
        }
    }
    
    Write-Info "C compilation: $compiled compiled, $failed failed"
    return $failed -eq 0
}

function Link-Executable {
    param([string]$BuildType)
    
    Write-Step "Linking executable ($BuildType)..."
    
    $exeName = if ($BuildType -eq "debug") { "$ProjectName-debug.exe" } else { "$ProjectName.exe" }
    $exePath = "$BuildDir\$exeName"
    
    # Collect all object files
    $objFiles = Get-ChildItem -Path "$BuildDir\obj" -Filter "*.obj" -Recurse
    
    if ($objFiles.Count -eq 0) {
        Write-Error-Custom "No object files found for linking"
        return $false
    }
    
    $objPaths = $objFiles | ForEach-Object { "`"$($_.FullName)`"" }
    $arguments = @($LinkerFlags.Split(' '), "-o", "`"$exePath`"") + $objPaths + $Libraries.Split(' ')
    
    try {
        $process = Start-Process -FilePath $Tools.GCC -ArgumentList $arguments -Wait -PassThru -NoNewWindow
        
        if ($process.ExitCode -eq 0) {
            Write-Success "✓ Executable linked successfully: $exePath"
            
            # Copy to output directory
            if (-not (Test-Path $OutputDir)) {
                New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
            }
            Copy-Item -Path $exePath -Destination "$OutputDir\$exeName" -Force
            
            # Show file info
            $fileInfo = Get-Item $exePath
            Write-Info "File size: $([math]::Round($fileInfo.Length / 1KB, 2)) KB"
            
            return $true
        } else {
            Write-Error-Custom "✗ Linking failed"
            return $false
        }
    } catch {
        Write-Error-Custom "✗ Exception during linking: $($_.Exception.Message)"
        return $false
    }
}

# Main build function
function Build-Project {
    param([string]$BuildType)
    
    Write-Banner "Building $ProjectName v$Version ($BuildType)"
    
    if (-not (Find-Tools)) {
        return $false
    }
    
    Initialize-Directories
    
    # Compile assembly files
    if (-not (Compile-Assembly)) {
        Write-Warning "Assembly compilation had issues, continuing..."
    }
    
    # Compile C sources
    if (-not (Compile-C-Sources $BuildType)) {
        Write-Error-Custom "C compilation failed"
        return $false
    }
    
    # Link executable
    if (-not (Link-Executable $BuildType)) {
        Write-Error-Custom "Linking failed"
        return $false
    }
    
    Write-Success "Build completed successfully!"
    return $true
}

function Show-Help {
    Write-Banner "$ProjectName Build System v$Version"
    
    Write-Host "Usage: .\build_simple.ps1 [options]" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Targets:" -ForegroundColor Cyan
    Write-Host "  release      Build optimized release version (default)" -ForegroundColor Gray
    Write-Host "  debug        Build with debug symbols and logging" -ForegroundColor Gray
    Write-Host "  clean        Remove all build artifacts" -ForegroundColor Gray
    Write-Host "  help         Show this help message" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Options:" -ForegroundColor Cyan
    Write-Host "  -Verbose     Enable verbose output" -ForegroundColor Gray
    Write-Host "  -InstallDeps Install build dependencies" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Examples:" -ForegroundColor Cyan
    Write-Host "  .\build_simple.ps1 debug -Verbose" -ForegroundColor Yellow
    Write-Host "  .\build_simple.ps1 -InstallDeps" -ForegroundColor Yellow
}

# Main execution
if ($InstallDeps) {
    Install-Dependencies
    exit
}

switch ($Target) {
    "clean" { Clean-Build }
    "debug" { Build-Project "debug" }
    "release" { Build-Project "release" }
    "help" { Show-Help }
    default { Build-Project "release" }
}

Write-Host ""
Write-Success "Build process completed!"