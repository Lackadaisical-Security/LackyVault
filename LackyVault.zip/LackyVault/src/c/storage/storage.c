/**
 * LackyVault - Secure Storage System
 * Lackadaisical Security
 * 
 * Encrypted wallet storage with military-grade security
 */

#include "../../../include/lacky_vault.h"
#include "../../../include/lacky_crypto.h"
#include <windows.h>
#include <shlobj.h>
#include <stdio.h>

#pragma comment(lib, "shell32.lib")

/* Storage constants */
#define LACKY_WALLET_EXTENSION L".lw"
#define LACKY_BACKUP_EXTENSION L".lbk"
#define LACKY_CONFIG_FILENAME L"lacky_config.dat"
#define LACKY_STORAGE_VERSION 1

/* File magic numbers */
#define LACKY_WALLET_MAGIC 0x4C41434B59564C54ULL  // "LACKYVLT"
#define LACKY_CONFIG_MAGIC 0x4C41434B59434647ULL  // "LACKYCFG"

/* Storage structure headers */
#pragma pack(push, 1)
typedef struct {
    uint64_t magic;
    uint32_t version;
    uint32_t encrypted_size;
    uint8_t salt[32];
    uint8_t iv[16];
    uint8_t auth_tag[16];
} lacky_file_header_t;
#pragma pack(pop)

/* Global storage context */
static lacky_storage_ctx_t g_storage_ctx = {0};

/**
 * Initialize storage subsystem
 */
lacky_error_t lacky_storage_init(lacky_storage_ctx_t* ctx) {
    if (!ctx) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    ZeroMemory(ctx, sizeof(lacky_storage_ctx_t));

    // Get application data directory
    wchar_t app_data_path[MAX_PATH];
    if (SHGetFolderPathW(NULL, CSIDL_APPDATA, NULL, SHGFP_TYPE_CURRENT, app_data_path) != S_OK) {
        return LACKY_ERROR_STORAGE_INIT;
    }

    // Create LackyVault directory
    wchar_t lacky_dir[MAX_PATH];
    swprintf_s(lacky_dir, MAX_PATH, L"%s\\LackyVault", app_data_path);
    CreateDirectoryW(lacky_dir, NULL);

    // Set storage directory
    wcscpy_s(ctx->data_directory, MAX_PATH, lacky_dir);

    // Initialize crypto context for storage
    lacky_crypto_random(ctx->encryption_key, sizeof(ctx->encryption_key));
    ctx->initialized = true;

    return LACKY_SUCCESS;
}

/**
 * Cleanup storage subsystem
 */
void lacky_storage_cleanup(lacky_storage_ctx_t* ctx) {
    if (!ctx) {
        return;
    }

    // Zero out sensitive data
    lacky_asm_zeroize(ctx->encryption_key, sizeof(ctx->encryption_key));
    lacky_asm_zeroize(ctx, sizeof(lacky_storage_ctx_t));
}

/**
 * Save wallet to encrypted file
 */
lacky_error_t lacky_wallet_save(lacky_wallet_t* wallet, const char* password) {
    if (!wallet || !password) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    // Create wallet filename
    wchar_t wallet_path[MAX_PATH];
    swprintf_s(wallet_path, MAX_PATH, L"%s\\%s%s", 
               g_storage_ctx.data_directory, 
               wallet->name, 
               LACKY_WALLET_EXTENSION);

    // Serialize wallet data
    size_t data_size = sizeof(lacky_wallet_t);
    uint8_t* plaintext = (uint8_t*)malloc(data_size);
    if (!plaintext) {
        return LACKY_ERROR_MEMORY;
    }

    memcpy(plaintext, wallet, data_size);

    // Prepare encryption
    lacky_file_header_t header = {0};
    header.magic = LACKY_WALLET_MAGIC;
    header.version = LACKY_STORAGE_VERSION;
    header.encrypted_size = (uint32_t)data_size;

    // Generate salt and IV
    lacky_crypto_random(header.salt, sizeof(header.salt));
    lacky_crypto_random(header.iv, sizeof(header.iv));

    // Derive encryption key from password
    uint8_t derived_key[32];
    lacky_error_t result = lacky_kdf_derive(password, strlen(password), 
                                           header.salt, sizeof(header.salt),
                                           derived_key, sizeof(derived_key));
    if (result != LACKY_ERROR_SUCCESS) {
        free(plaintext);
        return result;
    }

    // Encrypt wallet data
    uint8_t* ciphertext = (uint8_t*)malloc(data_size);
    if (!ciphertext) {
        free(plaintext);
        lacky_asm_zeroize(derived_key, sizeof(derived_key));
        return LACKY_ERROR_MEMORY;
    }

    result = lacky_chacha20_poly1305_encrypt(plaintext, data_size,
                                            derived_key, header.iv,
                                            NULL, 0,
                                            ciphertext, header.auth_tag);
    if (result != LACKY_ERROR_SUCCESS) {
        free(plaintext);
        free(ciphertext);
        lacky_asm_zeroize(derived_key, sizeof(derived_key));
        return result;
    }

    // Write to file
    HANDLE file = CreateFileW(wallet_path, GENERIC_WRITE, 0, NULL, 
                             CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (file == INVALID_HANDLE_VALUE) {
        free(plaintext);
        free(ciphertext);
        lacky_asm_zeroize(derived_key, sizeof(derived_key));
        return LACKY_ERROR_STORAGE_FAIL;
    }

    DWORD written;
    BOOL success = WriteFile(file, &header, sizeof(header), &written, NULL);
    if (success && written == sizeof(header)) {
        success = WriteFile(file, ciphertext, data_size, &written, NULL);
    }

    CloseHandle(file);

    // Cleanup
    free(plaintext);
    free(ciphertext);
    lacky_asm_zeroize(derived_key, sizeof(derived_key));

    return success ? LACKY_ERROR_SUCCESS : LACKY_ERROR_STORAGE_FAIL;
}

/**
 * Load wallet from encrypted file
 */
lacky_error_t lacky_wallet_load(lacky_wallet_t** wallet, const wchar_t* wallet_name, const char* password) {
    if (!wallet || !wallet_name || !password) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    // Create wallet filename
    wchar_t wallet_path[MAX_PATH];
    swprintf_s(wallet_path, MAX_PATH, L"%s\\%s%s", 
               g_storage_ctx.storage_dir, 
               wallet_name, 
               LACKY_WALLET_EXTENSION);

    // Open file
    HANDLE file = CreateFileW(wallet_path, GENERIC_READ, FILE_SHARE_READ, NULL, 
                             OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (file == INVALID_HANDLE_VALUE) {
        return LACKY_ERROR_STORAGE_FAIL;
    }

    // Read header
    lacky_file_header_t header;
    DWORD read;
    if (!ReadFile(file, &header, sizeof(header), &read, NULL) || 
        read != sizeof(header)) {
        CloseHandle(file);
        return LACKY_ERROR_STORAGE_FAIL;
    }

    // Verify magic number
    if (header.magic != LACKY_WALLET_MAGIC) {
        CloseHandle(file);
        return LACKY_ERROR_INVALID_FORMAT;
    }

    // Read encrypted data
    uint8_t* ciphertext = (uint8_t*)malloc(header.encrypted_size);
    if (!ciphertext) {
        CloseHandle(file);
        return LACKY_ERROR_MEMORY;
    }

    if (!ReadFile(file, ciphertext, header.encrypted_size, &read, NULL) || 
        read != header.encrypted_size) {
        CloseHandle(file);
        free(ciphertext);
        return LACKY_ERROR_STORAGE_FAIL;
    }

    CloseHandle(file);

    // Derive decryption key
    uint8_t derived_key[32];
    lacky_error_t result = lacky_kdf_derive(password, strlen(password), 
                                           header.salt, sizeof(header.salt),
                                           derived_key, sizeof(derived_key));
    if (result != LACKY_ERROR_SUCCESS) {
        free(ciphertext);
        return result;
    }

    // Decrypt wallet data
    uint8_t* plaintext = (uint8_t*)malloc(header.encrypted_size);
    if (!plaintext) {
        free(ciphertext);
        lacky_asm_zeroize(derived_key, sizeof(derived_key));
        return LACKY_ERROR_MEMORY;
    }

    result = lacky_chacha20_poly1305_decrypt(ciphertext, header.encrypted_size,
                                            derived_key, header.iv,
                                            NULL, 0,
                                            header.auth_tag, plaintext);
    if (result != LACKY_ERROR_SUCCESS) {
        free(ciphertext);
        free(plaintext);
        lacky_asm_zeroize(derived_key, sizeof(derived_key));
        return LACKY_ERROR_AUTH_FAIL;
    }

    // Create wallet structure
    *wallet = (lacky_wallet_t*)malloc(sizeof(lacky_wallet_t));
    if (!*wallet) {
        free(ciphertext);
        free(plaintext);
        lacky_asm_zeroize(derived_key, sizeof(derived_key));
        return LACKY_ERROR_MEMORY;
    }

    memcpy(*wallet, plaintext, sizeof(lacky_wallet_t));

    // Cleanup
    free(ciphertext);
    free(plaintext);
    lacky_asm_zeroize(derived_key, sizeof(derived_key));

    return LACKY_ERROR_SUCCESS;
}

/**
 * Create new wallet
 */
lacky_error_t lacky_wallet_create(lacky_wallet_t** wallet, const char* password) {
    if (!wallet || !password) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    // Allocate wallet structure
    *wallet = (lacky_wallet_t*)malloc(sizeof(lacky_wallet_t));
    if (!*wallet) {
        return LACKY_ERROR_MEMORY;
    }

    ZeroMemory(*wallet, sizeof(lacky_wallet_t));

    // Generate wallet name
    swprintf_s((*wallet)->name, 64, L"Wallet_%d", GetTickCount());

    // Generate master seed
    lacky_crypto_random((*wallet)->master_seed, sizeof((*wallet)->master_seed));

    // Generate BIP39 mnemonic
    lacky_error_t result = lacky_bip39_generate_mnemonic((*wallet)->master_seed, 
                                                        sizeof((*wallet)->master_seed),
                                                        (*wallet)->mnemonic, 
                                                        sizeof((*wallet)->mnemonic));
    if (result != LACKY_ERROR_SUCCESS) {
        free(*wallet);
        *wallet = NULL;
        return result;
    }

    // Generate HD wallet keys
    result = lacky_hd_derive_master_key((*wallet)->master_seed, 
                                       sizeof((*wallet)->master_seed),
                                       (*wallet)->master_private_key,
                                       (*wallet)->master_public_key);
    if (result != LACKY_ERROR_SUCCESS) {
        free(*wallet);
        *wallet = NULL;
        return result;
    }

    // Generate first receive address
    result = lacky_wallet_generate_address(*wallet, 0, 
                                          (*wallet)->receive_addresses[0],
                                          sizeof((*wallet)->receive_addresses[0]));
    if (result != LACKY_ERROR_SUCCESS) {
        free(*wallet);
        *wallet = NULL;
        return result;
    }

    (*wallet)->address_count = 1;
    (*wallet)->balance = 0;
    (*wallet)->created_time = time(NULL);

    // Save wallet
    result = lacky_wallet_save(*wallet, password);
    if (result != LACKY_ERROR_SUCCESS) {
        free(*wallet);
        *wallet = NULL;
        return result;
    }

    return LACKY_ERROR_SUCCESS;
}

/**
 * Import wallet from mnemonic
 */
lacky_error_t lacky_wallet_import(lacky_wallet_t** wallet, const char* mnemonic, const char* password) {
    if (!wallet || !mnemonic || !password) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    // Allocate wallet structure
    *wallet = (lacky_wallet_t*)malloc(sizeof(lacky_wallet_t));
    if (!*wallet) {
        return LACKY_ERROR_MEMORY;
    }

    ZeroMemory(*wallet, sizeof(lacky_wallet_t));

    // Generate wallet name
    swprintf_s((*wallet)->name, 64, L"Imported_%d", GetTickCount());

    // Validate and convert mnemonic to seed
    lacky_error_t result = lacky_bip39_mnemonic_to_seed(mnemonic, 
                                                       (*wallet)->master_seed,
                                                       sizeof((*wallet)->master_seed));
    if (result != LACKY_ERROR_SUCCESS) {
        free(*wallet);
        *wallet = NULL;
        return result;
    }

    // Store mnemonic
    strcpy_s((*wallet)->mnemonic, sizeof((*wallet)->mnemonic), mnemonic);

    // Generate HD wallet keys
    result = lacky_hd_derive_master_key((*wallet)->master_seed, 
                                       sizeof((*wallet)->master_seed),
                                       (*wallet)->master_private_key,
                                       (*wallet)->master_public_key);
    if (result != LACKY_ERROR_SUCCESS) {
        free(*wallet);
        *wallet = NULL;
        return result;
    }

    // Generate first receive address
    result = lacky_wallet_generate_address(*wallet, 0, 
                                          (*wallet)->receive_addresses[0],
                                          sizeof((*wallet)->receive_addresses[0]));
    if (result != LACKY_ERROR_SUCCESS) {
        free(*wallet);
        *wallet = NULL;
        return result;
    }

    (*wallet)->address_count = 1;
    (*wallet)->balance = 0;
    (*wallet)->created_time = time(NULL);

    // Save wallet
    result = lacky_wallet_save(*wallet, password);
    if (result != LACKY_ERROR_SUCCESS) {
        free(*wallet);
        *wallet = NULL;
        return result;
    }

    return LACKY_ERROR_SUCCESS;
}

/**
 * Generate new address for wallet
 */
lacky_error_t lacky_wallet_generate_address(lacky_wallet_t* wallet, uint32_t index, 
                                           char* address, size_t address_size) {
    if (!wallet || !address) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    // Derive address from HD wallet
    uint8_t private_key[32];
    uint8_t public_key[33];
    
    lacky_error_t result = lacky_hd_derive_key(wallet->master_private_key,
                                              wallet->master_public_key,
                                              0, // Account 0
                                              0, // External chain
                                              index,
                                              private_key,
                                              public_key);
    if (result != LACKY_ERROR_SUCCESS) {
        return result;
    }

    // Generate Bitcoin address
    result = lacky_bitcoin_pubkey_to_address(public_key, sizeof(public_key),
                                            address, address_size);
    
    // Clear private key
    lacky_asm_zeroize(private_key, sizeof(private_key));

    return result;
}

/**
 * List available wallets
 */
lacky_error_t lacky_storage_list_wallets(wchar_t wallet_names[][64], size_t* count, size_t max_count) {
    if (!wallet_names || !count) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    *count = 0;

    // Search for wallet files
    wchar_t search_pattern[MAX_PATH];
    swprintf_s(search_pattern, MAX_PATH, L"%s\\*%s", 
               g_storage_ctx.storage_dir, 
               LACKY_WALLET_EXTENSION);

    WIN32_FIND_DATAW find_data;
    HANDLE find_handle = FindFirstFileW(search_pattern, &find_data);
    
    if (find_handle == INVALID_HANDLE_VALUE) {
        return LACKY_ERROR_SUCCESS; // No wallets found
    }

    do {
        if (*count >= max_count) {
            break;
        }

        // Extract wallet name (remove extension)
        wchar_t* ext = wcsrchr(find_data.cFileName, L'.');
        if (ext) {
            *ext = L'\0';
        }

        wcscpy_s(wallet_names[*count], 64, find_data.cFileName);
        (*count)++;

    } while (FindNextFileW(find_handle, &find_data));

    FindClose(find_handle);

    return LACKY_ERROR_SUCCESS;
}

/**
 * Delete wallet file
 */
lacky_error_t lacky_wallet_delete(const wchar_t* wallet_name) {
    if (!wallet_name) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    wchar_t wallet_path[MAX_PATH];
    swprintf_s(wallet_path, MAX_PATH, L"%s\\%s%s", 
               g_storage_ctx.storage_dir, 
               wallet_name, 
               LACKY_WALLET_EXTENSION);

    if (!DeleteFileW(wallet_path)) {
        return LACKY_ERROR_STORAGE_FAIL;
    }

    return LACKY_ERROR_SUCCESS;
}

/**
 * Initialize global storage context
 */
void lacky_storage_init_global(void) {
    lacky_storage_init(&g_storage_ctx);
}

/**
 * Get global storage context
 */
lacky_storage_context_t* lacky_storage_get_global(void) {
    return &g_storage_ctx;
}
