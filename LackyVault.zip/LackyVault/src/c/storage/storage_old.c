/**
 * LackyVault - Storage Layer
 * Lackadaisical Security
 * 
 * Encrypted file storage and wallet management
 * TODO: Implement encrypted VFS and wallet formats
 */

#include "../../../include/lacky_vault.h"
#include <windows.h>
#include <shlobj.h>

/**
 * Initialize storage subsystem
 */
lacky_error_t lacky_storage_init(lacky_app_t* app) {
    if (!app) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    /* Get application data directory */
    wchar_t app_data_path[MAX_PATH];
    HRESULT hr = SHGetFolderPathW(
        NULL,
        CSIDL_APPDATA,
        NULL,
        SHGFP_TYPE_CURRENT,
        app_data_path
    );
    
    if (FAILED(hr)) {
        return LACKY_ERROR_STORAGE_INIT;
    }
    
    /* Create LackyVault directory */
    wcscat_s(app_data_path, MAX_PATH, L"\\LackyVault");
    CreateDirectoryW(app_data_path, NULL);
    
    /* Store path */
    WideCharToMultiByte(
        CP_UTF8, 0,
        app_data_path, -1,
        app->storage.data_directory,
        sizeof(app->storage.data_directory),
        NULL, NULL
    );
    
    app->storage.initialized = 1;
    return LACKY_SUCCESS;
}

/**
 * Cleanup storage subsystem
 */
void lacky_storage_cleanup(lacky_app_t* app) {
    if (!app || !app->storage.initialized) {
        return;
    }
    
    /* Clear sensitive data */
    lacky_secure_zero(app->storage.data_directory, sizeof(app->storage.data_directory));
    app->storage.initialized = 0;
}

/**
 * Create wallet file
 */
lacky_error_t lacky_storage_create_wallet(
    lacky_app_t* app,
    const char* wallet_name,
    const uint8_t* encrypted_data,
    size_t data_size
) {
    if (!app || !wallet_name || !encrypted_data || data_size == 0) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    /* Build wallet file path */
    char wallet_path[MAX_PATH];
    snprintf(wallet_path, sizeof(wallet_path), "%s\\%s.wallet", 
             app->storage.data_directory, wallet_name);
    
    /* Create file */
    HANDLE file = CreateFileA(
        wallet_path,
        GENERIC_WRITE,
        0,
        NULL,
        CREATE_NEW,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );
    
    if (file == INVALID_HANDLE_VALUE) {
        return LACKY_ERROR_STORAGE_CREATE;
    }
    
    /* Write encrypted data */
    DWORD bytes_written;
    BOOL result = WriteFile(
        file,
        encrypted_data,
        (DWORD)data_size,
        &bytes_written,
        NULL
    );
    
    CloseHandle(file);
    
    if (!result || bytes_written != data_size) {
        DeleteFileA(wallet_path);
        return LACKY_ERROR_STORAGE_WRITE;
    }
    
    return LACKY_SUCCESS;
}

/**
 * Load wallet file
 */
lacky_error_t lacky_storage_load_wallet(
    lacky_app_t* app,
    const char* wallet_name,
    uint8_t** encrypted_data,
    size_t* data_size
) {
    if (!app || !wallet_name || !encrypted_data || !data_size) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    /* Build wallet file path */
    char wallet_path[MAX_PATH];
    snprintf(wallet_path, sizeof(wallet_path), "%s\\%s.wallet", 
             app->storage.data_directory, wallet_name);
    
    /* Open file */
    HANDLE file = CreateFileA(
        wallet_path,
        GENERIC_READ,
        FILE_SHARE_READ,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );
    
    if (file == INVALID_HANDLE_VALUE) {
        return LACKY_ERROR_STORAGE_NOT_FOUND;
    }
    
    /* Get file size */
    LARGE_INTEGER file_size;
    if (!GetFileSizeEx(file, &file_size)) {
        CloseHandle(file);
        return LACKY_ERROR_STORAGE_READ;
    }
    
    if (file_size.QuadPart > LACKY_MAX_WALLET_SIZE) {
        CloseHandle(file);
        return LACKY_ERROR_STORAGE_TOO_LARGE;
    }
    
    /* Allocate buffer */
    *data_size = (size_t)file_size.QuadPart;
    *encrypted_data = (uint8_t*)lacky_secure_alloc(*data_size);
    if (!*encrypted_data) {
        CloseHandle(file);
        return LACKY_ERROR_MEMORY;
    }
    
    /* Read file */
    DWORD bytes_read;
    BOOL result = ReadFile(
        file,
        *encrypted_data,
        (DWORD)*data_size,
        &bytes_read,
        NULL
    );
    
    CloseHandle(file);
    
    if (!result || bytes_read != *data_size) {
        lacky_secure_free(*encrypted_data, *data_size);
        *encrypted_data = NULL;
        *data_size = 0;
        return LACKY_ERROR_STORAGE_READ;
    }
    
    return LACKY_SUCCESS;
}

/**
 * Delete wallet file
 */
lacky_error_t lacky_storage_delete_wallet(lacky_app_t* app, const char* wallet_name) {
    if (!app || !wallet_name) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    /* Build wallet file path */
    char wallet_path[MAX_PATH];
    snprintf(wallet_path, sizeof(wallet_path), "%s\\%s.wallet", 
             app->storage.data_directory, wallet_name);
    
    /* Delete file */
    if (!DeleteFileA(wallet_path)) {
        return LACKY_ERROR_STORAGE_DELETE;
    }
    
    return LACKY_SUCCESS;
}

/**
 * List available wallets
 */
lacky_error_t lacky_storage_list_wallets(lacky_app_t* app, char*** wallet_names, size_t* count) {
    if (!app || !wallet_names || !count) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    /* Search for .wallet files */
    char search_pattern[MAX_PATH];
    snprintf(search_pattern, sizeof(search_pattern), "%s\\*.wallet", app->storage.data_directory);
    
    WIN32_FIND_DATAA find_data;
    HANDLE find_handle = FindFirstFileA(search_pattern, &find_data);
    
    if (find_handle == INVALID_HANDLE_VALUE) {
        *wallet_names = NULL;
        *count = 0;
        return LACKY_SUCCESS;
    }
    
    /* Count files first */
    size_t file_count = 0;
    do {
        if (!(find_data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
            file_count++;
        }
    } while (FindNextFileA(find_handle, &find_data));
    
    FindClose(find_handle);
    
    if (file_count == 0) {
        *wallet_names = NULL;
        *count = 0;
        return LACKY_SUCCESS;
    }
    
    /* Allocate array */
    char** names = (char**)calloc(file_count, sizeof(char*));
    if (!names) {
        return LACKY_ERROR_MEMORY;
    }
    
    /* Collect names */
    find_handle = FindFirstFileA(search_pattern, &find_data);
    size_t index = 0;
    
    do {
        if (!(find_data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
            /* Remove .wallet extension */
            char* ext = strrchr(find_data.cFileName, '.');
            if (ext) *ext = '\0';
            
            names[index] = _strdup(find_data.cFileName);
            if (!names[index]) {
                /* Cleanup on error */
                for (size_t i = 0; i < index; i++) {
                    free(names[i]);
                }
                free(names);
                FindClose(find_handle);
                return LACKY_ERROR_MEMORY;
            }
            index++;
        }
    } while (FindNextFileA(find_handle, &find_data) && index < file_count);
    
    FindClose(find_handle);
    
    *wallet_names = names;
    *count = index;
    return LACKY_SUCCESS;
}

/**
 * Free wallet names list
 */
void lacky_storage_free_wallet_list(char** wallet_names, size_t count) {
    if (!wallet_names) {
        return;
    }
    
    for (size_t i = 0; i < count; i++) {
        if (wallet_names[i]) {
            free(wallet_names[i]);
        }
    }
    free(wallet_names);
}
