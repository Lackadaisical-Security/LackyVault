/**
 * LackyVault - Win32 Window Management
 * Lackadaisical Security
 * 
 * Main window procedure and UI event handling
 */

#include "../../../include/lacky_vault.h"
#include "../../../include/lacky_crypto.h"
#include <commctrl.h>

/* Window class name */
#define LACKY_WINDOW_CLASS L"LackyVaultWindow"

/* Window procedure forward declaration */
static LRESULT CALLBACK lacky_window_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);

/* UI Message Handlers */
static LRESULT handle_create(HWND hwnd, WPARAM wparam, LPARAM lparam);
static LRESULT handle_paint(HWND hwnd, WPARAM wparam, LPARAM lparam);
static LRESULT handle_size(HWND hwnd, WPARAM wparam, LPARAM lparam);
static LRESULT handle_command(HWND hwnd, WPARAM wparam, LPARAM lparam);
static LRESULT handle_keydown(HWND hwnd, WPARAM wparam, LPARAM lparam);
static LRESULT handle_close(HWND hwnd, WPARAM wparam, LPARAM lparam);
static LRESULT handle_destroy(HWND hwnd, WPARAM wparam, LPARAM lparam);

/* Panic mode hotkey combination (Ctrl+Shift+Alt+P) */
#define LACKY_PANIC_HOTKEY_ID 1
#define LACKY_PANIC_MODIFIERS (MOD_CONTROL | MOD_SHIFT | MOD_ALT)
#define LACKY_PANIC_KEY 'P'

/**
 * Register the window class
 */
lacky_error_t lacky_window_register_class(HINSTANCE hinstance) {
    WNDCLASSEXW wc = {0};
    
    wc.cbSize = sizeof(WNDCLASSEXW);
    wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
    wc.lpfnWndProc = lacky_window_proc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = sizeof(lacky_app_t*);  // Store app pointer
    wc.hInstance = hinstance;
    wc.hIcon = LoadIcon(hinstance, MAKEINTRESOURCE(101));  // Main icon
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = CreateSolidBrush(RGB(0, 0, 0));  // Black background
    wc.lpszMenuName = NULL;
    wc.lpszClassName = LACKY_WINDOW_CLASS;
    wc.hIconSm = LoadIcon(hinstance, MAKEINTRESOURCE(102));  // Small icon
    
    if (!RegisterClassExW(&wc)) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    return LACKY_SUCCESS;
}

/**
 * Create the main window
 */
lacky_error_t lacky_window_create(lacky_app_t* app) {
    if (!app) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    /* Calculate window position (center on screen) */
    int screen_width = GetSystemMetrics(SM_CXSCREEN);
    int screen_height = GetSystemMetrics(SM_CYSCREEN);
    int window_x = (screen_width - LACKY_WINDOW_WIDTH) / 2;
    int window_y = (screen_height - LACKY_WINDOW_HEIGHT) / 2;
    
    /* Create main window */
    app->main_window = CreateWindowExW(
        WS_EX_APPWINDOW | WS_EX_WINDOWEDGE,
        LACKY_WINDOW_CLASS,
        L"LackyVault - Lackadaisical Security",
        WS_OVERLAPPEDWINDOW,
        window_x, window_y,
        LACKY_WINDOW_WIDTH, LACKY_WINDOW_HEIGHT,
        NULL,
        NULL,
        app->hinstance,
        app  // Pass app pointer to window proc
    );
    
    if (!app->main_window) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    /* Register panic hotkey */
    RegisterHotKey(app->main_window, LACKY_PANIC_HOTKEY_ID, LACKY_PANIC_MODIFIERS, LACKY_PANIC_KEY);
    
    /* Show window */
    ShowWindow(app->main_window, SW_SHOW);
    UpdateWindow(app->main_window);
    
    return LACKY_SUCCESS;
}

/**
 * Toggle fullscreen mode
 */
void lacky_window_toggle_fullscreen(HWND hwnd) {
    static WINDOWPLACEMENT prev_placement = {sizeof(WINDOWPLACEMENT)};
    static bool is_fullscreen = false;
    
    if (!is_fullscreen) {
        /* Save current window state */
        GetWindowPlacement(hwnd, &prev_placement);
        
        /* Go fullscreen */
        SetWindowLongPtr(hwnd, GWL_STYLE, WS_POPUP | WS_VISIBLE);
        SetWindowPos(hwnd, HWND_TOP, 0, 0, 
                    GetSystemMetrics(SM_CXSCREEN), 
                    GetSystemMetrics(SM_CYSCREEN),
                    SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
        is_fullscreen = true;
    } else {
        /* Restore windowed mode */
        SetWindowLongPtr(hwnd, GWL_STYLE, WS_OVERLAPPEDWINDOW | WS_VISIBLE);
        SetWindowPlacement(hwnd, &prev_placement);
        SetWindowPos(hwnd, NULL, 0, 0, 0, 0,
                    SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER |
                    SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
        is_fullscreen = false;
    }
}

/**
 * Show about dialog
 */
void lacky_show_about_dialog(HWND parent) {
    MessageBoxW(parent,
               L"LackyVault v1.0.0\n"
               L"Lackadaisical Security\n\n"
               L"Zero-trust crypto wallet with custom primitives.\n"
               L"Built with x86-64 ASM and C, using only Win32 API.",
               L"About LackyVault",
               MB_OK | MB_ICONINFORMATION);
}

/**
 * Main window procedure
 */
static LRESULT CALLBACK lacky_window_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    lacky_app_t* app = NULL;
    
    if (msg == WM_NCCREATE) {
        /* Store app pointer in window data */
        CREATESTRUCT* cs = (CREATESTRUCT*)lparam;
        app = (lacky_app_t*)cs->lpCreateParams;
        SetWindowLongPtr(hwnd, GWLP_USERDATA, (LONG_PTR)app);
    } else {
        /* Retrieve app pointer */
        app = (lacky_app_t*)GetWindowLongPtr(hwnd, GWLP_USERDATA);
    }
    
    switch (msg) {
        case WM_CREATE:
            return handle_create(hwnd, wparam, lparam);
            
        case WM_PAINT:
            return handle_paint(hwnd, wparam, lparam);
            
        case WM_SIZE:
            return handle_size(hwnd, wparam, lparam);
            
        case WM_COMMAND:
            return handle_command(hwnd, wparam, lparam);
            
        case WM_KEYDOWN:
            return handle_keydown(hwnd, wparam, lparam);
            
        case WM_HOTKEY:
            if (wparam == LACKY_PANIC_HOTKEY_ID && app) {
                lacky_panic_mode(app);
                return 0;
            }
            break;
            
        case WM_CLOSE:
            return handle_close(hwnd, wparam, lparam);
            
        case WM_DESTROY:
            return handle_destroy(hwnd, wparam, lparam);
            
        default:
            return DefWindowProcW(hwnd, msg, wparam, lparam);
    }
    
    return DefWindowProcW(hwnd, msg, wparam, lparam);
}

/**
 * Handle WM_CREATE
 */
static LRESULT handle_create(HWND hwnd, WPARAM wparam, LPARAM lparam) {
    LACKY_UNUSED(wparam);
    
    lacky_app_t* app = (lacky_app_t*)((CREATESTRUCT*)lparam)->lpCreateParams;
    if (app) {
        /* Initialize theme system */
        lacky_theme_init(app);
        
        /* Create initial controls based on state */
        lacky_controls_create_for_state(hwnd, app->current_state);
    }
    
    return 0;
}

/**
 * Handle WM_PAINT
 */
static LRESULT handle_paint(HWND hwnd, WPARAM wparam, LPARAM lparam) {
    LACKY_UNUSED(wparam);
    LACKY_UNUSED(lparam);
    
    PAINTSTRUCT ps;
    HDC hdc = BeginPaint(hwnd, &ps);
    
    lacky_app_t* app = (lacky_app_t*)GetWindowLongPtr(hwnd, GWLP_USERDATA);
    if (app) {
        /* Render based on current state */
        switch (app->current_state) {
            case LACKY_STATE_SPLASH:
                lacky_theme_render_splash(hdc, &ps.rcPaint, app);
                break;
                
            case LACKY_STATE_AUTH:
                lacky_theme_render_auth_screen(hdc, &ps.rcPaint, app);
                break;
                
            case LACKY_STATE_MAIN:
                lacky_theme_render_main_interface(hdc, &ps.rcPaint, app);
                break;
                
            case LACKY_STATE_TRANSACTION:
                lacky_theme_render_transaction_screen(hdc, &ps.rcPaint, app);
                break;
                
            case LACKY_STATE_SETTINGS:
                lacky_theme_render_settings_screen(hdc, &ps.rcPaint, app);
                break;
                
            case LACKY_STATE_PANIC:
                lacky_theme_render_fake_windows_update(hdc, &ps.rcPaint, app);
                break;
                
            default:
                /* Fill with black */
                FillRect(hdc, &ps.rcPaint, (HBRUSH)GetStockObject(BLACK_BRUSH));
                break;
        }
    }
    
    EndPaint(hwnd, &ps);
    return 0;
}

/**
 * Handle WM_SIZE
 */
static LRESULT handle_size(HWND hwnd, WPARAM wparam, LPARAM lparam) {
    LACKY_UNUSED(wparam);
    
    int width = LOWORD(lparam);
    int height = HIWORD(lparam);
    
    lacky_app_t* app = (lacky_app_t*)GetWindowLongPtr(hwnd, GWLP_USERDATA);
    if (app) {
        /* Update theme layout */
        lacky_theme_update_layout(app, width, height);
        
        /* Resize controls */
        lacky_controls_resize_for_state(hwnd, app->current_state, width, height);
    }
    
    return 0;
}

/**
 * Handle WM_COMMAND
 */
static LRESULT handle_command(HWND hwnd, WPARAM wparam, LPARAM lparam) {
    WORD command_id = LOWORD(wparam);
    WORD notification = HIWORD(wparam);
    HWND control_hwnd = (HWND)lparam;
    
    lacky_app_t* app = (lacky_app_t*)GetWindowLongPtr(hwnd, GWLP_USERDATA);
    if (!app) {
        return 0;
    }
    
    /* Delegate to state-specific handlers */
    switch (app->current_state) {
        case LACKY_STATE_AUTH:
            return lacky_auth_handle_command(app, command_id, notification, control_hwnd);
            
        case LACKY_STATE_MAIN:
            return lacky_main_handle_command(app, command_id, notification, control_hwnd);
            
        case LACKY_STATE_TRANSACTION:
            return lacky_transaction_handle_command(app, command_id, notification, control_hwnd);
            
        case LACKY_STATE_SETTINGS:
            return lacky_settings_handle_command(app, command_id, notification, control_hwnd);
            
        default:
            break;
    }
    
    /* Handle global commands */
    switch (command_id) {
        case ID_FILE_EXIT:
            PostMessage(hwnd, WM_CLOSE, 0, 0);
            break;
            
        case ID_SECURITY_PANIC:
            lacky_panic_mode(app);
            break;
            
        case LACKY_BTN_ABOUT:
            lacky_show_about_dialog(hwnd);
            break;
    }
    
    return 0;
}

/**
 * Handle WM_KEYDOWN
 */
static LRESULT handle_keydown(HWND hwnd, WPARAM wparam, LPARAM lparam) {
    LACKY_UNUSED(lparam);
    
    lacky_app_t* app = (lacky_app_t*)GetWindowLongPtr(hwnd, GWLP_USERDATA);
    
    switch (wparam) {
        case VK_F11:
            lacky_window_toggle_fullscreen(hwnd);
            return 0;
            
        case VK_ESCAPE:
            if (app && app->current_state == LACKY_STATE_PANIC) {
                /* Exit panic mode only with special key sequence */
                // TODO: Implement special exit sequence
            }
            break;
    }
    
    return DefWindowProcW(hwnd, WM_KEYDOWN, wparam, lparam);
}

/**
 * Handle WM_CLOSE
 */
static LRESULT handle_close(HWND hwnd, WPARAM wparam, LPARAM lparam) {
    LACKY_UNUSED(wparam);
    LACKY_UNUSED(lparam);
    
    lacky_app_t* app = (lacky_app_t*)GetWindowLongPtr(hwnd, GWLP_USERDATA);
    if (app) {
        /* Check if wallet needs to be saved */
        if (app->active_wallet) {
            int result = MessageBoxW(hwnd,
                L"Do you want to save your wallet before exiting?",
                L"Save Wallet",
                MB_YESNOCANCEL | MB_ICONQUESTION);
                
            if (result == IDCANCEL) {
                return 0; // Don't close
            }
            
            if (result == IDYES) {
                /* TODO: Implement wallet save dialog */
            }
        }
        
        /* Set shutdown flag */
        app->shutdown_requested = true;
    }
    
    DestroyWindow(hwnd);
    return 0;
}

/**
 * Handle WM_DESTROY
 */
static LRESULT handle_destroy(HWND hwnd, WPARAM wparam, LPARAM lparam) {
    LACKY_UNUSED(hwnd);
    LACKY_UNUSED(wparam);
    LACKY_UNUSED(lparam);
    
    /* Unregister panic hotkey */
    UnregisterHotKey(hwnd, LACKY_PANIC_HOTKEY_ID);
    
    PostQuitMessage(0);
    return 0;
}
