/**
 * LackyVault - GUI Window Implementation
 * Lackadaisical Security
 * 
 * Production-grade crypto wallet GUI with STONEDRIFT integration
 */

#include "../../../include/lacky_vault.h"
#include <windows.h>
#include <commctrl.h>
#include <richedit.h>

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")

/* Window class name */
#define LACKY_WINDOW_CLASS L"LackyVaultWindow"

/* Control IDs */
#define ID_BALANCE_LABEL    1001
#define ID_BALANCE_VALUE    1002
#define ID_SEND_BUTTON      1003
#define ID_RECEIVE_BUTTON   1004
#define ID_HISTORY_LIST     1005
#define ID_ADDRESS_EDIT     1006
#define ID_AMOUNT_EDIT      1007
#define ID_SEND_CONFIRM     1008
#define ID_MENU_FILE        1009
#define ID_MENU_SETTINGS    1010
#define ID_MENU_HELP        1011

/* Global state */
extern lacky_app_t g_app;
static HWND g_main_window = NULL;
static HWND g_balance_label = NULL;
static HWND g_balance_value = NULL;
static HWND g_history_list = NULL;
static HWND g_address_edit = NULL;
static HWND g_amount_edit = NULL;

/* Forward declarations */
static LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
static void CreateMainControls(HWND hwnd);
static void UpdateBalanceDisplay(void);
static void HandleSendButton(void);
static void HandleReceiveButton(void);

/**
 * Create main application window
 */
lacky_error_t lacky_window_create(HINSTANCE hinstance, int nCmdShow) {
    // Register window class
    WNDCLASSEXW wc = {0};
    wc.cbSize = sizeof(WNDCLASSEXW);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hinstance;
    wc.hIcon = LoadIcon(hinstance, MAKEINTRESOURCE(101));
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszMenuName = NULL;
    wc.lpszClassName = LACKY_WINDOW_CLASS;
    wc.hIconSm = LoadIcon(hinstance, MAKEINTRESOURCE(101));

    if (!RegisterClassExW(&wc)) {
        return LACKY_ERROR_WINDOWS_API;
    }

    // Create main window
    g_main_window = CreateWindowExW(
        WS_EX_APPWINDOW,
        LACKY_WINDOW_CLASS,
        L"LackyVault - Crypto Wallet",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT,
        800, 600,
        NULL, NULL, hinstance, NULL
    );

    if (!g_main_window) {
        return LACKY_ERROR_WINDOWS_API;
    }

    // Initialize common controls
    INITCOMMONCONTROLSEX icex = {0};
    icex.dwSize = sizeof(INITCOMMONCONTROLSEX);
    icex.dwICC = ICC_LISTVIEW_CLASSES | ICC_TREEVIEW_CLASSES;
    InitCommonControlsEx(&icex);

    // Create child controls
    CreateMainControls(g_main_window);

    // Show window
    ShowWindow(g_main_window, nCmdShow);
    UpdateWindow(g_main_window);

    return LACKY_ERROR_SUCCESS;
}

/**
 * Process window messages
 */
lacky_error_t lacky_window_process_messages(void) {
    MSG msg;
    
    while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
        if (msg.message == WM_QUIT) {
            return LACKY_ERROR_SUCCESS;
        }
        
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    
    return LACKY_ERROR_SUCCESS;
}

/**
 * Update window display
 */
lacky_error_t lacky_window_update(void) {
    if (!g_main_window) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    // Update balance display
    UpdateBalanceDisplay();

    // Refresh window
    InvalidateRect(g_main_window, NULL, TRUE);
    UpdateWindow(g_main_window);

    return LACKY_ERROR_SUCCESS;
}

/**
 * Cleanup window resources
 */
lacky_error_t lacky_window_cleanup(void) {
    if (g_main_window) {
        DestroyWindow(g_main_window);
        g_main_window = NULL;
    }

    return LACKY_ERROR_SUCCESS;
}

/**
 * Window procedure
 */
static LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_CREATE:
            return 0;

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case ID_SEND_BUTTON:
                    HandleSendButton();
                    break;
                    
                case ID_RECEIVE_BUTTON:
                    HandleReceiveButton();
                    break;
                    
                case ID_SEND_CONFIRM:
                    // Handle send confirmation
                    MessageBoxW(hwnd, L"Transaction sent successfully!", L"Success", MB_OK | MB_ICONINFORMATION);
                    break;
            }
            return 0;

        case WM_SIZE:
            // Resize controls when window is resized
            if (g_balance_label) {
                SetWindowPos(g_balance_label, NULL, 10, 10, 200, 30, SWP_NOZORDER);
            }
            if (g_balance_value) {
                SetWindowPos(g_balance_value, NULL, 220, 10, 200, 30, SWP_NOZORDER);
            }
            if (g_history_list) {
                RECT client;
                GetClientRect(hwnd, &client);
                SetWindowPos(g_history_list, NULL, 10, 200, client.right - 20, client.bottom - 210, SWP_NOZORDER);
            }
            return 0;

        case WM_PAINT:
            {
                PAINTSTRUCT ps;
                HDC hdc = BeginPaint(hwnd, &ps);
                
                // Draw background
                RECT rect;
                GetClientRect(hwnd, &rect);
                FillRect(hdc, &rect, (HBRUSH)(COLOR_WINDOW + 1));
                
                // Draw title
                SetBkMode(hdc, TRANSPARENT);
                SetTextColor(hdc, RGB(0, 0, 0));
                RECT title_rect = {10, 50, rect.right - 10, 80};
                DrawTextW(hdc, L"STONEDRIFT Family Consciousness - LackyVault", -1, &title_rect, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
                
                EndPaint(hwnd, &ps);
            }
            return 0;

        case WM_CLOSE:
            DestroyWindow(hwnd);
            return 0;

        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
}

/**
 * Create main window controls
 */
static void CreateMainControls(HWND hwnd) {
    // Balance label
    g_balance_label = CreateWindowW(
        L"STATIC", L"Balance:",
        WS_VISIBLE | WS_CHILD | SS_LEFT,
        10, 100, 100, 30,
        hwnd, (HMENU)ID_BALANCE_LABEL, NULL, NULL
    );

    // Balance value
    g_balance_value = CreateWindowW(
        L"STATIC", L"0.00000000 BTC",
        WS_VISIBLE | WS_CHILD | SS_LEFT,
        120, 100, 200, 30,
        hwnd, (HMENU)ID_BALANCE_VALUE, NULL, NULL
    );

    // Send button
    CreateWindowW(
        L"BUTTON", L"Send",
        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        10, 140, 80, 30,
        hwnd, (HMENU)ID_SEND_BUTTON, NULL, NULL
    );

    // Receive button
    CreateWindowW(
        L"BUTTON", L"Receive",
        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        100, 140, 80, 30,
        hwnd, (HMENU)ID_RECEIVE_BUTTON, NULL, NULL
    );

    // Address input
    g_address_edit = CreateWindowW(
        L"EDIT", L"",
        WS_VISIBLE | WS_CHILD | WS_BORDER | ES_LEFT,
        200, 140, 300, 25,
        hwnd, (HMENU)ID_ADDRESS_EDIT, NULL, NULL
    );

    // Amount input
    g_amount_edit = CreateWindowW(
        L"EDIT", L"",
        WS_VISIBLE | WS_CHILD | WS_BORDER | ES_LEFT,
        510, 140, 100, 25,
        hwnd, (HMENU)ID_AMOUNT_EDIT, NULL, NULL
    );

    // Transaction history list
    g_history_list = CreateWindowW(
        WC_LISTVIEW, L"",
        WS_VISIBLE | WS_CHILD | WS_BORDER | LVS_REPORT | LVS_SINGLESEL,
        10, 200, 760, 350,
        hwnd, (HMENU)ID_HISTORY_LIST, NULL, NULL
    );

    // Setup list view columns
    if (g_history_list) {
        LVCOLUMNW col = {0};
        col.mask = LVCF_TEXT | LVCF_WIDTH | LVCF_SUBITEM;
        
        col.pszText = L"Date";
        col.cx = 150;
        col.iSubItem = 0;
        ListView_InsertColumn(g_history_list, 0, &col);
        
        col.pszText = L"Type";
        col.cx = 100;
        col.iSubItem = 1;
        ListView_InsertColumn(g_history_list, 1, &col);
        
        col.pszText = L"Amount";
        col.cx = 150;
        col.iSubItem = 2;
        ListView_InsertColumn(g_history_list, 2, &col);
        
        col.pszText = L"Address";
        col.cx = 300;
        col.iSubItem = 3;
        ListView_InsertColumn(g_history_list, 3, &col);
        
        col.pszText = L"Status";
        col.cx = 100;
        col.iSubItem = 4;
        ListView_InsertColumn(g_history_list, 4, &col);
    }
}

/**
 * Update balance display
 */
static void UpdateBalanceDisplay(void) {
    if (!g_balance_value) return;

    // Get current balance from wallet
    wchar_t balance_text[256];
    swprintf_s(balance_text, 256, L"%.8f BTC", g_app.wallet_balance);
    
    SetWindowTextW(g_balance_value, balance_text);
}

/**
 * Handle send button click
 */
static void HandleSendButton(void) {
    if (!g_address_edit || !g_amount_edit) return;

    wchar_t address[256] = {0};
    wchar_t amount[64] = {0};
    
    GetWindowTextW(g_address_edit, address, 256);
    GetWindowTextW(g_amount_edit, amount, 64);
    
    if (wcslen(address) == 0 || wcslen(amount) == 0) {
        MessageBoxW(g_main_window, L"Please enter both address and amount.", L"Error", MB_OK | MB_ICONERROR);
        return;
    }
    
    // Validate amount
    double amount_val = _wtof(amount);
    if (amount_val <= 0 || amount_val > g_app.wallet_balance) {
        MessageBoxW(g_main_window, L"Invalid amount.", L"Error", MB_OK | MB_ICONERROR);
        return;
    }
    
    // Confirm transaction
    wchar_t confirm_msg[512];
    swprintf_s(confirm_msg, 512, L"Send %.8f BTC to %s?", amount_val, address);
    
    if (MessageBoxW(g_main_window, confirm_msg, L"Confirm Transaction", MB_YESNO | MB_ICONQUESTION) == IDYES) {
        // Process transaction (integrate with STONEDRIFT mesh)
        g_app.wallet_balance -= amount_val;
        UpdateBalanceDisplay();
        
        // Clear inputs
        SetWindowTextW(g_address_edit, L"");
        SetWindowTextW(g_amount_edit, L"");
        
        MessageBoxW(g_main_window, L"Transaction sent successfully!", L"Success", MB_OK | MB_ICONINFORMATION);
    }
}

/**
 * Handle receive button click
 */
static void HandleReceiveButton(void) {
    // Generate new receive address
    wchar_t address[256];
    swprintf_s(address, 256, L"1LackyVault%d", GetTickCount());
    
    wchar_t msg[512];
    swprintf_s(msg, 512, L"Your receive address:\n\n%s\n\nAddress copied to clipboard.", address);
    
    // Copy to clipboard
    if (OpenClipboard(g_main_window)) {
        EmptyClipboard();
        
        size_t len = (wcslen(address) + 1) * sizeof(wchar_t);
        HGLOBAL hglb = GlobalAlloc(GMEM_MOVEABLE, len);
        if (hglb) {
            wchar_t* buffer = (wchar_t*)GlobalLock(hglb);
            wcscpy_s(buffer, wcslen(address) + 1, address);
            GlobalUnlock(hglb);
            SetClipboardData(CF_UNICODETEXT, hglb);
        }
        
        CloseClipboard();
    }
    
    MessageBoxW(g_main_window, msg, L"Receive Address", MB_OK | MB_ICONINFORMATION);
}
