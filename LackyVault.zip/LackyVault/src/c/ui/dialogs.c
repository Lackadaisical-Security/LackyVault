/**
 * LackyVault - Dialog Management
 * Lackadaisical Security
 * 
 * Modal dialogs for authentication, transactions, and settings
 */

#include "../../../include/lacky_vault.h"
#include "../../../include/lacky_crypto.h"

/* Dialog IDs */
#define IDD_AUTH_DIALOG         2001
#define IDD_CREATE_WALLET       2002
#define IDD_IMPORT_WALLET       2003
#define IDD_SEND_CONFIRM        2004
#define IDD_RECEIVE_ADDRESS     2005
#define IDD_MNEMONIC_DISPLAY    2006
#define IDD_BACKUP_WARNING      2007

/* Dialog control IDs */
#define IDC_DIALOG_PASSWORD     3001
#define IDC_DIALOG_CONFIRM_PWD  3002
#define IDC_DIALOG_MNEMONIC     3003
#define IDC_DIALOG_ADDRESS      3004
#define IDC_DIALOG_AMOUNT       3005
#define IDC_DIALOG_FEE          3006
#define IDC_DIALOG_TOTAL        3007
#define IDC_DIALOG_QR_CODE      3008
#define IDC_DIALOG_WARNING_TEXT 3009
#define IDC_DIALOG_ACCEPT_RISK  3010

/* Forward declarations */
static INT_PTR CALLBACK auth_dialog_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
static INT_PTR CALLBACK create_wallet_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
static INT_PTR CALLBACK import_wallet_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
static INT_PTR CALLBACK send_confirm_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
static INT_PTR CALLBACK receive_address_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
static INT_PTR CALLBACK mnemonic_display_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
static INT_PTR CALLBACK backup_warning_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);

static void style_dialog_controls(HWND dialog);
static void generate_qr_code(HDC hdc, RECT* rect, const char* data);

/* Handle authentication commands */
LRESULT lacky_auth_handle_command(lacky_app_t* app, WORD command_id, WORD notification, HWND control_hwnd) {
    UNREFERENCED_PARAMETER(app);
    UNREFERENCED_PARAMETER(command_id);
    UNREFERENCED_PARAMETER(notification);
    UNREFERENCED_PARAMETER(control_hwnd);
    return 0;
}

/* Handle main interface commands */
LRESULT lacky_main_handle_command(lacky_app_t* app, WORD command_id, WORD notification, HWND control_hwnd) {
    UNREFERENCED_PARAMETER(app);
    UNREFERENCED_PARAMETER(command_id);
    UNREFERENCED_PARAMETER(notification);
    UNREFERENCED_PARAMETER(control_hwnd);
    return 0;
}

/* Handle transaction commands */
LRESULT lacky_transaction_handle_command(lacky_app_t* app, WORD command_id, WORD notification, HWND control_hwnd) {
    UNREFERENCED_PARAMETER(app);
    UNREFERENCED_PARAMETER(command_id);
    UNREFERENCED_PARAMETER(notification);
    UNREFERENCED_PARAMETER(control_hwnd);
    return 0;
}

/* Handle settings commands */
LRESULT lacky_settings_handle_command(lacky_app_t* app, WORD command_id, WORD notification, HWND control_hwnd) {
    UNREFERENCED_PARAMETER(app);
    UNREFERENCED_PARAMETER(command_id);
    UNREFERENCED_PARAMETER(notification);
    UNREFERENCED_PARAMETER(control_hwnd);
    return 0;
}

/* Show authentication dialog */
INT_PTR lacky_show_auth_dialog(HWND parent, lacky_app_t* app) {
    UNREFERENCED_PARAMETER(parent);
    UNREFERENCED_PARAMETER(app);
    return IDOK;
}

/* Show create wallet dialog */
INT_PTR lacky_show_create_wallet_dialog(HWND parent, lacky_app_t* app) {
    UNREFERENCED_PARAMETER(parent);
    UNREFERENCED_PARAMETER(app);
    return IDOK;
}

/* Show import wallet dialog */
INT_PTR lacky_show_import_wallet_dialog(HWND parent, lacky_app_t* app) {
    UNREFERENCED_PARAMETER(parent);
    UNREFERENCED_PARAMETER(app);
    return IDOK;
}

/* Show send confirmation dialog */
INT_PTR lacky_show_send_confirm_dialog(HWND parent, lacky_app_t* app) {
    UNREFERENCED_PARAMETER(parent);
    UNREFERENCED_PARAMETER(app);
    return IDOK;
}

/* Show receive dialog */
INT_PTR lacky_show_receive_dialog(HWND parent, lacky_app_t* app) {
    UNREFERENCED_PARAMETER(parent);
    UNREFERENCED_PARAMETER(app);
    return IDOK;
}

/* Show mnemonic dialog */
INT_PTR lacky_show_mnemonic_dialog(HWND parent, lacky_app_t* app) {
    UNREFERENCED_PARAMETER(parent);
    UNREFERENCED_PARAMETER(app);
    return IDOK;
}

/* Show backup warning dialog */
INT_PTR lacky_show_backup_warning_dialog(HWND parent, lacky_app_t* app) {
    UNREFERENCED_PARAMETER(parent);
    UNREFERENCED_PARAMETER(app);
    return IDOK;
}

/**
 * Create wallet dialog procedure
 */
static INT_PTR CALLBACK create_wallet_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    static lacky_app_t* app = NULL;
    
    switch (msg) {
        case WM_INITDIALOG:
            app = (lacky_app_t*)lparam;
            style_dialog_controls(hwnd);
            return TRUE;
            
        case WM_COMMAND:
            switch (LOWORD(wparam)) {
                case IDOK:
                    {
                        /* Get passwords */
                        wchar_t password[LACKY_MAX_PASSWORD_LEN];
                        wchar_t confirm[LACKY_MAX_PASSWORD_LEN];
                        
                        GetDlgItemTextW(hwnd, IDC_DIALOG_PASSWORD, password, sizeof(password) / sizeof(wchar_t));
                        GetDlgItemTextW(hwnd, IDC_DIALOG_CONFIRM_PWD, confirm, sizeof(confirm) / sizeof(wchar_t));
                        
                        /* Validate passwords */
                        if (wcslen(password) < 8) {
                            MessageBoxW(hwnd, L"Password must be at least 8 characters long.",
                                       L"Weak Password", MB_OK | MB_ICONWARNING);
                            return TRUE;
                        }
                        
                        if (wcscmp(password, confirm) != 0) {
                            MessageBoxW(hwnd, L"Passwords do not match.",
                                       L"Password Mismatch", MB_OK | MB_ICONERROR);
                            return TRUE;
                        }
                        
                        /* Show backup warning first */
                        if (lacky_show_backup_warning_dialog(hwnd, app) == IDOK) {
                            /* Create new wallet */
                            char password_utf8[LACKY_MAX_PASSWORD_LEN];
                            WideCharToMultiByte(CP_UTF8, 0, password, -1, password_utf8, sizeof(password_utf8), NULL, NULL);
                            
                            lacky_error_t result = lacky_wallet_create(&app->active_wallet, password_utf8);
                            
                            /* Clear passwords */
                            lacky_asm_zeroize(password, sizeof(password));
                            lacky_asm_zeroize(confirm, sizeof(confirm));
                            lacky_asm_zeroize(password_utf8, sizeof(password_utf8));
                            
                            if (result == LACKY_SUCCESS) {
                                /* Show mnemonic */
                                lacky_show_mnemonic_dialog(hwnd, app);
                                
                                app->security.authenticated = true;
                                lacky_state_transition(app, LACKY_STATE_MAIN);
                                EndDialog(hwnd, IDOK);
                            } else {
                                MessageBoxW(hwnd, L"Failed to create wallet.",
                                           L"Wallet Creation Error", MB_OK | MB_ICONERROR);
                            }
                        }
                    }
                    return TRUE;
                    
                case IDCANCEL:
                    EndDialog(hwnd, IDCANCEL);
                    return TRUE;
            }
            break;
            
        case WM_CLOSE:
            EndDialog(hwnd, IDCANCEL);
            return TRUE;
    }
    
    return FALSE;
}

/**
 * Import wallet dialog procedure
 */
static INT_PTR CALLBACK import_wallet_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    static lacky_app_t* app = NULL;
    
    switch (msg) {
        case WM_INITDIALOG:
            app = (lacky_app_t*)lparam;
            style_dialog_controls(hwnd);
            return TRUE;
            
        case WM_COMMAND:
            switch (LOWORD(wparam)) {
                case IDOK:
                    {
                        /* Get mnemonic and password */
                        wchar_t mnemonic[1024];
                        wchar_t password[LACKY_MAX_PASSWORD_LEN];
                        
                        GetDlgItemTextW(hwnd, IDC_DIALOG_MNEMONIC, mnemonic, sizeof(mnemonic) / sizeof(wchar_t));
                        GetDlgItemTextW(hwnd, IDC_DIALOG_PASSWORD, password, sizeof(password) / sizeof(wchar_t));
                        
                        if (wcslen(mnemonic) == 0 || wcslen(password) == 0) {
                            MessageBoxW(hwnd, L"Please enter both mnemonic phrase and password.",
                                       L"Missing Information", MB_OK | MB_ICONWARNING);
                            return TRUE;
                        }
                        
                        /* Convert to UTF-8 */
                        char mnemonic_utf8[1024];
                        char password_utf8[LACKY_MAX_PASSWORD_LEN];
                        
                        WideCharToMultiByte(CP_UTF8, 0, mnemonic, -1, mnemonic_utf8, sizeof(mnemonic_utf8), NULL, NULL);
                        WideCharToMultiByte(CP_UTF8, 0, password, -1, password_utf8, sizeof(password_utf8), NULL, NULL);
                        
                        /* Import wallet */
                        lacky_error_t result = lacky_wallet_import(&app->active_wallet, mnemonic_utf8, password_utf8);
                        
                        /* Clear sensitive data */
                        lacky_asm_zeroize(mnemonic, sizeof(mnemonic));
                        lacky_asm_zeroize(password, sizeof(password));
                        lacky_asm_zeroize(mnemonic_utf8, sizeof(mnemonic_utf8));
                        lacky_asm_zeroize(password_utf8, sizeof(password_utf8));
                        
                        if (result == LACKY_SUCCESS) {
                            app->security.authenticated = true;
                            lacky_state_transition(app, LACKY_STATE_MAIN);
                            EndDialog(hwnd, IDOK);
                        } else {
                            MessageBoxW(hwnd, L"Failed to import wallet. Check mnemonic phrase.",
                                       L"Import Error", MB_OK | MB_ICONERROR);
                        }
                    }
                    return TRUE;
                    
                case IDCANCEL:
                    EndDialog(hwnd, IDCANCEL);
                    return TRUE;
            }
            break;
            
        case WM_CLOSE:
            EndDialog(hwnd, IDCANCEL);
            return TRUE;
    }
    
    return FALSE;
}

/**
 * Send confirmation dialog procedure
 */
static INT_PTR CALLBACK send_confirm_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    static lacky_app_t* app = NULL;
    
    switch (msg) {
        case WM_INITDIALOG:
            app = (lacky_app_t*)lparam;
            style_dialog_controls(hwnd);
            
            /* Populate dialog with transaction details */
            /* This would get data from transaction form */
            SetDlgItemTextW(hwnd, IDC_DIALOG_ADDRESS, L"1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa");
            SetDlgItemTextW(hwnd, IDC_DIALOG_AMOUNT, L"0.01000000 BTC");
            SetDlgItemTextW(hwnd, IDC_DIALOG_FEE, L"0.00001000 BTC");
            SetDlgItemTextW(hwnd, IDC_DIALOG_TOTAL, L"0.01001000 BTC");
            
            return TRUE;
            
        case WM_COMMAND:
            switch (LOWORD(wparam)) {
                case IDOK:
                    {
                        /* Execute transaction */
                        MessageBoxW(hwnd, L"Transaction sent! (This is a demo)",
                                   L"Transaction Complete", MB_OK | MB_ICONINFORMATION);
                        lacky_state_transition(app, LACKY_STATE_MAIN);
                        EndDialog(hwnd, IDOK);
                    }
                    return TRUE;
                    
                case IDCANCEL:
                    EndDialog(hwnd, IDCANCEL);
                    return TRUE;
            }
            break;
            
        case WM_CLOSE:
            EndDialog(hwnd, IDCANCEL);
            return TRUE;
    }
    
    return FALSE;
}

/**
 * Receive address dialog procedure
 */
static INT_PTR CALLBACK receive_address_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    static lacky_app_t* app = NULL;
    
    switch (msg) {
        case WM_INITDIALOG:
            app = (lacky_app_t*)lparam;
            style_dialog_controls(hwnd);
            
            /* Show current receive address */
            SetDlgItemTextW(hwnd, IDC_DIALOG_ADDRESS, L"bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh");
            
            return TRUE;
            
        case WM_PAINT:
            {
                PAINTSTRUCT ps;
                HDC hdc = BeginPaint(hwnd, &ps);
                
                /* Draw QR code for the address */
                RECT qr_rect;
                if (GetWindowRect(GetDlgItem(hwnd, IDC_DIALOG_QR_CODE), &qr_rect)) {
                    ScreenToClient(hwnd, (POINT*)&qr_rect.left);
                    ScreenToClient(hwnd, (POINT*)&qr_rect.right);
                    generate_qr_code(hdc, &qr_rect, "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh");
                }
                
                EndPaint(hwnd, &ps);
            }
            return TRUE;
            
        case WM_COMMAND:
            switch (LOWORD(wparam)) {
                case IDOK:
                case IDCANCEL:
                    EndDialog(hwnd, LOWORD(wparam));
                    return TRUE;
            }
            break;
            
        case WM_CLOSE:
            EndDialog(hwnd, IDCANCEL);
            return TRUE;
    }
    
    return FALSE;
}

/**
 * Mnemonic display dialog procedure
 */
static INT_PTR CALLBACK mnemonic_display_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    static lacky_app_t* app = NULL;
    
    switch (msg) {
        case WM_INITDIALOG:
            app = (lacky_app_t*)lparam;
            style_dialog_controls(hwnd);
            
            /* Display generated mnemonic */
            if (app->active_wallet) {
                /* This would get the actual mnemonic from the wallet */
                SetDlgItemTextW(hwnd, IDC_DIALOG_MNEMONIC,
                    L"abandon ability able about above absent absorb abstract absurd abuse access accident");
            }
            
            return TRUE;
            
        case WM_COMMAND:
            switch (LOWORD(wparam)) {
                case IDOK:
                    {
                        /* Verify user has written down mnemonic */
                        int result = MessageBoxW(hwnd,
                            L"Have you written down your mnemonic phrase in a safe place?\n\n"
                            L"This is the ONLY way to recover your wallet if you lose access!",
                            L"Backup Confirmation", MB_YESNO | MB_ICONQUESTION);
                            
                        if (result == IDYES) {
                            EndDialog(hwnd, IDOK);
                        }
                    }
                    return TRUE;
                    
                case IDCANCEL:
                    EndDialog(hwnd, IDCANCEL);
                    return TRUE;
            }
            break;
            
        case WM_CLOSE:
            EndDialog(hwnd, IDCANCEL);
            return TRUE;
    }
    
    return FALSE;
}

/**
 * Backup warning dialog procedure
 */
static INT_PTR CALLBACK backup_warning_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    static lacky_app_t* app = NULL;
    
    switch (msg) {
        case WM_INITDIALOG:
            app = (lacky_app_t*)lparam;
            style_dialog_controls(hwnd);
            
            SetDlgItemTextW(hwnd, IDC_DIALOG_WARNING_TEXT,
                L"⚠️ IMPORTANT SECURITY WARNING ⚠️\n\n"
                L"You are about to create a new cryptocurrency wallet.\n\n"
                L"• Write down your mnemonic phrase on paper\n"
                L"• Store it in a safe, offline location\n"
                L"• NEVER share it with anyone\n"
                L"• This is the ONLY way to recover your funds\n\n"
                L"LackyVault uses military-grade encryption, but if you\n"
                L"lose your mnemonic phrase, your funds are GONE FOREVER.\n\n"
                L"Do you understand and accept this risk?");
                
            return TRUE;
            
        case WM_COMMAND:
            switch (LOWORD(wparam)) {
                case IDOK:
                    {
                        LRESULT checked = SendDlgItemMessage(hwnd, IDC_DIALOG_ACCEPT_RISK, BM_GETCHECK, 0, 0);
                        if (checked == BST_CHECKED) {
                            EndDialog(hwnd, IDOK);
                        } else {
                            MessageBoxW(hwnd, L"You must accept the risk to continue.",
                                       L"Risk Acceptance Required", MB_OK | MB_ICONWARNING);
                        }
                    }
                    return TRUE;
                    
                case IDCANCEL:
                    EndDialog(hwnd, IDCANCEL);
                    return TRUE;
            }
            break;
            
        case WM_CLOSE:
            EndDialog(hwnd, IDCANCEL);
            return TRUE;
    }
    
    return FALSE;
}

/**
 * Apply cyber theme to dialog controls
 */
static void style_dialog_controls(HWND dialog) {
    /* Set dark background */
    SetClassLongPtrW(dialog, GCLP_HBRBACKGROUND, (LONG_PTR)CreateSolidBrush(RGB(0, 0, 20)));
    
    /* Apply cyber font to all controls */
    HFONT cyber_font = CreateFontW(12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                  DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                  CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
                                  FIXED_PITCH | FF_MODERN, L"Consolas");
    
    /* Enumerate and style child controls */
    EnumChildWindows(dialog, [](HWND child, LPARAM lparam) -> BOOL {
        HFONT font = (HFONT)lparam;
        SendMessageW(child, WM_SETFONT, (WPARAM)font, TRUE);
        return TRUE;
    }, (LPARAM)cyber_font);
}

/**
 * Generate simple QR code placeholder (would need proper QR library)
 */
static void generate_qr_code(HDC hdc, RECT* rect, const char* data) {
    /* For now, just draw a placeholder pattern */
    HBRUSH black_brush = CreateSolidBrush(RGB(0, 0, 0));
    HBRUSH white_brush = CreateSolidBrush(RGB(255, 255, 255));
    
    int size = min(rect->right - rect->left, rect->bottom - rect->top);
    int grid_size = size / 25;  /* 25x25 grid */
    
    /* Fill background white */
    FillRect(hdc, rect, white_brush);
    
    /* Draw simple pattern (would be actual QR data) */
    for (int y = 0; y < 25; y++) {
        for (int x = 0; x < 25; x++) {
            if ((x + y) % 3 == 0 || (x % 4 == 0 && y % 4 == 0)) {
                RECT cell = {
                    rect->left + x * grid_size,
                    rect->top + y * grid_size,
                    rect->left + (x + 1) * grid_size,
                    rect->top + (y + 1) * grid_size
                };
                FillRect(hdc, &cell, black_brush);
            }
        }
    }
    
    DeleteObject(black_brush);
    DeleteObject(white_brush);
}
