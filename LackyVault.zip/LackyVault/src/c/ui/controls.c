/**
 * LackyVault - Custom UI Controls
 * Lackadaisical Security
 * 
 * Custom Win32 controls for wallet interface
 */

#include "../../../include/lacky_vault.h"
#include "../../../include/lacky_crypto.h"
#include <windows.h>
#include <commctrl.h>

/* Additional constants if not defined */
#ifndef BS_CHECKED
#define BS_CHECKED 0x0001L
#endif

/* Control IDs */
#define IDC_PASSWORD_EDIT       1001
#define IDC_LOGIN_BUTTON        1002
#define IDC_CREATE_WALLET_BTN   1003
#define IDC_IMPORT_WALLET_BTN   1004
#define IDC_SEND_BUTTON         1005
#define IDC_RECEIVE_BUTTON      1006
#define IDC_SETTINGS_BUTTON     1007
#define IDC_ADDRESS_EDIT        1008
#define IDC_AMOUNT_EDIT         1009
#define IDC_FEE_COMBO           1010
#define IDC_MEMO_EDIT           1011
#define IDC_SEND_TX_BUTTON      1012
#define IDC_CANCEL_BUTTON       1013
#define IDC_THEME_COMBO         1014
#define IDC_PROXY_EDIT          1015
#define IDC_PANIC_HOTKEY_CHECK  1016
#define IDC_AUTO_LOCK_EDIT      1017

/* Custom control styles */
#define LACKY_BUTTON_STYLE (WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW)
#define LACKY_EDIT_STYLE (WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL)
#define LACKY_COMBO_STYLE (WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST)

/* Forward declarations */
static HWND create_cyber_button(HWND parent, const wchar_t* text, int id, int x, int y, int w, int h);
static HWND create_cyber_edit(HWND parent, int id, int x, int y, int w, int h, bool password);
static HWND create_cyber_combo(HWND parent, int id, int x, int y, int w, int h);
static void draw_cyber_button(HWND hwnd, HDC hdc, RECT* rect, const wchar_t* text, bool pressed);
static LRESULT CALLBACK cyber_button_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
static LRESULT CALLBACK cyber_edit_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
static BOOL CALLBACK destroy_child_proc(HWND hwnd, LPARAM lparam);

/* Missing constants */
#ifndef BS_CHECKED
#define BS_CHECKED 0x0001
#endif

#define IDC_DIALOG_PASSWORD 3001

/* Original window procedures */
static WNDPROC original_button_proc = NULL;
static WNDPROC original_edit_proc = NULL;

/**
 * Helper function to destroy child windows
 */
static BOOL CALLBACK destroy_child_proc(HWND hwnd, LPARAM lparam) {
    UNREFERENCED_PARAMETER(lparam);
    DestroyWindow(hwnd);
    return TRUE;
}

/**
 * Create controls for authentication state
 */
void lacky_controls_create_for_state(HWND parent, lacky_state_t state) {
    /* Remove existing controls first */
    EnumChildWindows(parent, destroy_child_proc, 0);
    
    switch (state) {
        case LACKY_STATE_AUTH:
            lacky_controls_create_auth(parent);
            break;
        case LACKY_STATE_MAIN:
            lacky_controls_create_main(parent);
            break;
        case LACKY_STATE_TRANSACTION:
            lacky_controls_create_transaction(parent);
            break;
        case LACKY_STATE_SETTINGS:
            lacky_controls_create_settings(parent);
            break;
        default:
            break;
    }
}

/**
 * Resize controls for current state
 */
void lacky_controls_resize_for_state(HWND parent, lacky_state_t state, int width, int height) {
    switch (state) {
        case LACKY_STATE_AUTH:
            lacky_controls_resize_auth(parent, width, height);
            break;
        case LACKY_STATE_MAIN:
            lacky_controls_resize_main(parent, width, height);
            break;
        case LACKY_STATE_TRANSACTION:
            lacky_controls_resize_transaction(parent, width, height);
            break;
        case LACKY_STATE_SETTINGS:
            lacky_controls_resize_settings(parent, width, height);
            break;
        default:
            break;
    }
}

/**
 * Create authentication controls
 */
void lacky_controls_create_auth(HWND parent) {
    int center_x = 400; /* Center for 800px window */
    int center_y = 300; /* Center for 600px window */
    
    /* Title */
    CreateWindowW(L"STATIC", L"🔒 LackyVault - Secure Authentication",
                 WS_CHILD | WS_VISIBLE | SS_CENTER,
                 center_x - 200, center_y - 150, 400, 30,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    /* Password label */
    CreateWindowW(L"STATIC", L"Master Password:",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 center_x - 150, center_y - 80, 120, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    /* Password edit */
    create_cyber_edit(parent, IDC_PASSWORD_EDIT, 
                     center_x - 150, center_y - 55, 300, 25, true);
    
    /* Login button */
    create_cyber_button(parent, L"🚀 Unlock Vault", IDC_LOGIN_BUTTON,
                       center_x - 100, center_y - 20, 200, 35);
    
    /* Create new wallet button */
    create_cyber_button(parent, L"⚡ Create New Wallet", IDC_CREATE_WALLET_BTN,
                       center_x - 150, center_y + 30, 140, 30);
    
    /* Import wallet button */
    create_cyber_button(parent, L"📥 Import Wallet", IDC_IMPORT_WALLET_BTN,
                       center_x + 10, center_y + 30, 140, 30);
    
    /* Security status */
    CreateWindowW(L"STATIC", L"🛡️ 15 Security Components Active • Zero Dependencies • Military Grade",
                 WS_CHILD | WS_VISIBLE | SS_CENTER,
                 center_x - 300, center_y + 100, 600, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
}

/**
 * Create main interface controls
 */
void lacky_controls_create_main(HWND parent) {
    /* Balance section */
    CreateWindowW(L"STATIC", L"💰 Wallet Balance",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 20, 20, 200, 25,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    CreateWindowW(L"STATIC", L"0.12345678 BTC",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 20, 45, 300, 35,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    CreateWindowW(L"STATIC", L"≈ $3,456.78 USD",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 20, 75, 200, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    /* Action buttons */
    create_cyber_button(parent, L"💸 Send", IDC_SEND_BUTTON,
                       20, 120, 100, 40);
    
    create_cyber_button(parent, L"💰 Receive", IDC_RECEIVE_BUTTON,
                       130, 120, 100, 40);
    
    create_cyber_button(parent, L"⚙️ Settings", IDC_SETTINGS_BUTTON,
                       240, 120, 100, 40);
    
    /* Recent transactions */
    CreateWindowW(L"STATIC", L"📊 Recent Transactions",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 20, 180, 200, 25,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    /* Transaction list */
    HWND list = CreateWindowW(WC_LISTVIEW, L"",
                             WS_CHILD | WS_VISIBLE | WS_BORDER | LVS_REPORT | LVS_SINGLESEL,
                             20, 210, 740, 300,
                             parent, NULL, GetModuleHandle(NULL), NULL);
    
    /* Setup list columns */
    LVCOLUMNW col = {0};
    col.mask = LVCF_TEXT | LVCF_WIDTH | LVCF_SUBITEM;
    
    col.pszText = (LPWSTR)L"Date";
    col.cx = 120;
    col.iSubItem = 0;
    ListView_InsertColumn(list, 0, &col);
    
    col.pszText = (LPWSTR)L"Type";
    col.cx = 80;
    col.iSubItem = 1;
    ListView_InsertColumn(list, 1, &col);
    
    col.pszText = (LPWSTR)L"Amount";
    col.cx = 150;
    col.iSubItem = 2;
    ListView_InsertColumn(list, 2, &col);
    
    col.pszText = (LPWSTR)L"Address";
    col.cx = 300;
    col.iSubItem = 3;
    ListView_InsertColumn(list, 3, &col);
    
    col.pszText = (LPWSTR)L"Status";
    col.cx = 90;
    col.iSubItem = 4;
    ListView_InsertColumn(list, 4, &col);
    
    /* Add sample transactions */
    LVITEMW item = {0};
    item.mask = LVIF_TEXT;
    
    /* Transaction 1 */
    item.iItem = 0;
    item.iSubItem = 0;
    item.pszText = (LPWSTR)L"2024-12-30";
    ListView_InsertItem(list, &item);
    ListView_SetItemText(list, 0, 1, (LPWSTR)L"Received");
    ListView_SetItemText(list, 0, 2, (LPWSTR)L"+0.05000000 BTC");
    ListView_SetItemText(list, 0, 3, (LPWSTR)L"bc1q...abc123");
    ListView_SetItemText(list, 0, 4, (LPWSTR)L"✅ Confirmed");
    
    /* Transaction 2 */
    item.iItem = 1;
    item.pszText = (LPWSTR)L"2024-12-29";
    ListView_InsertItem(list, &item);
    ListView_SetItemText(list, 1, 1, (LPWSTR)L"Sent");
    ListView_SetItemText(list, 1, 2, (LPWSTR)L"-0.02500000 BTC");
    ListView_SetItemText(list, 1, 3, (LPWSTR)L"1A1zP1...xyz789");
    ListView_SetItemText(list, 1, 4, (LPWSTR)L"✅ Confirmed");
}

/**
 * Create transaction controls
 */
void lacky_controls_create_transaction(HWND parent) {
    /* Transaction form */
    CreateWindowW(L"STATIC", L"💸 Send Cryptocurrency",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 20, 20, 300, 30,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    /* Recipient address */
    CreateWindowW(L"STATIC", L"📧 Recipient Address:",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 20, 70, 150, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    create_cyber_edit(parent, IDC_ADDRESS_EDIT,
                     20, 95, 500, 25, false);
    
    /* Amount */
    CreateWindowW(L"STATIC", L"💰 Amount:",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 20, 140, 100, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    create_cyber_edit(parent, IDC_AMOUNT_EDIT,
                     20, 165, 200, 25, false);
    
    CreateWindowW(L"STATIC", L"BTC",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 230, 168, 30, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    /* Fee selection */
    CreateWindowW(L"STATIC", L"⚡ Network Fee:",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 300, 140, 100, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    HWND fee_combo = create_cyber_combo(parent, IDC_FEE_COMBO,
                                       300, 165, 150, 25);
    
    SendMessageW(fee_combo, CB_ADDSTRING, 0, (LPARAM)L"🐌 Low (10 sat/vB)");
    SendMessageW(fee_combo, CB_ADDSTRING, 0, (LPARAM)L"🚀 Standard (20 sat/vB)");
    SendMessageW(fee_combo, CB_ADDSTRING, 0, (LPARAM)L"⚡ High (50 sat/vB)");
    SendMessageW(fee_combo, CB_SETCURSEL, 1, 0); /* Default to standard */
    
    /* Memo */
    CreateWindowW(L"STATIC", L"📝 Memo (Optional):",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 20, 210, 150, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    create_cyber_edit(parent, IDC_MEMO_EDIT,
                     20, 235, 500, 25, false);
    
    /* Transaction summary */
    CreateWindowW(L"STATIC", L"📊 Transaction Summary:",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 20, 280, 200, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    CreateWindowW(L"STATIC", L"Amount: 0.00000000 BTC\nFee: 0.00000000 BTC\nTotal: 0.00000000 BTC",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 20, 305, 300, 60,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    /* Action buttons */
    create_cyber_button(parent, L"🚀 Send Transaction", IDC_SEND_TX_BUTTON,
                       20, 380, 150, 40);
    
    create_cyber_button(parent, L"❌ Cancel", IDC_CANCEL_BUTTON,
                       180, 380, 100, 40);
    
    /* Privacy options */
    CreateWindowW(L"STATIC", L"🛡️ Privacy & Security Options:",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 400, 280, 200, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    CreateWindowW(L"BUTTON", L"🔀 Use CoinJoin Mixing",
                 WS_CHILD | WS_VISIBLE | BS_CHECKBOX,
                 400, 305, 200, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    CreateWindowW(L"BUTTON", L"🌐 Route via Tor",
                 WS_CHILD | WS_VISIBLE | BS_CHECKBOX,
                 400, 330, 150, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    CreateWindowW(L"BUTTON", L"🗑️ Delete transaction data after send",
                 WS_CHILD | WS_VISIBLE | BS_CHECKBOX,
                 400, 355, 250, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
}

/**
 * Create settings controls
 */
void lacky_controls_create_settings(HWND parent) {
    /* Settings tabs */
    CreateWindowW(L"STATIC", L"⚙️ LackyVault Settings",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 20, 20, 300, 30,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    /* Theme selection */
    CreateWindowW(L"STATIC", L"🎨 Visual Theme:",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 20, 70, 150, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    HWND theme_combo = create_cyber_combo(parent, IDC_THEME_COMBO,
                                         20, 95, 200, 25);
    
    SendMessageW(theme_combo, CB_ADDSTRING, 0, (LPARAM)L"🌐 Cyber (Default)");
    SendMessageW(theme_combo, CB_ADDSTRING, 0, (LPARAM)L"🌌 Cosmic");
    SendMessageW(theme_combo, CB_ADDSTRING, 0, (LPARAM)L"☀️ Light");
    SendMessageW(theme_combo, CB_ADDSTRING, 0, (LPARAM)L"🌙 Dark");
    SendMessageW(theme_combo, CB_ADDSTRING, 0, (LPARAM)L"📟 Retro 80s");
    SendMessageW(theme_combo, CB_ADDSTRING, 0, (LPARAM)L"💿 Retro 90s");
    SendMessageW(theme_combo, CB_ADDSTRING, 0, (LPARAM)L"🔢 Matrix");
    SendMessageW(theme_combo, CB_ADDSTRING, 0, (LPARAM)L"💻 Terminal");
    SendMessageW(theme_combo, CB_SETCURSEL, 0, 0);
    
    /* Security settings */
    CreateWindowW(L"STATIC", L"🔒 Security Settings:",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 20, 140, 200, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    CreateWindowW(L"BUTTON", L"🚨 Enable Panic Hotkey (Ctrl+Shift+F12)",
                 WS_CHILD | WS_VISIBLE | BS_CHECKBOX | BS_CHECKED,
                 20, 165, 300, 20,
                 parent, (HMENU)IDC_PANIC_HOTKEY_CHECK, GetModuleHandle(NULL), NULL);
    
    CreateWindowW(L"STATIC", L"🕐 Auto-lock timeout (minutes):",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 20, 195, 200, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    create_cyber_edit(parent, IDC_AUTO_LOCK_EDIT,
                     220, 192, 60, 25, false);
    
    /* Network settings */
    CreateWindowW(L"STATIC", L"🌐 Network Settings:",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 20, 240, 200, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    CreateWindowW(L"STATIC", L"🔗 Proxy Server (Optional):",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 20, 265, 180, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    create_cyber_edit(parent, IDC_PROXY_EDIT,
                     20, 290, 300, 25, false);
    
    CreateWindowW(L"BUTTON", L"🧅 Enable Tor Integration",
                 WS_CHILD | WS_VISIBLE | BS_CHECKBOX | BS_CHECKED,
                 20, 325, 200, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    /* Advanced security */
    CreateWindowW(L"STATIC", L"🛡️ Advanced Security Features:",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 400, 70, 250, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    CreateWindowW(L"BUTTON", L"🤖 Neuromorphic AI Evasion",
                 WS_CHILD | WS_VISIBLE | BS_CHECKBOX | BS_CHECKED,
                 400, 95, 200, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    CreateWindowW(L"BUTTON", L"🔀 Blockchain Transaction Mixing",
                 WS_CHILD | WS_VISIBLE | BS_CHECKBOX | BS_CHECKED,
                 400, 120, 220, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    CreateWindowW(L"BUTTON", L"🌐 Mesh Network Communication",
                 WS_CHILD | WS_VISIBLE | BS_CHECKBOX | BS_CHECKED,
                 400, 145, 200, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    CreateWindowW(L"BUTTON", L"🎭 Hardware Fingerprint Spoofing",
                 WS_CHILD | WS_VISIBLE | BS_CHECKBOX | BS_CHECKED,
                 400, 170, 220, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    CreateWindowW(L"BUTTON", L"🌪️ Decoy Traffic Generation",
                 WS_CHILD | WS_VISIBLE | BS_CHECKBOX | BS_CHECKED,
                 400, 195, 200, 20,
                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    /* Apply button */
    create_cyber_button(parent, L"✅ Apply Settings", IDC_DIALOG_PASSWORD + 100,
                       20, 380, 150, 40);
}

/**
 * Resize authentication controls
 */
void lacky_controls_resize_auth(HWND parent, int width, int height) {
    UNREFERENCED_PARAMETER(parent);
    UNREFERENCED_PARAMETER(width);
    UNREFERENCED_PARAMETER(height);
    // Stub implementation
}

/**
 * Resize main interface controls
 */
void lacky_controls_resize_main(HWND parent, int width, int height) {
    UNREFERENCED_PARAMETER(parent);
    UNREFERENCED_PARAMETER(width);
    UNREFERENCED_PARAMETER(height);
    // Stub implementation
}

/**
 * Resize transaction controls
 */
void lacky_controls_resize_transaction(HWND parent, int width, int height) {
    UNREFERENCED_PARAMETER(parent);
    UNREFERENCED_PARAMETER(width);
    UNREFERENCED_PARAMETER(height);
    // Stub implementation
}

/**
 * Resize settings controls
 */
void lacky_controls_resize_settings(HWND parent, int width, int height) {
    UNREFERENCED_PARAMETER(parent);
    UNREFERENCED_PARAMETER(width);
    UNREFERENCED_PARAMETER(height);
    // Stub implementation
}

/**
 * Create custom cyber-themed button
 */
static HWND create_cyber_button(HWND parent, const wchar_t* text, int id, int x, int y, int w, int h) {
    HWND button = CreateWindowW(L"BUTTON", text, LACKY_BUTTON_STYLE,
                               x, y, w, h, parent, (HMENU)(UINT_PTR)id,
                               GetModuleHandle(NULL), NULL);
    
    if (button && !original_button_proc) {
        original_button_proc = (WNDPROC)SetWindowLongPtrW(button, GWLP_WNDPROC, 
                                                          (LONG_PTR)cyber_button_proc);
    }
    
    return button;
}

/**
 * Create custom cyber-themed edit control
 */
static HWND create_cyber_edit(HWND parent, int id, int x, int y, int w, int h, bool password) {
    DWORD style = LACKY_EDIT_STYLE;
    if (password) {
        style |= ES_PASSWORD;
    }
    
    HWND edit = CreateWindowW(L"EDIT", NULL, style,
                             x, y, w, h, parent, (HMENU)(UINT_PTR)id,
                             GetModuleHandle(NULL), NULL);
    
    if (edit && !original_edit_proc) {
        original_edit_proc = (WNDPROC)SetWindowLongPtrW(edit, GWLP_WNDPROC,
                                                        (LONG_PTR)cyber_edit_proc);
    }
    
    /* Set cyber font with English charset */
    HFONT cyber_font = CreateFontW(14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                  ANSI_CHARSET, OUT_TT_ONLY_PRECIS,
                                  CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                                  FIXED_PITCH | FF_MODERN, L"Consolas");
    
    // Fallback fonts
    if (!cyber_font) {
        cyber_font = CreateFontW(14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                ANSI_CHARSET, OUT_TT_ONLY_PRECIS,
                                CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                                FIXED_PITCH | FF_MODERN, L"Courier New");
    }
    
    SendMessageW(edit, WM_SETFONT, (WPARAM)cyber_font, TRUE);
    
    return edit;
}

/**
 * Create custom cyber-themed combo box
 */
static HWND create_cyber_combo(HWND parent, int id, int x, int y, int w, int h) {
    HWND combo = CreateWindowW(L"COMBOBOX", NULL, LACKY_COMBO_STYLE,
                              x, y, w, h, parent, (HMENU)(UINT_PTR)id,
                              GetModuleHandle(NULL), NULL);
    
    /* Set cyber font with English charset */
    HFONT cyber_font = CreateFontW(14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                  ANSI_CHARSET, OUT_TT_ONLY_PRECIS,
                                  CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                                  FIXED_PITCH | FF_MODERN, L"Consolas");
    
    // Fallback fonts
    if (!cyber_font) {
        cyber_font = CreateFontW(14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                ANSI_CHARSET, OUT_TT_ONLY_PRECIS,
                                CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                                FIXED_PITCH | FF_MODERN, L"Courier New");
    }
    
    SendMessageW(combo, WM_SETFONT, (WPARAM)cyber_font, TRUE);
    
    return combo;
}

/**
 * Custom button window procedure for cyber theme
 */
static LRESULT CALLBACK cyber_button_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    switch (msg) {
        case WM_DRAWITEM:
            {
                DRAWITEMSTRUCT* dis = (DRAWITEMSTRUCT*)lparam;
                if (dis->CtlType == ODT_BUTTON) {
                    wchar_t text[256];
                    GetWindowTextW(hwnd, text, sizeof(text) / sizeof(wchar_t));
                    
                    bool pressed = (dis->itemState & ODS_SELECTED) != 0;
                    draw_cyber_button(hwnd, dis->hDC, &dis->rcItem, text, pressed);
                    return TRUE;
                }
            }
            break;
    }
    
    return CallWindowProcW(original_button_proc, hwnd, msg, wparam, lparam);
}

/**
 * Custom edit window procedure for cyber theme
 */
static LRESULT CALLBACK cyber_edit_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    switch (msg) {
        case WM_NCPAINT:
            {
                /* Custom border drawing for cyber theme */
                LRESULT result = CallWindowProcW(original_edit_proc, hwnd, msg, wparam, lparam);
                
                HDC hdc = GetDCEx(hwnd, (HRGN)wparam, DCX_WINDOW | DCX_INTERSECTRGN);
                if (hdc) {
                    RECT rect;
                    GetWindowRect(hwnd, &rect);
                    OffsetRect(&rect, -rect.left, -rect.top);
                    
                    HPEN cyber_pen = CreatePen(PS_SOLID, 2, RGB(0, 255, 255));
                    HPEN old_pen = (HPEN)SelectObject(hdc, cyber_pen);
                    HBRUSH old_brush = (HBRUSH)SelectObject(hdc, GetStockObject(NULL_BRUSH));
                    
                    Rectangle(hdc, rect.left, rect.top, rect.right, rect.bottom);
                    
                    SelectObject(hdc, old_pen);
                    SelectObject(hdc, old_brush);
                    DeleteObject(cyber_pen);
                    ReleaseDC(hwnd, hdc);
                }
                
                return result;
            }
            break;
    }
    
    return CallWindowProcW(original_edit_proc, hwnd, msg, wparam, lparam);
}

/**
 * Draw custom cyber button
 */
static void draw_cyber_button(HWND hwnd, HDC hdc, RECT* rect, const wchar_t* text, bool pressed) {
    /* Background gradient */
    COLORREF bg_color1 = pressed ? RGB(0, 40, 80) : RGB(0, 20, 40);
    COLORREF bg_color2 = pressed ? RGB(0, 80, 120) : RGB(0, 60, 100);
    
    TRIVERTEX vertex[2];
    GRADIENT_RECT gradient_rect;
    
    vertex[0].x = rect->left;
    vertex[0].y = rect->top;
    vertex[0].Red = GetRValue(bg_color1) << 8;
    vertex[0].Green = GetGValue(bg_color1) << 8;
    vertex[0].Blue = GetBValue(bg_color1) << 8;
    vertex[0].Alpha = 0x0000;
    
    vertex[1].x = rect->right;
    vertex[1].y = rect->bottom;
    vertex[1].Red = GetRValue(bg_color2) << 8;
    vertex[1].Green = GetGValue(bg_color2) << 8;
    vertex[1].Blue = GetBValue(bg_color2) << 8;
    vertex[1].Alpha = 0x0000;
    
    gradient_rect.UpperLeft = 0;
    gradient_rect.LowerRight = 1;
    
    GradientFill(hdc, vertex, 2, &gradient_rect, 1, GRADIENT_FILL_RECT_V);
    
    /* Neon border */
    COLORREF border_color = pressed ? RGB(255, 0, 255) : RGB(0, 255, 255);
    HPEN border_pen = CreatePen(PS_SOLID, 2, border_color);
    HPEN old_pen = (HPEN)SelectObject(hdc, border_pen);
    HBRUSH old_brush = (HBRUSH)SelectObject(hdc, GetStockObject(NULL_BRUSH));
    
    Rectangle(hdc, rect->left, rect->top, rect->right, rect->bottom);
    
    /* Cyber font for text */
    HFONT cyber_font = CreateFontW(14, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                                  DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                  CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
                                  FIXED_PITCH | FF_MODERN, L"Consolas");
    
    HFONT old_font = (HFONT)SelectObject(hdc, cyber_font);
    
    /* Text with glow effect */
    SetBkMode(hdc, TRANSPARENT);
    
    /* Glow layers */
    for (int i = 2; i > 0; i--) {
        COLORREF glow_color = RGB(
            GetRValue(border_color) / (i + 1),
            GetGValue(border_color) / (i + 1),
            GetBValue(border_color) / (i + 1)
        );
        
        SetTextColor(hdc, glow_color);
        
        for (int dx = -i; dx <= i; dx++) {
            for (int dy = -i; dy <= i; dy++) {
                RECT text_rect = *rect;
                OffsetRect(&text_rect, dx, dy);
                if (pressed) {
                    OffsetRect(&text_rect, 1, 1);
                }
                DrawTextW(hdc, text, -1, &text_rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
            }
        }
    }
    
    /* Main text */
    SetTextColor(hdc, border_color);
    RECT text_rect = *rect;
    if (pressed) {
        OffsetRect(&text_rect, 1, 1);
    }
    DrawTextW(hdc, text, -1, &text_rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    
    /* Cleanup */
    SelectObject(hdc, old_pen);
    SelectObject(hdc, old_brush);
    SelectObject(hdc, old_font);
    DeleteObject(border_pen);
    DeleteObject(cyber_font);
}
