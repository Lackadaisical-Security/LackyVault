/**
 * LackyVault - Theme System
 * Lackadaisical Security
 * 
 * Advanced theme system with 8 distinct visual styles
 */

#include "../../../include/lacky_vault.h"
#include "../../../include/lacky_crypto.h"
#include <math.h>
#include <stdio.h>

/* Animation state */
static DWORD g_last_frame_time = 0;
static float g_animation_time = 0.0f;

/* Theme color palettes */
typedef struct {
    COLORREF background;
    COLORREF surface;
    COLORREF primary;
    COLORREF secondary;
    COLORREF accent;
    COLORREF text;
    COLORREF text_secondary;
    COLORREF border;
    COLORREF grid;
    COLORREF neon;
    COLORREF success;
    COLORREF warning;
    COLORREF error;
    COLORREF critical;
} theme_palette_t;

/* Theme effects configuration */
typedef struct {
    bool enable_glow;
    bool enable_pulse;
    bool enable_starfield;
    bool enable_scanlines;
    bool enable_crt_effect;
    bool enable_digital_rain;
    bool enable_plasma;
    float glow_intensity;
    float animation_speed;
    int particle_count;
} theme_effects_t;

/* Complete theme structure */
typedef struct {
    theme_palette_t palette;
    theme_effects_t effects;
    char font_family[64];
    int font_size;
    int border_radius;
    float window_opacity;
} theme_config_t;

/* All theme configurations */
static theme_config_t g_themes[8] = {
    /* LACKY_THEME_CYBER */
    {
        .palette = {
            .background = RGB(0, 0, 0),
            .surface = RGB(10, 10, 10),
            .primary = RGB(0, 255, 255),
            .secondary = RGB(255, 0, 255),
            .accent = RGB(0, 255, 0),
            .text = RGB(0, 255, 255),
            .text_secondary = RGB(255, 113, 206),
            .border = RGB(119, 0, 255),
            .grid = RGB(0, 64, 64),
            .neon = RGB(0, 255, 255),
            .success = RGB(0, 255, 136),
            .warning = RGB(255, 170, 0),
            .error = RGB(255, 0, 85),
            .critical = RGB(255, 0, 0)
        },
        .effects = {
            .enable_glow = true,
            .enable_pulse = true,
            .enable_starfield = true,
            .enable_scanlines = true,
            .enable_crt_effect = true,
            .glow_intensity = 0.8f,
            .animation_speed = 0.6f,
            .particle_count = 150
        },
        .font_family = "Courier New",
        .font_size = 12,
        .border_radius = 0,
        .window_opacity = 0.95f
    },
    
    /* LACKY_THEME_COSMIC */
    {
        .palette = {
            .background = RGB(10, 10, 15),
            .surface = RGB(26, 26, 46),
            .primary = RGB(0, 255, 255),
            .secondary = RGB(255, 0, 255),
            .accent = RGB(255, 255, 0),
            .text = RGB(255, 255, 255),
            .text_secondary = RGB(176, 176, 176),
            .border = RGB(64, 64, 64),
            .grid = RGB(45, 27, 105),
            .neon = RGB(0, 255, 255),
            .success = RGB(0, 255, 0),
            .warning = RGB(255, 170, 0),
            .error = RGB(255, 68, 68),
            .critical = RGB(255, 0, 68)
        },
        .effects = {
            .enable_glow = true,
            .enable_pulse = true,
            .enable_starfield = true,
            .enable_scanlines = true,
            .enable_crt_effect = false,
            .glow_intensity = 0.3f,
            .animation_speed = 0.5f,
            .particle_count = 100
        },
        .font_family = "Consolas",
        .font_size = 12,
        .border_radius = 8,
        .window_opacity = 0.95f
    },
    
    /* LACKY_THEME_LIGHT */
    {
        .palette = {
            .background = RGB(248, 249, 250),
            .surface = RGB(255, 255, 255),
            .primary = RGB(0, 102, 204),
            .secondary = RGB(108, 117, 125),
            .accent = RGB(40, 167, 69),
            .text = RGB(33, 37, 41),
            .text_secondary = RGB(108, 117, 125),
            .border = RGB(222, 226, 230),
            .grid = RGB(233, 236, 239),
            .neon = RGB(0, 102, 204),
            .success = RGB(40, 167, 69),
            .warning = RGB(255, 193, 7),
            .error = RGB(220, 53, 69),
            .critical = RGB(169, 30, 44)
        },
        .effects = {
            .enable_glow = false,
            .enable_pulse = false,
            .enable_starfield = false,
            .enable_scanlines = false,
            .enable_crt_effect = false,
            .glow_intensity = 0.0f,
            .animation_speed = 0.3f,
            .particle_count = 0
        },
        .font_family = "Segoe UI",
        .font_size = 12,
        .border_radius = 4,
        .window_opacity = 1.0f
    },
    
    /* LACKY_THEME_DARK */
    {
        .palette = {
            .background = RGB(18, 18, 18),
            .surface = RGB(30, 30, 30),
            .primary = RGB(187, 134, 252),
            .secondary = RGB(3, 218, 198),
            .accent = RGB(207, 102, 121),
            .text = RGB(255, 255, 255),
            .text_secondary = RGB(179, 179, 179),
            .border = RGB(45, 45, 45),
            .grid = RGB(45, 45, 45),
            .neon = RGB(187, 134, 252),
            .success = RGB(76, 175, 80),
            .warning = RGB(255, 152, 0),
            .error = RGB(244, 67, 54),
            .critical = RGB(211, 47, 47)
        },
        .effects = {
            .enable_glow = true,
            .enable_pulse = false,
            .enable_starfield = false,
            .enable_scanlines = false,
            .enable_crt_effect = false,
            .glow_intensity = 0.1f,
            .animation_speed = 0.4f,
            .particle_count = 0
        },
        .font_family = "Segoe UI",
        .font_size = 12,
        .border_radius = 8,
        .window_opacity = 0.98f
    },
    
    /* LACKY_THEME_RETRO_80S */
    {
        .palette = {
            .background = RGB(13, 2, 33),
            .surface = RGB(26, 0, 51),
            .primary = RGB(0, 255, 255),
            .secondary = RGB(255, 0, 255),
            .accent = RGB(255, 255, 0),
            .text = RGB(0, 255, 255),
            .text_secondary = RGB(255, 113, 206),
            .border = RGB(119, 0, 255),
            .grid = RGB(119, 0, 255),
            .neon = RGB(255, 0, 255),
            .success = RGB(0, 255, 136),
            .warning = RGB(255, 170, 0),
            .error = RGB(255, 0, 85),
            .critical = RGB(255, 0, 0)
        },
        .effects = {
            .enable_glow = true,
            .enable_pulse = true,
            .enable_starfield = true,
            .enable_scanlines = true,
            .enable_crt_effect = true,
            .glow_intensity = 0.8f,
            .animation_speed = 0.6f,
            .particle_count = 150
        },
        .font_family = "Courier New",
        .font_size = 12,
        .border_radius = 0,
        .window_opacity = 0.95f
    },
    
    /* LACKY_THEME_RETRO_90S */
    {
        .palette = {
            .background = RGB(5, 21, 25),
            .surface = RGB(10, 46, 56),
            .primary = RGB(0, 255, 0),
            .secondary = RGB(255, 0, 255),
            .accent = RGB(0, 255, 255),
            .text = RGB(51, 255, 51),
            .text_secondary = RGB(255, 102, 255),
            .border = RGB(102, 255, 0),
            .grid = RGB(26, 77, 46),
            .neon = RGB(0, 255, 0),
            .success = RGB(0, 255, 0),
            .warning = RGB(255, 153, 0),
            .error = RGB(255, 0, 102),
            .critical = RGB(255, 0, 0)
        },
        .effects = {
            .enable_glow = true,
            .enable_pulse = true,
            .enable_starfield = true,
            .enable_scanlines = false,
            .enable_crt_effect = false,
            .enable_plasma = true,
            .glow_intensity = 0.9f,
            .animation_speed = 0.8f,
            .particle_count = 200
        },
        .font_family = "Comic Sans MS",
        .font_size = 13,
        .border_radius = 20,
        .window_opacity = 0.92f
    },
    
    /* LACKY_THEME_MATRIX */
    {
        .palette = {
            .background = RGB(0, 0, 0),
            .surface = RGB(10, 10, 10),
            .primary = RGB(0, 255, 0),
            .secondary = RGB(0, 143, 0),
            .accent = RGB(0, 204, 0),
            .text = RGB(0, 255, 0),
            .text_secondary = RGB(0, 170, 0),
            .border = RGB(0, 85, 0),
            .grid = RGB(0, 51, 0),
            .neon = RGB(0, 255, 0),
            .success = RGB(0, 255, 0),
            .warning = RGB(255, 255, 0),
            .error = RGB(255, 0, 0),
            .critical = RGB(204, 0, 0)
        },
        .effects = {
            .enable_glow = true,
            .enable_pulse = false,
            .enable_starfield = false,
            .enable_scanlines = true,
            .enable_crt_effect = true,
            .enable_digital_rain = true,
            .glow_intensity = 0.6f,
            .animation_speed = 1.0f,
            .particle_count = 0
        },
        .font_family = "Consolas",
        .font_size = 12,
        .border_radius = 0,
        .window_opacity = 0.95f
    },
    
    /* LACKY_THEME_TERMINAL */
    {
        .palette = {
            .background = RGB(0, 0, 0),
            .surface = RGB(15, 15, 15),
            .primary = RGB(255, 176, 0),
            .secondary = RGB(204, 136, 0),
            .accent = RGB(255, 136, 0),
            .text = RGB(255, 176, 0),
            .text_secondary = RGB(204, 136, 0),
            .border = RGB(102, 68, 0),
            .grid = RGB(26, 17, 0),
            .neon = RGB(255, 176, 0),
            .success = RGB(0, 255, 0),
            .warning = RGB(255, 255, 0),
            .error = RGB(255, 0, 0),
            .critical = RGB(204, 0, 0)
        },
        .effects = {
            .enable_glow = false,
            .enable_pulse = false,
            .enable_starfield = false,
            .enable_scanlines = true,
            .enable_crt_effect = true,
            .glow_intensity = 0.4f,
            .animation_speed = 0.0f,
            .particle_count = 0
        },
        .font_family = "Consolas",
        .font_size = 12,
        .border_radius = 0,
        .window_opacity = 1.0f
    }
};

/* Matrix rain characters */
static WCHAR g_matrix_chars[] = L"01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン";
static int g_matrix_char_count = sizeof(g_matrix_chars) / sizeof(WCHAR) - 1;

/* Matrix rain columns */
typedef struct {
    int y;
    int speed;
    int length;
    WCHAR chars[50];
} matrix_column_t;

static matrix_column_t* g_matrix_columns = NULL;
static int g_matrix_column_count = 0;

/* Get current theme configuration */
static theme_config_t* get_current_theme(lacky_app_t* app) {
    if (app->config.theme >= 0 && app->config.theme < 8) {
        return &g_themes[app->config.theme];
    }
    return &g_themes[LACKY_THEME_CYBER]; // Default fallback
}

/* Update animation time */
static void update_animation(void) {
    DWORD current_time = GetTickCount();
    if (g_last_frame_time == 0) {
        g_last_frame_time = current_time;
    }
    
    DWORD delta = current_time - g_last_frame_time;
    g_animation_time += delta * 0.001f; // Convert to seconds
    g_last_frame_time = current_time;
    
    // Keep animation time reasonable
    if (g_animation_time > 1000.0f) {
        g_animation_time = fmodf(g_animation_time, 1000.0f);
    }
}

/* Initialize Matrix rain effect */
static void init_matrix_rain(int width, int height) {
    if (g_matrix_columns) {
        free(g_matrix_columns);
    }
    
    g_matrix_column_count = width / 10; // One column every 10 pixels
    g_matrix_columns = (matrix_column_t*)calloc(g_matrix_column_count, sizeof(matrix_column_t));
    
    for (int i = 0; i < g_matrix_column_count; i++) {
        g_matrix_columns[i].y = -(rand() % height);
        g_matrix_columns[i].speed = 1 + (rand() % 3);
        g_matrix_columns[i].length = 10 + (rand() % 20);
        
        for (int j = 0; j < g_matrix_columns[i].length; j++) {
            g_matrix_columns[i].chars[j] = g_matrix_chars[rand() % g_matrix_char_count];
        }
    }
}

/* Draw Matrix digital rain effect */
static void draw_matrix_rain(HDC hdc, RECT* rect, theme_config_t* theme) {
    if (!g_matrix_columns) {
        init_matrix_rain(rect->right - rect->left, rect->bottom - rect->top);
    }
    
    HFONT matrix_font = CreateFontW(14, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                                    DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                    CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                                    FIXED_PITCH | FF_MODERN, L"Consolas");
    
    HFONT old_font = (HFONT)SelectObject(hdc, matrix_font);
    SetBkMode(hdc, TRANSPARENT);
    
    int height = rect->bottom - rect->top;
    
    for (int i = 0; i < g_matrix_column_count; i++) {
        int x = rect->left + i * 10;
        
        // Update position
        g_matrix_columns[i].y += g_matrix_columns[i].speed;
        
        // Reset if off screen
        if (g_matrix_columns[i].y > height) {
            g_matrix_columns[i].y = -g_matrix_columns[i].length * 14;
            // Randomize characters
            for (int j = 0; j < g_matrix_columns[i].length; j++) {
                g_matrix_columns[i].chars[j] = g_matrix_chars[rand() % g_matrix_char_count];
            }
        }
        
        // Draw characters with fading effect
        for (int j = 0; j < g_matrix_columns[i].length; j++) {
            int y = g_matrix_columns[i].y - j * 14;
            
            if (y >= rect->top && y < rect->bottom) {
                int brightness = 255 - (j * 255 / g_matrix_columns[i].length);
                if (j == 0) brightness = 255; // Bright head
                
                SetTextColor(hdc, RGB(0, brightness, 0));
                WCHAR ch[2] = { g_matrix_columns[i].chars[j], 0 };
                TextOutW(hdc, x, y, ch, 1);
            }
        }
    }
    
    SelectObject(hdc, old_font);
    DeleteObject(matrix_font);
}

/* Draw plasma effect for 90s theme */
static void draw_plasma_effect(HDC hdc, RECT* rect, theme_config_t* theme) {
    int width = rect->right - rect->left;
    int height = rect->bottom - rect->top;
    
    // Create a simple plasma effect with sine waves
    for (int y = 0; y < height; y += 4) {
        for (int x = 0; x < width; x += 4) {
            float value = sinf(x * 0.02f + g_animation_time) + 
                         sinf(y * 0.02f + g_animation_time * 0.7f) +
                         sinf((x + y) * 0.01f + g_animation_time * 0.5f);
            
            value = (value + 3.0f) / 6.0f; // Normalize to 0-1
            
            BYTE r = (BYTE)(GetRValue(theme->palette.primary) * value);
            BYTE g = (BYTE)(GetGValue(theme->palette.secondary) * value);
            BYTE b = (BYTE)(GetBValue(theme->palette.accent) * value);
            
            HBRUSH plasma_brush = CreateSolidBrush(RGB(r, g, b));
            RECT pixel_rect = { rect->left + x, rect->top + y, 
                               rect->left + x + 4, rect->top + y + 4 };
            FillRect(hdc, &pixel_rect, plasma_brush);
            DeleteObject(plasma_brush);
        }
    }
}

/* Draw starfield background */
static void draw_starfield(HDC hdc, RECT* rect, theme_config_t* theme) {
    static POINT stars[200] = {0};
    static bool stars_initialized = false;
    
    if (!stars_initialized) {
        for (int i = 0; i < 200; i++) {
            stars[i].x = rand() % (rect->right - rect->left);
            stars[i].y = rand() % (rect->bottom - rect->top);
        }
        stars_initialized = true;
    }
    
    // Draw stars with twinkling effect
    for (int i = 0; i < theme->effects.particle_count && i < 200; i++) {
        float brightness = (sinf(g_animation_time * (2.0f + i * 0.1f)) + 1.0f) * 0.5f;
        BYTE intensity = (BYTE)(255 * brightness);
        
        SetPixel(hdc, rect->left + stars[i].x, rect->top + stars[i].y, 
                RGB(intensity, intensity, intensity));
        
        // Move stars slowly
        if (theme->effects.animation_speed > 0) {
            stars[i].y += 1;
            if (stars[i].y >= rect->bottom - rect->top) {
                stars[i].y = 0;
                stars[i].x = rand() % (rect->right - rect->left);
            }
        }
    }
}

/* Draw grid background */
static void draw_grid_background(HDC hdc, RECT* rect, theme_palette_t* palette) {
    HPEN grid_pen = CreatePen(PS_SOLID, 1, palette->grid);
    HPEN old_pen = (HPEN)SelectObject(hdc, grid_pen);
    
    int grid_size = 50;
    int width = rect->right - rect->left;
    int height = rect->bottom - rect->top;
    
    // Animate grid offset
    int offset_x = (int)(sinf(g_animation_time * 0.5f) * 10.0f);
    int offset_y = (int)(cosf(g_animation_time * 0.3f) * 10.0f);
    
    // Draw vertical lines
    for (int x = (rect->left % grid_size) + offset_x; x < rect->right; x += grid_size) {
        MoveToEx(hdc, x, rect->top, NULL);
        LineTo(hdc, x, rect->bottom);
    }
    
    // Draw horizontal lines
    for (int y = (rect->top % grid_size) + offset_y; y < rect->bottom; y += grid_size) {
        MoveToEx(hdc, rect->left, y, NULL);
        LineTo(hdc, rect->right, y);
    }
    
    SelectObject(hdc, old_pen);
    DeleteObject(grid_pen);
}

/* Draw neon text effect */
static void draw_neon_text(HDC hdc, const WCHAR* text, int x, int y, HFONT font, theme_palette_t* palette) {
    HFONT old_font = (HFONT)SelectObject(hdc, font);
    
    // Glow effect - draw multiple times with decreasing opacity
    for (int i = 3; i >= 0; i--) {
        COLORREF glow_color;
        if (i == 0) {
            glow_color = palette->neon; // Bright center
        } else {
            // Dimmer glow layers
            int r = GetRValue(palette->neon) / (i + 1);
            int g = GetGValue(palette->neon) / (i + 1);
            int b = GetBValue(palette->neon) / (i + 1);
            glow_color = RGB(r, g, b);
        }
        
        SetTextColor(hdc, glow_color);
        SetBkMode(hdc, TRANSPARENT);
        
        // Offset for glow effect
        int offset = i;
        for (int dx = -offset; dx <= offset; dx++) {
            for (int dy = -offset; dy <= offset; dy++) {
                if (dx == 0 && dy == 0 && i > 0) continue; // Skip center for outer glow
                TextOutW(hdc, x + dx, y + dy, text, (int)wcslen(text));
            }
        }
    }
    
    SelectObject(hdc, old_font);
}

/* Draw glitch effect */
static void draw_glitch_effect(HDC hdc, RECT* rect, theme_palette_t* palette) {
    // Random glitch lines
    if ((int)(g_animation_time * 10.0f) % 5 == 0) { // Glitch every 0.5 seconds briefly
        HPEN glitch_pen = CreatePen(PS_SOLID, 2, palette->accent);
        HPEN old_pen = (HPEN)SelectObject(hdc, glitch_pen);
        
        int num_lines = 3 + (rand() % 5);
        for (int i = 0; i < num_lines; i++) {
            int y = rect->top + (rand() % (rect->bottom - rect->top));
            int x1 = rect->left + (rand() % (rect->right - rect->left)) / 3;
            int x2 = x1 + 50 + (rand() % 100);
            
            MoveToEx(hdc, x1, y, NULL);
            LineTo(hdc, x2, y);
        }
        
        SelectObject(hdc, old_pen);
        DeleteObject(glitch_pen);
    }
}

/* Initialize theme system */
lacky_error_t lacky_theme_init(lacky_app_t* app) {
    if (!app) return LACKY_ERROR_INVALID_PARAM;
    
    // Create fonts with explicit English charset and fallback prevention
    app->fonts[0] = CreateFontW(16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                               ANSI_CHARSET, OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS,
                               ANTIALIASED_QUALITY, FIXED_PITCH | FF_MODERN, L"Consolas");
    
    app->fonts[1] = CreateFontW(20, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                               ANSI_CHARSET, OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS,
                               ANTIALIASED_QUALITY, FIXED_PITCH | FF_MODERN, L"Consolas");
    
    app->fonts[2] = CreateFontW(24, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                               ANSI_CHARSET, OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS,
                               ANTIALIASED_QUALITY, FIXED_PITCH | FF_MODERN, L"Consolas");
    
    app->fonts[3] = CreateFontW(32, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                               ANSI_CHARSET, OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS,
                               ANTIALIASED_QUALITY, FIXED_PITCH | FF_MODERN, L"Consolas");
    
    // Fallback fonts if Consolas not available
    for (int i = 0; i < 4; i++) {
        if (!app->fonts[i]) {
            int sizes[] = {16, 20, 24, 32};
            int weights[] = {FW_NORMAL, FW_BOLD, FW_BOLD, FW_BOLD};
            
            // Try Courier New as fallback
            app->fonts[i] = CreateFontW(sizes[i], 0, 0, 0, weights[i], FALSE, FALSE, FALSE,
                                       ANSI_CHARSET, OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS,
                                       ANTIALIASED_QUALITY, FIXED_PITCH | FF_MODERN, L"Courier New");
            
            // Final fallback to system fixed font
            if (!app->fonts[i]) {
                app->fonts[i] = CreateFontW(sizes[i], 0, 0, 0, weights[i], FALSE, FALSE, FALSE,
                                           ANSI_CHARSET, OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS,
                                           ANTIALIASED_QUALITY, FIXED_PITCH | FF_MODERN, L"Lucida Console");
            }
        }
    }
    
    // Create brushes
    theme_config_t* theme = get_current_theme(app);
    app->brushes[0] = CreateSolidBrush(theme->palette.background);
    app->brushes[1] = CreateSolidBrush(theme->palette.primary);
    app->brushes[2] = CreateSolidBrush(theme->palette.secondary);
    app->brushes[3] = CreateSolidBrush(theme->palette.accent);
    
    // Create pens
    app->pens[0] = CreatePen(PS_SOLID, 1, theme->palette.primary);
    app->pens[1] = CreatePen(PS_SOLID, 2, theme->palette.primary);
    app->pens[2] = CreatePen(PS_SOLID, 1, theme->palette.secondary);
    app->pens[3] = CreatePen(PS_SOLID, 2, theme->palette.secondary);
    
    return LACKY_SUCCESS;
}

/* Cleanup theme resources */
void lacky_theme_cleanup(lacky_app_t* app) {
    if (!app) return;
    
    // Delete fonts
    for (int i = 0; i < 4; i++) {
        if (app->fonts[i]) {
            DeleteObject(app->fonts[i]);
            app->fonts[i] = NULL;
        }
    }
    
    // Delete brushes
    for (int i = 0; i < 8; i++) {
        if (app->brushes[i]) {
            DeleteObject(app->brushes[i]);
            app->brushes[i] = NULL;
        }
    }
    
    // Delete pens
    for (int i = 0; i < 8; i++) {
        if (app->pens[i]) {
            DeleteObject(app->pens[i]);
            app->pens[i] = NULL;
        }
    }
}

/* Update layout for window resize */
void lacky_theme_update_layout(lacky_app_t* app, int width, int height) {
    if (!app) return;
    
    // Update any layout-dependent theme elements
    // For now, just invalidate to trigger redraw
    if (app->main_window) {
        InvalidateRect(app->main_window, NULL, TRUE);
    }
}

/* Render splash screen */
void lacky_theme_render_splash(HDC hdc, RECT* rect, lacky_app_t* app) {
    update_animation();
    theme_config_t* theme = get_current_theme(app);
    theme_palette_t* palette = &theme->palette;
    
    // Fill background
    HBRUSH bg_brush = CreateSolidBrush(palette->background);
    FillRect(hdc, rect, bg_brush);
    DeleteObject(bg_brush);
    
    // Draw grid
    draw_grid_background(hdc, rect, palette);
    
    // Draw title
    int center_x = (rect->right - rect->left) / 2;
    int center_y = (rect->bottom - rect->top) / 2;
    
    draw_neon_text(hdc, L"LACKYVAULT", center_x - 100, center_y - 40, app->fonts[3], palette);
    draw_neon_text(hdc, L"Lackadaisical Security", center_x - 120, center_y + 20, app->fonts[1], palette);
    
    // Animated loading text
    float pulse = (sinf(g_animation_time * 3.0f) + 1.0f) * 0.5f;
    if (pulse > 0.5f) {
        draw_neon_text(hdc, L"Loading...", center_x - 40, center_y + 80, app->fonts[0], palette);
    }
    
    // Glitch effects
    draw_glitch_effect(hdc, rect, palette);
}

/* Render authentication screen */
void lacky_theme_render_auth_screen(HDC hdc, RECT* rect, lacky_app_t* app) {
    update_animation();
    theme_config_t* theme = get_current_theme(app);
    theme_palette_t* palette = &theme->palette;
    
    // Fill background
    HBRUSH bg_brush = CreateSolidBrush(palette->background);
    FillRect(hdc, rect, bg_brush);
    DeleteObject(bg_brush);
    
    // Draw grid
    draw_grid_background(hdc, rect, palette);
    
    // Draw title
    draw_neon_text(hdc, L"SECURE ACCESS", 50, 50, app->fonts[2], palette);
    
    // Security indicators
    draw_neon_text(hdc, L"[CRYPTO_READY]", 50, 100, app->fonts[0], palette);
    draw_neon_text(hdc, L"[NETWORK_SECURED]", 50, 130, app->fonts[0], palette);
    draw_neon_text(hdc, L"[ANTI_DEBUG_ACTIVE]", 50, 160, app->fonts[0], palette);
}

/* Render main interface */
void lacky_theme_render_main_interface(HDC hdc, RECT* rect, lacky_app_t* app) {
    update_animation();
    theme_config_t* theme = get_current_theme(app);
    theme_palette_t* palette = &theme->palette;
    
    // Fill background
    HBRUSH bg_brush = CreateSolidBrush(palette->background);
    FillRect(hdc, rect, bg_brush);
    DeleteObject(bg_brush);
    
    // Draw grid
    draw_grid_background(hdc, rect, palette);
    
    // Draw header
    draw_neon_text(hdc, L"LACKYVAULT", 20, 20, app->fonts[2], palette);
    
    // Status indicators
    draw_neon_text(hdc, L"[ONLINE]", rect->right - 100, 20, app->fonts[0], palette);
    draw_neon_text(hdc, L"[SECURED]", rect->right - 100, 40, app->fonts[0], palette);
}

/* Render transaction screen */
void lacky_theme_render_transaction_screen(HDC hdc, RECT* rect, lacky_app_t* app) {
    update_animation();
    theme_config_t* theme = get_current_theme(app);
    theme_palette_t* palette = &theme->palette;
    
    // Fill background
    HBRUSH bg_brush = CreateSolidBrush(palette->background);
    FillRect(hdc, rect, bg_brush);
    DeleteObject(bg_brush);
    
    // Draw grid
    draw_grid_background(hdc, rect, palette);
    
    // Draw title
    draw_neon_text(hdc, L"TRANSACTION", 20, 20, app->fonts[2], palette);
}

/* Render settings screen */
void lacky_theme_render_settings_screen(HDC hdc, RECT* rect, lacky_app_t* app) {
    update_animation();
    theme_config_t* theme = get_current_theme(app);
    theme_palette_t* palette = &theme->palette;
    
    // Fill background
    HBRUSH bg_brush = CreateSolidBrush(palette->background);
    FillRect(hdc, rect, bg_brush);
    DeleteObject(bg_brush);
    
    // Draw grid
    draw_grid_background(hdc, rect, palette);
    
    // Draw title
    draw_neon_text(hdc, L"SYSTEM CONFIG", 20, 20, app->fonts[2], palette);
}

/* Render fake Windows update screen for panic mode */
void lacky_theme_render_fake_windows_update(HDC hdc, RECT* rect, lacky_app_t* app) {
    UNREFERENCED_PARAMETER(app);
    
    // Fill with standard Windows blue
    HBRUSH bg_brush = CreateSolidBrush(RGB(0, 120, 215));
    FillRect(hdc, rect, bg_brush);
    DeleteObject(bg_brush);
    
    // Create Windows-style font with explicit English charset
    HFONT update_font = CreateFontW(24, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                   ANSI_CHARSET, OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS,
                                   ANTIALIASED_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");
    
    // Fallback if Segoe UI not available
    if (!update_font) {
        update_font = CreateFontW(24, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                 ANSI_CHARSET, OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS,
                                 ANTIALIASED_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Tahoma");
    }
    
    HFONT old_font = (HFONT)SelectObject(hdc, update_font);
    SetTextColor(hdc, RGB(255, 255, 255));
    SetBkMode(hdc, TRANSPARENT);
    
    int center_x = (rect->right - rect->left) / 2;
    int center_y = (rect->bottom - rect->top) / 2;
    
    // Draw fake update text - explicitly English
    const WCHAR* update_text = L"Working on updates";
    SIZE text_size;
    GetTextExtentPoint32W(hdc, update_text, (int)wcslen(update_text), &text_size);
    TextOutW(hdc, center_x - text_size.cx / 2, center_y - 50, update_text, (int)wcslen(update_text));
    
    const WCHAR* percent_text = L"45% complete";
    GetTextExtentPoint32W(hdc, percent_text, (int)wcslen(percent_text), &text_size);
    TextOutW(hdc, center_x - text_size.cx / 2, center_y, percent_text, (int)wcslen(percent_text));
    
    const WCHAR* warning_text = L"Don't turn off your PC";
    GetTextExtentPoint32W(hdc, warning_text, (int)wcslen(warning_text), &text_size);
    TextOutW(hdc, center_x - text_size.cx / 2, center_y + 50, warning_text, (int)wcslen(warning_text));
    
    SelectObject(hdc, old_font);
    DeleteObject(update_font);
}
