/**
 * LackyVault - Main Application Entry Point
 * Production-grade crypto wallet with advanced privacy and security features
 */

#include <windows.h>
#include <commctrl.h>
#include <shellapi.h>
#include <dwmapi.h>
#include "../../../include/lacky_vault.h"
#include "../../../include/lacky_crypto.h"
#include "../security/security_integration.h"

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "dwmapi.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")

/* Global application instance */
static lacky_app_t g_app = {0};
static bool g_emergency_shutdown = false;

/* Window class name */
#define LACKY_WINDOW_CLASS L"LackyVaultMainWindow"

/* Privacy and security features */
#define PANIC_HOTKEY_ID 1
#define STEALTH_HOTKEY_ID 2
#define EMERGENCY_HOTKEY_ID 3
#define SECURITY_STATUS_HOTKEY_ID 4
#define ADVANCED_MODE_HOTKEY_ID 5

/* UI State flags */
typedef enum {
    UI_MODE_NORMAL = 0,
    UI_MODE_STEALTH,
    UI_MODE_DECOY,
    UI_MODE_EMERGENCY,
    UI_MODE_PANIC,
    UI_MODE_SECURITY_STATUS
} ui_mode_t;

static ui_mode_t g_ui_mode = UI_MODE_NORMAL;

/* Forward declarations */
LRESULT CALLBACK MainWindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
lacky_error_t InitializeApplication(HINSTANCE hInstance);
lacky_error_t CreateMainInterface(void);
lacky_error_t SetupPrivacyFeatures(void);
lacky_error_t HandlePanicMode(void);
lacky_error_t EnableStealthMode(void);
lacky_error_t ShowDecoyInterface(void);
void RenderMainInterface(HDC hdc, RECT* rect);
void RenderWalletDashboard(HDC hdc, RECT* rect);
void RenderTransactionInterface(HDC hdc, RECT* rect);
void RenderPrivacyControls(HDC hdc, RECT* rect);
void RenderSecurityStatus(HDC hdc, RECT* rect);
void RenderAuthenticationScreen(HDC hdc, RECT* rect);
void RenderDecoyInterface(HDC hdc, RECT* rect);
void RenderFakeWindowsUpdate(HDC hdc, RECT* rect);
void RenderEmergencyInterface(HDC hdc, RECT* rect);

/**
 * Main application entry point
 */
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // Initialize COM
    CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);

    // Initialize common controls
    INITCOMMONCONTROLSEX icex = {0};
    icex.dwSize = sizeof(INITCOMMONCONTROLSEX);
    icex.dwICC = ICC_WIN95_CLASSES | ICC_COOL_CLASSES | ICC_USEREX_CLASSES;
    InitCommonControlsEx(&icex);

    // Enable DPI awareness
    SetProcessDPIAware();

    // Initialize application
    lacky_error_t result = InitializeApplication(hInstance);
    if (result != LACKY_SUCCESS) {
        MessageBoxA(NULL, "Failed to initialize LackyVault", "Fatal Error", MB_ICONERROR);
        return 1;
    }

    // Create main interface
    result = CreateMainInterface();
    if (result != LACKY_SUCCESS) {
        MessageBoxA(NULL, "Failed to create user interface", "Fatal Error", MB_ICONERROR);
        lacky_cleanup(&g_app);
        return 1;
    }

    // Setup privacy and security features
    SetupPrivacyFeatures();

    // Show main window
    ShowWindow(g_app.main_window, nCmdShow);
    UpdateWindow(g_app.main_window);

    // Main message loop with security enhancements
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        // Check for emergency shutdown
        if (g_emergency_shutdown) {
            break;
        }

        // Security: Filter dangerous messages
        if (msg.message == WM_COPYDATA || msg.message == WM_DROPFILES) {
            if (g_ui_mode != UI_MODE_NORMAL) {
                continue; // Block in stealth/panic modes
            }
        }

        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    // Cleanup
    lacky_cleanup(&g_app);
    CoUninitialize();
    
    return (int)msg.wParam;
}

/**
 * Initialize the main application
 */
lacky_error_t InitializeApplication(HINSTANCE hInstance) {
    ZeroMemory(&g_app, sizeof(lacky_app_t));
    
    g_app.hinstance = hInstance;
    g_app.current_state = LACKY_STATE_INIT;

    // Initialize crypto subsystem
    lacky_error_t result = lacky_crypto_init(&g_app.crypto_ctx);
    if (result != LACKY_SUCCESS) {
        return result;
    }

    // Initialize storage subsystem
    result = lacky_storage_init(&g_app.storage);
    if (result != LACKY_SUCCESS) {
        return result;
    }

    // Initialize network subsystem
    result = lacky_network_init(&g_app.network);
    if (result != LACKY_SUCCESS) {
        return result;
    }

    // Initialize security context
    lacky_crypto_random(g_app.security.salt, sizeof(g_app.security.salt));
    g_app.security.authenticated = false;
    g_app.security.panic_mode = false;
    QueryPerformanceCounter(&g_app.security.last_activity);

    // Initialize configuration with secure defaults
    g_app.config.theme = LACKY_THEME_CYBER;
    g_app.config.crypto_algo = LACKY_CRYPTO_XCHACHA20_POLY1305;
    g_app.config.auto_lock_timeout = 300; // 5 minutes
    g_app.config.enable_panic_hotkey = true;
    g_app.config.enable_decoy_wallets = true;
    g_app.config.enable_tor_proxy = true;

    // Initialize event system
    InitializeCriticalSection(&g_app.event_lock);
    g_app.event_head = 0;
    g_app.event_tail = 0;

    // Initialize advanced security integration
    printf("[MAIN] Initializing LackyVault Advanced Security Systems...\n");
    if (security_integration_init()) {
        printf("[MAIN] ✓ Advanced Security Integration: ACTIVE\n");
        
        // Configure security level based on application mode
        security_integration_configure(SECURITY_LEVEL_ADVANCED, false, true);
        
        // Enable anti-analysis protection
        enable_anti_analysis();
        
        printf("[MAIN] ✓ Security Level: ADVANCED\n");
        printf("[MAIN] ✓ Anti-Analysis Protection: ENABLED\n");
    } else {
        printf("[MAIN] ✗ Advanced Security Integration: FAILED (Running in degraded mode)\n");
    }

    g_app.current_state = LACKY_STATE_SPLASH;
    return LACKY_SUCCESS;
}

/**
 * Create the main user interface
 */
lacky_error_t CreateMainInterface(void) {
    // Register window class
    WNDCLASSEXW wc = {0};
    wc.cbSize = sizeof(WNDCLASSEXW);
    wc.style = CS_HREDRAW | CS_VREDRAW | CS_DROPSHADOW;
    wc.lpfnWndProc = MainWindowProc;
    wc.hInstance = g_app.hinstance;
    wc.hIcon = LoadIcon(g_app.hinstance, MAKEINTRESOURCE(100));
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = CreateSolidBrush(RGB(18, 18, 18)); // Dark theme
    wc.lpszClassName = LACKY_WINDOW_CLASS;
    wc.hIconSm = LoadIcon(g_app.hinstance, MAKEINTRESOURCE(100));

    if (!RegisterClassExW(&wc)) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    // Create main window with enhanced security features
    g_app.main_window = CreateWindowExW(
        WS_EX_APPWINDOW | WS_EX_COMPOSITED,
        LACKY_WINDOW_CLASS,
        L"LackyVault - Secure Crypto Wallet",
        WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
        CW_USEDEFAULT, CW_USEDEFAULT,
        LACKY_WINDOW_WIDTH, LACKY_WINDOW_HEIGHT,
        NULL, NULL, g_app.hinstance, NULL
    );

    if (!g_app.main_window) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    // Enable dark mode
    BOOL darkMode = TRUE;
    DwmSetWindowAttribute(g_app.main_window, 
                         DWMWA_USE_IMMERSIVE_DARK_MODE, 
                         &darkMode, sizeof(darkMode));

    // Initialize UI resources
    g_app.fonts[0] = CreateFontW(16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                                DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");

    g_app.fonts[1] = CreateFontW(20, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                                DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                                DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");

    g_app.fonts[2] = CreateFontW(12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                                FIXED_PITCH | FF_MODERN, L"Consolas");

    // Create brushes for cyber theme
    g_app.brushes[0] = CreateSolidBrush(RGB(18, 18, 18));   // Background
    g_app.brushes[1] = CreateSolidBrush(RGB(0, 255, 255));  // Cyan accent
    g_app.brushes[2] = CreateSolidBrush(RGB(255, 0, 128));  // Pink accent
    g_app.brushes[3] = CreateSolidBrush(RGB(128, 255, 0));  // Green accent
    g_app.brushes[4] = CreateSolidBrush(RGB(64, 64, 64));   // Dark gray
    g_app.brushes[5] = CreateSolidBrush(RGB(255, 0, 0));    // Red warning
    g_app.brushes[6] = CreateSolidBrush(RGB(255, 255, 0));  // Yellow warning
    g_app.brushes[7] = CreateSolidBrush(RGB(0, 255, 0));    // Green success

    // Create pens
    g_app.pens[0] = CreatePen(PS_SOLID, 1, RGB(0, 255, 255));
    g_app.pens[1] = CreatePen(PS_SOLID, 2, RGB(255, 0, 128));
    g_app.pens[2] = CreatePen(PS_SOLID, 1, RGB(128, 255, 0));

    return LACKY_SUCCESS;
}

/**
 * Setup privacy and security features
 */
lacky_error_t SetupPrivacyFeatures(void) {
    // Register global hotkeys for emergency functions
    RegisterHotKey(g_app.main_window, PANIC_HOTKEY_ID, 
                   MOD_CONTROL | MOD_SHIFT, VK_F12);
    
    RegisterHotKey(g_app.main_window, STEALTH_HOTKEY_ID,
                   MOD_CONTROL | MOD_ALT, VK_F11);
    
    RegisterHotKey(g_app.main_window, EMERGENCY_HOTKEY_ID,
                   MOD_CONTROL | MOD_SHIFT | MOD_ALT, VK_F10);
    
    // Register new security feature hotkeys
    RegisterHotKey(g_app.main_window, SECURITY_STATUS_HOTKEY_ID,
                   0, VK_F9);
    
    RegisterHotKey(g_app.main_window, ADVANCED_MODE_HOTKEY_ID,
                   0, VK_F8);

    // Enable Tor by default
    if (g_app.network) {
        // lacky_network_set_tor(g_app.network, TRUE);
    }

    // Setup memory protection
    HANDLE process = GetCurrentProcess();
    SetProcessWorkingSetSize(process, (SIZE_T)-1, (SIZE_T)-1);

    return LACKY_SUCCESS;
}

/**
 * Main window procedure with enhanced security
 */
LRESULT CALLBACK MainWindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    static POINT last_cursor_pos = {0};
    static DWORD last_activity_time = 0;
    
    switch (msg) {
        case WM_CREATE:
            // Initialize UI state
            g_app.current_state = LACKY_STATE_AUTH;
            SetTimer(hwnd, 1, 1000, NULL); // Security timer
            break;
        
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);
            
            // Get client area
            RECT rect;
            GetClientRect(hwnd, &rect);
            
            // Render based on current mode
            switch (g_ui_mode) {
                case UI_MODE_NORMAL:
                    RenderMainInterface(hdc, &rect);
                        break;
                case UI_MODE_STEALTH:
                    RenderDecoyInterface(hdc, &rect);
                        break;
                case UI_MODE_DECOY:
                    RenderFakeWindowsUpdate(hdc, &rect);
                        break;
                case UI_MODE_EMERGENCY:
                    RenderEmergencyInterface(hdc, &rect);
                        break;
                case UI_MODE_PANIC:
                    // Show nothing - black screen
                    FillRect(hdc, &rect, g_app.brushes[0]);
                        break;
                case UI_MODE_SECURITY_STATUS:
                    // Full-screen security status display
                    RenderSecurityStatus(hdc, &rect);
                        break;
            }
            
            EndPaint(hwnd, &ps);
            return 0;
        }
        
        case WM_HOTKEY:
            switch (wParam) {
                case PANIC_HOTKEY_ID:
                    HandlePanicMode();
                    
                    // Activate emergency security measures
                    security_randomize_fingerprints();
                    enable_anti_analysis();
                    printf("[SECURITY] Emergency security measures activated!\n");
                    break;
                case STEALTH_HOTKEY_ID:
                    EnableStealthMode();
                    
                    // Display security metrics in stealth mode
                    security_print_metrics();
                    break;
                case EMERGENCY_HOTKEY_ID:
                    g_emergency_shutdown = true;
                    
                    // Emergency security shutdown
                    printf("[SECURITY] Emergency shutdown initiated!\n");
                    security_integration_shutdown();
                    PostQuitMessage(0);
                    break;
                case SECURITY_STATUS_HOTKEY_ID:
                    // Toggle security status display
                    if (g_ui_mode == UI_MODE_SECURITY_STATUS) {
                        g_ui_mode = UI_MODE_NORMAL;
                    } else {
                        g_ui_mode = UI_MODE_SECURITY_STATUS;
                    }
                    
                    printf("[SECURITY] Security status display toggled\n");
                    InvalidateRect(g_app.main_window, NULL, TRUE);
                    break;
                case ADVANCED_MODE_HOTKEY_ID:
                    // Toggle advanced security mode
                    security_status_t status = {0};
                    security_get_status(&status, sizeof(status));
                    
                    int new_level = (status.security_level >= 3) ? 1 : status.security_level + 1;
                    security_integration_configure(new_level, status.stealth_mode, status.defensive_mode);
                    
                    printf("[SECURITY] Security level changed to: %s\n", 
                           new_level == 1 ? "BASIC" :
                           new_level == 2 ? "ADVANCED" : "PARANOID");
                    break;
            }
            break;

        case WM_TIMER:
            // Security monitoring
            if (wParam == 1) {
                DWORD current_time = GetTickCount();
                
                // Auto-lock after timeout
                if (g_app.security.authenticated && 
                    current_time - last_activity_time > g_app.config.auto_lock_timeout * 1000) {
                    g_app.security.authenticated = false;
                    g_app.current_state = LACKY_STATE_AUTH;
                    InvalidateRect(hwnd, NULL, TRUE);
                }

                // Monitor for suspicious activity
                POINT cursor_pos;
                GetCursorPos(&cursor_pos);
                if (cursor_pos.x != last_cursor_pos.x || cursor_pos.y != last_cursor_pos.y) {
                    last_cursor_pos = cursor_pos;
                    last_activity_time = current_time;
                    QueryPerformanceCounter(&g_app.security.last_activity);
                }
            }
            break;

        case WM_MOUSEMOVE:
        case WM_KEYDOWN:
        case WM_LBUTTONDOWN:
        case WM_RBUTTONDOWN:
            // Update activity timestamp
            last_activity_time = GetTickCount();
            QueryPerformanceCounter(&g_app.security.last_activity);
            break;

        case WM_COMMAND:
            // Handle menu commands
            switch (LOWORD(wParam)) {
                case ID_VIEW_THEME_CYBER:
                case ID_VIEW_THEME_COSMIC:
                case ID_VIEW_THEME_LIGHT:
                case ID_VIEW_THEME_DARK:
                case ID_VIEW_THEME_RETRO_80S:
                case ID_VIEW_THEME_RETRO_90S:
                case ID_VIEW_THEME_MATRIX:
                case ID_VIEW_THEME_TERMINAL:
                    {
                        // Map menu ID to theme enum
                        lacky_theme_t new_theme = LACKY_THEME_CYBER;
                        switch (LOWORD(wParam)) {
                            case ID_VIEW_THEME_CYBER: new_theme = LACKY_THEME_CYBER; break;
                            case ID_VIEW_THEME_COSMIC: new_theme = LACKY_THEME_COSMIC; break;
                            case ID_VIEW_THEME_LIGHT: new_theme = LACKY_THEME_LIGHT; break;
                            case ID_VIEW_THEME_DARK: new_theme = LACKY_THEME_DARK; break;
                            case ID_VIEW_THEME_RETRO_80S: new_theme = LACKY_THEME_RETRO_80S; break;
                            case ID_VIEW_THEME_RETRO_90S: new_theme = LACKY_THEME_RETRO_90S; break;
                            case ID_VIEW_THEME_MATRIX: new_theme = LACKY_THEME_MATRIX; break;
                            case ID_VIEW_THEME_TERMINAL: new_theme = LACKY_THEME_TERMINAL; break;
                        }
                        
                        // Update theme
                        g_app.config.theme = new_theme;
                        
                        // Recreate theme resources
                        lacky_theme_cleanup(&g_app);
                        lacky_theme_init(&g_app);
                        
                        // Force redraw
                        InvalidateRect(hwnd, NULL, TRUE);
                        
                        printf("[UI] Theme changed to: %d\n", new_theme);
                    }
                    break;
                    
                default:
                    // Handle UI commands based on current state
                    switch (g_app.current_state) {
                        case LACKY_STATE_AUTH:
                            // Handle authentication commands
                            break;
                        case LACKY_STATE_MAIN:
                            // Handle main interface commands
                            break;
                        case LACKY_STATE_TRANSACTION:
                            // Handle transaction commands
                            break;
                    }
                    break;
            }
            break;

        case WM_CLOSE:
            // Secure shutdown
            if (g_app.security.authenticated) {
                if (MessageBoxW(hwnd, 
                               L"Are you sure you want to exit? All sensitive data will be securely wiped.",
                               L"Confirm Exit", MB_YESNO | MB_ICONQUESTION) != IDYES) {
                    return 0;
                }
            }
            
            // Emergency data wipe
            if (g_app.active_wallet) {
                lacky_wallet_lock(g_app.active_wallet, "");
            }
            
            DestroyWindow(hwnd);
            break;

        case WM_DESTROY:
            // Cleanup hotkeys
            UnregisterHotKey(hwnd, PANIC_HOTKEY_ID);
            UnregisterHotKey(hwnd, STEALTH_HOTKEY_ID);
            UnregisterHotKey(hwnd, EMERGENCY_HOTKEY_ID);
            UnregisterHotKey(hwnd, SECURITY_STATUS_HOTKEY_ID);
            UnregisterHotKey(hwnd, ADVANCED_MODE_HOTKEY_ID);
            
            KillTimer(hwnd, 1);
            PostQuitMessage(0);
            break;

        case WM_WINDOWPOSCHANGING:
            // Prevent window capture in stealth mode
            if (g_ui_mode == UI_MODE_STEALTH || g_ui_mode == UI_MODE_PANIC) {
                SetWindowDisplayAffinity(hwnd, WDA_MONITOR);
            }
            break;

        default:
            return DefWindowProcW(hwnd, msg, wParam, lParam);
    }

            return 0;
        }

/**
 * Render main interface with wallet dashboard
 */
void RenderMainInterface(HDC hdc, RECT* rect) {
    // Set background
    FillRect(hdc, rect, g_app.brushes[0]);
    
    // Draw header
    RECT header_rect = {0, 0, rect->right, 80};
    FillRect(hdc, &header_rect, g_app.brushes[4]);
    
    // Draw cyber-style border
    SelectObject(hdc, g_app.pens[0]);
    MoveToEx(hdc, 0, 80, NULL);
    LineTo(hdc, rect->right, 80);
    
    // Title
    SelectObject(hdc, g_app.fonts[1]);
    SetTextColor(hdc, RGB(0, 255, 255));
    SetBkMode(hdc, TRANSPARENT);
    
    RECT title_rect = {20, 20, rect->right - 20, 60};
    DrawTextW(hdc, L"LackyVault - Secure Crypto Wallet", -1, &title_rect, 
              DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    // Security status indicator
    RECT status_rect = {rect->right - 200, 20, rect->right - 20, 60};
    if (g_app.security.authenticated) {
        SetTextColor(hdc, RGB(0, 255, 0));
        DrawTextW(hdc, L"🔒 SECURE", -1, &status_rect, 
                  DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
    } else {
        SetTextColor(hdc, RGB(255, 255, 0));
        DrawTextW(hdc, L"🔓 LOCKED", -1, &status_rect, 
                  DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
    }

    // Main content area (adjusted for larger footer)
    RECT content_rect = {20, 100, rect->right - 20, rect->bottom - 120};
    
    if (g_app.security.authenticated) {
        RenderWalletDashboard(hdc, &content_rect);
    } else {
        RenderAuthenticationScreen(hdc, &content_rect);
    }
    
    // Footer with privacy controls (increased height for enhanced security display)
    RECT footer_rect = {0, rect->bottom - 100, rect->right, rect->bottom};
    RenderPrivacyControls(hdc, &footer_rect);
}

/**
 * Render wallet dashboard
 */
void RenderWalletDashboard(HDC hdc, RECT* rect) {
    SelectObject(hdc, g_app.fonts[0]);
    SetTextColor(hdc, RGB(255, 255, 255));
    
    // Split the dashboard into main wallet area and security status area
    int security_height = 280;
    RECT wallet_rect = {rect->left, rect->top, rect->right, rect->bottom - security_height};
    RECT security_rect = {rect->left, rect->bottom - security_height, rect->right, rect->bottom};
    
    // Render main wallet area
    // Wallet cards
    int card_width = (wallet_rect.right - wallet_rect.left - 60) / 3;
    int card_height = 120;
    
    for (int i = 0; i < 3; i++) {
        RECT card_rect = {
            wallet_rect.left + i * (card_width + 20),
            wallet_rect.top + 20,
            wallet_rect.left + i * (card_width + 20) + card_width,
            wallet_rect.top + 20 + card_height
        };
        
        // Card background
        FillRect(hdc, &card_rect, g_app.brushes[4]);
        
        // Card border
        SelectObject(hdc, g_app.pens[i % 3]);
        Rectangle(hdc, card_rect.left, card_rect.top, card_rect.right, card_rect.bottom);
        
        // Card content
        RECT text_rect = {card_rect.left + 10, card_rect.top + 10, 
                         card_rect.right - 10, card_rect.bottom - 10};
        
        const wchar_t* currencies[] = {L"Bitcoin", L"Ethereum", L"Monero"};
        const wchar_t* symbols[] = {L"BTC", L"ETH", L"XMR"};
        const wchar_t* balances[] = {L"0.00000000", L"0.000000000000000000", L"0.000000000000"};
        
        // Currency name
        SelectObject(hdc, g_app.fonts[1]);
        DrawTextW(hdc, currencies[i], -1, &text_rect, DT_LEFT | DT_TOP | DT_SINGLELINE);
        
        // Balance
        RECT balance_rect = {text_rect.left, text_rect.top + 30, 
                           text_rect.right, text_rect.bottom};
        SelectObject(hdc, g_app.fonts[2]);
        SetTextColor(hdc, RGB(0, 255, 255));
        DrawTextW(hdc, balances[i], -1, &balance_rect, DT_LEFT | DT_TOP | DT_SINGLELINE);
        
        // Symbol
        RECT symbol_rect = {text_rect.left, text_rect.bottom - 30, 
                          text_rect.right, text_rect.bottom};
        SelectObject(hdc, g_app.fonts[0]);
        SetTextColor(hdc, RGB(128, 255, 0));
        DrawTextW(hdc, symbols[i], -1, &symbol_rect, DT_LEFT | DT_BOTTOM | DT_SINGLELINE);
    }
    
    // Render security status area
    RenderSecurityStatus(hdc, &security_rect);
}

/**
 * Render authentication screen
 */
void RenderAuthenticationScreen(HDC hdc, RECT* rect) {
    // Center authentication panel
    int panel_width = 400;
    int panel_height = 300;
    
    RECT panel_rect = {
        rect->left + (rect->right - rect->left - panel_width) / 2,
        rect->top + (rect->bottom - rect->top - panel_height) / 2,
        rect->left + (rect->right - rect->left - panel_width) / 2 + panel_width,
        rect->top + (rect->bottom - rect->top - panel_height) / 2 + panel_height
    };
    
    // Panel background
    FillRect(hdc, &panel_rect, g_app.brushes[4]);
    SelectObject(hdc, g_app.pens[1]);
    Rectangle(hdc, panel_rect.left, panel_rect.top, panel_rect.right, panel_rect.bottom);
    
    // Title
    RECT title_rect = {panel_rect.left + 20, panel_rect.top + 20,
                      panel_rect.right - 20, panel_rect.top + 60};
    SelectObject(hdc, g_app.fonts[1]);
    SetTextColor(hdc, RGB(255, 0, 128));
    SetBkMode(hdc, TRANSPARENT);
    DrawTextW(hdc, L"Authentication Required", -1, &title_rect, 
              DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    
    // Instructions
    RECT instruction_rect = {panel_rect.left + 20, panel_rect.top + 80,
                           panel_rect.right - 20, panel_rect.top + 120};
    SelectObject(hdc, g_app.fonts[0]);
    SetTextColor(hdc, RGB(255, 255, 255));
    DrawTextW(hdc, L"Enter your master password to unlock the vault", -1, &instruction_rect, 
              DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    
    // Mock password field
    RECT password_rect = {panel_rect.left + 40, panel_rect.top + 140,
                         panel_rect.right - 40, panel_rect.top + 170};
    FillRect(hdc, &password_rect, g_app.brushes[0]);
    SelectObject(hdc, g_app.pens[0]);
    Rectangle(hdc, password_rect.left, password_rect.top, password_rect.right, password_rect.bottom);
    
    // Mock unlock button
    RECT button_rect = {panel_rect.left + 150, panel_rect.top + 200,
                       panel_rect.right - 150, panel_rect.top + 240};
    FillRect(hdc, &button_rect, g_app.brushes[1]);
    SelectObject(hdc, g_app.pens[1]);
    Rectangle(hdc, button_rect.left, button_rect.top, button_rect.right, button_rect.bottom);
    
    RECT button_text_rect = button_rect;
    SelectObject(hdc, g_app.fonts[1]);
    SetTextColor(hdc, RGB(0, 0, 0));
    DrawTextW(hdc, L"UNLOCK", -1, &button_text_rect, 
              DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

/**
 * Render privacy controls footer
 */
void RenderPrivacyControls(HDC hdc, RECT* rect) {
    FillRect(hdc, rect, g_app.brushes[4]);
    
    // Get security status
    security_status_t status = {0};
    security_get_status(&status, sizeof(status));
    
    // Privacy status indicators
    SelectObject(hdc, g_app.fonts[0]);
    SetBkMode(hdc, TRANSPARENT);
    
    // Row 1: Core network privacy features
    int y_pos = rect->top + 15;
    
    RECT tor_rect = {rect->left + 20, y_pos, rect->left + 120, y_pos + 20};
    SetTextColor(hdc, g_app.config.enable_tor_proxy ? RGB(0, 255, 0) : RGB(255, 0, 0));
    DrawTextW(hdc, g_app.config.enable_tor_proxy ? L"🧅 TOR ON" : L"🧅 TOR OFF", -1, &tor_rect, 
              DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    RECT mixer_rect = {rect->left + 140, y_pos, rect->left + 260, y_pos + 20};
    SetTextColor(hdc, status.blockchain_mixer_active ? RGB(0, 255, 0) : RGB(128, 128, 128));
    DrawTextW(hdc, L"🔄 MIXER", -1, &mixer_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    RECT decoy_rect = {rect->left + 280, y_pos, rect->left + 400, y_pos + 20};
    SetTextColor(hdc, status.decoy_traffic_active ? RGB(0, 255, 0) : RGB(128, 128, 128));
    DrawTextW(hdc, L"📡 DECOY", -1, &decoy_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    RECT stealth_rect = {rect->left + 420, y_pos, rect->left + 540, y_pos + 20};
    SetTextColor(hdc, g_ui_mode == UI_MODE_STEALTH ? RGB(255, 0, 128) : RGB(128, 128, 128));
    DrawTextW(hdc, L"👤 STEALTH", -1, &stealth_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    RECT spoof_rect = {rect->left + 560, y_pos, rect->left + 680, y_pos + 20};
    SetTextColor(hdc, status.hardware_spoofing_active ? RGB(0, 255, 0) : RGB(128, 128, 128));
    DrawTextW(hdc, L"🎭 SPOOF", -1, &spoof_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    // Row 2: Advanced security features
    y_pos += 25;
    
    RECT entropy_rect = {rect->left + 20, y_pos, rect->left + 140, y_pos + 20};
    SetTextColor(hdc, status.quantum_entropy_active ? RGB(0, 255, 0) : RGB(128, 128, 128));
    DrawTextW(hdc, L"⚛️ ENTROPY", -1, &entropy_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    RECT mesh_rect = {rect->left + 160, y_pos, rect->left + 260, y_pos + 20};
    SetTextColor(hdc, status.mesh_network_active ? RGB(0, 255, 0) : RGB(128, 128, 128));
    DrawTextW(hdc, L"🕸️ MESH", -1, &mesh_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    RECT biometric_rect = {rect->left + 280, y_pos, rect->left + 400, y_pos + 20};
    SetTextColor(hdc, status.biometric_entropy_active ? RGB(0, 255, 0) : RGB(128, 128, 128));
    DrawTextW(hdc, L"👆 BIOMETRIC", -1, &biometric_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    RECT vm_rect = {rect->left + 420, y_pos, rect->left + 520, y_pos + 20};
    SetTextColor(hdc, status.code_virtualization_active ? RGB(0, 255, 0) : RGB(128, 128, 128));
    DrawTextW(hdc, L"💻 VM", -1, &vm_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    // Security level indicator
    RECT level_rect = {rect->left + 540, y_pos, rect->left + 680, y_pos + 20};
    SetTextColor(hdc, RGB(255, 255, 0));
    wchar_t level_text[50];
    swprintf(level_text, 50, L"🔒 LVL:%d", status.security_level);
    DrawTextW(hdc, level_text, -1, &level_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    // Hotkey hints
    RECT hotkey_rect = {rect->right - 350, rect->top + 15, rect->right - 20, rect->top + 35};
    SetTextColor(hdc, RGB(128, 255, 0));
    DrawTextW(hdc, L"F11: Stealth | F12: Panic | F10: Emergency", -1, &hotkey_rect, 
              DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
    
    // Additional hotkeys
    RECT hotkey2_rect = {rect->right - 350, rect->top + 40, rect->right - 20, rect->top + 60};
    SetTextColor(hdc, RGB(255, 255, 0));
    DrawTextW(hdc, L"F9: Security Status | F8: Toggle Advanced Mode", -1, &hotkey2_rect, 
              DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
}

/**
 * Handle panic mode activation
 */
lacky_error_t HandlePanicMode(void) {
    g_ui_mode = UI_MODE_PANIC;
    g_app.security.panic_mode = true;
    
    // Lock all wallets immediately
    if (g_app.active_wallet) {
        lacky_wallet_lock(g_app.active_wallet, "");
    }
    
    // Clear sensitive memory
    lacky_secure_zero(&g_app.security.master_key, sizeof(g_app.security.master_key));
    lacky_secure_zero(&g_app.security.session_key, sizeof(g_app.security.session_key));
    
    // Hide window
    ShowWindow(g_app.main_window, SW_HIDE);
    
    // Optional: Show decoy interface
    ShowDecoyInterface();
    
    return LACKY_SUCCESS;
}

/**
 * Enable stealth mode
 */
lacky_error_t EnableStealthMode(void) {
    g_ui_mode = UI_MODE_STEALTH;
    
    // Enable window capture protection
    SetWindowDisplayAffinity(g_app.main_window, WDA_MONITOR);
    
    // Change window title
    SetWindowTextW(g_app.main_window, L"System Configuration Utility");
    
    // Minimize to system tray (optional)
    // ShowWindow(g_app.main_window, SW_HIDE);
    
    InvalidateRect(g_app.main_window, NULL, TRUE);
    return LACKY_SUCCESS;
}

/**
 * Show decoy interface (fake Windows update)
 */
lacky_error_t ShowDecoyInterface(void) {
    g_ui_mode = UI_MODE_DECOY;
    
    // Make window fullscreen
    SetWindowLongPtr(g_app.main_window, GWL_STYLE, WS_POPUP);
    SetWindowPos(g_app.main_window, HWND_TOPMOST, 0, 0, 
                GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN),
                SWP_SHOWWINDOW);
    
    InvalidateRect(g_app.main_window, NULL, TRUE);
    return LACKY_SUCCESS;
}

/**
 * Render fake Windows update screen
 */
void RenderFakeWindowsUpdate(HDC hdc, RECT* rect) {
    // Blue background like Windows update
    HBRUSH blue_brush = CreateSolidBrush(RGB(0, 120, 215));
    FillRect(hdc, rect, blue_brush);
    DeleteObject(blue_brush);
    
    // Center content
    RECT content_rect = {
        rect->left + 100,
        rect->top + rect->bottom / 2 - 100,
        rect->right - 100,
        rect->top + rect->bottom / 2 + 100
    };
    
    // Title
    SelectObject(hdc, g_app.fonts[1]);
    SetTextColor(hdc, RGB(255, 255, 255));
    SetBkMode(hdc, TRANSPARENT);
    
    RECT title_rect = content_rect;
    title_rect.bottom = title_rect.top + 40;
    DrawTextW(hdc, L"Working on updates", -1, &title_rect, 
              DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    
    // Percentage
    RECT percent_rect = {content_rect.left, content_rect.top + 60, 
                        content_rect.right, content_rect.top + 100};
    DrawTextW(hdc, L"45% complete", -1, &percent_rect, 
              DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    
    // Instructions
    RECT instruction_rect = {content_rect.left, content_rect.bottom - 40,
                           content_rect.right, content_rect.bottom};
    SelectObject(hdc, g_app.fonts[0]);
    DrawTextW(hdc, L"Don't turn off your computer. This will take a while.", -1, &instruction_rect,
              DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

/**
 * Render emergency interface
 */
void RenderEmergencyInterface(HDC hdc, RECT* rect) {
    // Red background for emergency
    HBRUSH red_brush = CreateSolidBrush(RGB(139, 0, 0));
    FillRect(hdc, rect, red_brush);
    DeleteObject(red_brush);
    
    // Emergency message
    SelectObject(hdc, g_app.fonts[1]);
    SetTextColor(hdc, RGB(255, 255, 255));
    SetBkMode(hdc, TRANSPARENT);
    
    RECT message_rect = *rect;
    DrawTextW(hdc, L"EMERGENCY MODE ACTIVATED\nAll data has been secured", -1, &message_rect,
              DT_CENTER | DT_VCENTER | DT_WORDBREAK);
}

/**
 * Render decoy interface (stealth mode)
 */
void RenderDecoyInterface(HDC hdc, RECT* rect) {
    // Light gray background like Windows dialog
    HBRUSH gray_brush = CreateSolidBrush(RGB(240, 240, 240));
    FillRect(hdc, rect, gray_brush);
    DeleteObject(gray_brush);
    
    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, RGB(0, 0, 0));
    
    // Fake system dialog
    RECT dialog_rect = {
        rect->left + (rect->right - rect->left) / 4,
        rect->top + (rect->bottom - rect->top) / 4,
        rect->right - (rect->right - rect->left) / 4,
        rect->bottom - (rect->bottom - rect->top) / 4
    };
    
    // Dialog background
    HBRUSH white_brush = CreateSolidBrush(RGB(255, 255, 255));
    FillRect(hdc, &dialog_rect, white_brush);
    DeleteObject(white_brush);
    
    // Dialog border
    HPEN border_pen = CreatePen(PS_SOLID, 1, RGB(128, 128, 128));
    HPEN old_pen = (HPEN)SelectObject(hdc, border_pen);
    HBRUSH old_brush = (HBRUSH)SelectObject(hdc, GetStockObject(NULL_BRUSH));
    Rectangle(hdc, dialog_rect.left, dialog_rect.top, dialog_rect.right, dialog_rect.bottom);
    SelectObject(hdc, old_pen);
    SelectObject(hdc, old_brush);
    DeleteObject(border_pen);
    
    // Dialog content
    RECT title_rect = {dialog_rect.left + 20, dialog_rect.top + 20, 
                      dialog_rect.right - 20, dialog_rect.top + 50};
    SelectObject(hdc, g_app.fonts[0]);
    DrawTextW(hdc, L"System Configuration", -1, &title_rect, DT_LEFT | DT_SINGLELINE);
    
    RECT content_rect = {dialog_rect.left + 20, dialog_rect.top + 60, 
                        dialog_rect.right - 20, dialog_rect.bottom - 60};
    DrawTextW(hdc, L"Updating system settings...\n\nThis may take several minutes.\n\nPlease do not close this window.", 
              -1, &content_rect, DT_LEFT | DT_WORDBREAK);
}

/**
 * Render advanced security status dashboard
 */
void RenderSecurityStatus(HDC hdc, RECT* rect) {
    // Get security status from integration layer
    security_status_t status = {0};
    security_get_status(&status, sizeof(status));
    
    // Background with gradient
    FillRect(hdc, rect, g_app.brushes[0]);
    
    // Title
    SelectObject(hdc, g_app.fonts[1]);
    SetTextColor(hdc, RGB(0, 255, 255));
    SetBkMode(hdc, TRANSPARENT);
    
    RECT title_rect = {rect->left + 20, rect->top + 10, rect->right - 20, rect->top + 40};
    DrawTextW(hdc, L"🛡️ ADVANCED SECURITY STATUS", -1, &title_rect, 
              DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    
    // Security components grid
    SelectObject(hdc, g_app.fonts[0]);
    int y_offset = 60;
    int x_left = rect->left + 20;
    int x_right = rect->left + 400;
    
    // Component 1: Blockchain Mixer
    RECT comp1_rect = {x_left, rect->top + y_offset, x_right, rect->top + y_offset + 20};
    SetTextColor(hdc, status.blockchain_mixer_active ? RGB(0, 255, 0) : RGB(255, 0, 0));
    DrawTextW(hdc, status.blockchain_mixer_active ? L"✓ Blockchain Mixer: ACTIVE" : L"✗ Blockchain Mixer: INACTIVE", 
              -1, &comp1_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    y_offset += 25;
    
    // Component 2: Quantum Entropy
    RECT comp2_rect = {x_left, rect->top + y_offset, x_right, rect->top + y_offset + 20};
    SetTextColor(hdc, status.quantum_entropy_active ? RGB(0, 255, 0) : RGB(255, 0, 0));
    DrawTextW(hdc, status.quantum_entropy_active ? L"✓ Quantum Entropy: ACTIVE" : L"✗ Quantum Entropy: INACTIVE", 
              -1, &comp2_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    y_offset += 25;
    
    // Component 3: Decoy Traffic
    RECT comp3_rect = {x_left, rect->top + y_offset, x_right, rect->top + y_offset + 20};
    SetTextColor(hdc, status.decoy_traffic_active ? RGB(0, 255, 0) : RGB(255, 0, 0));
    DrawTextW(hdc, status.decoy_traffic_active ? L"✓ Decoy Traffic: ACTIVE" : L"✗ Decoy Traffic: INACTIVE", 
              -1, &comp3_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    y_offset += 25;
    
    // Component 4: Hardware Spoofing
    RECT comp4_rect = {x_left, rect->top + y_offset, x_right, rect->top + y_offset + 20};
    SetTextColor(hdc, status.hardware_spoofing_active ? RGB(0, 255, 0) : RGB(255, 0, 0));
    DrawTextW(hdc, status.hardware_spoofing_active ? L"✓ Hardware Spoofing: ACTIVE" : L"✗ Hardware Spoofing: INACTIVE", 
              -1, &comp4_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    y_offset += 25;
    
    // Component 5: Mesh Network
    RECT comp5_rect = {x_left, rect->top + y_offset, x_right, rect->top + y_offset + 20};
    SetTextColor(hdc, status.mesh_network_active ? RGB(0, 255, 0) : RGB(255, 0, 0));
    DrawTextW(hdc, status.mesh_network_active ? L"✓ Mesh Network: ACTIVE" : L"✗ Mesh Network: INACTIVE", 
              -1, &comp5_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    y_offset += 25;
    
    // Component 6: Biometric Entropy
    RECT comp6_rect = {x_left, rect->top + y_offset, x_right, rect->top + y_offset + 20};
    SetTextColor(hdc, status.biometric_entropy_active ? RGB(0, 255, 0) : RGB(255, 0, 0));
    DrawTextW(hdc, status.biometric_entropy_active ? L"✓ Biometric Entropy: ACTIVE" : L"✗ Biometric Entropy: INACTIVE", 
              -1, &comp6_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    y_offset += 25;
    
    // Component 7: Code Virtualization
    RECT comp7_rect = {x_left, rect->top + y_offset, x_right, rect->top + y_offset + 20};
    SetTextColor(hdc, status.code_virtualization_active ? RGB(0, 255, 0) : RGB(255, 0, 0));
    DrawTextW(hdc, status.code_virtualization_active ? L"✓ Code Virtualization: ACTIVE" : L"✗ Code Virtualization: INACTIVE", 
              -1, &comp7_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    // Performance metrics on the right side
    int metrics_x = rect->left + 450;
    y_offset = 60;
    
    SetTextColor(hdc, RGB(255, 255, 0));
    RECT metrics_title_rect = {metrics_x, rect->top + y_offset, rect->right - 20, rect->top + y_offset + 20};
    DrawTextW(hdc, L"🔢 PERFORMANCE METRICS", -1, &metrics_title_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    y_offset += 35;
    
    SetTextColor(hdc, RGB(255, 255, 255));
    
    // Entropy bits
    RECT entropy_rect = {metrics_x, rect->top + y_offset, rect->right - 20, rect->top + y_offset + 20};
    wchar_t entropy_text[100];
    swprintf(entropy_text, 100, L"Entropy: %llu bits", status.entropy_bits_generated);
    DrawTextW(hdc, entropy_text, -1, &entropy_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    y_offset += 25;
    
    // Transactions mixed
    RECT tx_rect = {metrics_x, rect->top + y_offset, rect->right - 20, rect->top + y_offset + 20};
    wchar_t tx_text[100];
    swprintf(tx_text, 100, L"Transactions: %llu", status.transactions_mixed);
    DrawTextW(hdc, tx_text, -1, &tx_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    y_offset += 25;
    
    // Decoy packets
    RECT packets_rect = {metrics_x, rect->top + y_offset, rect->right - 20, rect->top + y_offset + 20};
    wchar_t packets_text[100];
    swprintf(packets_text, 100, L"Decoy Packets: %llu", status.decoy_packets_sent);
    DrawTextW(hdc, packets_text, -1, &packets_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    y_offset += 25;
    
    // MAC randomizations
    RECT mac_rect = {metrics_x, rect->top + y_offset, rect->right - 20, rect->top + y_offset + 20};
    wchar_t mac_text[100];
    swprintf(mac_text, 100, L"MAC Changes: %llu", status.mac_randomizations);
    DrawTextW(hdc, mac_text, -1, &mac_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    y_offset += 25;
    
    // VM executions
    RECT vm_rect = {metrics_x, rect->top + y_offset, rect->right - 20, rect->top + y_offset + 20};
    wchar_t vm_text[100];
    swprintf(vm_text, 100, L"VM Executions: %llu", status.vm_executions);
    DrawTextW(hdc, vm_text, -1, &vm_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    // Security level indicator at bottom
    RECT level_rect = {rect->left + 20, rect->bottom - 60, rect->right - 20, rect->bottom - 40};
    SetTextColor(hdc, RGB(255, 0, 128));
    wchar_t level_text[100];
    swprintf(level_text, 100, L"🔒 SECURITY LEVEL: %s", 
             status.security_level == 1 ? L"BASIC" :
             status.security_level == 2 ? L"ADVANCED" : L"PARANOID");
    DrawTextW(hdc, level_text, -1, &level_rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    
    // Mode indicators
    RECT mode_rect = {rect->left + 20, rect->bottom - 35, rect->right - 20, rect->bottom - 15};
    SetTextColor(hdc, RGB(128, 255, 0));
    wchar_t mode_text[200];
    swprintf(mode_text, 200, L"Stealth: %s | Defensive: %s | Performance: %s",
             status.stealth_mode ? L"ON" : L"OFF",
             status.defensive_mode ? L"ON" : L"OFF",
             status.performance_mode ? L"ON" : L"OFF");
    DrawTextW(hdc, mode_text, -1, &mode_rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

/**
 * Cleanup application resources
 */
void lacky_cleanup(lacky_app_t* app) {
    if (!app) return;
    
    // Cleanup network
    if (app->network) {
        lacky_network_cleanup(app->network);
        app->network = NULL;
    }
    
    // Cleanup storage
    lacky_storage_cleanup(&app->storage);
    
    // Cleanup crypto
    lacky_crypto_cleanup(&app->crypto_ctx);
    
    // Cleanup wallet
    if (app->active_wallet) {
        lacky_wallet_cleanup(app->active_wallet);
        app->active_wallet = NULL;
    }
    
    // Cleanup UI resources
    for (int i = 0; i < 4; i++) {
        if (app->fonts[i]) {
            DeleteObject(app->fonts[i]);
        }
    }
    
    for (int i = 0; i < 8; i++) {
        if (app->brushes[i]) {
            DeleteObject(app->brushes[i]);
        }
        if (i < 3 && app->pens[i]) {
            DeleteObject(app->pens[i]);
        }
    }
    
    // Cleanup event system
    DeleteCriticalSection(&app->event_lock);
    
    // Shutdown advanced security integration
    printf("[MAIN] Shutting down advanced security systems...\n");
    security_integration_shutdown();
    printf("[MAIN] ✓ Security integration shutdown complete.\n");
    
    // Secure memory wipe
    lacky_secure_zero(app, sizeof(lacky_app_t));
}
