/**
 * LackyVault - State Management & Event System
 * Lackadaisical Security
 * 
 * Finite state machine and inter-thread communication
 */

#include "../../../include/lacky_vault.h"

/* State transition table */
static const struct {
    lacky_state_t from;
    lacky_state_t to;
    bool allowed;
} state_transitions[] = {
    {LACKY_STATE_INIT, LACKY_STATE_SPLASH, true},
    {LACKY_STATE_SPLASH, LACKY_STATE_AUTH, true},
    {LACKY_STATE_INIT, LACKY_STATE_AUTH, true},
    {LACKY_STATE_AUTH, LACKY_STATE_MAIN, true},
    {LACKY_STATE_AUTH, LACKY_STATE_PANIC, true},
    {LACKY_STATE_MAIN, LACKY_STATE_TRANSACTION, true},
    {LACKY_STATE_MAIN, LACKY_STATE_SETTINGS, true},
    {LACKY_STATE_MAIN, LACKY_STATE_AUTH, true},
    {LACKY_STATE_MAIN, LACKY_STATE_PANIC, true},
    {LACKY_STATE_TRANSACTION, LACKY_STATE_MAIN, true},
    {LACKY_STATE_TRANSACTION, LACKY_STATE_PANIC, true},
    {LACKY_STATE_SETTINGS, LACKY_STATE_MAIN, true},
    {LACKY_STATE_SETTINGS, LACKY_STATE_PANIC, true},
    {LACKY_STATE_PANIC, LACKY_STATE_SHUTDOWN, true},
    {LACKY_STATE_SHUTDOWN, LACKY_STATE_EXIT, true},
    /* Any state can transition to exit */
    {LACKY_STATE_INIT, LACKY_STATE_EXIT, true},
    {LACKY_STATE_SPLASH, LACKY_STATE_EXIT, true},
    {LACKY_STATE_AUTH, LACKY_STATE_EXIT, true},
    {LACKY_STATE_MAIN, LACKY_STATE_EXIT, true},
    {LACKY_STATE_TRANSACTION, LACKY_STATE_EXIT, true},
    {LACKY_STATE_SETTINGS, LACKY_STATE_EXIT, true},
    {LACKY_STATE_PANIC, LACKY_STATE_EXIT, true}
};

/**
 * Check if state transition is allowed
 */
static bool is_transition_allowed(lacky_state_t from, lacky_state_t to) {
    size_t num_transitions = sizeof(state_transitions) / sizeof(state_transitions[0]);
    
    for (size_t i = 0; i < num_transitions; i++) {
        if (state_transitions[i].from == from && 
            state_transitions[i].to == to && 
            state_transitions[i].allowed) {
            return true;
        }
    }
    
    return false;
}

/**
 * Get state name as string
 */
const char* lacky_state_name(lacky_state_t state) {
    switch (state) {
        case LACKY_STATE_INIT: return "INIT";
        case LACKY_STATE_SPLASH: return "SPLASH";
        case LACKY_STATE_AUTH: return "AUTH";
        case LACKY_STATE_MAIN: return "MAIN";
        case LACKY_STATE_TRANSACTION: return "TRANSACTION";
        case LACKY_STATE_SETTINGS: return "SETTINGS";
        case LACKY_STATE_PANIC: return "PANIC";
        case LACKY_STATE_SHUTDOWN: return "SHUTDOWN";
        case LACKY_STATE_EXIT: return "EXIT";
        default: return "UNKNOWN";
    }
}

/**
 * Execute state entry actions
 */
static void execute_state_entry(lacky_app_t* app, lacky_state_t new_state) {
    switch (new_state) {
        case LACKY_STATE_INIT:
            LACKY_DEBUG("Entering INIT state");
            /* Initialization already complete */
            break;
            
        case LACKY_STATE_SPLASH:
            LACKY_DEBUG("Entering SPLASH state");
            /* Show splash screen */
            InvalidateRect(app->main_window, NULL, TRUE);
            break;
            
        case LACKY_STATE_AUTH:
            LACKY_DEBUG("Entering AUTH state");
            /* Clear any existing authentication */
            app->security.authenticated = false;
            lacky_asm_zeroize(app->security.master_key, sizeof(app->security.master_key));
            lacky_asm_zeroize(app->security.session_key, sizeof(app->security.session_key));
            
            /* Invalidate UI to show auth screen */
            InvalidateRect(app->main_window, NULL, TRUE);
            break;
            
        case LACKY_STATE_MAIN:
            LACKY_DEBUG("Entering MAIN state");
            /* Main wallet interface ready */
            InvalidateRect(app->main_window, NULL, TRUE);
            break;
            
        case LACKY_STATE_TRANSACTION:
            LACKY_DEBUG("Entering TRANSACTION state");
            /* Transaction UI ready */
            InvalidateRect(app->main_window, NULL, TRUE);
            break;
            
        case LACKY_STATE_SETTINGS:
            LACKY_DEBUG("Entering SETTINGS state");
            /* Settings UI ready */
            InvalidateRect(app->main_window, NULL, TRUE);
            break;
            
        case LACKY_STATE_PANIC:
            LACKY_DEBUG("Entering PANIC state");
            /* Immediate security actions */
            lacky_panic_mode(app);
            break;
            
        case LACKY_STATE_SHUTDOWN:
            LACKY_DEBUG("Entering SHUTDOWN state");
            /* Begin graceful shutdown */
            app->shutdown_requested = true;
            break;
            
        case LACKY_STATE_EXIT:
            LACKY_DEBUG("Entering EXIT state");
            /* Initiate shutdown */
            app->shutdown_requested = true;
            PostQuitMessage(0);
            break;
    }
}

/**
 * Execute state exit actions
 */
static void execute_state_exit(lacky_app_t* app, lacky_state_t old_state) {
    switch (old_state) {
        case LACKY_STATE_INIT:
            LACKY_DEBUG("Exiting INIT state");
            break;
            
        case LACKY_STATE_SPLASH:
            LACKY_DEBUG("Exiting SPLASH state");
            break;
            
        case LACKY_STATE_AUTH:
            LACKY_DEBUG("Exiting AUTH state");
            break;
            
        case LACKY_STATE_MAIN:
            LACKY_DEBUG("Exiting MAIN state");
            /* Save any pending data */
            break;
            
        case LACKY_STATE_TRANSACTION:
            LACKY_DEBUG("Exiting TRANSACTION state");
            /* Clear transaction data */
            break;
            
        case LACKY_STATE_SETTINGS:
            LACKY_DEBUG("Exiting SETTINGS state");
            /* Save configuration */
            char config_path[MAX_PATH];
            snprintf(config_path, sizeof(config_path), "%s\\lacky_vault.conf", app->config.data_directory);
            lacky_config_save(&app->config, config_path);
            break;
            
        case LACKY_STATE_PANIC:
            LACKY_DEBUG("Exiting PANIC state");
            break;
            
        case LACKY_STATE_SHUTDOWN:
            LACKY_DEBUG("Exiting SHUTDOWN state");
            break;
            
        case LACKY_STATE_EXIT:
            /* Should not exit from EXIT state */
            break;
    }
}

/**
 * Perform state transition
 */
lacky_error_t lacky_state_transition(lacky_app_t* app, lacky_state_t new_state) {
    if (!app) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    lacky_state_t old_state = app->current_state;
    
    /* Check if transition is allowed */
    if (!is_transition_allowed(old_state, new_state)) {
        LACKY_DEBUG("Invalid state transition: %s -> %s", 
                   lacky_state_name(old_state), lacky_state_name(new_state));
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    /* Execute exit actions for old state */
    execute_state_exit(app, old_state);
    
    /* Update state */
    app->current_state = new_state;
    
    /* Execute entry actions for new state */
    execute_state_entry(app, new_state);
    
    /* Post state change event */
    lacky_event_post(app, LACKY_EVENT_STATE_CHANGE, &new_state, sizeof(new_state));
    
    LACKY_DEBUG("State transition: %s -> %s", 
               lacky_state_name(old_state), lacky_state_name(new_state));
    
    return LACKY_SUCCESS;
}

/**
 * Post event to event queue
 */
lacky_error_t lacky_event_post(lacky_app_t* app, lacky_event_type_t type, const void* data, uint32_t size) {
    if (!app) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    if (size > sizeof(((lacky_event_t*)0)->data)) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    EnterCriticalSection(&app->event_lock);
    
    /* Check if queue is full */
    uint32_t next_head = (app->event_head + 1) % LACKY_ARRAY_SIZE(app->event_queue);
    if (next_head == app->event_tail) {
        LeaveCriticalSection(&app->event_lock);
        return LACKY_ERROR_OUT_OF_MEMORY;
    }
    
    /* Add event to queue */
    lacky_event_t* event = &app->event_queue[app->event_head];
    event->type = type;
    event->data_size = size;
    event->processed = 0;
    
    if (data && size > 0) {
        memcpy(event->data, data, size);
    }
    
    /* Update head pointer */
    app->event_head = next_head;
    
    LeaveCriticalSection(&app->event_lock);
    
    return LACKY_SUCCESS;
}

/**
 * Poll event from event queue
 */
lacky_error_t lacky_event_poll(lacky_app_t* app, lacky_event_t* event) {
    if (!app || !event) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    EnterCriticalSection(&app->event_lock);
    
    /* Check if queue is empty */
    if (app->event_tail == app->event_head) {
        LeaveCriticalSection(&app->event_lock);
        return LACKY_ERROR_INVALID_PARAM;  /* No events available */
    }
    
    /* Get event from queue */
    *event = app->event_queue[app->event_tail];
    
    /* Update tail pointer */
    app->event_tail = (app->event_tail + 1) % LACKY_ARRAY_SIZE(app->event_queue);
    
    LeaveCriticalSection(&app->event_lock);
    
    return LACKY_SUCCESS;
}

/**
 * Get current event queue size
 */
uint32_t lacky_event_queue_size(lacky_app_t* app) {
    if (!app) {
        return 0;
    }
    
    EnterCriticalSection(&app->event_lock);
    uint32_t size = (app->event_head - app->event_tail + LACKY_ARRAY_SIZE(app->event_queue)) % 
                    LACKY_ARRAY_SIZE(app->event_queue);
    LeaveCriticalSection(&app->event_lock);
    
    return size;
}

/**
 * Clear all events from queue
 */
void lacky_event_clear(lacky_app_t* app) {
    if (!app) {
        return;
    }
    
    EnterCriticalSection(&app->event_lock);
    app->event_head = 0;
    app->event_tail = 0;
    lacky_asm_zeroize(app->event_queue, sizeof(app->event_queue));
    LeaveCriticalSection(&app->event_lock);
}

/**
 * Handle authentication success
 */
lacky_error_t lacky_handle_auth_success(lacky_app_t* app, const uint8_t* master_key) {
    if (!app || !master_key) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    /* Store master key securely */
    memcpy(app->security.master_key, master_key, LACKY_KEY_SIZE);
    
    /* Derive session key */
    /* Use simple random generation for now */
    srand((unsigned int)GetTickCount());
    for (size_t i = 0; i < LACKY_KEY_SIZE; i++) {
        app->security.session_key[i] = (uint8_t)(rand() % 256);
    }
    
    /* Mark as authenticated */
    app->security.authenticated = true;
    
    /* Update last activity */
    QueryPerformanceCounter(&app->security.last_activity);
    
    /* Transition to main state */
    return lacky_state_transition(app, LACKY_STATE_MAIN);
}

/**
 * Handle authentication failure
 */
lacky_error_t lacky_handle_auth_failure(lacky_app_t* app) {
    if (!app) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    /* Clear any partial authentication data */
    lacky_asm_zeroize(&app->security, sizeof(app->security));
    app->security.authenticated = false;
    
    /* Stay in auth state */
    InvalidateRect(app->main_window, NULL, TRUE);
    
    return LACKY_SUCCESS;
}

/**
 * Check if auto-lock timeout has expired
 */
bool lacky_check_auto_lock(lacky_app_t* app) {
    if (!app || !app->security.authenticated || app->config.auto_lock_timeout == 0) {
        return false;
    }
    
    LARGE_INTEGER current_time;
    QueryPerformanceCounter(&current_time);
    
    LARGE_INTEGER frequency;
    QueryPerformanceFrequency(&frequency);
    
    uint64_t elapsed_ms = ((current_time.QuadPart - app->security.last_activity.QuadPart) * 1000) / frequency.QuadPart;
    
    return elapsed_ms > (app->config.auto_lock_timeout * 1000);
}

/**
 * Update last activity timestamp
 */
void lacky_update_activity(lacky_app_t* app) {
    if (!app) {
        return;
    }
    
    QueryPerformanceCounter(&app->security.last_activity);
}

/**
 * Process pending state machine events
 */
void lacky_process_state_events(lacky_app_t* app) {
    if (!app) {
        return;
    }
    
    /* Check for auto-lock */
    if (lacky_check_auto_lock(app)) {
        LACKY_DEBUG("Auto-lock timeout triggered");
        lacky_state_transition(app, LACKY_STATE_AUTH);
        return;
    }
    
    /* Check for panic mode trigger */
    if (app->panic_triggered) {
        LACKY_DEBUG("Panic mode triggered");
        lacky_state_transition(app, LACKY_STATE_PANIC);
        app->panic_triggered = false;
        return;
    }
    
    /* Process other state-specific logic */
    switch (app->current_state) {
        case LACKY_STATE_INIT:
            /* Automatic transition to auth after initialization */
            if (app->security.salt[0] != 0) {  /* Check if initialized */
                lacky_state_transition(app, LACKY_STATE_AUTH);
            }
            break;
            
        case LACKY_STATE_SPLASH:
            /* Automatic transition after splash timeout */
            /* Transition to auth after brief display */
            lacky_state_transition(app, LACKY_STATE_AUTH);
            break;
            
        case LACKY_STATE_AUTH:
            /* Check for successful authentication */
            if (app->security.authenticated) {
                lacky_state_transition(app, LACKY_STATE_MAIN);
            }
            break;
            
        case LACKY_STATE_MAIN:
        case LACKY_STATE_TRANSACTION:
        case LACKY_STATE_SETTINGS:
            /* Regular operation - handled by UI events */
            break;
            
        case LACKY_STATE_PANIC:
            /* Panic mode active - minimal functionality */
            break;
            
        case LACKY_STATE_SHUTDOWN:
            /* Graceful shutdown in progress */
            lacky_state_transition(app, LACKY_STATE_EXIT);
            break;
            
        case LACKY_STATE_EXIT:
            /* Shutdown in progress */
            break;
    }
}
