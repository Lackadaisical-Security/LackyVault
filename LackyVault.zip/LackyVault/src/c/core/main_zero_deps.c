/**
 * LackyVault - Zero Dependency Main Application
 * Pure C + Assembly implementation with no external libraries
 * Only uses: kernel32.dll, user32.dll, gdi32.dll (always present in Windows)
 */

#include <windows.h>
#include "../../../include/lacky_vault.h"
#include "../../../include/lacky_crypto.h"

/* No external library dependencies - only core Windows DLLs */

/* Global application instance */
static lacky_app_t g_app = {0};
static volatile BOOL g_emergency_shutdown = FALSE;

/* Window class name */
#define LACKY_WINDOW_CLASS L"LackyVaultZeroDeps"

/* Privacy and security modes */
typedef enum {
    UI_MODE_NORMAL = 0,
    UI_MODE_STEALTH,
    UI_MODE_DECOY,
    UI_MODE_PANIC
} ui_mode_t;

static ui_mode_t g_ui_mode = UI_MODE_NORMAL;

/* Assembly function declarations - implemented in src/asm/ */
extern void lacky_asm_chacha20_encrypt(const uint8_t* key, const uint8_t* nonce, 
                                       const uint8_t* plaintext, uint8_t* ciphertext, size_t len);
extern void lacky_asm_poly1305_mac(const uint8_t* key, const uint8_t* data, 
                                   size_t len, uint8_t* mac);
extern void lacky_asm_aes_gcm_encrypt(const uint8_t* key, const uint8_t* iv, 
                                      const uint8_t* plaintext, uint8_t* ciphertext, 
                                      size_t len, uint8_t* tag);
extern void lacky_asm_curve25519_scalarmult(uint8_t* result, const uint8_t* scalar, 
                                           const uint8_t* point);
extern void lacky_asm_zeroize(void* ptr, size_t size);
extern int lacky_asm_secure_memcmp(const void* a, const void* b, size_t len);
extern void lacky_asm_anti_debug_checks(void);
extern uint64_t lacky_asm_rdtsc(void);

/* Zero-dependency random number generation using Windows CAPI */
static HCRYPTPROV g_crypt_prov = 0;

lacky_error_t lacky_random_init(void) {
    // Use CryptAcquireContext from ADVAPI32.dll (always present)
    typedef BOOL (WINAPI *CryptAcquireContextW_t)(HCRYPTPROV*, LPCWSTR, LPCWSTR, DWORD, DWORD);
    typedef BOOL (WINAPI *CryptGenRandom_t)(HCRYPTPROV, DWORD, BYTE*);
    
    HMODULE advapi32 = LoadLibraryW(L"advapi32.dll");
    if (!advapi32) return LACKY_ERROR_CRYPTO_INIT;
    
    CryptAcquireContextW_t CryptAcquireContextW = 
        (CryptAcquireContextW_t)GetProcAddress(advapi32, "CryptAcquireContextW");
    
    if (!CryptAcquireContextW) {
        FreeLibrary(advapi32);
        return LACKY_ERROR_CRYPTO_INIT;
    }
    
    if (!CryptAcquireContextW(&g_crypt_prov, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)) {
        FreeLibrary(advapi32);
        return LACKY_ERROR_CRYPTO_INIT;
    }
    
    return LACKY_SUCCESS;
}

void lacky_crypto_random(uint8_t* buffer, size_t len) {
    if (!g_crypt_prov) {
        // Fallback to GetTickCount-based PRNG (not cryptographically secure)
        DWORD tick = GetTickCount();
        for (size_t i = 0; i < len; i++) {
            tick = tick * 1103515245 + 12345;
            buffer[i] = (uint8_t)(tick >> 16);
        }
        return;
    }
    
    typedef BOOL (WINAPI *CryptGenRandom_t)(HCRYPTPROV, DWORD, BYTE*);
    HMODULE advapi32 = GetModuleHandleW(L"advapi32.dll");
    if (advapi32) {
        CryptGenRandom_t CryptGenRandom = 
            (CryptGenRandom_t)GetProcAddress(advapi32, "CryptGenRandom");
        if (CryptGenRandom) {
            CryptGenRandom(g_crypt_prov, (DWORD)len, buffer);
            return;
        }
    }
    
    // Final fallback
    for (size_t i = 0; i < len; i++) {
        buffer[i] = (uint8_t)(GetTickCount() ^ (i * 17));
    }
}

/* Zero-dependency networking using raw WinSock (ws2_32.dll) */
typedef struct {
    SOCKET sock;
    BOOL tor_enabled;
    char proxy_host[256];
    uint16_t proxy_port;
} zero_deps_network_t;

static zero_deps_network_t g_network = {0};

lacky_error_t lacky_network_init_zero_deps(void) {
    // Load ws2_32.dll dynamically
    HMODULE ws2_32 = LoadLibraryW(L"ws2_32.dll");
    if (!ws2_32) return LACKY_ERROR_NETWORK_INIT;
    
    typedef int (WINAPI *WSAStartup_t)(WORD, LPWSADATA);
    WSAStartup_t WSAStartup = (WSAStartup_t)GetProcAddress(ws2_32, "WSAStartup");
    
    if (!WSAStartup) {
        FreeLibrary(ws2_32);
        return LACKY_ERROR_NETWORK_INIT;
    }
    
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        FreeLibrary(ws2_32);
        return LACKY_ERROR_NETWORK_INIT;
    }
    
    g_network.sock = INVALID_SOCKET;
    g_network.tor_enabled = TRUE;
    lstrcpyA(g_network.proxy_host, "127.0.0.1");
    g_network.proxy_port = 9050; // Tor SOCKS port
    
    return LACKY_SUCCESS;
}

/* Zero-dependency secure memory functions */
void lacky_secure_zero(void* ptr, size_t size) {
    // Use assembly implementation for secure zeroing
    lacky_asm_zeroize(ptr, size);
}

void* lacky_secure_alloc(size_t size) {
    // Use VirtualAlloc for secure memory allocation
    return VirtualAlloc(NULL, size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
}

void lacky_secure_free(void* ptr, size_t size) {
    if (ptr) {
        lacky_secure_zero(ptr, size);
        VirtualFree(ptr, 0, MEM_RELEASE);
    }
}

/* Forward declarations */
LRESULT CALLBACK MainWindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void RenderInterface(HDC hdc, RECT* rect);
void RenderAuthScreen(HDC hdc, RECT* rect);
void RenderWalletDashboard(HDC hdc, RECT* rect);
void RenderDecoyScreen(HDC hdc, RECT* rect);
lacky_error_t HandlePanicMode(void);
lacky_error_t EnableStealthMode(void);

/**
 * Zero-dependency main entry point
 */
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // Initialize with zero dependencies
    ZeroMemory(&g_app, sizeof(lacky_app_t));
    g_app.hinstance = hInstance;
    g_app.current_state = LACKY_STATE_INIT;

    // Initialize random number generator
    if (lacky_random_init() != LACKY_SUCCESS) {
        MessageBoxA(NULL, "Failed to initialize crypto", "Error", MB_ICONERROR);
        return 1;
    }

    // Initialize networking
    if (lacky_network_init_zero_deps() != LACKY_SUCCESS) {
        MessageBoxA(NULL, "Failed to initialize network", "Error", MB_ICONERROR);
        return 1;
    }

    // Register window class
    WNDCLASSW wc = {0};
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = MainWindowProc;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIconW(NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursorW(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.lpszClassName = LACKY_WINDOW_CLASS;

    if (!RegisterClassW(&wc)) {
        MessageBoxA(NULL, "Failed to register window class", "Error", MB_ICONERROR);
        return 1;
    }

    // Create main window
    g_app.main_window = CreateWindowW(
        LACKY_WINDOW_CLASS,
        L"LackyVault - Zero Dependencies Crypto Wallet",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT,
        1200, 800,
        NULL, NULL, hInstance, NULL
    );

    if (!g_app.main_window) {
        MessageBoxA(NULL, "Failed to create main window", "Error", MB_ICONERROR);
        return 1;
    }

    // Initialize security context
    g_app.security.authenticated = FALSE;
    g_app.security.panic_mode = FALSE;
    lacky_crypto_random(g_app.security.salt, sizeof(g_app.security.salt));

    // Anti-debugging checks using assembly
    lacky_asm_anti_debug_checks();

    // Show window
    ShowWindow(g_app.main_window, nCmdShow);
    UpdateWindow(g_app.main_window);

    // Main message loop
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        if (g_emergency_shutdown) break;
        
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    // Cleanup
    if (g_crypt_prov) {
        typedef BOOL (WINAPI *CryptReleaseContext_t)(HCRYPTPROV, DWORD);
        HMODULE advapi32 = GetModuleHandleW(L"advapi32.dll");
        if (advapi32) {
            CryptReleaseContext_t CryptReleaseContext = 
                (CryptReleaseContext_t)GetProcAddress(advapi32, "CryptReleaseContext");
            if (CryptReleaseContext) {
                CryptReleaseContext(g_crypt_prov, 0);
            }
        }
    }

    return (int)msg.wParam;
}

/**
 * Main window procedure
 */
LRESULT CALLBACK MainWindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    static DWORD last_activity = 0;
    
    switch (msg) {
        case WM_CREATE:
            SetTimer(hwnd, 1, 1000, NULL); // Security timer
            last_activity = GetTickCount();
            break;

        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);
            
            RECT rect;
            GetClientRect(hwnd, &rect);
            
            RenderInterface(hdc, &rect);
            
            EndPaint(hwnd, &ps);
            return 0;
        }

        case WM_KEYDOWN:
            last_activity = GetTickCount();
            
            // Panic hotkey: Ctrl+Shift+F12
            if (wParam == VK_F12 && (GetKeyState(VK_CONTROL) & 0x8000) && 
                (GetKeyState(VK_SHIFT) & 0x8000)) {
                HandlePanicMode();
            }
            
            // Stealth hotkey: Ctrl+Alt+F11
            if (wParam == VK_F11 && (GetKeyState(VK_CONTROL) & 0x8000) && 
                (GetKeyState(VK_MENU) & 0x8000)) {
                EnableStealthMode();
            }
            
            // Mock authentication: Enter key
            if (wParam == VK_RETURN && !g_app.security.authenticated) {
                g_app.security.authenticated = TRUE;
                g_app.current_state = LACKY_STATE_MAIN;
                InvalidateRect(hwnd, NULL, TRUE);
            }
            break;

        case WM_TIMER:
            if (wParam == 1) {
                DWORD current_time = GetTickCount();
                
                // Auto-lock after 5 minutes of inactivity
                if (g_app.security.authenticated && 
                    current_time - last_activity > 300000) {
                    g_app.security.authenticated = FALSE;
                    g_app.current_state = LACKY_STATE_AUTH;
                    InvalidateRect(hwnd, NULL, TRUE);
                }
            }
            break;

        case WM_MOUSEMOVE:
        case WM_LBUTTONDOWN:
        case WM_RBUTTONDOWN:
            last_activity = GetTickCount();
            break;

        case WM_CLOSE:
            if (g_app.security.authenticated) {
                if (MessageBoxW(hwnd, 
                               L"Exit and securely wipe all data?",
                               L"Confirm Exit", 
                               MB_YESNO | MB_ICONQUESTION) != IDYES) {
                    return 0;
                }
            }
            DestroyWindow(hwnd);
            break;

        case WM_DESTROY:
            KillTimer(hwnd, 1);
            PostQuitMessage(0);
            break;

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }

    return 0;
}

/**
 * Render main interface
 */
void RenderInterface(HDC hdc, RECT* rect) {
    // Black background
    HBRUSH black_brush = (HBRUSH)GetStockObject(BLACK_BRUSH);
    FillRect(hdc, rect, black_brush);
    
    switch (g_ui_mode) {
        case UI_MODE_NORMAL:
            if (g_app.security.authenticated) {
                RenderWalletDashboard(hdc, rect);
            } else {
                RenderAuthScreen(hdc, rect);
            }
            break;
            
        case UI_MODE_STEALTH:
        case UI_MODE_DECOY:
            RenderDecoyScreen(hdc, rect);
            break;
            
        case UI_MODE_PANIC:
            // Show nothing - black screen
            break;
    }
}

/**
 * Render authentication screen
 */
void RenderAuthScreen(HDC hdc, RECT* rect) {
    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, RGB(0, 255, 255)); // Cyan text
    
    // Title
    RECT title_rect = {rect->left + 50, rect->top + 100, rect->right - 50, rect->top + 150};
    DrawTextW(hdc, L"🔐 LackyVault - Secure Crypto Wallet", -1, &title_rect, 
              DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    
    // Subtitle
    SetTextColor(hdc, RGB(255, 255, 255));
    RECT subtitle_rect = {rect->left + 50, rect->top + 200, rect->right - 50, rect->top + 250};
    DrawTextW(hdc, L"Zero Dependencies • Maximum Security • Full Privacy", -1, &subtitle_rect,
              DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    
    // Instructions
    SetTextColor(hdc, RGB(128, 255, 0)); // Green text
    RECT instruction_rect = {rect->left + 50, rect->top + 350, rect->right - 50, rect->top + 400};
    DrawTextW(hdc, L"Press ENTER to unlock (demo mode)", -1, &instruction_rect,
              DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    
    // Security features
    SetTextColor(hdc, RGB(255, 0, 128)); // Pink text
    RECT features_rect = {rect->left + 50, rect->top + 500, rect->right - 50, rect->top + 650};
    DrawTextW(hdc, L"✓ Assembly-optimized cryptography\n"
                   L"✓ Zero external dependencies\n"
                   L"✓ Anti-debugging protection\n"
                   L"✓ Tor integration ready\n"
                   L"✓ Panic mode (Ctrl+Shift+F12)", 
              -1, &features_rect, DT_CENTER | DT_WORDBREAK);
}

/**
 * Render wallet dashboard
 */
void RenderWalletDashboard(HDC hdc, RECT* rect) {
    SetBkMode(hdc, TRANSPARENT);
    
    // Header
    SetTextColor(hdc, RGB(0, 255, 255));
    RECT header_rect = {rect->left + 20, rect->top + 20, rect->right - 20, rect->top + 60};
    DrawTextW(hdc, L"🔒 LackyVault Dashboard - SECURE MODE", -1, &header_rect,
              DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    // Status indicators
    SetTextColor(hdc, RGB(0, 255, 0));
    RECT status_rect = {rect->left + 20, rect->top + 80, rect->right - 20, rect->top + 120};
    DrawTextW(hdc, L"🟢 TOR READY  🟢 CRYPTO ACTIVE  🟢 ZERO DEPS", -1, &status_rect,
              DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    // Wallet cards
    int card_width = (rect->right - rect->left - 80) / 3;
    int card_height = 150;
    
    for (int i = 0; i < 3; i++) {
        RECT card_rect = {
            rect->left + 20 + i * (card_width + 20),
            rect->top + 150,
            rect->left + 20 + i * (card_width + 20) + card_width,
            rect->top + 150 + card_height
        };
        
        // Card outline
        HPEN pen = CreatePen(PS_SOLID, 2, RGB(0, 255, 255));
        HPEN old_pen = (HPEN)SelectObject(hdc, pen);
        HBRUSH old_brush = (HBRUSH)SelectObject(hdc, GetStockObject(NULL_BRUSH));
        
        Rectangle(hdc, card_rect.left, card_rect.top, card_rect.right, card_rect.bottom);
        
        SelectObject(hdc, old_pen);
        SelectObject(hdc, old_brush);
        DeleteObject(pen);
        
        // Card content
        const wchar_t* currencies[] = {L"Bitcoin (BTC)", L"Ethereum (ETH)", L"Monero (XMR)"};
        const wchar_t* balances[] = {L"0.00000000 BTC", L"0.000000000000000000 ETH", L"0.000000000000 XMR"};
        
        SetTextColor(hdc, RGB(255, 255, 255));
        RECT currency_rect = {card_rect.left + 10, card_rect.top + 20, 
                             card_rect.right - 10, card_rect.top + 50};
        DrawTextW(hdc, currencies[i], -1, &currency_rect, DT_CENTER | DT_SINGLELINE);
        
        SetTextColor(hdc, RGB(128, 255, 0));
        RECT balance_rect = {card_rect.left + 10, card_rect.top + 60, 
                           card_rect.right - 10, card_rect.top + 90};
        DrawTextW(hdc, balances[i], -1, &balance_rect, DT_CENTER | DT_SINGLELINE);
        
        SetTextColor(hdc, RGB(255, 0, 128));
        RECT value_rect = {card_rect.left + 10, card_rect.top + 100, 
                         card_rect.right - 10, card_rect.top + 130};
        DrawTextW(hdc, L"$0.00 USD", -1, &value_rect, DT_CENTER | DT_SINGLELINE);
    }
    
    // Transaction history
    SetTextColor(hdc, RGB(255, 255, 255));
    RECT tx_title_rect = {rect->left + 20, rect->top + 350, rect->right - 20, rect->top + 380};
    DrawTextW(hdc, L"Recent Transactions", -1, &tx_title_rect, DT_LEFT | DT_SINGLELINE);
    
    SetTextColor(hdc, RGB(128, 128, 128));
    RECT tx_empty_rect = {rect->left + 20, rect->top + 400, rect->right - 20, rect->top + 430};
    DrawTextW(hdc, L"No transactions yet - fully private and secure", -1, &tx_empty_rect, 
              DT_LEFT | DT_SINGLELINE);
    
    // Footer with hotkeys
    SetTextColor(hdc, RGB(255, 255, 0));
    RECT footer_rect = {rect->left + 20, rect->bottom - 60, rect->right - 20, rect->bottom - 30};
    DrawTextW(hdc, L"Hotkeys: Ctrl+Shift+F12=Panic | Ctrl+Alt+F11=Stealth", -1, &footer_rect,
              DT_CENTER | DT_SINGLELINE);
}

/**
 * Render decoy screen (fake system dialog)
 */
void RenderDecoyScreen(HDC hdc, RECT* rect) {
    // Light gray background like Windows dialog
    HBRUSH gray_brush = CreateSolidBrush(RGB(240, 240, 240));
    FillRect(hdc, rect, gray_brush);
    DeleteObject(gray_brush);
    
    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, RGB(0, 0, 0));
    
    // Fake system dialog
    RECT dialog_rect = {
        rect->left + (rect->right - rect->left) / 4,
        rect->top + (rect->bottom - rect->top) / 4,
        rect->right - (rect->right - rect->left) / 4,
        rect->bottom - (rect->bottom - rect->top) / 4
    };
    
    // Dialog background
    HBRUSH white_brush = CreateSolidBrush(RGB(255, 255, 255));
    FillRect(hdc, &dialog_rect, white_brush);
    DeleteObject(white_brush);
    
    // Dialog border
    HPEN border_pen = CreatePen(PS_SOLID, 1, RGB(128, 128, 128));
    HPEN old_pen = (HPEN)SelectObject(hdc, border_pen);
    HBRUSH old_brush = (HBRUSH)SelectObject(hdc, GetStockObject(NULL_BRUSH));
    Rectangle(hdc, dialog_rect.left, dialog_rect.top, dialog_rect.right, dialog_rect.bottom);
    SelectObject(hdc, old_pen);
    SelectObject(hdc, old_brush);
    DeleteObject(border_pen);
    
    // Dialog content
    RECT title_rect = {dialog_rect.left + 20, dialog_rect.top + 20, 
                      dialog_rect.right - 20, dialog_rect.top + 50};
    DrawTextW(hdc, L"System Configuration", -1, &title_rect, DT_LEFT | DT_SINGLELINE);
    
    RECT content_rect = {dialog_rect.left + 20, dialog_rect.top + 60, 
                        dialog_rect.right - 20, dialog_rect.bottom - 60};
    DrawTextW(hdc, L"Updating system settings...\n\nThis may take several minutes.\n\nPlease do not close this window.", 
              -1, &content_rect, DT_LEFT | DT_WORDBREAK);
}

/**
 * Handle panic mode
 */
lacky_error_t HandlePanicMode(void) {
    g_ui_mode = UI_MODE_PANIC;
    g_app.security.panic_mode = TRUE;
    g_app.security.authenticated = FALSE;
    
    // Secure memory wipe using assembly
    lacky_asm_zeroize(&g_app.security, sizeof(g_app.security));
    
    // Hide window
    ShowWindow(g_app.main_window, SW_HIDE);
    
    // Optional: Create decoy window
    // ShowDecoyInterface();
    
    InvalidateRect(g_app.main_window, NULL, TRUE);
    return LACKY_SUCCESS;
}

/**
 * Enable stealth mode
 */
lacky_error_t EnableStealthMode(void) {
    g_ui_mode = (g_ui_mode == UI_MODE_STEALTH) ? UI_MODE_NORMAL : UI_MODE_STEALTH;
    
    if (g_ui_mode == UI_MODE_STEALTH) {
        SetWindowTextW(g_app.main_window, L"System Configuration");
    } else {
        SetWindowTextW(g_app.main_window, L"LackyVault - Zero Dependencies Crypto Wallet");
    }
    
    InvalidateRect(g_app.main_window, NULL, TRUE);
    return LACKY_SUCCESS;
} 