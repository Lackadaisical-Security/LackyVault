/**
 * LackyVault - Security & Panic Mode
 * Lackadaisical Security
 * 
 * Security functions, integrity checking, and panic mode implementation
 */

#include "../../../include/lacky_vault.h"
#include "../../../include/lacky_crypto.h"
#include <psapi.h>
#include <tlhelp32.h>

/* Forward declarations */
static void show_fake_update_screen(lacky_app_t* app);
static void draw_fake_update_progress(HDC hdc, RECT* client_rect);

/* Security check intervals */
#define SECURITY_CHECK_INTERVAL_MS 5000
#define INTEGRITY_CHECK_INTERVAL_MS 30000

/* Panic mode state */
static volatile bool g_panic_mode_active = false;
static volatile uint32_t g_fake_progress = 0;

/**
 * Secure memory allocation
 */
void* lacky_secure_alloc(size_t size) {
    if (size == 0) {
        return NULL;
    }
    
    void* ptr = malloc(size);
    if (ptr) {
        lacky_secure_zero(ptr, size);
    }
    return ptr;
}

/**
 * Secure memory deallocation
 */
void lacky_secure_free(void* ptr, size_t size) {
    if (ptr && size > 0) {
        lacky_secure_zero(ptr, size);
        free(ptr);
    }
}

/**
 * Secure memory zeroing
 */
void lacky_secure_zero(void* ptr, size_t size) {
    if (ptr && size > 0) {
        volatile char* vptr = (volatile char*)ptr;
        for (size_t i = 0; i < size; i++) {
            vptr[i] = 0;
        }
    }
}

/**
 * Secure memory comparison
 */
int lacky_secure_memcmp(const void* a, const void* b, size_t len) {
    if (!a || !b) {
        return -1;
    }
    
    const volatile unsigned char* va = (const volatile unsigned char*)a;
    const volatile unsigned char* vb = (const volatile unsigned char*)b;
    volatile unsigned char result = 0;
    
    for (size_t i = 0; i < len; i++) {
        result |= va[i] ^ vb[i];
    }
    
    return result;
}

/* Known good hashes for integrity checking */
static const uint8_t expected_code_hash[LACKY_SHA256_DIGEST_SIZE] = {
    /* This would be computed at build time */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

/**
 * Secure memory zeroization using assembly
 */
void lacky_zeroize_memory(void* ptr, size_t size) {
    if (!ptr || size == 0) return;
    
    lacky_asm_zeroize(ptr, size);
}

/**
 * Derive master key from password using Argon2id
 */
lacky_error_t lacky_derive_key(const char* password, const uint8_t* salt, uint8_t* key) {
    if (!password || !salt || !key) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    lacky_argon2_ctx_t ctx = {
        .memory_kb = LACKY_ARGON2_MEMORY_KB,
        .iterations = LACKY_ARGON2_ITERATIONS,
        .parallelism = LACKY_ARGON2_PARALLELISM,
        .hash_len = LACKY_KEY_SIZE,
        .salt_len = LACKY_SALT_SIZE,
        .password = (const uint8_t*)password,
        .password_len = strlen(password),
        .salt = salt,
        .hash = key
    };
    
    int result = lacky_argon2id(&ctx);
    
    /* Clear password from memory if possible */
    if (strlen(password) < 1024) {
        lacky_zeroize_memory((void*)password, strlen(password));
    }
    
    return (result == 0) ? LACKY_SUCCESS : LACKY_ERROR_CRYPTO_FAIL;
}

/**
 * Verify code integrity
 */
bool lacky_verify_integrity(void) {
    /* Get current module handle */
    HMODULE hModule = GetModuleHandle(NULL);
    if (!hModule) return false;
    
    /* Get module information */
    MODULEINFO modinfo;
    if (!GetModuleInformation(GetCurrentProcess(), hModule, &modinfo, sizeof(modinfo))) {
        return false;
    }
    
    /* Calculate hash of .text section */
    uint8_t calculated_hash[LACKY_SHA256_DIGEST_SIZE];
    lacky_sha256((const uint8_t*)modinfo.lpBaseOfDll, modinfo.SizeOfImage, calculated_hash);
      /* Compare with expected hash */
    /* Note: In production, this would use the actual computed hash */
    return lacky_secure_memcmp(calculated_hash, expected_code_hash, LACKY_SHA256_DIGEST_SIZE) == 0;
}

/**
 * Check for running debuggers
 */
static bool check_debugger_advanced(void) {
    uint32_t result;
    
    /* Check PEB flags */
    __asm__ volatile (
        "mov %%gs:0x60, %%rax\n"        // PEB
        "movzbl 0x02(%%rax), %%eax\n"   // BeingDebugged flag
        "test %%al, %%al\n"
        "setne %%al\n"
        "movzbl %%al, %%eax\n"
        : "=a" (result)
        :
        : "memory"
    );
    
    if (result) return true;
    
    /* Check NtGlobalFlag */
    __asm__ volatile (
        "mov %%gs:0x60, %%rax\n"        // PEB
        "mov 0x68(%%rax), %%eax\n"      // NtGlobalFlag
        "and $0x70, %%eax\n"           // Check debug flags
        "setne %%al\n"
        "movzbl %%al, %%eax\n"
        : "=a" (result)
        :
        : "memory"
    );
    
    if (result) return true;
    
    /* Check for hardware breakpoints */
    CONTEXT ctx = {0};
    ctx.ContextFlags = CONTEXT_DEBUG_REGISTERS;
    
    if (GetThreadContext(GetCurrentThread(), &ctx)) {
        if (ctx.Dr0 || ctx.Dr1 || ctx.Dr2 || ctx.Dr3) {
            return true;
        }
    }
    
    /* Check for software breakpoints */
    uint8_t* code_start = (uint8_t*)GetModuleHandle(NULL);
    for (size_t i = 0; i < 4096; i++) {
        if (code_start[i] == 0xCC) {  // INT3 breakpoint
            return true;
        }
    }
    
    return false;
}

/**
 * Anti-VM detection
 */
static bool check_virtual_machine(void) {
    /* Check for VM-specific registry keys */
    HKEY hkey;
    
    const char* vm_keys[] = {
        "HARDWARE\\Description\\System\\SystemBiosVersion",
        "HARDWARE\\Description\\System\\VideoBiosVersion",
        "SOFTWARE\\VMware, Inc.\\VMware Tools",
        "SOFTWARE\\Oracle\\VirtualBox Guest Additions"
    };
    
    for (size_t i = 0; i < sizeof(vm_keys) / sizeof(vm_keys[0]); i++) {
        if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, vm_keys[i], 0, KEY_READ, &hkey) == ERROR_SUCCESS) {
            RegCloseKey(hkey);
            return true;
        }
    }
    
    /* Check for VM-specific processes */
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot != INVALID_HANDLE_VALUE) {
        PROCESSENTRY32 pe32 = {0};
        pe32.dwSize = sizeof(PROCESSENTRY32);
        
        if (Process32First(snapshot, &pe32)) {
            do {
                const char* vm_processes[] = {
                    "vmtoolsd.exe", "vmwaretray.exe", "vmwareuser.exe",
                    "vboxservice.exe", "vboxtray.exe", "vboxcontrol.exe"
                };
                
                for (size_t i = 0; i < sizeof(vm_processes) / sizeof(vm_processes[0]); i++) {
                    if (_stricmp(pe32.szExeFile, vm_processes[i]) == 0) {
                        CloseHandle(snapshot);
                        return true;
                    }
                }
            } while (Process32Next(snapshot, &pe32));
        }
        
        CloseHandle(snapshot);
    }
    
    /* Check CPU features */
    uint32_t cpuid_result[4];
    __asm__ volatile (
        "cpuid"
        : "=a" (cpuid_result[0]), "=b" (cpuid_result[1]), 
          "=c" (cpuid_result[2]), "=d" (cpuid_result[3])
        : "a" (0x40000000)
    );
    
    /* Check for hypervisor bit */
    if (cpuid_result[2] & (1 << 31)) {
        return true;
    }
    
    return false;
}

/**
 * Comprehensive security checks
 */
static bool perform_security_checks(void) {
    /* Check for debuggers */
    if (check_debugger_advanced()) {
        LACKY_DEBUG("Debugger detected");
        return false;
    }
    
    /* Check for virtual machines */
    if (check_virtual_machine()) {
        LACKY_DEBUG("Virtual machine detected");
        return false;
    }
    
    /* Check for code injection */
    if (!lacky_verify_integrity()) {
        LACKY_DEBUG("Code integrity check failed");
        return false;
    }
    
    /* Check for suspicious modules */
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, GetCurrentProcessId());
    if (snapshot != INVALID_HANDLE_VALUE) {
        MODULEENTRY32 me32 = {0};
        me32.dwSize = sizeof(MODULEENTRY32);
        
        if (Module32First(snapshot, &me32)) {
            do {
                /* Check for known analysis tools */
                const char* suspicious_modules[] = {
                    "dbghelp.dll", "wininet.dll", "urlmon.dll"
                };
                
                for (size_t i = 0; i < sizeof(suspicious_modules) / sizeof(suspicious_modules[0]); i++) {
                    if (_stricmp(me32.szModule, suspicious_modules[i]) == 0) {
                        LACKY_DEBUG("Suspicious module detected: %s", me32.szModule);
                        CloseHandle(snapshot);
                        return false;
                    }
                }
            } while (Module32Next(snapshot, &me32));
        }
        
        CloseHandle(snapshot);
    }
    
    return true;
}

/**
 * Activate panic mode
 */
void lacky_panic_mode(lacky_app_t* app) {
    if (!app) return;
    
    LACKY_DEBUG("PANIC MODE ACTIVATED");
    
    /* Set panic flag */
    g_panic_mode_active = true;
    app->security.panic_mode = true;
    app->panic_triggered = true;
      /* Immediate key zeroization */
    lacky_asm_zeroize(&app->security, sizeof(app->security));
    
    /* Clear event queue - TODO: implement event system */
    /* lacky_event_clear(app); */
    
    /* Zeroize wallet data */
    if (app->active_wallet) {
        lacky_wallet_cleanup(app->active_wallet);
        app->active_wallet = NULL;
    }
    
    /* Show fake update screen */
    show_fake_update_screen(app);
    
    /* Lock virtual filesystem */
    /* Implementation would lock all encrypted storage */
    
    /* Clear network connections */
    if (app->network) {
        lacky_network_cleanup(app->network);
        app->network = NULL;
    }
    
    /* Disable all hotkeys except recovery */
    UnregisterHotKey(app->main_window, 1);
    
    /* Start fake progress animation */
    SetTimer(app->main_window, 999, 100, NULL);  // 100ms timer for fake progress
}

/**
 * Show fake update screen during panic mode
 */
static void show_fake_update_screen(lacky_app_t* app) {
    if (!app || !app->main_window) return;
    
    /* Invalidate entire window */
    InvalidateRect(app->main_window, NULL, TRUE);
    
    /* Force immediate repaint */
    UpdateWindow(app->main_window);
}

/**
 * Draw fake update progress
 */
static void draw_fake_update_progress(HDC hdc, RECT* client_rect) {
    /* Dark background */
    HBRUSH bg_brush = CreateSolidBrush(RGB(32, 32, 32));
    FillRect(hdc, client_rect, bg_brush);
    DeleteObject(bg_brush);
    
    /* Title text */    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, RGB(255, 255, 255));
    HFONT title_font = CreateFontA(24, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                                   DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                                   CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Segoe UI");
    
    HFONT old_font = (HFONT)SelectObject(hdc, title_font);
    
    RECT title_rect = *client_rect;
    title_rect.top += 100;
    title_rect.bottom = title_rect.top + 40;
    
    DrawTextA(hdc, "Windows Update", -1, &title_rect, DT_CENTER | DT_VCENTER);
    
    /* Status text */
    HFONT status_font = CreateFontA(16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                    DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                                    CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Segoe UI");
    
    SelectObject(hdc, status_font);
    
    RECT status_rect = *client_rect;
    status_rect.top += 180;
    status_rect.bottom = status_rect.top + 30;
    
    DrawTextA(hdc, "Installing security updates... Please wait.", -1, &status_rect, DT_CENTER | DT_VCENTER);
    
    /* Progress bar */
    RECT progress_rect;
    progress_rect.left = client_rect->left + 100;
    progress_rect.right = client_rect->right - 100;
    progress_rect.top = client_rect->top + 250;
    progress_rect.bottom = progress_rect.top + 20;
    
    /* Progress bar background */
    HBRUSH progress_bg = CreateSolidBrush(RGB(64, 64, 64));
    FillRect(hdc, &progress_rect, progress_bg);
    DeleteObject(progress_bg);
    
    /* Progress bar fill */
    if (g_fake_progress > 100) g_fake_progress = 0;
    
    RECT fill_rect = progress_rect;
    fill_rect.right = fill_rect.left + ((fill_rect.right - fill_rect.left) * g_fake_progress) / 100;
    
    HBRUSH progress_fill = CreateSolidBrush(RGB(0, 120, 215));  // Windows blue
    FillRect(hdc, &fill_rect, progress_fill);
    DeleteObject(progress_fill);
    
    /* Progress percentage */
    char progress_text[32];
    snprintf(progress_text, sizeof(progress_text), "%u%% complete", g_fake_progress);
    
    RECT percent_rect = *client_rect;
    percent_rect.top += 280;
    percent_rect.bottom = percent_rect.top + 25;
    
    DrawTextA(hdc, progress_text, -1, &percent_rect, DT_CENTER | DT_VCENTER);
    
    /* Cleanup */
    SelectObject(hdc, old_font);
    DeleteObject(title_font);
    DeleteObject(status_font);
    
    /* Increment fake progress */
    g_fake_progress += 2;
}

/**
 * Handle panic mode recovery
 */
lacky_error_t lacky_panic_recovery(lacky_app_t* app, const char* recovery_password) {
    if (!app || !recovery_password) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    if (!g_panic_mode_active) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    /* Verify recovery password */
    /* This would implement dual-factor authentication */
    
    /* For now, simple password check */
    if (strcmp(recovery_password, "recovery_password_123") != 0) {
        return LACKY_ERROR_AUTH_FAIL;
    }
    
    /* Reset panic mode */
    g_panic_mode_active = false;
    app->security.panic_mode = false;
    app->panic_triggered = false;
    g_fake_progress = 0;
    
    /* Kill fake progress timer */
    KillTimer(app->main_window, 999);
    
    /* Re-register panic hotkey */
    RegisterHotKey(app->main_window, 1, MOD_CONTROL | MOD_ALT, 'D');
    
    /* Transition back to auth state */
    return lacky_state_transition(app, LACKY_STATE_AUTH);
}

/**
 * Check if panic mode is active
 */
bool lacky_is_panic_mode(void) {
    return g_panic_mode_active;
}

/**
 * Security monitor main function
 */
void lacky_security_monitor(lacky_app_t* app) {
    static LARGE_INTEGER last_check = {0};
    static LARGE_INTEGER last_integrity_check = {0};
    
    LARGE_INTEGER current_time;
    QueryPerformanceCounter(&current_time);
    
    LARGE_INTEGER frequency;
    QueryPerformanceFrequency(&frequency);
    
    /* Convert to milliseconds */
    uint64_t current_ms = (current_time.QuadPart * 1000) / frequency.QuadPart;
    uint64_t last_check_ms = (last_check.QuadPart * 1000) / frequency.QuadPart;
    uint64_t last_integrity_ms = (last_integrity_check.QuadPart * 1000) / frequency.QuadPart;
    
    /* Regular security checks */
    if (current_ms - last_check_ms >= SECURITY_CHECK_INTERVAL_MS) {
        if (!perform_security_checks()) {
            lacky_panic_mode(app);
            return;
        }
        last_check = current_time;
    }
    
    /* Integrity checks (less frequent) */
    if (current_ms - last_integrity_ms >= INTEGRITY_CHECK_INTERVAL_MS) {
        if (!lacky_verify_integrity()) {
            lacky_panic_mode(app);
            return;
        }
        last_integrity_check = current_time;
    }
}

/**
 * Emergency shutdown
 */
void lacky_emergency_shutdown(lacky_app_t* app) {
    if (!app) return;
    
    /* Immediate panic mode */
    lacky_panic_mode(app);
    
    /* Force process termination after brief delay */
    Sleep(2000);  // Allow fake screen to display
    
    TerminateProcess(GetCurrentProcess(), 1);
}
