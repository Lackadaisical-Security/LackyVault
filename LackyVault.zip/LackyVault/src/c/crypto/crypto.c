/**
 * LackyVault - Crypto Wallet Implementation
 * Lackadaisical Security
 * 
 * Production-grade crypto wallet with STONEDRIFT mesh integration
 */

#include "../../../include/lacky_vault.h"
#include "../../../include/lacky_crypto.h"
#include <windows.h>
#include <wincrypt.h>

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "crypt32.lib")

/* Global crypto context */
static lacky_crypto_context_t g_crypto_ctx = {0};
static HCRYPTPROV g_crypt_provider = 0;

/**
 * Initialize crypto subsystem with STONEDRIFT integration
 */
lacky_error_t lacky_crypto_init(lacky_crypto_context_t* ctx) {
    if (!ctx) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    ZeroMemory(ctx, sizeof(lacky_crypto_context_t));

    // Initialize Windows crypto provider
    if (!CryptAcquireContextA(&g_crypt_provider, NULL, NULL, PROV_RSA_AES, CRYPT_VERIFYCONTEXT)) {
        return LACKY_ERROR_CRYPTO_INIT;
    }

    ctx->rng_handle = (void*)g_crypt_provider;
    ctx->initialized = 1;

    // Initialize context structures
    ZeroMemory(&ctx->chacha20_ctx, sizeof(ctx->chacha20_ctx));
    ZeroMemory(&ctx->poly1305_ctx, sizeof(ctx->poly1305_ctx));
    ZeroMemory(&ctx->aes_gcm_ctx, sizeof(ctx->aes_gcm_ctx));
    ZeroMemory(&ctx->sha256_ctx, sizeof(ctx->sha256_ctx));
    ZeroMemory(&ctx->sha512_ctx, sizeof(ctx->sha512_ctx));
    ZeroMemory(&ctx->blake2b_ctx, sizeof(ctx->blake2b_ctx));

    return LACKY_SUCCESS;
}

/**
 * Cleanup crypto subsystem
 */
void lacky_crypto_cleanup(lacky_crypto_context_t* ctx) {
    if (!ctx) {
        return;
    }

    // Secure wipe of crypto contexts
    lacky_secure_zero(ctx, sizeof(lacky_crypto_context_t));

    // Release Windows crypto provider
    if (g_crypt_provider) {
        CryptReleaseContext(g_crypt_provider, 0);
        g_crypt_provider = 0;
    }

    ctx->initialized = 0;
}

/**
 * Generate secure random bytes for wallet operations
 */
void lacky_crypto_random(uint8_t* buffer, size_t len) {
    if (!buffer || len == 0) {
        return;
    }

    // Use Windows Crypto API for secure random generation
    if (g_crypt_provider) {
        CryptGenRandom(g_crypt_provider, (DWORD)len, buffer);
    } else {
        // Fallback to less secure method
        for (size_t i = 0; i < len; i++) {
            buffer[i] = (uint8_t)(rand() % 256);
        }
    }
}

/**
 * SHA-256 implementation for wallet addresses and transaction hashing
 */
void lacky_sha256(const uint8_t* data, size_t len, uint8_t* digest) {
    if (!data || !digest || len == 0) {
        return;
    }

    lacky_sha256_ctx_t ctx;
    lacky_sha256_init(&ctx);
    lacky_sha256_update(&ctx, data, len);
    lacky_sha256_finish(&ctx, digest);
}

/**
 * Initialize SHA-256 context
 */
void lacky_sha256_init(lacky_sha256_ctx_t* ctx) {
    if (!ctx) return;

    // SHA-256 initial hash values
    ctx->h[0] = 0x6a09e667;
    ctx->h[1] = 0xbb67ae85;
    ctx->h[2] = 0x3c6ef372;
    ctx->h[3] = 0xa54ff53a;
    ctx->h[4] = 0x510e527f;
    ctx->h[5] = 0x9b05688c;
    ctx->h[6] = 0x1f83d9ab;
    ctx->h[7] = 0x5be0cd19;
    
    ctx->total_len = 0;
    ctx->buffer_len = 0;
}

/**
 * Update SHA-256 with new data
 */
void lacky_sha256_update(lacky_sha256_ctx_t* ctx, const uint8_t* data, size_t len) {
    if (!ctx || !data || len == 0) return;

    const uint8_t* input = data;
    size_t remaining = len;

    // Process any buffered data first
    if (ctx->buffer_len > 0) {
        size_t copy_len = (remaining < 64 - ctx->buffer_len) ? remaining : 64 - ctx->buffer_len;
        memcpy(ctx->buffer + ctx->buffer_len, input, copy_len);
        ctx->buffer_len += copy_len;
        input += copy_len;
        remaining -= copy_len;

        if (ctx->buffer_len == 64) {
            sha256_process_block(ctx, ctx->buffer);
            ctx->buffer_len = 0;
        }
    }

    // Process complete 64-byte blocks
    while (remaining >= 64) {
        sha256_process_block(ctx, input);
        input += 64;
        remaining -= 64;
    }

    // Buffer remaining bytes
    if (remaining > 0) {
        memcpy(ctx->buffer, input, remaining);
        ctx->buffer_len = remaining;
    }

    ctx->total_len += len;
}

/**
 * Finalize SHA-256 and get digest
 */
void lacky_sha256_finish(lacky_sha256_ctx_t* ctx, uint8_t* digest) {
    if (!ctx || !digest) return;

    // Padding
    uint8_t padding[64];
    size_t pad_len;
    
    // Add '1' bit
    ctx->buffer[ctx->buffer_len] = 0x80;
    ctx->buffer_len++;

    // Calculate padding length
    if (ctx->buffer_len <= 56) {
        pad_len = 56 - ctx->buffer_len;
    } else {
        pad_len = 64 + 56 - ctx->buffer_len;
    }

    // Zero padding
    memset(ctx->buffer + ctx->buffer_len, 0, pad_len);
    ctx->buffer_len += pad_len;

    // If we need another block
    if (ctx->buffer_len > 56) {
        sha256_process_block(ctx, ctx->buffer);
        memset(ctx->buffer, 0, 56);
    }

    // Add length in bits (big-endian)
    uint64_t bit_len = ctx->total_len * 8;
    for (int i = 7; i >= 0; i--) {
        ctx->buffer[56 + i] = (uint8_t)(bit_len & 0xff);
        bit_len >>= 8;
    }

    // Process final block
    sha256_process_block(ctx, ctx->buffer);

    // Output hash (big-endian)
    for (int i = 0; i < 8; i++) {
        digest[i*4 + 0] = (ctx->h[i] >> 24) & 0xff;
        digest[i*4 + 1] = (ctx->h[i] >> 16) & 0xff;
        digest[i*4 + 2] = (ctx->h[i] >> 8) & 0xff;
        digest[i*4 + 3] = ctx->h[i] & 0xff;
    }

    // Secure cleanup
    lacky_secure_zero(ctx, sizeof(lacky_sha256_ctx_t));
}

/**
 * Process single SHA-256 block
 */
static void sha256_process_block(lacky_sha256_ctx_t* ctx, const uint8_t* block) {
    static const uint32_t K[64] = {
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
    };

    uint32_t W[64];
    uint32_t a, b, c, d, e, f, g, h;
    uint32_t T1, T2;

    // Prepare message schedule
    for (int i = 0; i < 16; i++) {
        W[i] = ((uint32_t)block[i*4 + 0] << 24) |
               ((uint32_t)block[i*4 + 1] << 16) |
               ((uint32_t)block[i*4 + 2] << 8) |
               ((uint32_t)block[i*4 + 3]);
    }

    for (int i = 16; i < 64; i++) {
        uint32_t s0 = ROTR(W[i-15], 7) ^ ROTR(W[i-15], 18) ^ (W[i-15] >> 3);
        uint32_t s1 = ROTR(W[i-2], 17) ^ ROTR(W[i-2], 19) ^ (W[i-2] >> 10);
        W[i] = W[i-16] + s0 + W[i-7] + s1;
    }

    // Initialize working variables
    a = ctx->h[0]; b = ctx->h[1]; c = ctx->h[2]; d = ctx->h[3];
    e = ctx->h[4]; f = ctx->h[5]; g = ctx->h[6]; h = ctx->h[7];

    // Main loop
    for (int i = 0; i < 64; i++) {
        uint32_t S1 = ROTR(e, 6) ^ ROTR(e, 11) ^ ROTR(e, 25);
        uint32_t ch = (e & f) ^ ((~e) & g);
        T1 = h + S1 + ch + K[i] + W[i];
        
        uint32_t S0 = ROTR(a, 2) ^ ROTR(a, 13) ^ ROTR(a, 22);
        uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
        T2 = S0 + maj;

        h = g; g = f; f = e; e = d + T1;
        d = c; c = b; b = a; a = T1 + T2;
    }

    // Update hash values
    ctx->h[0] += a; ctx->h[1] += b; ctx->h[2] += c; ctx->h[3] += d;
    ctx->h[4] += e; ctx->h[5] += f; ctx->h[6] += g; ctx->h[7] += h;
}

/**
 * ChaCha20 encryption for wallet data
 */
void lacky_chacha20_init(lacky_chacha20_ctx_t* ctx, const uint8_t* key, const uint8_t* nonce) {
    if (!ctx || !key || !nonce) return;

    // ChaCha20 constants "expand 32-byte k"
    ctx->state[0] = 0x61707865;
    ctx->state[1] = 0x3320646e;
    ctx->state[2] = 0x79622d32;
    ctx->state[3] = 0x6b206574;

    // Key (8 words)
    for (int i = 0; i < 8; i++) {
        ctx->state[4 + i] = ((uint32_t)key[i*4 + 0]) |
                           ((uint32_t)key[i*4 + 1] << 8) |
                           ((uint32_t)key[i*4 + 2] << 16) |
                           ((uint32_t)key[i*4 + 3] << 24);
    }

    // Counter (1 word, starts at 0)
    ctx->state[12] = 0;

    // Nonce (3 words)
    for (int i = 0; i < 3; i++) {
        ctx->state[13 + i] = ((uint32_t)nonce[i*4 + 0]) |
                            ((uint32_t)nonce[i*4 + 1] << 8) |
                            ((uint32_t)nonce[i*4 + 2] << 16) |
                            ((uint32_t)nonce[i*4 + 3] << 24);
    }

    ctx->counter = 0;
}

/**
 * ChaCha20 encryption (same as decryption)
 */
void lacky_chacha20_encrypt(lacky_chacha20_ctx_t* ctx, const uint8_t* plaintext, uint8_t* ciphertext, size_t len) {
    if (!ctx || !plaintext || !ciphertext || len == 0) return;

    uint8_t keystream[64];
    size_t remaining = len;
    const uint8_t* input = plaintext;
    uint8_t* output = ciphertext;

    while (remaining > 0) {
        // Generate keystream block
        chacha20_block(ctx->state, keystream);
        
        // XOR with input
        size_t block_len = (remaining < 64) ? remaining : 64;
        for (size_t i = 0; i < block_len; i++) {
            output[i] = input[i] ^ keystream[i];
        }

        // Increment counter
        ctx->state[12]++;
        if (ctx->state[12] == 0) {
            ctx->state[13]++; // Handle counter overflow
        }

        input += block_len;
        output += block_len;
        remaining -= block_len;
    }

    // Secure cleanup of keystream
    lacky_secure_zero(keystream, sizeof(keystream));
}

/**
 * ChaCha20 decryption (same as encryption)
 */
void lacky_chacha20_decrypt(lacky_chacha20_ctx_t* ctx, const uint8_t* ciphertext, uint8_t* plaintext, size_t len) {
    lacky_chacha20_encrypt(ctx, ciphertext, plaintext, len);
}

/**
 * Generate ChaCha20 keystream block
 */
static void chacha20_block(uint32_t* state, uint8_t* output) {
    uint32_t working_state[16];
    memcpy(working_state, state, 64);

    // 20 rounds (10 double rounds)
    for (int i = 0; i < 10; i++) {
        // Odd rounds
        CHACHA20_QUARTER_ROUND(working_state[0], working_state[4], working_state[8], working_state[12]);
        CHACHA20_QUARTER_ROUND(working_state[1], working_state[5], working_state[9], working_state[13]);
        CHACHA20_QUARTER_ROUND(working_state[2], working_state[6], working_state[10], working_state[14]);
        CHACHA20_QUARTER_ROUND(working_state[3], working_state[7], working_state[11], working_state[15]);
        
        // Even rounds
        CHACHA20_QUARTER_ROUND(working_state[0], working_state[5], working_state[10], working_state[15]);
        CHACHA20_QUARTER_ROUND(working_state[1], working_state[6], working_state[11], working_state[12]);
        CHACHA20_QUARTER_ROUND(working_state[2], working_state[7], working_state[8], working_state[13]);
        CHACHA20_QUARTER_ROUND(working_state[3], working_state[4], working_state[9], working_state[14]);
    }

    // Add original state
    for (int i = 0; i < 16; i++) {
        working_state[i] += state[i];
    }

    // Convert to bytes (little-endian)
    for (int i = 0; i < 16; i++) {
        output[i*4 + 0] = working_state[i] & 0xff;
        output[i*4 + 1] = (working_state[i] >> 8) & 0xff;
        output[i*4 + 2] = (working_state[i] >> 16) & 0xff;
        output[i*4 + 3] = (working_state[i] >> 24) & 0xff;
    }

    // Secure cleanup
    lacky_secure_zero(working_state, sizeof(working_state));
}

/**
 * Key derivation for wallet operations with STONEDRIFT integration
 */
lacky_error_t lacky_crypto_derive_key(const char* password, size_t password_len,
                                     const uint8_t* salt, size_t salt_len,
                                     uint8_t* output, size_t output_len) {
    if (!password || !salt || !output || password_len == 0 || salt_len == 0 || output_len == 0) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    // Use PBKDF2-SHA256 for key derivation
    return lacky_pbkdf2_sha256((const uint8_t*)password, password_len,
                              salt, salt_len, 100000, // 100k iterations
                              output, output_len);
}

/**
 * PBKDF2-SHA256 implementation
 */
int lacky_pbkdf2_sha256(const uint8_t* password, size_t password_len,
                        const uint8_t* salt, size_t salt_len,
                        uint32_t iterations,
                        uint8_t* derived_key, size_t key_len) {
    if (!password || !salt || !derived_key || iterations == 0) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    uint8_t u[32], t[32];
    uint8_t salt_block[256]; // Max salt + block number
    size_t blocks = (key_len + 31) / 32; // Number of 32-byte blocks needed

    if (salt_len > 252) { // Leave room for block number
        return LACKY_ERROR_INVALID_PARAM;
    }

    for (size_t block = 1; block <= blocks; block++) {
        // Prepare salt || block_number
        memcpy(salt_block, salt, salt_len);
        salt_block[salt_len + 0] = (block >> 24) & 0xff;
        salt_block[salt_len + 1] = (block >> 16) & 0xff;
        salt_block[salt_len + 2] = (block >> 8) & 0xff;
        salt_block[salt_len + 3] = block & 0xff;

        // First iteration: U_1 = HMAC(password, salt || block)
        hmac_sha256(password, password_len, salt_block, salt_len + 4, u);
        memcpy(t, u, 32);

        // Remaining iterations: U_i = HMAC(password, U_{i-1})
        for (uint32_t i = 1; i < iterations; i++) {
            hmac_sha256(password, password_len, u, 32, u);
            // XOR with accumulated result
            for (int j = 0; j < 32; j++) {
                t[j] ^= u[j];
            }
        }

        // Copy to output (may be partial for last block)
        size_t copy_len = (key_len < 32) ? key_len : 32;
        memcpy(derived_key + (block - 1) * 32, t, copy_len);
        key_len -= copy_len;
    }

    // Secure cleanup
    lacky_secure_zero(u, sizeof(u));
    lacky_secure_zero(t, sizeof(t));
    lacky_secure_zero(salt_block, sizeof(salt_block));

    return LACKY_SUCCESS;
}

/**
 * HMAC-SHA256 implementation
 */
static void hmac_sha256(const uint8_t* key, size_t key_len,
                       const uint8_t* data, size_t data_len,
                       uint8_t* output) {
    uint8_t ipad[64], opad[64];
    uint8_t key_buf[64];
    lacky_sha256_ctx_t ctx;

    // Prepare key
    memset(key_buf, 0, 64);
    if (key_len > 64) {
        lacky_sha256(key, key_len, key_buf);
    } else {
        memcpy(key_buf, key, key_len);
    }

    // Create inner and outer pads
    for (int i = 0; i < 64; i++) {
        ipad[i] = key_buf[i] ^ 0x36;
        opad[i] = key_buf[i] ^ 0x5c;
    }

    // Inner hash: SHA256(ipad || data)
    lacky_sha256_init(&ctx);
    lacky_sha256_update(&ctx, ipad, 64);
    lacky_sha256_update(&ctx, data, data_len);
    lacky_sha256_finish(&ctx, output);

    // Outer hash: SHA256(opad || inner_hash)
    lacky_sha256_init(&ctx);
    lacky_sha256_update(&ctx, opad, 64);
    lacky_sha256_update(&ctx, output, 32);
    lacky_sha256_finish(&ctx, output);

    // Secure cleanup
    lacky_secure_zero(key_buf, sizeof(key_buf));
    lacky_secure_zero(ipad, sizeof(ipad));
    lacky_secure_zero(opad, sizeof(opad));
}

// Helper macros for crypto operations
#define ROTR(x, n) (((x) >> (n)) | ((x) << (32 - (n))))
#define CHACHA20_QUARTER_ROUND(a, b, c, d) do { \
    a += b; d ^= a; d = (d << 16) | (d >> 16); \
    c += d; b ^= c; b = (b << 12) | (b >> 20); \
    a += b; d ^= a; d = (d << 8) | (d >> 24); \
    c += d; b ^= c; b = (b << 7) | (b >> 25); \
} while(0)

// Function declarations for internal use
static void sha256_process_block(lacky_sha256_ctx_t* ctx, const uint8_t* block);
static void chacha20_block(uint32_t* state, uint8_t* output);
static void hmac_sha256(const uint8_t* key, size_t key_len, const uint8_t* data, size_t data_len, uint8_t* output);
