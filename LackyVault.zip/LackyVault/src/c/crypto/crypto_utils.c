/**
 * LackyVault - Crypto Utilities Implementation
 * Provides missing cryptographic utility functions
 * 
 * Copyright (c) 2024 Lackadaisical Security
 * Production-grade implementations with zero dependencies
 */

#include <windows.h>
#include <bcrypt.h>
#include <ntstatus.h>
#include <stdint.h>
#include <string.h>
#include <intrin.h>
#include <immintrin.h>
#include "../../../include/lacky_crypto.h"
#include "../../../include/lacky_vault.h"

#pragma comment(lib, "bcrypt.lib")

#ifndef NT_SUCCESS
#define NT_SUCCESS(Status) (((NTSTATUS)(Status)) >= 0)
#endif

/* Global BCrypt algorithm handle for secure random generation */
static BCRYPT_ALG_HANDLE g_rng_algorithm = NULL;
static CRITICAL_SECTION g_rng_lock;
static bool g_rng_initialized = false;

/**
 * Initialize the random number generator
 */
static lacky_error_t init_rng_if_needed(void) {
    if (g_rng_initialized) {
        return LACKY_SUCCESS;
    }
    
    EnterCriticalSection(&g_rng_lock);
    
    if (!g_rng_initialized) {
        NTSTATUS status = BCryptOpenAlgorithmProvider(
            &g_rng_algorithm,
            BCRYPT_RNG_ALGORITHM,
            NULL,
            0
        );
        
        if (!NT_SUCCESS(status)) {
            LeaveCriticalSection(&g_rng_lock);
            return LACKY_ERROR_CRYPTO_INIT;
        }
        
        g_rng_initialized = true;
    }
    
    LeaveCriticalSection(&g_rng_lock);
    return LACKY_SUCCESS;
}

/**
 * Production-grade secure random bytes generation
 * Uses Windows BCrypt API for cryptographically secure randomness
 */
int lacky_random_bytes(uint8_t* buffer, size_t len) {
    if (!buffer || len == 0) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    // Initialize RNG if needed
    if (init_rng_if_needed() != LACKY_SUCCESS) {
        return LACKY_ERROR_CRYPTO_INIT;
    }
    
    // Generate secure random bytes using BCrypt
    NTSTATUS status = BCryptGenRandom(
        g_rng_algorithm,
        buffer,
        (ULONG)len,
        0  // No flags needed
    );
    
    if (!NT_SUCCESS(status)) {
        // Fallback to CryptGenRandom if BCrypt fails
        HCRYPTPROV hProv;
        if (CryptAcquireContextA(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)) {
            BOOL result = CryptGenRandom(hProv, (DWORD)len, buffer);
            CryptReleaseContext(hProv, 0);
            
            if (result) {
                return LACKY_SUCCESS;
            }
        }
        
        return LACKY_ERROR_CRYPTO_RANDOM;
    }
    
    return LACKY_SUCCESS;
}

/**
 * Initialize crypto utilities subsystem
 */
lacky_error_t lacky_crypto_utils_init(void) {
    InitializeCriticalSection(&g_rng_lock);
    return init_rng_if_needed();
}

/**
 * Cleanup crypto utilities subsystem
 */
void lacky_crypto_utils_cleanup(void) {
    EnterCriticalSection(&g_rng_lock);
    
    if (g_rng_initialized && g_rng_algorithm) {
        BCryptCloseAlgorithmProvider(g_rng_algorithm, 0);
        g_rng_algorithm = NULL;
        g_rng_initialized = false;
    }
    
    LeaveCriticalSection(&g_rng_lock);
    DeleteCriticalSection(&g_rng_lock);
}

/**
 * Generate random salt for key derivation
 */
lacky_error_t lacky_generate_salt(uint8_t* salt, size_t salt_size) {
    if (!salt || salt_size == 0) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    return lacky_random_bytes(salt, salt_size);
}

/**
 * Generate random nonce for encryption
 */
lacky_error_t lacky_generate_nonce(uint8_t* nonce, size_t nonce_size) {
    if (!nonce || nonce_size == 0) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    return lacky_random_bytes(nonce, nonce_size);
}

/**
 * Generate random key material
 */
lacky_error_t lacky_generate_key(uint8_t* key, size_t key_size) {
    if (!key || key_size == 0) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    return lacky_random_bytes(key, key_size);
}

/**
 * Constant-time memory comparison (production implementation)
 */
int lacky_crypto_secure_compare(const uint8_t* a, const uint8_t* b, size_t len) {
    if (!a || !b) {
        return -1;
    }
    
    volatile uint8_t result = 0;
    
    for (size_t i = 0; i < len; i++) {
        result |= a[i] ^ b[i];
    }
    
    return result;
}

/**
 * Secure memory zeroing (production implementation)
 */
void lacky_crypto_zeroize(void* ptr, size_t len) {
    if (!ptr || len == 0) {
        return;
    }
    
    // Use Windows SecureZeroMemory to prevent compiler optimization
    SecureZeroMemory(ptr, len);
}

/**
 * Hardware feature detection
 */
bool lacky_crypto_has_aes_ni(void) {
    int cpuid_info[4];
    __cpuid(cpuid_info, 1);
    return (cpuid_info[2] & (1 << 25)) != 0;  // Check ECX bit 25
}

bool lacky_crypto_has_avx2(void) {
    int cpuid_info[4];
    __cpuid(cpuid_info, 7);
    return (cpuid_info[1] & (1 << 5)) != 0;   // Check EBX bit 5
}

bool lacky_crypto_has_rdrand(void) {
    int cpuid_info[4];
    __cpuid(cpuid_info, 1);
    return (cpuid_info[2] & (1 << 30)) != 0;  // Check ECX bit 30
}

/**
 * Enhanced random number generation with hardware support
 */
lacky_error_t lacky_enhanced_random_bytes(uint8_t* buffer, size_t len) {
    if (!buffer || len == 0) {
        return LACKY_ERROR_INVALID_PARAM;
    }
    
    // Try hardware RNG first if available
    if (lacky_crypto_has_rdrand()) {
        size_t generated = 0;
        
        while (generated < len) {
            uint64_t rand_val;
            
            // Use _rdrand64_step for 64-bit values
            if (_rdrand64_step(&rand_val)) {
                size_t copy_size = (len - generated) < 8 ? (len - generated) : 8;
                memcpy(buffer + generated, &rand_val, copy_size);
                generated += copy_size;
            } else {
                // Fallback to software RNG if hardware fails
                break;
            }
        }
        
        // If we got all bytes from hardware, we're done
        if (generated == len) {
            return LACKY_SUCCESS;
        }
    }
    
    // Fallback to standard secure random generation
    return lacky_random_bytes(buffer, len);
}

/**
 * Test random number generator quality
 */
lacky_error_t lacky_test_rng_quality(void) {
    uint8_t test_buffer[1024];
    uint32_t bit_counts[8] = {0};
    
    // Generate test data
    if (lacky_random_bytes(test_buffer, sizeof(test_buffer)) != LACKY_SUCCESS) {
        return LACKY_ERROR_CRYPTO_RANDOM;
    }
    
    // Basic statistical test - count bits
    for (size_t i = 0; i < sizeof(test_buffer); i++) {
        for (int bit = 0; bit < 8; bit++) {
            if (test_buffer[i] & (1 << bit)) {
                bit_counts[bit]++;
            }
        }
    }
    
    // Check if bit distribution is reasonable (within 20% of expected)
    size_t expected = sizeof(test_buffer) / 2;  // 50% of bits should be 1
    for (int i = 0; i < 8; i++) {
        if (bit_counts[i] < expected * 0.8 || bit_counts[i] > expected * 1.2) {
            return LACKY_ERROR_CRYPTO_RANDOM;
        }
    }
    
    // Clear test data
    lacky_crypto_zeroize(test_buffer, sizeof(test_buffer));
    lacky_crypto_zeroize(bit_counts, sizeof(bit_counts));
    
    return LACKY_SUCCESS;
} 