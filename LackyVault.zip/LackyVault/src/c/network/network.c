/**
 * LackyVault - Network Communications
 * Lackadaisical Security
 * 
 * Secure networking for blockchain communications
 */

#include "../../../include/lacky_vault.h"
#include "../../../include/lacky_crypto.h"
#include <winsock2.h>
#include <ws2tcpip.h>
#include <winhttp.h>

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "winhttp.lib")

/* Global network context */
static lacky_network_ctx_t g_network_ctx = {0};

/**
 * Initialize network subsystem
 */
lacky_error_t lacky_network_init(lacky_network_ctx_t* network) {
    if (!network) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    ZeroMemory(network, sizeof(lacky_network_ctx_t));

    // Initialize Winsock
    WSADATA wsaData;
    int result = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (result != 0) {
        return LACKY_ERROR_NETWORK_INIT;
    }

    // Set default configuration
    network->use_tor = false;
    network->connect_timeout = 30000; // 30 seconds
    network->read_timeout = 30000;
    network->max_retries = 3;
    network->initialized = true;

    return LACKY_SUCCESS;
}

/**
 * Cleanup network subsystem
 */
void lacky_network_cleanup(lacky_network_ctx_t* network) {
    if (!network) {
        return;
    }

    // Cleanup Winsock
    WSACleanup();

    // Zero out network context
    lacky_asm_zeroize(network, sizeof(lacky_network_ctx_t));
}

/**
 * Send HTTP request
 */
lacky_error_t lacky_network_http_request(const char* url, const char* method, 
                                        const char* data, size_t data_len,
                                        char* response, size_t* response_len) {
    if (!url || !method || !response || !response_len) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    HINTERNET hSession = NULL;
    HINTERNET hConnect = NULL;
    HINTERNET hRequest = NULL;
    lacky_error_t error = LACKY_SUCCESS;

    // Convert URL to wide string
    wchar_t wide_url[1024];
    MultiByteToWideChar(CP_UTF8, 0, url, -1, wide_url, 1024);

    // Parse URL
    URL_COMPONENTSW urlComp = {0};
    urlComp.dwStructSize = sizeof(urlComp);
    urlComp.lpszHostName = NULL;
    urlComp.dwHostNameLength = 1024;
    urlComp.lpszUrlPath = NULL;
    urlComp.dwUrlPathLength = 1024;
    urlComp.nPort = 0;

    wchar_t hostName[1024];
    wchar_t urlPath[1024];
    urlComp.lpszHostName = hostName;
    urlComp.lpszUrlPath = urlPath;

    if (!WinHttpCrackUrl(wide_url, 0, 0, &urlComp)) {
        return LACKY_ERROR_NETWORK_INVALID_URL;
    }

    // Create session
    hSession = WinHttpOpen(L"LackyVault/1.0", 
                          WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
                          WINHTTP_NO_PROXY_NAME, 
                          WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSession) {
        return LACKY_ERROR_NETWORK_INIT;
    }

    // Set timeouts
    WinHttpSetTimeouts(hSession, 60000, 60000, 60000, 60000);

    // Connect
    hConnect = WinHttpConnect(hSession, hostName, urlComp.nPort, 0);
    if (!hConnect) {
        error = LACKY_ERROR_NETWORK_CONNECT;
        goto cleanup;
    }

    // Convert method to wide string
    wchar_t wide_method[16];
    MultiByteToWideChar(CP_UTF8, 0, method, -1, wide_method, 16);

    // Create request
    DWORD flags = (urlComp.nScheme == INTERNET_SCHEME_HTTPS) ? WINHTTP_FLAG_SECURE : 0;
    hRequest = WinHttpOpenRequest(hConnect, wide_method, urlPath, NULL, 
                                 WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, flags);
    if (!hRequest) {
        error = LACKY_ERROR_NETWORK_REQUEST;
        goto cleanup;
    }

    // Send request
    BOOL result = WinHttpSendRequest(hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
                                    (LPVOID)data, (DWORD)data_len, (DWORD)data_len, 0);
    if (!result) {
        error = LACKY_ERROR_NETWORK_SEND;
        goto cleanup;
    }

    // Receive response
    result = WinHttpReceiveResponse(hRequest, NULL);
    if (!result) {
        error = LACKY_ERROR_NETWORK_RECEIVE;
        goto cleanup;
    }

    // Read response data
    DWORD totalBytesRead = 0;
    DWORD bytesAvailable = 0;
    
    do {
        bytesAvailable = 0;
        if (!WinHttpQueryDataAvailable(hRequest, &bytesAvailable)) {
            error = LACKY_ERROR_NETWORK_RECEIVE;
            goto cleanup;
        }

        if (bytesAvailable > 0) {
            DWORD bytesToRead = min(bytesAvailable, (DWORD)(*response_len - totalBytesRead - 1));
            if (bytesToRead > 0) {
                DWORD bytesRead = 0;
                if (!WinHttpReadData(hRequest, response + totalBytesRead, bytesToRead, &bytesRead)) {
                    error = LACKY_ERROR_NETWORK_RECEIVE;
                    goto cleanup;
                }
                totalBytesRead += bytesRead;
            }
        }
    } while (bytesAvailable > 0 && totalBytesRead < *response_len - 1);

    response[totalBytesRead] = '\0';
    *response_len = totalBytesRead;

cleanup:
    if (hRequest) WinHttpCloseHandle(hRequest);
    if (hConnect) WinHttpCloseHandle(hConnect);
    if (hSession) WinHttpCloseHandle(hSession);

    return error;
}

/**
 * Get Bitcoin network information
 */
lacky_error_t lacky_network_get_block_info(uint64_t* block_height, char* block_hash, size_t hash_len) {
    if (!block_height || !block_hash) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    // For demo purposes, return simulated data
    *block_height = 800000;
    strcpy_s(block_hash, hash_len, "0000000000000000000123456789abcdef");

    return LACKY_SUCCESS;
}

/**
 * Get address balance
 */
lacky_error_t lacky_network_get_balance(const char* address, uint64_t* balance) {
    if (!address || !balance) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    // For demo purposes, return simulated balance
    *balance = 100000000; // 1 BTC in satoshis

    return LACKY_SUCCESS;
}

/**
 * Broadcast transaction
 */
lacky_error_t lacky_network_broadcast_transaction(const char* tx_hex, char* txid, size_t txid_len) {
    if (!tx_hex || !txid) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    // For demo purposes, return simulated transaction ID
    strcpy_s(txid, txid_len, "abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890");

    return LACKY_SUCCESS;
}

/**
 * Get transaction history
 */
lacky_error_t lacky_network_get_transactions(const char* address, lacky_transaction_t* transactions, 
                                           size_t* count, size_t max_count) {
    if (!address || !transactions || !count) {
        return LACKY_ERROR_INVALID_PARAM;
    }

    // For demo purposes, return simulated transaction data
    *count = min(3, max_count);
    
    for (size_t i = 0; i < *count; i++) {
        strcpy_s(transactions[i].txid, sizeof(transactions[i].txid), "demo_txid");
        transactions[i].amount = 50000000; // 0.5 BTC
        transactions[i].confirmations = 6;
        transactions[i].timestamp = time(NULL) - (DWORD)(i * 86400); // 1 day apart
        strcpy_s(transactions[i].address, sizeof(transactions[i].address), address);
    }

    return LACKY_SUCCESS;
}

/**
 * Initialize global network context
 */
lacky_error_t lacky_network_init_global(void) {
    return lacky_network_init(&g_network_ctx);
}

/**
 * Get global network context
 */
lacky_network_ctx_t* lacky_network_get_global(void) {
    return &g_network_ctx;
}

/**
 * Cleanup global network context
 */
void lacky_network_cleanup_global(void) {
    lacky_network_cleanup(&g_network_ctx);
}
