#include <windows.h>
#include <msi.h>
#include <msiquery.h>

#pragma comment(lib, "msi.lib")

// Log message to MSI log
static void LogMessage(MSIHANDLE hInstall, LPCWSTR message) {
    MSIHANDLE hRecord = MsiCreateRecord(1);
    if (hRecord) {
        MsiRecordSetStringW(hRecord, 0, L"LackyVault: [1]");
        MsiRecordSetStringW(hRecord, 1, message);
        MsiProcessMessage(hInstall, INSTALLMESSAGE_INFO, hRecord);
        MsiCloseHandle(hRecord);
    }
}

// Get MSI property value
static BOOL GetProperty(MSIHANDLE hInstall, LPCWSTR propertyName, LPWSTR buffer, DWORD bufferSize) {
    DWORD size = bufferSize;
    return (MsiGetPropertyW(hInstall, propertyName, buffer, &size) == ERROR_SUCCESS);
}

// Configure wallet settings during installation
UINT __stdcall ConfigureWallet(MSIHANDLE hInstall) {
    LogMessage(hInstall, L"Configuring LackyVault wallet settings...");
    
    WCHAR installPath[MAX_PATH];
    if (GetProperty(hInstall, L"INSTALLFOLDER", installPath, sizeof(installPath)/sizeof(WCHAR))) {
        // Create wallets directory
        WCHAR walletDir[MAX_PATH];
        wsprintfW(walletDir, L"%s\\wallets", installPath);
        CreateDirectoryW(walletDir, NULL);
        
        // Create logs directory
        WCHAR logsDir[MAX_PATH];
        wsprintfW(logsDir, L"%s\\logs", installPath);
        CreateDirectoryW(logsDir, NULL);
        
        // Create themes directory
        WCHAR themesDir[MAX_PATH];
        wsprintfW(themesDir, L"%s\\themes", installPath);
        CreateDirectoryW(themesDir, NULL);
        
        LogMessage(hInstall, L"Wallet directories created successfully");
    }
    
    return ERROR_SUCCESS;
}

// Setup Windows Firewall rules
UINT __stdcall SetupFirewallRules(MSIHANDLE hInstall) {
    LogMessage(hInstall, L"Setting up firewall rules...");
    
    WCHAR installPath[MAX_PATH];
    if (GetProperty(hInstall, L"INSTALLFOLDER", installPath, sizeof(installPath)/sizeof(WCHAR))) {
        // Use netsh to add firewall rule
        WCHAR command[512];
        wsprintfW(command, L"netsh advfirewall firewall add rule name=\"LackyVault Crypto Wallet\" dir=in action=allow program=\"%s\\LackyVault.exe\"", installPath);
        
        STARTUPINFOW si = {0};
        PROCESS_INFORMATION pi = {0};
        si.cb = sizeof(si);
        si.dwFlags = STARTF_USESHOWWINDOW;
        si.wShowWindow = SW_HIDE;
        
        if (CreateProcessW(NULL, command, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
            WaitForSingleObject(pi.hProcess, 10000);
            CloseHandle(pi.hProcess);
            CloseHandle(pi.hThread);
            LogMessage(hInstall, L"Firewall rule added successfully");
        }
    }
    
    return ERROR_SUCCESS;
}

// Create secure folder with proper permissions
UINT __stdcall CreateSecureFolder(MSIHANDLE hInstall) {
    LogMessage(hInstall, L"Creating secure folders...");
    
    WCHAR walletPath[MAX_PATH];
    if (GetProperty(hInstall, L"WALLET_LOCATION", walletPath, sizeof(walletPath)/sizeof(WCHAR))) {
        CreateDirectoryW(walletPath, NULL);
        LogMessage(hInstall, L"Secure folder created");
    }
    
    return ERROR_SUCCESS;
}

// DLL Entry Point
BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    return TRUE;
} 