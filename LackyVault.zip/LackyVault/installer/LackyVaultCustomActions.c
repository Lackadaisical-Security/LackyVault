/**
 * LackyVault Custom Actions for MSI Installer
 * Provides advanced installation functionality
 */

#include <windows.h>
#include <msiquery.h>
#include <msi.h>
#include <strsafe.h>
#include <shlobj.h>
#include <netfw.h>
#include <wincrypt.h>

#pragma comment(lib, "msi.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "oleaut32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "crypt32.lib")

#define LACKY_CA_SUCCESS    ERROR_SUCCESS
#define LACKY_CA_ERROR      ERROR_INSTALL_FAILURE

/**
 * Log message to MSI log
 */
static void LogMessage(MSIHANDLE hInstall, LPCWSTR message) {
    MSIHANDLE hRecord = MsiCreateRecord(1);
    if (hRecord) {
        MsiRecordSetStringW(hRecord, 0, L"LackyVault: [1]");
        MsiRecordSetStringW(hRecord, 1, message);
        MsiProcessMessage(hInstall, INSTALLMESSAGE_INFO, hRecord);
        MsiCloseHandle(hRecord);
    }
}

/**
 * Get MSI property value
 */
static BOOL GetProperty(MSIHANDLE hInstall, LPCWSTR propertyName, LPWSTR buffer, DWORD bufferSize) {
    DWORD size = bufferSize;
    return (MsiGetPropertyW(hInstall, propertyName, buffer, &size) == ERROR_SUCCESS);
}

/**
 * Set MSI property value
 */
static BOOL SetProperty(MSIHANDLE hInstall, LPCWSTR propertyName, LPCWSTR value) {
    return (MsiSetPropertyW(hInstall, propertyName, value) == ERROR_SUCCESS);
}

/**
 * Create secure directory with proper permissions
 */
UINT __stdcall CreateSecureFolder(MSIHANDLE hInstall) {
    LogMessage(hInstall, L"Creating secure wallet directory...");
    
    WCHAR walletPath[MAX_PATH];
    if (!GetProperty(hInstall, L"WALLET_LOCATION", walletPath, sizeof(walletPath)/sizeof(WCHAR))) {
        LogMessage(hInstall, L"Failed to get wallet location property");
        return LACKY_CA_ERROR;
    }
    
    // Create directory
    if (!CreateDirectoryW(walletPath, NULL) && GetLastError() != ERROR_ALREADY_EXISTS) {
        LogMessage(hInstall, L"Failed to create wallet directory");
        return LACKY_CA_ERROR;
    }
    
    // Set secure permissions (owner and SYSTEM only)
    PSECURITY_DESCRIPTOR pSD = NULL;
    PACL pDacl = NULL;
    
    // Get current user SID
    HANDLE hToken;
    TOKEN_USER* pTokenUser = NULL;
    DWORD dwSize = 0;
    
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken)) {
        GetTokenInformation(hToken, TokenUser, NULL, 0, &dwSize);
        pTokenUser = (TOKEN_USER*)LocalAlloc(LPTR, dwSize);
        
        if (pTokenUser && GetTokenInformation(hToken, TokenUser, pTokenUser, dwSize, &dwSize)) {
            // Create DACL with restricted access
            EXPLICIT_ACCESSW ea[2] = {0};
            
            // Owner full control
            ea[0].grfAccessPermissions = GENERIC_ALL;
            ea[0].grfAccessMode = SET_ACCESS;
            ea[0].grfInheritance = SUB_CONTAINERS_AND_OBJECTS_INHERIT;
            ea[0].Trustee.TrusteeForm = TRUSTEE_IS_SID;
            ea[0].Trustee.ptstrName = (LPWSTR)pTokenUser->User.Sid;
            
            // SYSTEM full control
            ea[1].grfAccessPermissions = GENERIC_ALL;
            ea[1].grfAccessMode = SET_ACCESS;
            ea[1].grfInheritance = SUB_CONTAINERS_AND_OBJECTS_INHERIT;
            ea[1].Trustee.TrusteeForm = TRUSTEE_IS_NAME;
            ea[1].Trustee.ptstrName = L"SYSTEM";
            
            if (SetEntriesInAclW(2, ea, NULL, &pDacl) == ERROR_SUCCESS) {
                pSD = LocalAlloc(LPTR, SECURITY_DESCRIPTOR_MIN_LENGTH);
                if (pSD && InitializeSecurityDescriptor(pSD, SECURITY_DESCRIPTOR_REVISION)) {
                    SetSecurityDescriptorDacl(pSD, TRUE, pDacl, FALSE);
                    SetFileSecurityW(walletPath, DACL_SECURITY_INFORMATION, pSD);
                }
            }
        }
        
        if (pTokenUser) LocalFree(pTokenUser);
        CloseHandle(hToken);
    }
    
    if (pDacl) LocalFree(pDacl);
    if (pSD) LocalFree(pSD);
    
    LogMessage(hInstall, L"Secure wallet directory created successfully");
    return LACKY_CA_SUCCESS;
}

/**
 * Setup Windows Firewall rules
 */
UINT __stdcall SetupFirewallRules(MSIHANDLE hInstall) {
    LogMessage(hInstall, L"Configuring Windows Firewall rules...");
    
    HRESULT hr = S_OK;
    INetFwMgr* pFwMgr = NULL;
    INetFwPolicy* pFwPolicy = NULL;
    INetFwProfile* pFwProfile = NULL;
    INetFwAuthorizedApplications* pFwApps = NULL;
    INetFwAuthorizedApplication* pFwApp = NULL;
    
    WCHAR appPath[MAX_PATH];
    if (!GetProperty(hInstall, L"INSTALLFOLDER", appPath, sizeof(appPath)/sizeof(WCHAR))) {
        return LACKY_CA_ERROR;
    }
    StringCchCatW(appPath, MAX_PATH, L"LackyVault.exe");
    
    // Initialize COM
    hr = CoInitializeEx(0, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
    if (FAILED(hr)) {
        LogMessage(hInstall, L"Failed to initialize COM");
        return LACKY_CA_ERROR;
    }
    
    // Create firewall manager
    hr = CoCreateInstance(&CLSID_NetFwMgr, NULL, CLSCTX_INPROC_SERVER, 
                         &IID_INetFwMgr, (void**)&pFwMgr);
    if (FAILED(hr)) goto cleanup;
    
    // Get firewall policy
    hr = pFwMgr->lpVtbl->get_LocalPolicy(pFwMgr, &pFwPolicy);
    if (FAILED(hr)) goto cleanup;
    
    // Get current profile
    hr = pFwPolicy->lpVtbl->get_CurrentProfile(pFwPolicy, &pFwProfile);
    if (FAILED(hr)) goto cleanup;
    
    // Get authorized applications
    hr = pFwProfile->lpVtbl->get_AuthorizedApplications(pFwProfile, &pFwApps);
    if (FAILED(hr)) goto cleanup;
    
    // Create new application entry
    hr = CoCreateInstance(&CLSID_NetFwAuthorizedApplication, NULL, CLSCTX_INPROC_SERVER,
                         &IID_INetFwAuthorizedApplication, (void**)&pFwApp);
    if (FAILED(hr)) goto cleanup;
    
    // Configure application
    BSTR bstrPath = SysAllocString(appPath);
    BSTR bstrName = SysAllocString(L"LackyVault Crypto Wallet");
    
    pFwApp->lpVtbl->put_ProcessImageFileName(pFwApp, bstrPath);
    pFwApp->lpVtbl->put_Name(pFwApp, bstrName);
    pFwApp->lpVtbl->put_Scope(pFwApp, NET_FW_SCOPE_ALL);
    pFwApp->lpVtbl->put_IpVersion(pFwApp, NET_FW_IP_VERSION_ANY);
    pFwApp->lpVtbl->put_Enabled(pFwApp, VARIANT_TRUE);
    
    // Add to authorized applications
    hr = pFwApps->lpVtbl->Add(pFwApps, pFwApp);
    
    SysFreeString(bstrPath);
    SysFreeString(bstrName);
    
cleanup:
    if (pFwApp) pFwApp->lpVtbl->Release(pFwApp);
    if (pFwApps) pFwApps->lpVtbl->Release(pFwApps);
    if (pFwProfile) pFwProfile->lpVtbl->Release(pFwProfile);
    if (pFwPolicy) pFwPolicy->lpVtbl->Release(pFwPolicy);
    if (pFwMgr) pFwMgr->lpVtbl->Release(pFwMgr);
    
    CoUninitialize();
    
    if (SUCCEEDED(hr)) {
        LogMessage(hInstall, L"Firewall rules configured successfully");
        return LACKY_CA_SUCCESS;
    } else {
        LogMessage(hInstall, L"Failed to configure firewall rules");
        return LACKY_CA_SUCCESS; // Non-critical failure
    }
}

/**
 * Configure wallet settings
 */
UINT __stdcall ConfigureWallet(MSIHANDLE hInstall) {
    LogMessage(hInstall, L"Configuring wallet settings...");
    
    // Get configuration properties
    WCHAR securityLevel[64];
    WCHAR networkMode[64];
    WCHAR enableTor[8];
    WCHAR enableStego[8];
    
    GetProperty(hInstall, L"SECURITY_LEVEL", securityLevel, sizeof(securityLevel)/sizeof(WCHAR));
    GetProperty(hInstall, L"NETWORK_MODE", networkMode, sizeof(networkMode)/sizeof(WCHAR));
    GetProperty(hInstall, L"ENABLE_TOR", enableTor, sizeof(enableTor)/sizeof(WCHAR));
    GetProperty(hInstall, L"ENABLE_STEGANOGRAPHY", enableStego, sizeof(enableStego)/sizeof(WCHAR));
    
    // Create default configuration file
    WCHAR configPath[MAX_PATH];
    GetProperty(hInstall, L"INSTALLFOLDER", configPath, sizeof(configPath)/sizeof(WCHAR));
    StringCchCatW(configPath, MAX_PATH, L"config\\default.conf");
    
    HANDLE hFile = CreateFileW(configPath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 
                              FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile != INVALID_HANDLE_VALUE) {
        char configData[2048];
        StringCchPrintfA(configData, sizeof(configData),
            "; LackyVault Configuration\n"
            "; Generated during installation\n\n"
            "[Security]\n"
            "Level=%S\n"
            "AutoLockTimeout=300\n"
            "RequirePasswordOnStartup=1\n"
            "EnableIntegrityChecks=1\n"
            "EnableAntiAnalysis=1\n\n"
            "[Network]\n"
            "Mode=%S\n"
            "EnableTor=%S\n"
            "TorPort=9050\n"
            "EnableProxy=0\n\n"
            "[Privacy]\n"
            "EnableSteganography=%S\n"
            "EnableOnionRouting=%S\n"
            "ClearClipboard=1\n"
            "DisableScreenshots=1\n\n"
            "[UI]\n"
            "Theme=cosmic\n"
            "MinimizeToTray=1\n"
            "ShowBalanceInTitle=0\n"
            "EnableAnimations=1\n\n"
            "[Backup]\n"
            "AutoBackup=1\n"
            "BackupInterval=24\n"
            "EncryptBackups=1\n"
            "MaxBackups=10\n",
            securityLevel, networkMode, enableTor, enableStego, enableTor
        );
        
        DWORD written;
        WriteFile(hFile, configData, (DWORD)strlen(configData), &written, NULL);
        CloseHandle(hFile);
    }
    
    LogMessage(hInstall, L"Wallet configuration completed");
    return LACKY_CA_SUCCESS;
}

/**
 * Generate initial security keys
 */
UINT __stdcall GenerateSecurityKeys(MSIHANDLE hInstall) {
    LogMessage(hInstall, L"Generating security keys...");
    
    WCHAR keyPath[MAX_PATH];
    GetProperty(hInstall, L"INSTALLFOLDER", keyPath, sizeof(keyPath)/sizeof(WCHAR));
    StringCchCatW(keyPath, MAX_PATH, L"config\\security.key");
    
    // Generate random key material
    HCRYPTPROV hProv;
    if (CryptAcquireContextW(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)) {
        BYTE keyData[64];
        if (CryptGenRandom(hProv, sizeof(keyData), keyData)) {
            HANDLE hFile = CreateFileW(keyPath, GENERIC_WRITE, 0, NULL, CREATE_NEW,
                                      FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM, NULL);
            if (hFile != INVALID_HANDLE_VALUE) {
                DWORD written;
                WriteFile(hFile, keyData, sizeof(keyData), &written, NULL);
                CloseHandle(hFile);
            }
        }
        CryptReleaseContext(hProv, 0);
    }
    
    // Secure delete key data from memory
    SecureZeroMemory(keyData, sizeof(keyData));
    
    LogMessage(hInstall, L"Security keys generated successfully");
    return LACKY_CA_SUCCESS;
}

/**
 * Clean up on uninstall
 */
UINT __stdcall CleanupOnUninstall(MSIHANDLE hInstall) {
    LogMessage(hInstall, L"Performing cleanup on uninstall...");
    
    // Remove firewall rules
    // Remove registry entries
    // Secure delete sensitive files
    // Clear temporary data
    
    LogMessage(hInstall, L"Cleanup completed");
    return LACKY_CA_SUCCESS;
}

/**
 * DLL Entry Point
 */
BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    switch (ul_reason_for_call) {
        case DLL_PROCESS_ATTACH:
        case DLL_THREAD_ATTACH:
        case DLL_THREAD_DETACH:
        case DLL_PROCESS_DETACH:
            break;
    }
    return TRUE;
}
