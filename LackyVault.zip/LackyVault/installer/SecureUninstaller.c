/**
 * LackyVault Secure Uninstaller
 * Performs secure cleanup of all LackyVault components
 */

#include <windows.h>
#include <shlobj.h>
#include <strsafe.h>
#include <wincrypt.h>
#include <tlhelp32.h>

#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "crypt32.lib")

#define LACKY_MAX_PATH 1024
#define LACKY_SECURE_PASSES 3

/**
 * Secure file deletion with multiple overwrites
 */
BOOL SecureDeleteFile(LPCWSTR filePath) {
    HANDLE hFile = CreateFileW(filePath, GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 
                               FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        return FALSE;
    }
    
    // Get file size
    LARGE_INTEGER fileSize;
    if (!GetFileSizeEx(hFile, &fileSize)) {
        CloseHandle(hFile);
        return FALSE;
    }
    
    // Allocate buffer for overwriting
    DWORD bufferSize = min(fileSize.QuadPart, 1024 * 1024); // 1MB max
    BYTE* buffer = (BYTE*)VirtualAlloc(NULL, bufferSize, MEM_COMMIT, PAGE_READWRITE);
    if (!buffer) {
        CloseHandle(hFile);
        return FALSE;
    }
    
    // Perform multiple secure overwrites
    for (int pass = 0; pass < LACKY_SECURE_PASSES; pass++) {
        SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
        
        // Generate pattern for this pass
        BYTE pattern = (pass == 0) ? 0x00 : (pass == 1) ? 0xFF : 0xAA;
        memset(buffer, pattern, bufferSize);
        
        // Overwrite file in chunks
        LARGE_INTEGER remaining = fileSize;
        while (remaining.QuadPart > 0) {
            DWORD writeSize = (DWORD)min(remaining.QuadPart, bufferSize);
            DWORD written;
            
            if (!WriteFile(hFile, buffer, writeSize, &written, NULL)) {
                break;
            }
            
            remaining.QuadPart -= written;
        }
        
        FlushFileBuffers(hFile);
    }
    
    VirtualFree(buffer, 0, MEM_RELEASE);
    CloseHandle(hFile);
    
    // Finally delete the file
    return DeleteFileW(filePath);
}

/**
 * Secure directory deletion
 */
BOOL SecureDeleteDirectory(LPCWSTR dirPath) {
    WCHAR searchPath[LACKY_MAX_PATH];
    StringCchPrintfW(searchPath, LACKY_MAX_PATH, L"%s\\*", dirPath);
    
    WIN32_FIND_DATAW findData;
    HANDLE hFind = FindFirstFileW(searchPath, &findData);
    
    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            if (wcscmp(findData.cFileName, L".") == 0 || 
                wcscmp(findData.cFileName, L"..") == 0) {
                continue;
            }
            
            WCHAR fullPath[LACKY_MAX_PATH];
            StringCchPrintfW(fullPath, LACKY_MAX_PATH, L"%s\\%s", dirPath, findData.cFileName);
            
            if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                SecureDeleteDirectory(fullPath);
            } else {
                SecureDeleteFile(fullPath);
            }
            
        } while (FindNextFileW(hFind, &findData));
        
        FindClose(hFind);
    }
    
    return RemoveDirectoryW(dirPath);
}

/**
 * Terminate LackyVault processes
 */
BOOL TerminateLackyVaultProcesses(void) {
    BOOL result = TRUE;
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    
    if (hSnapshot != INVALID_HANDLE_VALUE) {
        PROCESSENTRY32W pe32;
        pe32.dwSize = sizeof(PROCESSENTRY32W);
        
        if (Process32FirstW(hSnapshot, &pe32)) {
            do {
                if (_wcsicmp(pe32.szExeFile, L"LackyVault.exe") == 0) {
                    HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, pe32.th32ProcessID);
                    if (hProcess) {
                        TerminateProcess(hProcess, 0);
                        WaitForSingleObject(hProcess, 5000); // Wait up to 5 seconds
                        CloseHandle(hProcess);
                    }
                }
            } while (Process32NextW(hSnapshot, &pe32));
        }
        
        CloseHandle(hSnapshot);
    }
    
    return result;
}

/**
 * Clean registry entries
 */
BOOL CleanRegistryEntries(void) {
    BOOL result = TRUE;
    
    // Registry keys to delete
    LPCWSTR registryKeys[] = {
        L"Software\\LackadaisicalSecurity\\LackyVault",
        L"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\LackyVault",
        L"Software\\Classes\\LackyVault.Wallet",
        L"Software\\Classes\\.lvault"
    };
    
    for (int i = 0; i < sizeof(registryKeys) / sizeof(LPCWSTR); i++) {
        // Try HKLM first
        SHDeleteKeyW(HKEY_LOCAL_MACHINE, registryKeys[i]);
        // Then HKCU
        SHDeleteKeyW(HKEY_CURRENT_USER, registryKeys[i]);
    }
    
    // Remove autostart entry
    HKEY hKey;
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, 
                     L"Software\\Microsoft\\Windows\\CurrentVersion\\Run", 
                     0, KEY_SET_VALUE, &hKey) == ERROR_SUCCESS) {
        RegDeleteValueW(hKey, L"LackyVault");
        RegCloseKey(hKey);
    }
    
    return result;
}

/**
 * Remove Windows Firewall rules
 */
BOOL RemoveFirewallRules(void) {
    // Use netsh to remove firewall rules
    WCHAR command[512];
    StringCchPrintfW(command, 512, 
        L"netsh advfirewall firewall delete rule name=\"LackyVault Crypto Wallet\"");
    
    STARTUPINFOW si = {0};
    PROCESS_INFORMATION pi = {0};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    
    if (CreateProcessW(NULL, command, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
        WaitForSingleObject(pi.hProcess, 10000);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        return TRUE;
    }
    
    return FALSE;
}

/**
 * Clear Windows event logs related to LackyVault
 */
BOOL ClearEventLogs(void) {
    // Clear application event log entries
    HANDLE hEventLog = OpenEventLogW(NULL, L"Application");
    if (hEventLog) {
        // Note: This is a simplified approach
        // In practice, you'd need to enumerate and selectively clear entries
        CloseEventLog(hEventLog);
    }
    
    return TRUE;
}

/**
 * Clear temporary files and caches
 */
BOOL ClearTemporaryFiles(void) {
    WCHAR tempPath[MAX_PATH];
    WCHAR userProfile[MAX_PATH];
    
    // Get temp directory
    if (GetTempPathW(MAX_PATH, tempPath)) {
        WCHAR lackyTempPath[LACKY_MAX_PATH];
        StringCchPrintfW(lackyTempPath, LACKY_MAX_PATH, L"%sLackyVault*", tempPath);
        
        WIN32_FIND_DATAW findData;
        HANDLE hFind = FindFirstFileW(lackyTempPath, &findData);
        
        if (hFind != INVALID_HANDLE_VALUE) {
            do {
                WCHAR fullPath[LACKY_MAX_PATH];
                StringCchPrintfW(fullPath, LACKY_MAX_PATH, L"%s%s", tempPath, findData.cFileName);
                
                if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                    SecureDeleteDirectory(fullPath);
                } else {
                    SecureDeleteFile(fullPath);
                }
                
            } while (FindNextFileW(hFind, &findData));
            
            FindClose(hFind);
        }
    }
    
    // Clear user profile caches
    if (SHGetSpecialFolderPathW(NULL, userProfile, CSIDL_PROFILE, FALSE)) {
        WCHAR cachePath[LACKY_MAX_PATH];
        StringCchPrintfW(cachePath, LACKY_MAX_PATH, L"%s\\AppData\\Local\\LackyVault", userProfile);
        SecureDeleteDirectory(cachePath);
        
        StringCchPrintfW(cachePath, LACKY_MAX_PATH, L"%s\\AppData\\Roaming\\LackyVault", userProfile);
        SecureDeleteDirectory(cachePath);
    }
    
    return TRUE;
}

/**
 * Main uninstall function
 */
INT WINAPI LackyVaultUninstall(VOID) {
    BOOL success = TRUE;
    
    wprintf(L"LackyVault Secure Uninstaller\n");
    wprintf(L"=============================\n\n");
    
    // Step 1: Terminate running processes
    wprintf(L"Terminating LackyVault processes...\n");
    if (!TerminateLackyVaultProcesses()) {
        wprintf(L"Warning: Failed to terminate some processes\n");
    }
    
    // Step 2: Remove installation files
    wprintf(L"Removing installation files...\n");
    WCHAR installPath[MAX_PATH];
    HKEY hKey;
    DWORD dataSize = sizeof(installPath);
    
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, 
                     L"Software\\LackadaisicalSecurity\\LackyVault", 
                     0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        RegQueryValueExW(hKey, L"InstallLocation", NULL, NULL, 
                        (LPBYTE)installPath, &dataSize);
        RegCloseKey(hKey);
        
        if (wcslen(installPath) > 0) {
            SecureDeleteDirectory(installPath);
        }
    }
    
    // Step 3: Clean registry
    wprintf(L"Cleaning registry entries...\n");
    CleanRegistryEntries();
    
    // Step 4: Remove firewall rules
    wprintf(L"Removing firewall rules...\n");
    RemoveFirewallRules();
    
    // Step 5: Clear temporary files
    wprintf(L"Clearing temporary files...\n");
    ClearTemporaryFiles();
    
    // Step 6: Clear event logs
    wprintf(L"Clearing event logs...\n");
    ClearEventLogs();
    
    // Step 7: Remove start menu shortcuts
    wprintf(L"Removing shortcuts...\n");
    WCHAR startMenuPath[MAX_PATH];
    if (SHGetSpecialFolderPathW(NULL, startMenuPath, CSIDL_COMMON_PROGRAMS, FALSE)) {
        WCHAR lackyStartMenu[LACKY_MAX_PATH];
        StringCchPrintfW(lackyStartMenu, LACKY_MAX_PATH, L"%s\\LackyVault", startMenuPath);
        SecureDeleteDirectory(lackyStartMenu);
    }
    
    // Step 8: Remove desktop shortcut
    WCHAR desktopPath[MAX_PATH];
    if (SHGetSpecialFolderPathW(NULL, desktopPath, CSIDL_COMMON_DESKTOPDIRECTORY, FALSE)) {
        WCHAR shortcut[LACKY_MAX_PATH];
        StringCchPrintfW(shortcut, LACKY_MAX_PATH, L"%s\\LackyVault.lnk", desktopPath);
        SecureDeleteFile(shortcut);
    }
    
    wprintf(L"\nUninstallation completed successfully.\n");
    wprintf(L"LackyVault has been securely removed from your system.\n\n");
    wprintf(L"Thank you for using LackyVault!\n");
    
    return success ? 0 : 1;
}

/**
 * Entry point
 */
INT WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
                   LPWSTR lpCmdLine, INT nCmdShow) {
    UNREFERENCED_PARAMETER(hInstance);
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);
    UNREFERENCED_PARAMETER(nCmdShow);
    
    // Allocate console for output
    AllocConsole();
    freopen_s((FILE**)stdout, "CONOUT$", "w", stdout);
    freopen_s((FILE**)stderr, "CONOUT$", "w", stderr);
    freopen_s((FILE**)stdin, "CONIN$", "r", stdin);
    
    INT result = LackyVaultUninstall();
    
    wprintf(L"\nPress any key to exit...");
    _getwch();
    
    FreeConsole();
    return result;
}
