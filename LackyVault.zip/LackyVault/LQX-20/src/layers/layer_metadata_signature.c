/**
 * @file layer_metadata_signature.c
 * @brief LQX-10 Layer 9: Metadata Signature Implementation
 * 
 * Ninth layer implementing cryptographic signatures and metadata
 * authentication for integrity and non-repudiation.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../../include/lqx10_layers.h"
#include "../../include/lqx10_crypto.h"
#include <string.h>
#include <time.h>
#include <stdlib.h>

// Metadata signature parameters
#define METADATA_SIZE 64
#define SIGNATURE_SIZE 64
#define TIMESTAMP_SIZE 8

// Layer 9: Metadata Signature Forward Transform
lqx10_error_t lqx10_layer9_forward(lqx10_context_t* ctx, const uint8_t* input, 
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (*output_len < input_len + LQX10_LAYER9_OVERHEAD) {
        *output_len = input_len + LQX10_LAYER9_OVERHEAD;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    size_t working_len = input_len;
    
    // Copy input data
    memcpy(output, input, input_len);
    
    // Generate metadata
    uint8_t metadata[METADATA_SIZE];
    memset(metadata, 0, sizeof(metadata));
    
    // Add timestamp
    uint64_t timestamp = (uint64_t)time(NULL);
    memcpy(metadata, &timestamp, TIMESTAMP_SIZE);
    
    // Add data length
    uint64_t data_length = input_len;
    memcpy(metadata + TIMESTAMP_SIZE, &data_length, 8);
    
    // Add data hash
    uint8_t data_hash[32];
    result = lqx10_blake3_hash(input, input_len, data_hash, 32);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    memcpy(metadata + TIMESTAMP_SIZE + 8, data_hash, 32);
    
    // Add layer sequence number
    metadata[TIMESTAMP_SIZE + 8 + 32] = 9; // Layer 9
    
    // Add context ID
    memcpy(metadata + TIMESTAMP_SIZE + 8 + 32 + 1, &ctx->magic, 4);
    
    // Generate signature over data + metadata
    uint8_t signature[SIGNATURE_SIZE];
    
    // Create signing input (data + metadata)
    size_t signing_input_len = input_len + METADATA_SIZE;
    uint8_t* signing_input = malloc(signing_input_len);
    if (!signing_input) {
        return LQX10_ERROR_MEMORY_ALLOC;
    }
    
    memcpy(signing_input, input, input_len);
    memcpy(signing_input + input_len, metadata, METADATA_SIZE);
    
    // Generate HMAC signature using layer key
    result = lqx10_hmac_sha256(ctx->layer_keys[8], 32, signing_input, signing_input_len, signature);
    
    // Clear signing input
    lqx10_secure_zero(signing_input, signing_input_len);
    free(signing_input);
    
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Truncate signature to fit
    if (SIGNATURE_SIZE < 32) {
        memmove(signature, signature, SIGNATURE_SIZE);
    }
    
    // Append metadata and signature
    memcpy(output + working_len, metadata, METADATA_SIZE);
    working_len += METADATA_SIZE;
    
    memcpy(output + working_len, signature, SIGNATURE_SIZE);
    working_len += SIGNATURE_SIZE;
    
    *output_len = working_len;
    return LQX10_SUCCESS;
}

// Layer 9: Metadata Signature Reverse Transform
lqx10_error_t lqx10_layer9_reverse(lqx10_context_t* ctx, const uint8_t* input,
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (input_len < LQX10_LAYER9_OVERHEAD) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t data_len = input_len - LQX10_LAYER9_OVERHEAD;
    
    if (*output_len < data_len) {
        *output_len = data_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Extract metadata and signature
    const uint8_t* metadata = input + data_len;
    const uint8_t* signature = input + data_len + METADATA_SIZE;
    
    // Verify signature
    size_t signing_input_len = data_len + METADATA_SIZE;
    uint8_t* signing_input = malloc(signing_input_len);
    if (!signing_input) {
        return LQX10_ERROR_MEMORY_ALLOC;
    }
    
    memcpy(signing_input, input, data_len);
    memcpy(signing_input + data_len, metadata, METADATA_SIZE);
    
    uint8_t computed_signature[64];
    result = lqx10_hmac_sha256(ctx->layer_keys[8], 32, signing_input, signing_input_len, computed_signature);
    
    // Clear signing input
    lqx10_secure_zero(signing_input, signing_input_len);
    free(signing_input);
    
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Compare signatures (constant time)
    int sig_match = 0;
    for (int i = 0; i < SIGNATURE_SIZE; i++) {
        sig_match |= (computed_signature[i] ^ signature[i]);
    }
    
    if (sig_match != 0) {
        return LQX10_ERROR_AUTH_FAILURE;
    }
    
    // Verify metadata
    uint64_t stored_length;
    memcpy(&stored_length, metadata + TIMESTAMP_SIZE, 8);
    
    if (stored_length != data_len) {
        return LQX10_ERROR_AUTH_FAILURE;
    }
    
    // Verify data hash
    uint8_t computed_hash[32];
    result = lqx10_blake3_hash(input, data_len, computed_hash, 32);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    if (memcmp(computed_hash, metadata + TIMESTAMP_SIZE + 8, 32) != 0) {
        return LQX10_ERROR_AUTH_FAILURE;
    }
    
    // Verify layer sequence
    if (metadata[TIMESTAMP_SIZE + 8 + 32] != 9) {
        return LQX10_ERROR_INVALID_LAYER;
    }
    
    // Verify context ID
    uint32_t stored_magic;
    memcpy(&stored_magic, metadata + TIMESTAMP_SIZE + 8 + 32 + 1, 4);
    
    if (stored_magic != ctx->magic) {
        return LQX10_ERROR_CONTEXT_CORRUPTED;
    }
    
    // Check timestamp for reasonable bounds (anti-replay)
    uint64_t stored_timestamp;
    memcpy(&stored_timestamp, metadata, TIMESTAMP_SIZE);
    
    uint64_t current_time = (uint64_t)time(NULL);
    
    // Allow 1 hour time skew
    if (stored_timestamp > current_time + 3600 || 
        stored_timestamp < current_time - 3600) {
        // Timestamp out of reasonable range - possible replay attack
        return LQX10_ERROR_AUTH_FAILURE;
    }
    
    // Copy verified data
    memcpy(output, input, data_len);
    
    *output_len = data_len;
    return LQX10_SUCCESS;
}
