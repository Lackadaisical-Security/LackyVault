/**
 * @file layer_final_shroud.c
 * @brief LQX-10 Layer 10: Final Shroud Implementation
 * 
 * Tenth and final layer implementing ultimate data protection
 * with steganographic hiding and plausible deniability.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../../include/lqx10_layers.h"
#include "../../include/lqx10_crypto.h"
#include <string.h>

// Final shroud parameters
#define SHROUD_HEADER_SIZE 128
#define STEGANOGRAPHIC_RATIO 8  // 1 real bit per 8 carrier bits
#define PLAUSIBLE_DENIAL_SIZE 256

// Layer 10: Final Shroud Forward Transform
lqx10_error_t lqx10_layer10_forward(lqx10_context_t* ctx, const uint8_t* input, 
                                    size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t steganographic_size = input_len * STEGANOGRAPHIC_RATIO;
    size_t total_size = SHROUD_HEADER_SIZE + steganographic_size + PLAUSIBLE_DENIAL_SIZE;
    
    if (*output_len < total_size) {
        *output_len = total_size;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    size_t working_len = 0;
    
    // Generate plausible cover data (fake document header)
    uint8_t shroud_header[SHROUD_HEADER_SIZE];
    
    // Make it look like a PDF header
    const char pdf_header[] = "%PDF-1.7\n%âãÏÓ\n1 0 obj\n<<\n/Type /Catalog\n/Pages 2 0 R\n>>\nendobj\n2 0 obj\n<<\n/Type /Pages\n/Kids [3 0 R]\n/Count 1\n>>\nendobj\n";
    
    memcpy(shroud_header, pdf_header, strlen(pdf_header));
    
    // Fill rest with plausible PDF-like content
    for (size_t i = strlen(pdf_header); i < SHROUD_HEADER_SIZE; i++) {
        shroud_header[i] = 0x20 + (ctx->layer_keys[9][i % 32] % 95); // Printable ASCII
    }
    
    memcpy(output + working_len, shroud_header, SHROUD_HEADER_SIZE);
    working_len += SHROUD_HEADER_SIZE;
    
    // Generate carrier data for steganography
    uint8_t* carrier_data = output + working_len;
    
    // Fill with realistic-looking data
    result = lqx10_secure_random_bytes(carrier_data, steganographic_size);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Hide real data in carrier using LSB steganography
    for (size_t i = 0; i < input_len; i++) {
        uint8_t data_byte = input[i];
        
        // Spread each bit across STEGANOGRAPHIC_RATIO bytes
        for (int bit = 0; bit < 8; bit++) {
            size_t carrier_pos = i * STEGANOGRAPHIC_RATIO + bit;
            
            if (carrier_pos < steganographic_size) {
                // Clear LSB and set to data bit
                carrier_data[carrier_pos] &= 0xFE;
                carrier_data[carrier_pos] |= (data_byte >> bit) & 1;
                
                // XOR with key for additional obfuscation
                carrier_data[carrier_pos] ^= ctx->layer_keys[9][(carrier_pos + bit) % 32];
            }
        }
    }
    
    working_len += steganographic_size;
    
    // Add plausible denial data (fake ending)
    uint8_t denial_data[PLAUSIBLE_DENIAL_SIZE];
    
    // Make it look like end of PDF
    const char pdf_end[] = "3 0 obj\n<<\n/Type /Page\n/Parent 2 0 R\n/Contents 4 0 R\n>>\nendobj\nxref\n0 5\n0000000000 65535 f\n0000000009 00000 n\n0000000074 00000 n\n0000000120 00000 n\n0000000179 00000 n\ntrailer\n<<\n/Size 5\n/Root 1 0 R\n>>\nstartxref\n492\n%%EOF\n";
    
    memcpy(denial_data, pdf_end, strlen(pdf_end));
    
    // Fill rest with more plausible content
    for (size_t i = strlen(pdf_end); i < PLAUSIBLE_DENIAL_SIZE; i++) {
        denial_data[i] = ctx->layer_keys[9][(i + SHROUD_HEADER_SIZE) % 32] ^ (uint8_t)(i & 0xFF);
    }
    
    memcpy(output + working_len, denial_data, PLAUSIBLE_DENIAL_SIZE);
    working_len += PLAUSIBLE_DENIAL_SIZE;
    
    *output_len = working_len;
    return LQX10_SUCCESS;
}

// Layer 10: Final Shroud Reverse Transform
lqx10_error_t lqx10_layer10_reverse(lqx10_context_t* ctx, const uint8_t* input,
                                    size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (input_len < SHROUD_HEADER_SIZE + PLAUSIBLE_DENIAL_SIZE) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Calculate steganographic data size
    size_t steganographic_size = input_len - SHROUD_HEADER_SIZE - PLAUSIBLE_DENIAL_SIZE;
    size_t hidden_data_len = steganographic_size / STEGANOGRAPHIC_RATIO;
    
    if (*output_len < hidden_data_len) {
        *output_len = hidden_data_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Extract carrier data
    const uint8_t* carrier_data = input + SHROUD_HEADER_SIZE;
    
    // Extract hidden data from carrier
    for (size_t i = 0; i < hidden_data_len; i++) {
        uint8_t data_byte = 0;
        
        // Reconstruct byte from spread bits
        for (int bit = 0; bit < 8; bit++) {
            size_t carrier_pos = i * STEGANOGRAPHIC_RATIO + bit;
            
            if (carrier_pos < steganographic_size) {
                // Remove key obfuscation
                uint8_t carrier_byte = carrier_data[carrier_pos] ^ ctx->layer_keys[9][(carrier_pos + bit) % 32];
                
                // Extract LSB and place in correct bit position
                data_byte |= (carrier_byte & 1) << bit;
            }
        }
        
        output[i] = data_byte;
    }
    
    *output_len = hidden_data_len;
    return LQX10_SUCCESS;
}
