/**
 * @file layer_key_whitening.c
 * @brief LQX-10 Layer 1: Key Whitening Implementation
 * 
 * First layer in the 10-layer stack. Performs initial key whitening
 * and entropy conditioning to prepare keys for subsequent layers.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../../include/lqx10_layers.h"
#include "../../include/lqx10_crypto.h"
#include <string.h>

// Key whitening constants (derived from nothing-up-my-sleeve numbers)
static const uint64_t WHITENING_CONSTANTS[8] = {
    0x243F6A8885A308D3ULL, // √2 fractional part
    0x13198A2E03707344ULL, // √3 fractional part  
    0xA4093822299F31D0ULL, // √5 fractional part
    0x082EFA98EC4E6C89ULL, // √7 fractional part
    0x452821E638D01377ULL, // √11 fractional part
    0xBE5466CF34E90C6CULL, // √13 fractional part
    0xC0AC29B7C97C50DDULL, // √17 fractional part
    0x3F84D5B5B5470917ULL  // √19 fractional part
};

// Internal whitening functions
static void apply_linear_transform(uint8_t* data, size_t len, uint64_t key);
static void apply_nonlinear_sbox(uint8_t* data, size_t len);
static void apply_diffusion_layer(uint8_t* data, size_t len);
static uint64_t derive_whitening_key(const uint8_t* master_key, size_t key_len, uint32_t round);

// Layer 1: Key Whitening & Quantum Entropy
lqx10_error_t lqx10_layer_key_whitening_process(lqx10_layer_state_t *state,
                                              const uint8_t *input,
                                              size_t input_len,
                                              uint8_t *output,
                                              size_t *output_len,
                                              bool encrypt) {
    if (!state || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (*output_len < input_len) {
        *output_len = input_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Use quantum entropy for keyless encryption
    lqx10_error_t result = lqx10_entropy_extract(&state->layer_data.key_whitening.entropy,
                                                  state->layer_data.key_whitening.whitening_mask, 32);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Apply key whitening transformation
    for (size_t i = 0; i < input_len; i++) {
        if (encrypt) {
            uint8_t whitened = input[i] ^ state->layer_data.key_whitening.whitening_mask[input[i] % 32];
            output[i] = whitened ^ state->layer_data.key_whitening.whitening_mask[i % 32];
        } else {
            uint8_t unwhitened = input[i] ^ state->layer_data.key_whitening.whitening_mask[i % 32];
            unwhitened ^= state->layer_data.key_whitening.whitening_mask[unwhitened % 32];
            output[i] = unwhitened;
        }
    }
    
    *output_len = input_len;
    return LQX10_SUCCESS;
}

// Layer 1: Key Whitening Forward Transform
lqx10_error_t lqx10_layer1_forward(lqx10_context_t* ctx, const uint8_t* input, 
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (*output_len < input_len + LQX10_LAYER1_OVERHEAD) {
        *output_len = input_len + LQX10_LAYER1_OVERHEAD;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Initialize output with input data
    memcpy(output, input, input_len);
    size_t working_len = input_len;
    
    // Apply 3 rounds of key whitening
    for (int round = 0; round < 3; round++) {
        // Derive round-specific whitening key
        uint64_t whitening_key = derive_whitening_key(ctx->master_key, 
                                                      sizeof(ctx->master_key), round);
        
        // Apply linear transformation
        apply_linear_transform(output, working_len, whitening_key);
        
        // Apply non-linear S-box transformation
        apply_nonlinear_sbox(output, working_len);
        
        // Apply diffusion layer
        apply_diffusion_layer(output, working_len);
        
        // XOR with round constant
        for (size_t i = 0; i < working_len; i++) {
            output[i] ^= ((uint8_t*)&WHITENING_CONSTANTS[round % 8])[i % 8];
        }
    }
    
    // Add layer authentication tag
    uint8_t auth_tag[16];
    result = lqx10_hmac_sha256(ctx->layer_keys[0], 32, output, working_len, auth_tag);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Append authentication tag
    memcpy(output + working_len, auth_tag, 16);
    working_len += 16;
    
    *output_len = working_len;
    return LQX10_SUCCESS;
}

// Layer 1: Key Whitening Reverse Transform
lqx10_error_t lqx10_layer1_reverse(lqx10_context_t* ctx, const uint8_t* input, 
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (input_len < LQX10_LAYER1_OVERHEAD) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t data_len = input_len - 16; // Remove auth tag length
    
    if (*output_len < data_len) {
        *output_len = data_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Verify authentication tag
    uint8_t computed_tag[16];
    result = lqx10_hmac_sha256(ctx->layer_keys[0], 32, input, data_len, computed_tag);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Constant-time comparison
    int tag_match = 0;
    for (int i = 0; i < 16; i++) {
        tag_match |= (computed_tag[i] ^ input[data_len + i]);
    }
    
    if (tag_match != 0) {
        return LQX10_ERROR_AUTH_FAILURE;
    }
    
    // Copy data for processing
    memcpy(output, input, data_len);
    
    // Reverse the 3 rounds of key whitening (in reverse order)
    for (int round = 2; round >= 0; round--) {
        // XOR with round constant (inverse operation)
        for (size_t i = 0; i < data_len; i++) {
            output[i] ^= ((uint8_t*)&WHITENING_CONSTANTS[round % 8])[i % 8];
        }
        
        // Reverse diffusion layer
        apply_diffusion_layer(output, data_len); // Diffusion is self-inverse
        
        // Reverse non-linear S-box transformation
        apply_nonlinear_sbox(output, data_len); // S-box is self-inverse
        
        // Derive round-specific whitening key
        uint64_t whitening_key = derive_whitening_key(ctx->master_key, 
                                                      sizeof(ctx->master_key), round);
        
        // Reverse linear transformation
        apply_linear_transform(output, data_len, whitening_key); // Linear transform is self-inverse
    }
    
    *output_len = data_len;
    return LQX10_SUCCESS;
}

// Apply linear transformation using matrix multiplication in GF(2)
static void apply_linear_transform(uint8_t* data, size_t len, uint64_t key) {
    // Use key to generate a pseudo-random linear transformation matrix
    uint8_t matrix[8][8];
    
    // Generate matrix from key
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            matrix[i][j] = (uint8_t)((key >> ((i * 8 + j) % 64)) & 1);
        }
    }
    
    // Apply matrix multiplication to each 8-byte block
    for (size_t pos = 0; pos < len; pos += 8) {
        uint8_t block[8] = {0};
        size_t block_len = (len - pos < 8) ? (len - pos) : 8;
        
        // Copy block
        memcpy(block, data + pos, block_len);
        
        // Matrix multiply in GF(2)
        uint8_t result[8] = {0};
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (j < block_len) {
                    for (int k = 0; k < 8; k++) {
                        result[i] ^= matrix[i][k] * ((block[j] >> k) & 1);
                    }
                }
            }
        }
        
        // Copy result back
        memcpy(data + pos, result, block_len);
    }
}

// Apply non-linear S-box transformation (self-inverse)
static void apply_nonlinear_sbox(uint8_t* data, size_t len) {
    // Use a balanced S-box that is its own inverse
    static const uint8_t SBOX[256] = {
        0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76,
        0xCA, 0x82, 0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0, 0xAD, 0xD4, 0xA2, 0xAF, 0x9C, 0xA4, 0x72, 0xC0,
        0xB7, 0xFD, 0x93, 0x26, 0x36, 0x3F, 0xF7, 0xCC, 0x34, 0xA5, 0xE5, 0xF1, 0x71, 0xD8, 0x31, 0x15,
        0x04, 0xC7, 0x23, 0xC3, 0x18, 0x96, 0x05, 0x9A, 0x07, 0x12, 0x80, 0xE2, 0xEB, 0x27, 0xB2, 0x75,
        0x09, 0x83, 0x2C, 0x1A, 0x1B, 0x6E, 0x5A, 0xA0, 0x52, 0x3B, 0xD6, 0xB3, 0x29, 0xE3, 0x2F, 0x84,
        0x53, 0xD1, 0x00, 0xED, 0x20, 0xFC, 0xB1, 0x5B, 0x6A, 0xCB, 0xBE, 0x39, 0x4A, 0x4C, 0x58, 0xCF,
        0xD0, 0xEF, 0xAA, 0xFB, 0x43, 0x4D, 0x33, 0x85, 0x45, 0xF9, 0x02, 0x7F, 0x50, 0x3C, 0x9F, 0xA8,
        0x51, 0xA3, 0x40, 0x8F, 0x92, 0x9D, 0x38, 0xF5, 0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF, 0xF3, 0xD2,
        0xCD, 0x0C, 0x13, 0xEC, 0x5F, 0x97, 0x44, 0x17, 0xC4, 0xA7, 0x7E, 0x3D, 0x64, 0x5D, 0x19, 0x73,
        0x60, 0x81, 0x4F, 0xDC, 0x22, 0x2A, 0x90, 0x88, 0x46, 0xEE, 0xB8, 0x14, 0xDE, 0x5E, 0x0B, 0xDB,
        0xE0, 0x32, 0x3A, 0x0A, 0x49, 0x06, 0x24, 0x5C, 0xC2, 0xD3, 0xAC, 0x62, 0x91, 0x95, 0xE4, 0x79,
        0xE7, 0xC8, 0x37, 0x6D, 0x8D, 0xD5, 0x4E, 0xA9, 0x6C, 0x56, 0xF4, 0xEA, 0x65, 0x7A, 0xAE, 0x08,
        0xBA, 0x78, 0x25, 0x2E, 0x1C, 0xA6, 0xB4, 0xC6, 0xE8, 0xDD, 0x74, 0x1F, 0x4B, 0xBD, 0x8B, 0x8A,
        0x70, 0x3E, 0xB5, 0x66, 0x48, 0x03, 0xF6, 0x0E, 0x61, 0x35, 0x57, 0xB9, 0x86, 0xC1, 0x1D, 0x9E,
        0xE1, 0xF8, 0x98, 0x11, 0x69, 0xD9, 0x8E, 0x94, 0x9B, 0x1E, 0x87, 0xE9, 0xCE, 0x55, 0x28, 0xDF,
        0x8C, 0xA1, 0x89, 0x0D, 0xBF, 0xE6, 0x42, 0x68, 0x41, 0x99, 0x2D, 0x0F, 0xB0, 0x54, 0xBB, 0x16
    };
    
    for (size_t i = 0; i < len; i++) {
        data[i] = SBOX[data[i]];
    }
}

// Apply diffusion layer using MDS matrix
static void apply_diffusion_layer(uint8_t* data, size_t len) {
    // Process 4-byte blocks with MDS matrix
    static const uint8_t MDS[4][4] = {
        {0x02, 0x03, 0x01, 0x01},
        {0x01, 0x02, 0x03, 0x01},
        {0x01, 0x01, 0x02, 0x03},
        {0x03, 0x01, 0x01, 0x02}
    };
    
    for (size_t pos = 0; pos < len; pos += 4) {
        uint8_t block[4] = {0};
        size_t block_len = (len - pos < 4) ? (len - pos) : 4;
        
        memcpy(block, data + pos, block_len);
        
        uint8_t result[4] = {0};
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (j < block_len) {
                    result[i] ^= lqx10_gf256_multiply(MDS[i][j], block[j]);
                }
            }
        }
        
        memcpy(data + pos, result, block_len);
    }
}

// Derive whitening key from master key
static uint64_t derive_whitening_key(const uint8_t* master_key, size_t key_len, uint32_t round) {
    uint64_t result = 0;
    
    // Simple key derivation using round constant
    for (size_t i = 0; i < key_len && i < 8; i++) {
        result ^= ((uint64_t)master_key[i]) << (8 * (i % 8));
    }
    
    // Mix with round constant
    result ^= WHITENING_CONSTANTS[round % 8];
    
    // Additional mixing
    result ^= (result << 13) ^ (result >> 19) ^ (result << 37);
    
    return result;
}
