/**
 * @file layer_network_camouflage.c
 * @brief LQX-10 Layer 5: Network Camouflage Implementation
 * 
 * Fifth layer implementing network traffic obfuscation and padding
 * to hide communication patterns and data sizes.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../../include/lqx10_layers.h"
#include "../../include/lqx10_crypto.h"
#include <string.h>

// Network camouflage parameters
#define MIN_PADDING_SIZE 16
#define MAX_PADDING_SIZE 512
#define DECOY_HEADER_SIZE 32

// Layer 5: Network Camouflage Forward Transform
lqx10_error_t lqx10_layer5_forward(lqx10_context_t* ctx, const uint8_t* input, 
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Calculate padding size (pseudo-random but deterministic for decryption)
    uint32_t padding_seed = 0;
    for (size_t i = 0; i < 32 && i < input_len; i++) {
        padding_seed ^= input[i] << (i % 24);
    }
    
    size_t padding_size = MIN_PADDING_SIZE + (padding_seed % (MAX_PADDING_SIZE - MIN_PADDING_SIZE));
    
    if (*output_len < input_len + DECOY_HEADER_SIZE + padding_size + 4) {
        *output_len = input_len + DECOY_HEADER_SIZE + padding_size + 4;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    size_t working_len = 0;
    
    // Generate decoy header
    uint8_t decoy_header[DECOY_HEADER_SIZE];
    result = lqx10_secure_random_bytes(decoy_header, sizeof(decoy_header));
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Make header look like common protocol
    decoy_header[0] = 0x16; // TLS Handshake
    decoy_header[1] = 0x03; // TLS version
    decoy_header[2] = 0x03;
    
    memcpy(output + working_len, decoy_header, DECOY_HEADER_SIZE);
    working_len += DECOY_HEADER_SIZE;
    
    // Add real data length (encrypted)
    uint32_t encrypted_len = (uint32_t)input_len;
    for (int i = 0; i < 4; i++) {
        ((uint8_t*)&encrypted_len)[i] ^= ctx->layer_keys[4][i % 32];
    }
    
    memcpy(output + working_len, &encrypted_len, 4);
    working_len += 4;
    
    // Add real data
    memcpy(output + working_len, input, input_len);
    working_len += input_len;
    
    // Add padding
    uint8_t* padding = output + working_len;
    result = lqx10_secure_random_bytes(padding, padding_size);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // XOR padding with layer key for verification
    for (size_t i = 0; i < padding_size; i++) {
        padding[i] ^= ctx->layer_keys[4][(i + 4) % 32];
    }
    
    working_len += padding_size;
    
    *output_len = working_len;
    return LQX10_SUCCESS;
}

// Layer 5: Network Camouflage Reverse Transform
lqx10_error_t lqx10_layer5_reverse(lqx10_context_t* ctx, const uint8_t* input,
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (input_len < DECOY_HEADER_SIZE + 4 + MIN_PADDING_SIZE) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Skip decoy header
    size_t pos = DECOY_HEADER_SIZE;
    
    // Extract and decrypt data length
    uint32_t encrypted_len;
    memcpy(&encrypted_len, input + pos, 4);
    pos += 4;
    
    for (int i = 0; i < 4; i++) {
        ((uint8_t*)&encrypted_len)[i] ^= ctx->layer_keys[4][i % 32];
    }
    
    size_t data_len = encrypted_len;
    
    // Validate data length
    if (data_len > input_len - DECOY_HEADER_SIZE - 4 - MIN_PADDING_SIZE) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (*output_len < data_len) {
        *output_len = data_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Extract real data
    memcpy(output, input + pos, data_len);
    pos += data_len;
    
    // Verify padding (optional verification)
    size_t padding_size = input_len - pos;
    if (padding_size >= MIN_PADDING_SIZE && padding_size <= MAX_PADDING_SIZE) {
        // Verify padding XOR pattern
        for (size_t i = 0; i < padding_size; i++) {
            uint8_t expected = input[pos + i] ^ ctx->layer_keys[4][(i + 4) % 32];
            // In a production system, you might want to validate this
            (void)expected; // Suppress unused variable warning
        }
    }
    
    *output_len = data_len;
    return LQX10_SUCCESS;
}
