/**
 * @file layer_decoy_injection.c
 * @brief LQX-10 Layer 8: Decoy Injection Implementation
 * 
 * Eighth layer implementing decoy data injection and honeypot
 * techniques to confuse attackers and detect tampering.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../../include/lqx10_layers.h"
#include "../../include/lqx10_crypto.h"
#include <string.h>

// Decoy parameters
#define DECOY_SEGMENTS 4
#define DECOY_SEGMENT_SIZE 64
#define HONEYPOT_MARKERS 8

// Layer 8: Decoy Injection Forward Transform
lqx10_error_t lqx10_layer8_forward(lqx10_context_t* ctx, const uint8_t* input, 
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t total_decoy_size = DECOY_SEGMENTS * DECOY_SEGMENT_SIZE + HONEYPOT_MARKERS * 4;
    
    if (*output_len < input_len + total_decoy_size + 4) {
        *output_len = input_len + total_decoy_size + 4;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    size_t working_len = 0;
    
    // Store real data length (encrypted)
    uint32_t real_len = (uint32_t)input_len;
    for (int i = 0; i < 4; i++) {
        ((uint8_t*)&real_len)[i] ^= ctx->layer_keys[7][i];
    }
    
    memcpy(output + working_len, &real_len, 4);
    working_len += 4;
    
    // Generate and inject decoy segments
    for (int seg = 0; seg < DECOY_SEGMENTS; seg++) {
        uint8_t decoy_data[DECOY_SEGMENT_SIZE];
        
        // Generate plausible decoy data
        for (int i = 0; i < DECOY_SEGMENT_SIZE; i++) {
            // Create realistic-looking data patterns
            if (i % 16 < 8) {
                // ASCII-like patterns
                decoy_data[i] = 0x20 + (ctx->layer_keys[7][(seg * DECOY_SEGMENT_SIZE + i) % 32] % 96);
            } else {
                // Binary-like patterns
                decoy_data[i] = ctx->layer_keys[7][(seg * DECOY_SEGMENT_SIZE + i) % 32] ^ (uint8_t)(i + seg);
            }
        }
        
        // Add some real data mixed in
        size_t real_data_pos = (seg * input_len) / DECOY_SEGMENTS;
        size_t mix_len = input_len / DECOY_SEGMENTS;
        if (mix_len > DECOY_SEGMENT_SIZE / 2) {
            mix_len = DECOY_SEGMENT_SIZE / 2;
        }
        
        if (real_data_pos + mix_len <= input_len) {
            for (size_t i = 0; i < mix_len; i++) {
                size_t decoy_pos = (i * 2) + (seg % 2);
                if (decoy_pos < DECOY_SEGMENT_SIZE) {
                    decoy_data[decoy_pos] = input[real_data_pos + i] ^ ctx->layer_keys[7][(i + seg) % 32];
                }
            }
        }
        
        memcpy(output + working_len, decoy_data, DECOY_SEGMENT_SIZE);
        working_len += DECOY_SEGMENT_SIZE;
    }
    
    // Add real data in the middle
    memcpy(output + working_len, input, input_len);
    working_len += input_len;
    
    // Add honeypot markers
    for (int marker = 0; marker < HONEYPOT_MARKERS; marker++) {
        uint32_t honeypot = 0xDEADBEEF ^ (marker * 0x12345678);
        
        // Encrypt honeypot marker
        for (int i = 0; i < 4; i++) {
            ((uint8_t*)&honeypot)[i] ^= ctx->layer_keys[7][(marker * 4 + i + 4) % 32];
        }
        
        memcpy(output + working_len, &honeypot, 4);
        working_len += 4;
    }
    
    *output_len = working_len;
    return LQX10_SUCCESS;
}

// Layer 8: Decoy Injection Reverse Transform
lqx10_error_t lqx10_layer8_reverse(lqx10_context_t* ctx, const uint8_t* input,
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t total_decoy_size = DECOY_SEGMENTS * DECOY_SEGMENT_SIZE + HONEYPOT_MARKERS * 4;
    
    if (input_len < total_decoy_size + 4) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Extract and decrypt real data length
    uint32_t real_len;
    memcpy(&real_len, input, 4);
    
    for (int i = 0; i < 4; i++) {
        ((uint8_t*)&real_len)[i] ^= ctx->layer_keys[7][i];
    }
    
    if (real_len > input_len - total_decoy_size - 4) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (*output_len < real_len) {
        *output_len = real_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Verify honeypot markers (tamper detection)
    size_t honeypot_start = 4 + DECOY_SEGMENTS * DECOY_SEGMENT_SIZE + real_len;
    
    for (int marker = 0; marker < HONEYPOT_MARKERS; marker++) {
        uint32_t stored_honeypot;
        memcpy(&stored_honeypot, input + honeypot_start + marker * 4, 4);
        
        // Decrypt honeypot marker
        for (int i = 0; i < 4; i++) {
            ((uint8_t*)&stored_honeypot)[i] ^= ctx->layer_keys[7][(marker * 4 + i + 4) % 32];
        }
        
        uint32_t expected_honeypot = 0xDEADBEEF ^ (marker * 0x12345678);
        
        if (stored_honeypot != expected_honeypot) {
            // Honeypot triggered - possible tampering detected
            return LQX10_ERROR_AUTH_FAILURE;
        }
    }
    
    // Extract real data (skip decoy segments)
    size_t real_data_start = 4 + DECOY_SEGMENTS * DECOY_SEGMENT_SIZE;
    memcpy(output, input + real_data_start, real_len);
    
    *output_len = real_len;
    return LQX10_SUCCESS;
}
