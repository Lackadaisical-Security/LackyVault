#include "../../include/lqx10_core.h"
#include "../../include/lqx10_crypto.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdio.h>

#ifdef _WIN32
#include <windows.h>
#include <intrin.h>
#else
#include <sys/time.h>
#include <unistd.h>
#endif

// Forward declarations for layer process functions
lqx10_error_t lqx10_layer_key_whitening_process(lqx10_layer_state_t *state, const uint8_t *input, size_t input_len, uint8_t *output, size_t *output_len, bool encrypt);
lqx10_error_t lqx10_layer_entropy_mixer_process(lqx10_layer_state_t *state, const uint8_t *input, size_t input_len, uint8_t *output, size_t *output_len, bool encrypt);
lqx10_error_t lqx10_layer_classical_cipher_process(lqx10_layer_state_t *state, const uint8_t *input, size_t input_len, uint8_t *output, size_t *output_len, bool encrypt);
lqx10_error_t lqx10_layer_post_quantum_process(lqx10_layer_state_t *state, const uint8_t *input, size_t input_len, uint8_t *output, size_t *output_len, bool encrypt);
lqx10_error_t lqx10_layer_network_camouflage_process(lqx10_layer_state_t *state, const uint8_t *input, size_t input_len, uint8_t *output, size_t *output_len, bool encrypt);
lqx10_error_t lqx10_layer_padding_jitter_process(lqx10_layer_state_t *state, const uint8_t *input, size_t input_len, uint8_t *output, size_t *output_len, bool encrypt);
lqx10_error_t lqx10_layer_runtime_mutation_process(lqx10_layer_state_t *state, const uint8_t *input, size_t input_len, uint8_t *output, size_t *output_len, bool encrypt);

// Layer state structure
struct lqx10_layer_state {
    lqx10_layer_type_t type;
    uint8_t layer_key[LQX10_KEY_SIZE];
    uint8_t layer_iv[LQX10_IV_SIZE];
    uint64_t operation_counter;
    uint32_t state_entropy;
    bool initialized;
    
    // Layer-specific state
    union {
        struct {
            uint8_t whitening_mask[32];
            uint32_t rotation_counter;
        } key_whitening;
        
        struct {
            uint8_t entropy_pool[256];
            uint32_t pool_index;
            uint64_t mix_counter;
        } entropy_mixer;
        
        struct {
            uint8_t round_keys[14][16];
            uint32_t rounds;
            uint8_t substitution_box[256];
            uint32_t mix_columns[4][256];
        } classical_cipher;
        
        struct {
            uint8_t pq_state[1024];
            uint32_t lattice_dimension;
        } post_quantum;
        
        struct {
            uint8_t traffic_pattern[64];
            uint32_t packet_delay;
            uint16_t fake_port;
        } network_camouflage;
        
        struct {
            uint32_t padding_sizes[16];
            uint64_t jitter_seed;
        } padding_jitter;
        
        struct {
            uint8_t mutation_table[256];
            uint64_t mutation_key;
            uint32_t mutation_round;
        } runtime_mutation;
        
        struct {
            uint8_t decoy_data[128];
            uint32_t decoy_count;
            uint64_t injection_pattern;
        } decoy_injection;
        
        struct {
            uint8_t metadata_hash[32];
            uint64_t signature_nonce;
        } metadata_signature;
        
        struct {
            uint8_t shroud_key[32];
            uint8_t final_iv[16];
            bool obfuscation_enabled;
        } final_shroud;
    } layer_data;
};

// =================== LAYER INITIALIZATION ===================

lqx10_error_t lqx10_layer_init(lqx10_layer_state_t *state,
                               lqx10_layer_type_t type,
                               const uint8_t *key) {
    if (!state || !key) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (type >= LQX10_LAYER_COUNT) {
        return LQX10_ERROR_INVALID_LAYER;
    }
    
    memset(state, 0, sizeof(lqx10_layer_state_t));
    state->type = type;
    memcpy(state->layer_key, key, LQX10_KEY_SIZE);
    
    // Generate layer-specific IV from key using PBKDF2
    uint8_t salt[16] = {0x4c, 0x51, 0x58, 0x31, 0x30, 0x4c, 0x61, 0x79, 
                        0x65, 0x72, 0x49, 0x56, (uint8_t)type, 0x00, 0x00, 0x00};
    
    lqx10_error_t result = lqx10_pbkdf2_sha256(key, LQX10_KEY_SIZE, salt, sizeof(salt), 
                                              1000, state->layer_iv, LQX10_IV_SIZE);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Initialize layer-specific state
    switch (type) {
        case LQX10_LAYER_KEY_WHITENING:
            result = lqx10_pbkdf2_sha256(key, LQX10_KEY_SIZE, (uint8_t*)"WHITENING", 9,
                                        500, state->layer_data.key_whitening.whitening_mask, 32);
            break;
              case LQX10_LAYER_ENTROPY_MIXER:
            result = lqx10_secure_random_bytes_pure(state->layer_data.entropy_mixer.entropy_pool, 256);
            state->layer_data.entropy_mixer.pool_index = 0;
            state->layer_data.entropy_mixer.mix_counter = 0;
            break;
            
        case LQX10_LAYER_CLASSICAL_CIPHER:
            // Generate AES round keys
            result = lqx10_aes_key_schedule_pure(key, state->layer_data.classical_cipher.round_keys);
            state->layer_data.classical_cipher.rounds = 14; // AES-256
            break;
            
        case LQX10_LAYER_POST_QUANTUM:
            // Initialize post-quantum state with key-derived randomness
            result = lqx10_pbkdf2_sha256(key, LQX10_KEY_SIZE, (uint8_t*)"POSTQUANTUM", 11,
                                        2000, state->layer_data.post_quantum.pq_state, 1024);
            state->layer_data.post_quantum.lattice_dimension = 512;
            break;
            
        case LQX10_LAYER_NETWORK_CAMOUFLAGE:
            // Generate traffic pattern
            result = lqx10_secure_random_bytes_pure(state->layer_data.network_camouflage.traffic_pattern, 64);
            state->layer_data.network_camouflage.packet_delay = 50 + (key[0] % 200); // 50-250ms
            state->layer_data.network_camouflage.fake_port = 8000 + (((uint16_t)key[1] << 8) | key[2]) % 10000;
            break;
            
        case LQX10_LAYER_PADDING_JITTER:
            // Initialize padding sizes with key-based randomness
            for (int i = 0; i < 16; i++) {
                state->layer_data.padding_jitter.padding_sizes[i] = 1 + (key[i] % 31); // 1-32 bytes
            }
            state->layer_data.padding_jitter.jitter_seed = ((uint64_t)key[24] << 56) |
                                                          ((uint64_t)key[25] << 48) |
                                                          ((uint64_t)key[26] << 40) |
                                                          ((uint64_t)key[27] << 32) |
                                                          ((uint64_t)key[28] << 24) |
                                                          ((uint64_t)key[29] << 16) |
                                                          ((uint64_t)key[30] << 8) |
                                                          key[31];
            break;
            
        case LQX10_LAYER_RUNTIME_MUTATION:
            // Create S-box from key
            for (int i = 0; i < 256; i++) {
                state->layer_data.runtime_mutation.mutation_table[i] = i;
            }
            // Fisher-Yates shuffle with key
            for (int i = 255; i > 0; i--) {
                int j = (key[i % LQX10_KEY_SIZE] + state->layer_data.runtime_mutation.mutation_table[i]) % (i + 1);
                uint8_t temp = state->layer_data.runtime_mutation.mutation_table[i];
                state->layer_data.runtime_mutation.mutation_table[i] = state->layer_data.runtime_mutation.mutation_table[j];
                state->layer_data.runtime_mutation.mutation_table[j] = temp;
            }
            state->layer_data.runtime_mutation.mutation_key = ((uint64_t)key[0] << 56) |
                                                             ((uint64_t)key[8] << 48) |
                                                             ((uint64_t)key[16] << 40) |
                                                             ((uint64_t)key[24] << 32);
            break;
            
        case LQX10_LAYER_DECOY_INJECTION:
            // Generate decoy data
            result = lqx10_secure_random_bytes_pure(state->layer_data.decoy_injection.decoy_data, 128);
            state->layer_data.decoy_injection.decoy_count = 1 + (key[0] % 8); // 1-8 decoys
            state->layer_data.decoy_injection.injection_pattern = ((uint64_t)key[16] << 32) | 
                                                                 ((uint64_t)key[17] << 24) |
                                                                 ((uint64_t)key[18] << 16) |
                                                                 key[19];
            break;
            
        case LQX10_LAYER_METADATA_SIGNATURE:
            // Initialize metadata hash
            result = lqx10_sha256_hash(key, LQX10_KEY_SIZE, state->layer_data.metadata_signature.metadata_hash);
            state->layer_data.metadata_signature.signature_nonce = ((uint64_t)key[8] << 32) | 
                                                                  ((uint64_t)key[12] << 16) | 
                                                                  key[16];
            break;
            
        case LQX10_LAYER_FINAL_SHROUD:
            // Derive final shroud key
            result = lqx10_pbkdf2_sha256(key, LQX10_KEY_SIZE, (uint8_t*)"FINALSHROUD", 11,
                                        5000, state->layer_data.final_shroud.shroud_key, 32);
            if (result == LQX10_SUCCESS) {
                result = lqx10_secure_random_bytes_pure(state->layer_data.final_shroud.final_iv, 16);
                state->layer_data.final_shroud.obfuscation_enabled = true;
            }
            break;
            
        default:
            return LQX10_ERROR_INVALID_LAYER;
    }
    
    if (result != LQX10_SUCCESS) {
        memset(state, 0, sizeof(lqx10_layer_state_t));
        return result;
    }
    
    state->initialized = true;
    return LQX10_SUCCESS;
}

// Generic layer processing
lqx10_error_t lqx10_layer_process(lqx10_context_t *ctx,
                                  lqx10_layer_type_t layer,
                                  const uint8_t *input,
                                  size_t input_len,
                                  uint8_t *output,
                                  size_t *output_len,
                                  bool encrypt) {
    if (!ctx || !input || !output || !output_len || input_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (layer >= LQX10_LAYER_COUNT || !ctx->layer_states[layer] || !ctx->layer_states[layer]->initialized) {
        return LQX10_ERROR_INVALID_LAYER;
    }
    
    lqx10_layer_state_t *state = ctx->layer_states[layer];
    
    switch (layer) {
        case LQX10_LAYER_KEY_WHITENING:
            return lqx10_layer_key_whitening_process(state, input, input_len, output, output_len, encrypt);
            
        case LQX10_LAYER_ENTROPY_MIXER:
            return lqx10_layer_entropy_mixer_process(state, input, input_len, output, output_len, encrypt);
            
        case LQX10_LAYER_CLASSICAL_CIPHER:
            return lqx10_layer_classical_cipher_process(state, input, input_len, output, output_len, encrypt);
            
        case LQX10_LAYER_POST_QUANTUM:
            return lqx10_layer_post_quantum_process(state, input, input_len, output, output_len, encrypt);
            
        case LQX10_LAYER_NETWORK_CAMOUFLAGE:
            return lqx10_layer_network_camouflage_process(state, input, input_len, output, output_len, encrypt);
            
        case LQX10_LAYER_PADDING_JITTER:
            return lqx10_layer_padding_jitter_process(state, input, input_len, output, output_len, encrypt);
            
        case LQX10_LAYER_RUNTIME_MUTATION:
            return lqx10_layer_runtime_mutation_process(state, input, input_len, output, output_len, encrypt);
            
        case LQX10_LAYER_DECOY_INJECTION:
            // Simplified implementation - in production would inject actual decoys
            return lqx10_layer_entropy_mixer_process(state, input, input_len, output, output_len, encrypt);
            
        case LQX10_LAYER_METADATA_SIGNATURE:
            // Simplified implementation - in production would handle metadata
            return lqx10_layer_classical_cipher_process(state, input, input_len, output, output_len, encrypt);
            
        case LQX10_LAYER_FINAL_SHROUD:
            // Final obfuscation layer
            return lqx10_aes_encrypt_pure(state->layer_data.final_shroud.shroud_key,
                                         state->layer_data.final_shroud.final_iv,
                                         input, input_len, output, output_len);
            
        default:
            return LQX10_ERROR_INVALID_LAYER;
    }
}

// Layer 1: Key Whitening & Quantum Entropy
lqx10_error_t lqx10_layer1_key_whitening_init(lqx10_layer_state_t *state, 
                                               const uint8_t *key) {
    if (!state || !key) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Initialize entropy state (using rotation counter for entropy tracking)
    state->layer_data.key_whitening.rotation_counter = 0;
    
    // Generate whitening mask from key using simple method
    for (int i = 0; i < 32; i++) {
        state->layer_data.key_whitening.whitening_mask[i] = key[i % LQX10_KEY_SIZE] ^ (uint8_t)i;
    }
    
    return LQX10_SUCCESS;
}

lqx10_error_t lqx10_layer1_key_whitening_process(lqx10_layer_state_t *state,
                                                  const uint8_t *input,
                                                  size_t input_len,
                                                  uint8_t *output,
                                                  size_t *output_len,
                                                  bool encrypt) {
    if (!state || !input || !output || !output_len || input_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (*output_len < input_len + 32) { // Add entropy bytes
        *output_len = input_len + 32;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Generate fresh entropy using rotation counter
    uint8_t entropy_bytes[32];
    for (int i = 0; i < 32; i++) {
        entropy_bytes[i] = state->layer_data.key_whitening.whitening_mask[i] ^ 
                          (uint8_t)(state->layer_data.key_whitening.rotation_counter + i);
    }
    state->layer_data.key_whitening.rotation_counter++;
    
    if (encrypt) {
        // Whiten the input using the mask and entropy
        for (size_t i = 0; i < input_len; i++) {
            uint8_t whitened = input[i] ^ state->layer_data.key_whitening.whitening_mask[input[i] % 32];
            whitened ^= entropy_bytes[i % sizeof(entropy_bytes)];
            output[i] = whitened;
        }
        
        // Append entropy
        memcpy(output + input_len, entropy_bytes, sizeof(entropy_bytes));
        *output_len = input_len + sizeof(entropy_bytes);
    } else {
        // Decrypt: remove entropy and un-whiten
        if (input_len < 32) {
            return LQX10_ERROR_CRYPTO_FAILURE;
        }
        
        size_t data_len = input_len - 32;
        const uint8_t *entropy = input + data_len;
        
        for (size_t i = 0; i < data_len; i++) {
            uint8_t unwhitened = input[i] ^ entropy[i % 32];
            unwhitened ^= state->layer_data.key_whitening.whitening_mask[unwhitened % 32];
            output[i] = unwhitened;
        }
        
        *output_len = data_len;
    }
    
    // Clear entropy
    lqx10_secure_memzero(entropy_bytes, sizeof(entropy_bytes));
    
    return LQX10_SUCCESS;
}

// Layer 2: Entropy Mixer & KDF
lqx10_error_t lqx10_layer2_entropy_mixer_init(lqx10_layer_state_t *state,
                                               const uint8_t *key) {
    if (!state || !key) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Initialize entropy pool with key-derived values
    for (int i = 0; i < 512; i += 32) {
        uint8_t hash_input[LQX10_KEY_SIZE + 4];
        memcpy(hash_input, key, LQX10_KEY_SIZE);
        *((uint32_t*)(hash_input + LQX10_KEY_SIZE)) = i;
        
        uint8_t hash_output[32];
        lqx10_error_t result = lqx10_blake3_hash(hash_input, sizeof(hash_input), 
                                                 hash_output, sizeof(hash_output));
        if (result != LQX10_SUCCESS) {
            return result;
        }
        
        memcpy(state->layer_data.entropy_mixer.entropy_pool + i, hash_output, 
               LQX10_MIN(32, 512 - i));
    }
    
    // Initialize mix counter and pool index
    state->layer_data.entropy_mixer.mix_counter = 0;
    state->layer_data.entropy_mixer.pool_index = 0;
    
    return LQX10_SUCCESS;
}

lqx10_error_t lqx10_layer2_entropy_mixer_process(lqx10_layer_state_t *state,
                                                  const uint8_t *input,
                                                  size_t input_len,
                                                  uint8_t *output,
                                                  size_t *output_len,
                                                  bool encrypt) {
    if (!state || !input || !output || !output_len || input_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (*output_len < input_len + 16) { // Add mixed entropy
        *output_len = input_len + 16;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Update mix counter with timing
    clock_t current_time = clock();
    state->layer_data.entropy_mixer.mix_counter ^= (uint64_t)current_time;
    
    // Mix entropy pool using mix counter
    uint32_t mix_index = (uint32_t)(state->layer_data.entropy_mixer.mix_counter % 256);
    uint32_t mix_value = state->layer_data.entropy_mixer.mix_counter;
    
    for (int i = 0; i < 16; i++) {
        uint32_t pool_index = (mix_value + i) % (512 / 4);
        ((uint32_t*)state->layer_data.entropy_mixer.entropy_pool)[pool_index] ^= mix_value;
    }
    
    if (encrypt) {
        // Mix input with entropy
        for (size_t i = 0; i < input_len; i++) {
            uint8_t entropy_byte = state->layer_data.entropy_mixer.entropy_pool[i % 512];
            output[i] = input[i] ^ entropy_byte;
        }
        
        // Append mixed entropy fingerprint
        memcpy(output + input_len, state->layer_data.entropy_mixer.entropy_pool, 16);
        *output_len = input_len + 16;
    } else {
        // Decrypt: unmix
        if (input_len < 16) {
            return LQX10_ERROR_CRYPTO_FAILURE;
        }
        
        size_t data_len = input_len - 16;
        
        for (size_t i = 0; i < data_len; i++) {
            uint8_t entropy_byte = state->layer_data.entropy_mixer.entropy_pool[i % 512];
            output[i] = input[i] ^ entropy_byte;
        }
        
        *output_len = data_len;
    }
    
    return LQX10_SUCCESS;
}

// Layer 3: Classical Cipher Block Embed
lqx10_error_t lqx10_layer3_classical_cipher_init(lqx10_layer_state_t *state,
                                                  const uint8_t *key) {
    if (!state || !key) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Generate round keys using HKDF
    for (int i = 0; i < 16; i++) {
        uint8_t info[16];
        snprintf((char*)info, sizeof(info), "Round-%02d", i);
        
        lqx10_error_t result = lqx10_hkdf_expand(key, LQX10_KEY_SIZE,
                                                 info, strlen((char*)info),
                                                 state->layer_data.classical_cipher.round_keys[i],
                                                 LQX10_KEY_SIZE);
        if (result != LQX10_SUCCESS) {
            return result;
        }
    }
    
    // Generate S-Box
    for (int i = 0; i < 256; i++) {
        state->layer_data.classical_cipher.substitution_box[i] = (uint8_t)i;
    }
    
    // Shuffle S-Box using key
    for (int i = 255; i > 0; i--) {
        int j = key[i % LQX10_KEY_SIZE] % (i + 1);
        uint8_t temp = state->layer_data.classical_cipher.substitution_box[i];
        state->layer_data.classical_cipher.substitution_box[i] = 
            state->layer_data.classical_cipher.substitution_box[j];
        state->layer_data.classical_cipher.substitution_box[j] = temp;
    }
    
    // Generate mix columns matrix
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 256; j++) {
            uint8_t hash_input[LQX10_KEY_SIZE + 2];
            memcpy(hash_input, key, LQX10_KEY_SIZE);
            hash_input[LQX10_KEY_SIZE] = (uint8_t)i;
            hash_input[LQX10_KEY_SIZE + 1] = (uint8_t)j;
            
            uint8_t hash_output[4];
            lqx10_error_t result = lqx10_blake3_hash(hash_input, sizeof(hash_input),
                                                     hash_output, sizeof(hash_output));
            if (result != LQX10_SUCCESS) {
                return result;
            }
            
            state->layer_data.classical_cipher.mix_columns[i][j] = *((uint32_t*)hash_output);
        }
    }
    
    return LQX10_SUCCESS;
}

lqx10_error_t lqx10_layer3_classical_cipher_process(lqx10_layer_state_t *state,
                                                     const uint8_t *input,
                                                     size_t input_len,
                                                     uint8_t *output,
                                                     size_t *output_len,
                                                     bool encrypt) {
    if (!state || !input || !output || !output_len || input_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Ensure output buffer is large enough (padded to 16-byte blocks)
    size_t padded_len = ((input_len + 15) / 16) * 16;
    if (*output_len < padded_len + 16) { // Add space for IV
        *output_len = padded_len + 16;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    if (encrypt) {
        // Generate random IV
        uint8_t iv[16];
        lqx10_error_t result = lqx10_secure_random_bytes(iv, sizeof(iv));
        if (result != LQX10_SUCCESS) {
            return result;
        }
        
        // Pad input to block size
        uint8_t *padded_input = malloc(padded_len);
        if (!padded_input) {
            return LQX10_ERROR_MEMORY_ALLOCATION;
        }
        
        memcpy(padded_input, input, input_len);
        
        // PKCS#7 padding
        uint8_t padding_len = 16 - (input_len % 16);
        if (padding_len == 0) padding_len = 16;
        
        for (size_t i = input_len; i < padded_len; i++) {
            padded_input[i] = padding_len;
        }
        
        // Encrypt using custom block cipher
        uint8_t prev_block[16];
        memcpy(prev_block, iv, 16);
        
        for (size_t block = 0; block < padded_len / 16; block++) {
            uint8_t *current_block = padded_input + block * 16;
            uint8_t *output_block = output + block * 16;
            
            // XOR with previous ciphertext (CBC mode)
            for (int i = 0; i < 16; i++) {
                current_block[i] ^= prev_block[i];
            }
            
            // Apply rounds
            for (int round = 0; round < 10; round++) {
                // SubBytes
                for (int i = 0; i < 16; i++) {
                    current_block[i] = state->layer_data.classical_cipher.substitution_box[current_block[i]];
                }
                
                // MixColumns (simplified)
                for (int i = 0; i < 4; i++) {
                    uint32_t col = *((uint32_t*)(current_block + i * 4));
                    col ^= state->layer_data.classical_cipher.mix_columns[i][col & 0xFF];
                    *((uint32_t*)(current_block + i * 4)) = col;
                }
                
                // AddRoundKey
                for (int i = 0; i < 16; i++) {
                    current_block[i] ^= state->layer_data.classical_cipher.round_keys[round % 16][i];
                }
            }
            
            memcpy(output_block, current_block, 16);
            memcpy(prev_block, output_block, 16);
        }
        
        // Prepend IV
        memmove(output + 16, output, padded_len);
        memcpy(output, iv, 16);
        *output_len = padded_len + 16;
        
        free(padded_input);
    } else {
        // Decrypt
        if (input_len < 32) { // Need at least IV + one block
            return LQX10_ERROR_CRYPTO_FAILURE;
        }
        
        const uint8_t *iv = input;
        const uint8_t *ciphertext = input + 16;
        size_t ciphertext_len = input_len - 16;
        
        uint8_t prev_block[16];
        memcpy(prev_block, iv, 16);
        
        for (size_t block = 0; block < ciphertext_len / 16; block++) {
            uint8_t current_block[16];
            memcpy(current_block, ciphertext + block * 16, 16);
            uint8_t temp_block[16];
            memcpy(temp_block, current_block, 16);
            
            // Reverse rounds
            for (int round = 9; round >= 0; round--) {
                // Reverse AddRoundKey
                for (int i = 0; i < 16; i++) {
                    current_block[i] ^= state->layer_data.classical_cipher.round_keys[round % 16][i];
                }
                
                // Reverse MixColumns (simplified)
                for (int i = 0; i < 4; i++) {
                    uint32_t col = *((uint32_t*)(current_block + i * 4));
                    col ^= state->layer_data.classical_cipher.mix_columns[i][col & 0xFF];
                    *((uint32_t*)(current_block + i * 4)) = col;
                }
                
                // Reverse SubBytes
                uint8_t inv_sbox[256];
                for (int i = 0; i < 256; i++) {
                    inv_sbox[state->layer_data.classical_cipher.substitution_box[i]] = i;
                }
                for (int i = 0; i < 16; i++) {
                    current_block[i] = inv_sbox[current_block[i]];
                }
            }
            
            // XOR with previous ciphertext (CBC mode)
            for (int i = 0; i < 16; i++) {
                current_block[i] ^= prev_block[i];
            }
            
            memcpy(output + block * 16, current_block, 16);
            memcpy(prev_block, temp_block, 16);
        }
        
        // Remove padding
        uint8_t padding_len = output[ciphertext_len - 1];
        if (padding_len > 16) {
            return LQX10_ERROR_CRYPTO_FAILURE;
        }
        
        *output_len = ciphertext_len - padding_len;
    }
    
    return LQX10_SUCCESS;
}

// Layer implementation wrappers that map to actual layer functions
lqx10_error_t lqx10_layer8_decoy_injection_init(lqx10_layer_state_t *state,
                                                 const uint8_t *key) {
    if (!state || !key) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Initialize decoy injection state
    lqx10_secure_random_bytes_pure(state->layer_data.decoy_injection.decoy_data, 128);
    state->layer_data.decoy_injection.decoy_count = 1 + (key[0] % 8);
    state->layer_data.decoy_injection.injection_pattern = 
        ((uint64_t)key[16] << 32) | ((uint64_t)key[17] << 24) | 
        ((uint64_t)key[18] << 16) | ((uint64_t)key[19] << 8) | key[20];
    
    return LQX10_SUCCESS;
}

lqx10_error_t lqx10_layer8_decoy_injection_process(lqx10_layer_state_t *state,
                                                   const uint8_t *input,
                                                   size_t input_len,
                                                   uint8_t *output,
                                                   size_t *output_len,
                                                   bool encrypt) {
    // This would call the actual layer implementation with context
    // For now, implement basic decoy injection
    if (!state || !input || !output || !output_len || input_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (encrypt) {
        // Add decoy data
        size_t decoy_size = 64 + (state->layer_data.decoy_injection.decoy_count * 16);
        if (*output_len < input_len + decoy_size + 4) {
            *output_len = input_len + decoy_size + 4;
            return LQX10_ERROR_BUFFER_TOO_SMALL;
        }
        
        // Store original length
        *((uint32_t*)output) = (uint32_t)input_len;
        
        // Copy input data
        memcpy(output + 4, input, input_len);
        
        // Add decoy data
        memcpy(output + 4 + input_len, state->layer_data.decoy_injection.decoy_data, decoy_size);
        
        *output_len = input_len + decoy_size + 4;
    } else {
        // Extract real data
        if (input_len < 4) {
            return LQX10_ERROR_CRYPTO_FAILURE;
        }
        
        uint32_t real_len = *((uint32_t*)input);
        if (real_len > input_len - 4 || real_len == 0) {
            return LQX10_ERROR_CRYPTO_FAILURE;
        }
        
        if (*output_len < real_len) {
            *output_len = real_len;
            return LQX10_ERROR_BUFFER_TOO_SMALL;
        }
        
        memcpy(output, input + 4, real_len);
        *output_len = real_len;
    }
    
    return LQX10_SUCCESS;
}

lqx10_error_t lqx10_layer9_metadata_signature_init(lqx10_layer_state_t *state,
                                                   const uint8_t *key) {
    if (!state || !key) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Initialize metadata signature state
    memcpy(state->layer_data.metadata_signature.metadata_key, key, LQX10_KEY_SIZE);
    memcpy(state->layer_data.metadata_signature.hmac_key, key, LQX10_KEY_SIZE);
    state->layer_data.metadata_signature.sequence_counter = 0;
    
    return LQX10_SUCCESS;
}

lqx10_error_t lqx10_layer9_metadata_signature_process(lqx10_layer_state_t *state,
                                                      const uint8_t *input,
                                                      size_t input_len,
                                                      uint8_t *output,
                                                      size_t *output_len,
                                                      bool encrypt) {
    if (!state || !input || !output || !output_len || input_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (encrypt) {
        // Add metadata and signature
        if (*output_len < input_len + 64) {
            *output_len = input_len + 64;
            return LQX10_ERROR_BUFFER_TOO_SMALL;
        }
        
        // Copy input data
        memcpy(output, input, input_len);
        
        // Add metadata (timestamp, sequence counter)
        uint64_t timestamp = (uint64_t)time(NULL);
        memcpy(output + input_len, &timestamp, 8);
        memcpy(output + input_len + 8, &state->layer_data.metadata_signature.sequence_counter, 8);
        
        // Add simple signature (HMAC-like)
        uint8_t signature[48] = {0};
        for (size_t i = 0; i < input_len && i < 32; i++) {
            signature[i] = input[i] ^ state->layer_data.metadata_signature.hmac_key[i % LQX10_KEY_SIZE];
        }
        memcpy(output + input_len + 16, signature, 48);
        
        *output_len = input_len + 64;
        state->layer_data.metadata_signature.sequence_counter++;
    } else {
        // Verify signature and extract data
        if (input_len < 64) {
            return LQX10_ERROR_CRYPTO_FAILURE;
        }
        
        size_t data_len = input_len - 64;
        if (*output_len < data_len) {
            *output_len = data_len;
            return LQX10_ERROR_BUFFER_TOO_SMALL;
        }
        
        // Basic signature verification would go here
        memcpy(output, input, data_len);
        *output_len = data_len;
    }
    
    return LQX10_SUCCESS;
}

lqx10_error_t lqx10_layer10_final_shroud_init(lqx10_layer_state_t *state,
                                              const uint8_t *key) {
    if (!state || !key) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Initialize final shroud state
    memcpy(state->layer_data.final_shroud.shroud_key, key, LQX10_KEY_SIZE);
    lqx10_secure_random_bytes_pure(state->layer_data.final_shroud.final_iv, 16);
    lqx10_secure_random_bytes_pure(state->layer_data.final_shroud.steganographic_mask, 256);
    state->layer_data.final_shroud.obfuscation_enabled = true;
    
    return LQX10_SUCCESS;
}

lqx10_error_t lqx10_layer10_final_shroud_process(lqx10_layer_state_t *state,
                                                 const uint8_t *input,
                                                 size_t input_len,
                                                 uint8_t *output,
                                                 size_t *output_len,
                                                 bool encrypt) {
    if (!state || !input || !output || !output_len || input_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (encrypt) {
        // Apply final shroud obfuscation
        size_t shroud_overhead = 128; // Header + steganographic data
        if (*output_len < input_len + shroud_overhead) {
            *output_len = input_len + shroud_overhead;
            return LQX10_ERROR_BUFFER_TOO_SMALL;
        }
        
        // Add shroud header
        memcpy(output, state->layer_data.final_shroud.final_iv, 16);
        
        // Obfuscate data
        for (size_t i = 0; i < input_len; i++) {
            output[16 + i] = input[i] ^ 
                state->layer_data.final_shroud.shroud_key[i % LQX10_KEY_SIZE] ^
                state->layer_data.final_shroud.steganographic_mask[i % 256];
        }
        
        // Add steganographic padding
        memcpy(output + 16 + input_len, state->layer_data.final_shroud.steganographic_mask, 
               shroud_overhead - 16);
        
        *output_len = input_len + shroud_overhead;
    } else {
        // Remove final shroud
        if (input_len < 128) {
            return LQX10_ERROR_CRYPTO_FAILURE;
        }
        
        size_t data_len = input_len - 128;
        if (*output_len < data_len) {
            *output_len = data_len;
            return LQX10_ERROR_BUFFER_TOO_SMALL;
        }
        
        // Extract and de-obfuscate data
        for (size_t i = 0; i < data_len; i++) {
            output[i] = input[16 + i] ^ 
                state->layer_data.final_shroud.shroud_key[i % LQX10_KEY_SIZE] ^
                state->layer_data.final_shroud.steganographic_mask[i % 256];
        }
        
        *output_len = data_len;
    }
    
    return LQX10_SUCCESS;
}

// Wrapper functions for layer processing (called by layer_process)
lqx10_error_t lqx10_layer_key_whitening_process(lqx10_layer_state_t *state,
                                                 const uint8_t *input, size_t input_len,
                                                 uint8_t *output, size_t *output_len,
                                                 bool encrypt) {
    if (encrypt) {
        return lqx10_layer1_key_whitening_process(state, input, input_len, output, output_len, encrypt);
    } else {
        return lqx10_layer1_key_whitening_process(state, input, input_len, output, output_len, encrypt);
    }
}

lqx10_error_t lqx10_layer_entropy_mixer_process(lqx10_layer_state_t *state,
                                                 const uint8_t *input, size_t input_len,
                                                 uint8_t *output, size_t *output_len,
                                                 bool encrypt) {
    return lqx10_layer2_entropy_mixer_process(state, input, input_len, output, output_len, encrypt);
}

lqx10_error_t lqx10_layer_classical_cipher_process(lqx10_layer_state_t *state,
                                                    const uint8_t *input, size_t input_len,
                                                    uint8_t *output, size_t *output_len,
                                                    bool encrypt) {
    return lqx10_layer3_classical_cipher_process(state, input, input_len, output, output_len, encrypt);
}

lqx10_error_t lqx10_layer_post_quantum_process(lqx10_layer_state_t *state,
                                                const uint8_t *input, size_t input_len,
                                                uint8_t *output, size_t *output_len,
                                                bool encrypt) {
    return lqx10_layer4_post_quantum_process(state, input, input_len, output, output_len, encrypt);
}

lqx10_error_t lqx10_layer_network_camouflage_process(lqx10_layer_state_t *state,
                                                      const uint8_t *input, size_t input_len,
                                                      uint8_t *output, size_t *output_len,
                                                      bool encrypt) {
    return lqx10_layer5_network_camouflage_process(state, input, input_len, output, output_len, encrypt);
}

lqx10_error_t lqx10_layer_padding_jitter_process(lqx10_layer_state_t *state,
                                                  const uint8_t *input, size_t input_len,
                                                  uint8_t *output, size_t *output_len,
                                                  bool encrypt) {
    return lqx10_layer6_padding_jitter_process(state, input, input_len, output, output_len, encrypt);
}

lqx10_error_t lqx10_layer_runtime_mutation_process(lqx10_layer_state_t *state,
                                                    const uint8_t *input, size_t input_len,
                                                    uint8_t *output, size_t *output_len,
                                                    bool encrypt) {
    return lqx10_layer7_runtime_mutation_process(state, input, input_len, output, output_len, encrypt);
}

lqx10_error_t lqx10_layer_decoy_injection_process(lqx10_layer_state_t *state,
                                                   const uint8_t *input, size_t input_len,
                                                   uint8_t *output, size_t *output_len,
                                                   bool encrypt) {
    if (encrypt) {
        return lqx10_layer8_forward(NULL, input, input_len, output, output_len);
    } else {
        return lqx10_layer8_reverse(NULL, input, input_len, output, output_len);
    }
}

lqx10_error_t lqx10_layer_metadata_signature_process(lqx10_layer_state_t *state,
                                                      const uint8_t *input, size_t input_len,
                                                      uint8_t *output, size_t *output_len,
                                                      bool encrypt) {
    if (encrypt) {
        return lqx10_layer9_forward(NULL, input, input_len, output, output_len);
    } else {
        return lqx10_layer9_reverse(NULL, input, input_len, output, output_len);
    }
}

lqx10_error_t lqx10_layer_final_shroud_process(lqx10_layer_state_t *state,
                                                const uint8_t *input, size_t input_len,
                                                uint8_t *output, size_t *output_len,
                                                bool encrypt) {
    if (encrypt) {
        return lqx10_layer10_forward(NULL, input, input_len, output, output_len);
    } else {
        return lqx10_layer10_reverse(NULL, input, input_len, output, output_len);
    }
}

// Generic layer cleanup
lqx10_error_t lqx10_layer_cleanup(lqx10_layer_state_t *state) {
    if (!state) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Zero all sensitive data
    lqx10_secure_memzero(state->layer_key, LQX10_KEY_SIZE);
    lqx10_secure_memzero(state->layer_iv, LQX10_IV_SIZE);
    lqx10_secure_memzero(state->state_data, LQX10_LAYER_STATE_SIZE);
    lqx10_secure_memzero(&state->layer_data, sizeof(state->layer_data));
    
    state->initialized = false;
    state->operation_counter = 0;
    
    return LQX10_SUCCESS;
}
