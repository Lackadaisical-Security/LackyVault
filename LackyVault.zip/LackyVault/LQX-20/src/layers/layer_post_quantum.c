/**
 * @file layer_post_quantum.c
 * @brief LQX-10 Layer 4: Post-Quantum Cryptography Implementation
 * 
 * Fourth layer implementing post-quantum resistant algorithms
 * for future-proofing against quantum computer attacks.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../../include/lqx10_layers.h"
#include "../../include/lqx10_crypto.h"
#include <string.h>

// Post-quantum parameters
#define PQ_KEY_SIZE 1568    // CRYSTALS-Kyber-768 key size
#define PQ_CIPHERTEXT_SIZE 1088
#define PQ_SHARED_SECRET_SIZE 32

// Layer 4: Post-Quantum Forward Transform
lqx10_error_t lqx10_layer4_forward(lqx10_context_t* ctx, const uint8_t* input, 
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (*output_len < input_len + LQX10_LAYER4_OVERHEAD) {
        *output_len = input_len + LQX10_LAYER4_OVERHEAD;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Generate ephemeral post-quantum keypair
    uint8_t public_key[PQ_KEY_SIZE];
    uint8_t secret_key[PQ_KEY_SIZE * 2];
    uint8_t shared_secret[PQ_SHARED_SECRET_SIZE];
    uint8_t ciphertext[PQ_CIPHERTEXT_SIZE];
    
    // Use our pure post-quantum implementation
    result = lqx10_kyber_keygen_pure(public_key, secret_key);
    if (result != LQX10_SUCCESS) {
        return LQX10_ERROR_POST_QUANTUM_FAILURE;
    }
    
    // Encapsulate using the layer key as additional entropy
    result = lqx10_kyber_encaps_pure(public_key, ciphertext, shared_secret);
    if (result != LQX10_SUCCESS) {
        return LQX10_ERROR_POST_QUANTUM_FAILURE;
    }
    
    // Derive encryption key from shared secret using HKDF
    uint8_t encryption_key[32];
    result = lqx10_hkdf_expand(shared_secret, PQ_SHARED_SECRET_SIZE, 
                              (uint8_t*)"LQX10-PQ-Layer4", 15, 
                              encryption_key, 32);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Encrypt data using derived key
    uint8_t iv[16];
    result = lqx10_secure_random_bytes(iv, sizeof(iv));
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    size_t encrypted_len = input_len + 16; // Add padding space
    result = lqx10_aes_encrypt(encryption_key, iv, input, input_len, output, &encrypted_len);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    size_t working_len = encrypted_len;
    
    // Append post-quantum ciphertext
    memcpy(output + working_len, ciphertext, PQ_CIPHERTEXT_SIZE);
    working_len += PQ_CIPHERTEXT_SIZE;
    
    // Append IV
    memcpy(output + working_len, iv, 16);
    working_len += 16;
    
    // Clear sensitive data
    lqx10_secure_zero(secret_key, sizeof(secret_key));
    lqx10_secure_zero(shared_secret, sizeof(shared_secret));
    lqx10_secure_zero(encryption_key, sizeof(encryption_key));
    
    *output_len = working_len;
    return LQX10_SUCCESS;
}

// Layer 4: Post-Quantum Reverse Transform
lqx10_error_t lqx10_layer4_reverse(lqx10_context_t* ctx, const uint8_t* input,
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (input_len < LQX10_LAYER4_OVERHEAD) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t data_len = input_len - LQX10_LAYER4_OVERHEAD;
    
    if (*output_len < data_len) {
        *output_len = data_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Extract components
    const uint8_t* ciphertext = input + data_len;
    const uint8_t* iv = input + data_len + PQ_CIPHERTEXT_SIZE;
    
    // Decapsulate to recover shared secret using layer key
    uint8_t shared_secret[PQ_SHARED_SECRET_SIZE];
    result = lqx10_kyber_decaps_pure(ctx->layer_keys[3], ciphertext, shared_secret);
    if (result != LQX10_SUCCESS) {
        return LQX10_ERROR_POST_QUANTUM_FAILURE;
    }
    
    // Derive decryption key from shared secret using HKDF
    uint8_t decryption_key[32];
    result = lqx10_hkdf_expand(shared_secret, PQ_SHARED_SECRET_SIZE, 
                              (uint8_t*)"LQX10-PQ-Layer4", 15, 
                              decryption_key, 32);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Decrypt data
    size_t decrypted_len = data_len;
    result = lqx10_aes_decrypt(decryption_key, iv, input, data_len, output, &decrypted_len);
    if (result != LQX10_SUCCESS) {
        // Clear sensitive data before returning
        lqx10_secure_zero(shared_secret, sizeof(shared_secret));
        lqx10_secure_zero(decryption_key, sizeof(decryption_key));
        return LQX10_ERROR_CRYPTO_FAILURE;
    }
    
    // Clear sensitive data
    lqx10_secure_zero(shared_secret, sizeof(shared_secret));
    lqx10_secure_zero(decryption_key, sizeof(decryption_key));
    
    *output_len = data_len;
    return LQX10_SUCCESS;
}
