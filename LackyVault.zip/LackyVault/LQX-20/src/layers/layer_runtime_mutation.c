/**
 * @file layer_runtime_mutation.c
 * @brief LQX-10 Layer 7: Runtime Mutation Implementation
 * 
 * Seventh layer implementing runtime code mutation and anti-analysis
 * techniques to resist reverse engineering and tampering.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../../include/lqx10_layers.h"
#include "../../include/lqx10_crypto.h"
#include <string.h>
#include <time.h>
#include <stdlib.h>

#ifdef _WIN32
#include <windows.h>
#endif

// Mutation parameters
#define MUTATION_KEY_SIZE 32
#define MUTATION_ROUNDS 3
#define CONTROL_FLOW_COMPLEXITY 8

// Runtime mutation state
static uint32_t mutation_state = 0xDEADBEEF;
static bool anti_debug_triggered = false;

// Internal mutation functions
static void apply_data_mutation(uint8_t* data, size_t len, uint32_t key);
static void apply_control_flow_obfuscation(uint8_t* data, size_t len);
static bool check_debug_environment(void);
static void trigger_anti_debug_response(void);

// Layer 7: Runtime Mutation Forward Transform
lqx10_error_t lqx10_layer7_forward(lqx10_context_t* ctx, const uint8_t* input, 
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (*output_len < input_len + LQX10_LAYER7_OVERHEAD) {
        *output_len = input_len + LQX10_LAYER7_OVERHEAD;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Anti-debug check
    if (ctx->anti_debug_enabled && check_debug_environment()) {
        trigger_anti_debug_response();
        return LQX10_ERROR_ANTI_DEBUG;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Update mutation state
    mutation_state ^= (uint32_t)input_len;
    mutation_state = (mutation_state << 13) ^ (mutation_state >> 19);
    
    size_t working_len = input_len;
    
    // Copy input to output for processing
    memcpy(output, input, input_len);
    
    // Apply multiple rounds of mutation
    for (int round = 0; round < MUTATION_ROUNDS; round++) {
        // Derive round key
        uint32_t round_key = 0;
        for (int i = 0; i < 32; i++) {
            round_key ^= ctx->layer_keys[6][i] << (i % 24);
        }
        round_key ^= mutation_state ^ round;
        
        // Apply data mutation
        apply_data_mutation(output, working_len, round_key);
        
        // Apply control flow obfuscation (data transformation)
        apply_control_flow_obfuscation(output, working_len);
        
        // Update mutation state for next round
        mutation_state ^= round_key;
    }
    
    // Add mutation metadata
    uint8_t mutation_info[16];
    memset(mutation_info, 0, sizeof(mutation_info));
    
    // Store mutation state (encrypted)
    uint32_t state_copy = mutation_state;
    for (int i = 0; i < 4; i++) {
        ((uint8_t*)&state_copy)[i] ^= ctx->layer_keys[6][i + 16];
    }
    
    memcpy(mutation_info, &state_copy, 4);
    
    // Add timestamp for anti-replay
    uint32_t timestamp = (uint32_t)time(NULL);
    for (int i = 0; i < 4; i++) {
        ((uint8_t*)&timestamp)[i] ^= ctx->layer_keys[6][i + 20];
    }
    
    memcpy(mutation_info + 4, &timestamp, 4);
    
    // Add checksum
    uint32_t checksum = 0;
    for (size_t i = 0; i < working_len; i++) {
        checksum ^= output[i] << (i % 24);
    }
    
    for (int i = 0; i < 4; i++) {
        ((uint8_t*)&checksum)[i] ^= ctx->layer_keys[6][i + 24];
    }
    
    memcpy(mutation_info + 8, &checksum, 4);
    
    // Append mutation info
    memcpy(output + working_len, mutation_info, sizeof(mutation_info));
    working_len += sizeof(mutation_info);
    
    *output_len = working_len;
    return LQX10_SUCCESS;
}

// Layer 7: Runtime Mutation Reverse Transform
lqx10_error_t lqx10_layer7_reverse(lqx10_context_t* ctx, const uint8_t* input,
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (input_len < LQX10_LAYER7_OVERHEAD) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Anti-debug check
    if (ctx->anti_debug_enabled && check_debug_environment()) {
        trigger_anti_debug_response();
        return LQX10_ERROR_ANTI_DEBUG;
    }
    
    size_t data_len = input_len - 16; // Remove mutation info
    
    if (*output_len < data_len) {
        *output_len = data_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Extract mutation info
    const uint8_t* mutation_info = input + data_len;
    
    // Extract and decrypt mutation state
    uint32_t stored_state;
    memcpy(&stored_state, mutation_info, 4);
    
    for (int i = 0; i < 4; i++) {
        ((uint8_t*)&stored_state)[i] ^= ctx->layer_keys[6][i + 16];
    }
    
    // Extract and verify timestamp (basic anti-replay)
    uint32_t timestamp;
    memcpy(&timestamp, mutation_info + 4, 4);
    
    for (int i = 0; i < 4; i++) {
        ((uint8_t*)&timestamp)[i] ^= ctx->layer_keys[6][i + 20];
    }
    
    // Check timestamp is reasonable (within 1 hour)
    uint32_t current_time = (uint32_t)time(NULL);
    if (abs((int)(current_time - timestamp)) > 3600) {
        return LQX10_ERROR_RUNTIME_MUTATION;
    }
    
    // Copy data for processing
    memcpy(output, input, data_len);
    
    // Set mutation state for reverse processing
    mutation_state = stored_state;
    
    // Reverse mutation rounds (in reverse order)
    for (int round = MUTATION_ROUNDS - 1; round >= 0; round--) {
        // Derive round key (same as forward)
        uint32_t round_key = 0;
        for (int i = 0; i < 32; i++) {
            round_key ^= ctx->layer_keys[6][i] << (i % 24);
        }
        round_key ^= stored_state ^ round;
        
        // Reverse control flow obfuscation
        apply_control_flow_obfuscation(output, data_len); // Self-inverse
        
        // Reverse data mutation
        apply_data_mutation(output, data_len, round_key); // Self-inverse
        
        // Update state for previous round
        stored_state ^= round_key;
    }
    
    // Verify checksum
    uint32_t computed_checksum = 0;
    for (size_t i = 0; i < data_len; i++) {
        computed_checksum ^= output[i] << (i % 24);
    }
    
    for (int i = 0; i < 4; i++) {
        ((uint8_t*)&computed_checksum)[i] ^= ctx->layer_keys[6][i + 24];
    }
    
    uint32_t stored_checksum;
    memcpy(&stored_checksum, mutation_info + 8, 4);
    
    if (computed_checksum != stored_checksum) {
        return LQX10_ERROR_RUNTIME_MUTATION;
    }
    
    *output_len = data_len;
    return LQX10_SUCCESS;
}

// Apply data mutation transformation
static void apply_data_mutation(uint8_t* data, size_t len, uint32_t key) {
    for (size_t i = 0; i < len; i++) {
        // Complex bit manipulation based on position and key
        uint8_t pos_key = (uint8_t)(key >> ((i % 4) * 8));
        uint8_t mutation = pos_key ^ (uint8_t)(i & 0xFF);
        
        // Bit rotation based on mutation value
        uint8_t rotation = mutation & 0x07;
        data[i] = (data[i] << rotation) | (data[i] >> (8 - rotation));
        
        // XOR with position-dependent key
        data[i] ^= mutation;
    }
}

// Apply control flow obfuscation (data transformation)
static void apply_control_flow_obfuscation(uint8_t* data, size_t len) {
    // Simulate control flow complexity through data transformation
    for (int complexity = 0; complexity < CONTROL_FLOW_COMPLEXITY; complexity++) {
        for (size_t i = 0; i < len; i++) {
            size_t next_pos = (i + complexity + 1) % len;
            
            // Conditional data swapping based on content
            if ((data[i] ^ data[next_pos]) & 1) {
                uint8_t temp = data[i];
                data[i] = data[next_pos];
                data[next_pos] = temp;
            }
            
            // Conditional bit flipping
            if ((data[i] + complexity) & 2) {
                data[i] ^= 0x55; // Alternate bit pattern
            }
        }
    }
}

// Check for debug environment
static bool check_debug_environment(void) {
#ifdef _WIN32
    // Check for debugger presence
    if (IsDebuggerPresent()) {
        return true;
    }
    
    // Check for remote debugger
    BOOL remote_debugger = FALSE;
    CheckRemoteDebuggerPresent(GetCurrentProcess(), &remote_debugger);
    if (remote_debugger) {
        return true;
    }
    
    // Check for common debugging tools
    HWND hwnd = FindWindow(L"OLLYDBG", NULL);
    if (hwnd) return true;
    
    hwnd = FindWindow(L"IDA", NULL);
    if (hwnd) return true;
    
#else
    // Unix-based debug detection
    char line[256];
    FILE* status = fopen("/proc/self/status", "r");
    if (status) {
        while (fgets(line, sizeof(line), status)) {
            if (strncmp(line, "TracerPid:", 10) == 0) {
                int tracer_pid = atoi(line + 10);
                fclose(status);
                return tracer_pid != 0;
            }
        }
        fclose(status);
    }
#endif
    
    return false;
}

// Trigger anti-debug response
static void trigger_anti_debug_response(void) {
    anti_debug_triggered = true;
    
    // Clear sensitive memory
    if (mutation_state != 0) {
        mutation_state = 0;
    }
    
    // Could implement additional countermeasures here
    // For now, just set the flag
}
