/**
 * @file layer_entropy_mixer.c
 * @brief LQX-10 Layer 2: Entropy Mixer Implementation
 * 
 * Second layer in the 10-layer stack. Mixes additional entropy
 * and applies entropy conditioning to increase randomness.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../../include/lqx10_layers.h"
#include "../../include/lqx10_crypto.h"
#include <string.h>

#ifdef _WIN32
#include <windows.h>
#include <wincrypt.h>
#else
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#endif

// Entropy pool size and management
#define ENTROPY_POOL_SIZE 1024
#define MIN_ENTROPY_BITS 256

// Internal entropy state
static uint8_t entropy_pool[ENTROPY_POOL_SIZE];
static size_t entropy_index = 0;
static uint32_t entropy_estimate = 0;

// Internal functions
static lqx10_error_t collect_system_entropy(uint8_t* buffer, size_t len);
static lqx10_error_t mix_entropy_pool(void);
static void von_neumann_corrector(uint8_t* data, size_t len);
static void entropy_whitening(uint8_t* data, size_t len, const uint8_t* key);

// Layer 2: Entropy Mixer Forward Transform
lqx10_error_t lqx10_layer2_forward(lqx10_context_t* ctx, const uint8_t* input, 
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (*output_len < input_len + LQX10_LAYER2_OVERHEAD) {
        *output_len = input_len + LQX10_LAYER2_OVERHEAD;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Collect fresh entropy
    uint8_t fresh_entropy[64];
    result = collect_system_entropy(fresh_entropy, sizeof(fresh_entropy));
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Mix entropy into pool
    result = mix_entropy_pool();
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Copy input to output buffer
    memcpy(output, input, input_len);
    size_t working_len = input_len;
    
    // Add entropy header (32 bytes)
    uint8_t entropy_header[32];
    result = lqx10_secure_random_bytes(entropy_header, sizeof(entropy_header));
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Apply von Neumann bias correction
    von_neumann_corrector(entropy_header, sizeof(entropy_header));
    
    // Mix entropy with data using XOR stream
    for (size_t i = 0; i < working_len; i++) {
        output[i] ^= entropy_header[i % sizeof(entropy_header)];
    }
    
    // Apply entropy whitening
    entropy_whitening(output, working_len, ctx->layer_keys[1]);
    
    // Generate and append entropy-based authentication
    uint8_t entropy_auth[20];
    result = lqx10_hmac_sha256(ctx->layer_keys[1], 32, output, working_len, entropy_auth);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Append entropy header and auth
    memcpy(output + working_len, entropy_header, sizeof(entropy_header));
    working_len += sizeof(entropy_header);
    
    memcpy(output + working_len, entropy_auth, 20);
    working_len += 20;
    
    *output_len = working_len;
    return LQX10_SUCCESS;
}

// Layer 2: Entropy Mixer Reverse Transform  
lqx10_error_t lqx10_layer2_reverse(lqx10_context_t* ctx, const uint8_t* input,
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (input_len < LQX10_LAYER2_OVERHEAD) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t data_len = input_len - LQX10_LAYER2_OVERHEAD;
    
    if (*output_len < data_len) {
        *output_len = data_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Extract entropy header and auth
    const uint8_t* entropy_header = input + data_len;
    const uint8_t* entropy_auth = input + data_len + 32;
    
    // Verify entropy-based authentication
    uint8_t computed_auth[20];
    result = lqx10_hmac_sha256(ctx->layer_keys[1], 32, input, data_len, computed_auth);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Constant-time comparison
    int auth_match = 0;
    for (int i = 0; i < 20; i++) {
        auth_match |= (computed_auth[i] ^ entropy_auth[i]);
    }
    
    if (auth_match != 0) {
        return LQX10_ERROR_AUTH_FAILURE;
    }
    
    // Copy data for processing
    memcpy(output, input, data_len);
    
    // Reverse entropy whitening
    entropy_whitening(output, data_len, ctx->layer_keys[1]);
    
    // Reverse entropy mixing using XOR stream
    for (size_t i = 0; i < data_len; i++) {
        output[i] ^= entropy_header[i % 32];
    }
    
    *output_len = data_len;
    return LQX10_SUCCESS;
}

// Collect entropy from system sources
static lqx10_error_t collect_system_entropy(uint8_t* buffer, size_t len) {
    if (!buffer || len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Collect from multiple sources and mix
    uint8_t temp_buffer[64];
    memset(temp_buffer, 0, sizeof(temp_buffer));
    
#ifdef _WIN32
    // Use Windows entropy sources
    HCRYPTPROV hProv;
    if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)) {
        CryptGenRandom(hProv, len > 32 ? 32 : (DWORD)len, temp_buffer);
        CryptReleaseContext(hProv, 0);
    }
    
    // Add high-resolution timer
    LARGE_INTEGER counter;
    QueryPerformanceCounter(&counter);
    for (int i = 0; i < 8 && i < len; i++) {
        temp_buffer[32 + i] = (uint8_t)(counter.QuadPart >> (i * 8));
    }
    
    // Add process and thread IDs
    DWORD pid = GetCurrentProcessId();
    DWORD tid = GetCurrentThreadId();
    for (int i = 0; i < 4 && (40 + i) < sizeof(temp_buffer); i++) {
        temp_buffer[40 + i] = (uint8_t)(pid >> (i * 8));
        temp_buffer[44 + i] = (uint8_t)(tid >> (i * 8));
    }
    
#else
    // Use Unix entropy sources
    FILE* urandom = fopen("/dev/urandom", "rb");
    if (urandom) {
        fread(temp_buffer, 1, len > 32 ? 32 : len, urandom);
        fclose(urandom);
    }
    
    // Add high-resolution timer
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    for (int i = 0; i < 8 && (32 + i) < sizeof(temp_buffer); i++) {
        temp_buffer[32 + i] = (uint8_t)(ts.tv_nsec >> (i * 8));
    }
    
    // Add process ID
    pid_t pid = getpid();
    for (int i = 0; i < 4 && (40 + i) < sizeof(temp_buffer); i++) {
        temp_buffer[40 + i] = (uint8_t)(pid >> (i * 8));
    }
#endif
    
    // Mix collected entropy using BLAKE3
    lqx10_error_t result = lqx10_blake3_hash(temp_buffer, sizeof(temp_buffer), buffer, len);
    
    // Clear temporary buffer
    memset(temp_buffer, 0, sizeof(temp_buffer));
    
    return result;
}

// Mix entropy into global pool
static lqx10_error_t mix_entropy_pool(void) {
    uint8_t fresh_entropy[64];
    
    // Collect fresh entropy
    lqx10_error_t result = collect_system_entropy(fresh_entropy, sizeof(fresh_entropy));
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Mix into pool using XOR and rotation
    for (size_t i = 0; i < sizeof(fresh_entropy); i++) {
        size_t pool_pos = (entropy_index + i) % ENTROPY_POOL_SIZE;
        entropy_pool[pool_pos] ^= fresh_entropy[i];
        
        // Rotate pool byte
        uint8_t rotated = (entropy_pool[pool_pos] << 1) | (entropy_pool[pool_pos] >> 7);
        entropy_pool[pool_pos] = rotated;
    }
    
    // Update entropy index
    entropy_index = (entropy_index + sizeof(fresh_entropy)) % ENTROPY_POOL_SIZE;
    
    // Increase entropy estimate
    entropy_estimate += 256; // Conservative estimate
    if (entropy_estimate > ENTROPY_POOL_SIZE * 8) {
        entropy_estimate = ENTROPY_POOL_SIZE * 8;
    }
    
    // Clear fresh entropy
    memset(fresh_entropy, 0, sizeof(fresh_entropy));
    
    return LQX10_SUCCESS;
}

// Apply von Neumann bias correction
static void von_neumann_corrector(uint8_t* data, size_t len) {
    for (size_t i = 0; i < len; i++) {
        uint8_t byte = data[i];
        uint8_t corrected = 0;
        int bit_count = 0;
        
        // Process pairs of bits
        for (int j = 0; j < 8; j += 2) {
            if (j + 1 < 8) {
                int bit1 = (byte >> j) & 1;
                int bit2 = (byte >> (j + 1)) & 1;
                
                // von Neumann correction: 01 -> 0, 10 -> 1, 00/11 -> discard
                if (bit1 != bit2) {
                    corrected |= (bit2 << bit_count);
                    bit_count++;
                }
            }
        }
        
        // Pad with original bits if needed
        while (bit_count < 8) {
            corrected |= ((byte >> bit_count) & 1) << bit_count;
            bit_count++;
        }
        
        data[i] = corrected;
    }
}

// Apply entropy whitening transformation
static void entropy_whitening(uint8_t* data, size_t len, const uint8_t* key) {
    // Use stream cipher approach with key-dependent S-box
    uint8_t keystream[32];
    
    // Generate keystream from key using BLAKE3
    lqx10_blake3_hash(key, 32, keystream, sizeof(keystream));
    
    // Apply keystream to data
    for (size_t i = 0; i < len; i++) {
        // Combine with pool entropy
        size_t pool_pos = (entropy_index + i) % ENTROPY_POOL_SIZE;
        uint8_t pool_byte = entropy_pool[pool_pos];
        
        // XOR with keystream and pool
        data[i] ^= keystream[i % sizeof(keystream)] ^ pool_byte;
        
        // Update pool position
        entropy_pool[pool_pos] = (pool_byte + data[i]) & 0xFF;
    }
}
