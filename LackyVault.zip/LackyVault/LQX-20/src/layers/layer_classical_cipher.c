/**
 * @file layer_classical_cipher.c
 * @brief LQX-10 Layer 3: Classical Cipher Implementation
 * 
 * Third layer implementing classical cryptographic ciphers
 * including AES-256-GCM and ChaCha20-Poly1305.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../../include/lqx10_layers.h"
#include "../../include/lqx10_crypto.h"
#include <string.h>

// Layer 3: Classical Cipher Forward Transform
lqx10_error_t lqx10_layer3_forward(lqx10_context_t* ctx, const uint8_t* input, 
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (*output_len < input_len + LQX10_LAYER3_OVERHEAD) {
        *output_len = input_len + LQX10_LAYER3_OVERHEAD;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    size_t working_len = input_len;
    
    // Generate random IV for this layer
    uint8_t iv[16];
    result = lqx10_secure_random_bytes(iv, sizeof(iv));
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Encrypt using AES-256-CBC 
    size_t encrypted_len = input_len + 16; // Add padding space
    result = lqx10_aes_encrypt(ctx->layer_keys[2], iv, input, input_len, 
                               output, &encrypted_len);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    working_len = encrypted_len;
    
    // Append IV 
    memcpy(output + working_len, iv, sizeof(iv));
    working_len += sizeof(iv);
    
    *output_len = working_len;
    return LQX10_SUCCESS;
}

// Layer 3: Classical Cipher Reverse Transform
lqx10_error_t lqx10_layer3_reverse(lqx10_context_t* ctx, const uint8_t* input,
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (input_len < LQX10_LAYER3_OVERHEAD) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t data_len = input_len - LQX10_LAYER3_OVERHEAD;
    
    if (*output_len < data_len) {
        *output_len = data_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Extract IV 
    const uint8_t* iv = input + data_len;
    
    // Decrypt using AES-256-CBC
    size_t decrypted_len = data_len;
    result = lqx10_aes_decrypt(ctx->layer_keys[2], iv, input, data_len,
                               output, &decrypted_len);
    if (result != LQX10_SUCCESS) {
        return LQX10_ERROR_CRYPTO_FAILURE;
    }
    
    *output_len = data_len;
    return LQX10_SUCCESS;
}
