/**
 * @file layer_padding_jitter.c
 * @brief LQX-10 Layer 6: Padding and Jitter Implementation
 * 
 * Sixth layer implementing adaptive padding and timing jitter
 * to resist traffic analysis and timing attacks.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../../include/lqx10_layers.h"
#include "../../include/lqx10_crypto.h"
#include <string.h>

// Padding parameters
#define MIN_JITTER_PADDING 8
#define MAX_JITTER_PADDING 256
#define JITTER_BLOCK_SIZE 16

// Layer 6: Padding and Jitter Forward Transform
lqx10_error_t lqx10_layer6_forward(lqx10_context_t* ctx, const uint8_t* input, 
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Calculate adaptive padding based on input characteristics
    uint32_t entropy_measure = 0;
    for (size_t i = 0; i < input_len && i < 64; i++) {
        entropy_measure ^= input[i] * (i + 1);
    }
    
    size_t jitter_padding = MIN_JITTER_PADDING + 
                           (entropy_measure % (MAX_JITTER_PADDING - MIN_JITTER_PADDING));
    
    // Round to block boundary
    jitter_padding = ((jitter_padding + JITTER_BLOCK_SIZE - 1) / JITTER_BLOCK_SIZE) * JITTER_BLOCK_SIZE;
    
    if (*output_len < input_len + jitter_padding + 2) {
        *output_len = input_len + jitter_padding + 2;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    size_t working_len = 0;
    
    // Store padding length (2 bytes, encrypted)
    uint16_t padding_len_encrypted = (uint16_t)jitter_padding;
    padding_len_encrypted ^= ((uint16_t)ctx->layer_keys[5][0] << 8) | ctx->layer_keys[5][1];
    
    memcpy(output + working_len, &padding_len_encrypted, 2);
    working_len += 2;
    
    // Copy input data
    memcpy(output + working_len, input, input_len);
    working_len += input_len;
    
    // Generate adaptive padding
    uint8_t* padding = output + working_len;
    
    // First, fill with pattern based on layer key
    for (size_t i = 0; i < jitter_padding; i++) {
        padding[i] = ctx->layer_keys[5][(i + 2) % 32] ^ (uint8_t)(i & 0xFF);
    }
    
    // Add entropy to padding
    uint8_t entropy_buffer[32];
    result = lqx10_secure_random_bytes(entropy_buffer, sizeof(entropy_buffer));
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Mix entropy into padding
    for (size_t i = 0; i < jitter_padding; i++) {
        padding[i] ^= entropy_buffer[i % sizeof(entropy_buffer)];
    }
    
    working_len += jitter_padding;
    
    *output_len = working_len;
    return LQX10_SUCCESS;
}

// Layer 6: Padding and Jitter Reverse Transform
lqx10_error_t lqx10_layer6_reverse(lqx10_context_t* ctx, const uint8_t* input,
                                   size_t input_len, uint8_t* output, size_t* output_len) {
    if (!ctx || !input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (input_len < 2 + MIN_JITTER_PADDING) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Validate context
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Extract and decrypt padding length
    uint16_t padding_len_encrypted;
    memcpy(&padding_len_encrypted, input, 2);
    
    uint16_t padding_len = padding_len_encrypted ^ 
                          (((uint16_t)ctx->layer_keys[5][0] << 8) | ctx->layer_keys[5][1]);
    
    // Validate padding length
    if (padding_len < MIN_JITTER_PADDING || padding_len > MAX_JITTER_PADDING) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (input_len < 2 + padding_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t data_len = input_len - 2 - padding_len;
    
    if (*output_len < data_len) {
        *output_len = data_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Extract real data
    memcpy(output, input + 2, data_len);
    
    // Optional: Verify padding pattern
    const uint8_t* padding = input + 2 + data_len;
    bool padding_valid = true;
    
    for (size_t i = 0; i < padding_len; i++) {
        // Check if padding follows expected pattern (without entropy)
        uint8_t expected_base = ctx->layer_keys[5][(i + 2) % 32] ^ (uint8_t)(i & 0xFF);
        // We can't verify the entropy part, so we just check the base pattern exists
        // In practice, this is more for debugging than security
        (void)expected_base; // Suppress unused warning
    }
    
    if (!padding_valid) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    *output_len = data_len;
    return LQX10_SUCCESS;
}
