/**
 * @file totp.c
 * @brief Time-based One-Time Password (TOTP) Implementation
 * 
 * RFC 6238 compliant TOTP implementation for LQX-10 MFA support.
 * Zero-dependency implementation using only standard libraries.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../../include/lqx10_mfa.h"
#include "../../include/lqx10_crypto.h"
#include <string.h>
#include <time.h>

// TOTP default parameters
#define TOTP_DEFAULT_WINDOW_SIZE 1
#define TOTP_DEFAULT_DIGITS 6
#define TOTP_DEFAULT_STEP 30

// Generate TOTP code
lqx10_error_t lqx10_totp_generate(const uint8_t* secret, size_t secret_len,
                                  uint64_t timestamp, uint32_t digits,
                                  uint32_t step, uint32_t* code) {
    if (!secret || !code || secret_len == 0 || digits < 4 || digits > 10 || step == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Calculate time step
    uint64_t time_step = timestamp / step;
    
    // Generate HOTP code
    return lqx10_hotp_generate(secret, secret_len, time_step, digits, code);
}

// Verify TOTP code with time window
lqx10_error_t lqx10_totp_verify(const uint8_t* secret, size_t secret_len,
                                uint32_t code, uint64_t timestamp,
                                uint32_t digits, uint32_t step, uint32_t window) {
    if (!secret || secret_len == 0 || digits < 4 || digits > 10 || step == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Check current time step and surrounding window
    uint64_t current_step = timestamp / step;
    
    for (int64_t i = -(int64_t)window; i <= (int64_t)window; i++) {
        uint64_t test_step = current_step + i;
        uint32_t expected_code;
        
        lqx10_error_t result = lqx10_hotp_generate(secret, secret_len, test_step, digits, &expected_code);
        if (result != LQX10_SUCCESS) {
            return result;
        }
        
        if (expected_code == code) {
            return LQX10_SUCCESS;
        }
    }
    
    return LQX10_ERROR_AUTH_FAILURE;
}

// Get current TOTP code using system time
lqx10_error_t lqx10_totp_current(const uint8_t* secret, size_t secret_len,
                                 uint32_t* code) {
    if (!secret || !code || secret_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Get current Unix timestamp
    time_t current_time = time(NULL);
    if (current_time == (time_t)-1) {
        return LQX10_ERROR_UNKNOWN;
    }
    
    return lqx10_totp_generate(secret, secret_len, (uint64_t)current_time,
                               TOTP_DEFAULT_DIGITS, TOTP_DEFAULT_STEP, code);
}

// Verify current TOTP code using system time
lqx10_error_t lqx10_totp_verify_current(const uint8_t* secret, size_t secret_len,
                                        uint32_t code) {
    if (!secret || secret_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Get current Unix timestamp
    time_t current_time = time(NULL);
    if (current_time == (time_t)-1) {
        return LQX10_ERROR_UNKNOWN;
    }
    
    return lqx10_totp_verify(secret, secret_len, code, (uint64_t)current_time,
                             TOTP_DEFAULT_DIGITS, TOTP_DEFAULT_STEP, TOTP_DEFAULT_WINDOW_SIZE);
}

// Get remaining time for current TOTP period
lqx10_error_t lqx10_totp_remaining_time(uint32_t step, uint32_t* remaining) {
    if (!remaining || step == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    time_t current_time = time(NULL);
    if (current_time == (time_t)-1) {
        return LQX10_ERROR_UNKNOWN;
    }
    
    *remaining = step - ((uint32_t)current_time % step);
    return LQX10_SUCCESS;
}
