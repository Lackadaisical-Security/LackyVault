/**
 * @file hotp.c
 * @brief HMAC-based One-Time Password (HOTP) Implementation
 * 
 * RFC 4226 compliant HOTP implementation for LQX-10 MFA support.
 * Zero-dependency implementation using only standard libraries.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../../include/lqx10_mfa.h"
#include "../../include/lqx10_crypto.h"
#include <string.h>

// Dynamic truncation as per RFC 4226
static uint32_t dynamic_truncate(const uint8_t* hmac_result) {
    uint32_t offset = hmac_result[19] & 0x0F;
    
    uint32_t code = ((uint32_t)(hmac_result[offset] & 0x7F) << 24) |
                    ((uint32_t)(hmac_result[offset + 1] & 0xFF) << 16) |
                    ((uint32_t)(hmac_result[offset + 2] & 0xFF) << 8) |
                    ((uint32_t)(hmac_result[offset + 3] & 0xFF));
    
    return code;
}

// Generate HOTP code
lqx10_error_t lqx10_hotp_generate(const uint8_t* secret, size_t secret_len,
                                  uint64_t counter, uint32_t digits, uint32_t* code) {
    if (!secret || !code || secret_len == 0 || digits < 4 || digits > 10) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Convert counter to big-endian byte array
    uint8_t counter_bytes[8];
    for (int i = 7; i >= 0; i--) {
        counter_bytes[i] = (uint8_t)(counter & 0xFF);
        counter >>= 8;
    }
    
    // Calculate HMAC-SHA256
    uint8_t hmac_result[32];
    lqx10_error_t result = lqx10_hmac_sha256(secret, secret_len, counter_bytes, 8, hmac_result);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Dynamic truncation (use first 20 bytes for compatibility)
    uint32_t truncated = dynamic_truncate(hmac_result);
    
    // Generate modulus for desired number of digits
    uint32_t modulus = 1;
    for (uint32_t i = 0; i < digits; i++) {
        modulus *= 10;
    }
    
    *code = truncated % modulus;
    return LQX10_SUCCESS;
}

// Verify HOTP code
lqx10_error_t lqx10_hotp_verify(const uint8_t* secret, size_t secret_len,
                                uint32_t code, uint64_t counter, uint32_t digits) {
    if (!secret || secret_len == 0 || digits < 4 || digits > 10) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    uint32_t expected_code;
    lqx10_error_t result = lqx10_hotp_generate(secret, secret_len, counter, digits, &expected_code);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    if (expected_code == code) {
        return LQX10_SUCCESS;
    } else {
        return LQX10_ERROR_AUTH_FAILURE;
    }
}

// Verify HOTP code with counter window (for synchronization)
lqx10_error_t lqx10_hotp_verify_window(const uint8_t* secret, size_t secret_len,
                                       uint32_t code, uint64_t counter, uint32_t digits,
                                       uint32_t window, uint64_t* matched_counter) {
    if (!secret || secret_len == 0 || digits < 4 || digits > 10) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Check counter and following window
    for (uint32_t i = 0; i <= window; i++) {
        uint64_t test_counter = counter + i;
        uint32_t expected_code;
        
        lqx10_error_t result = lqx10_hotp_generate(secret, secret_len, test_counter, digits, &expected_code);
        if (result != LQX10_SUCCESS) {
            return result;
        }
        
        if (expected_code == code) {
            if (matched_counter) {
                *matched_counter = test_counter;
            }
            return LQX10_SUCCESS;
        }
    }
    
    return LQX10_ERROR_AUTH_FAILURE;
}
