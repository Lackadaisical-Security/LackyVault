#include "../include/lqx10_mfa.h"
#include "../include/lqx10_crypto.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

#ifdef _WIN32
#include <windows.h>
#include <wincred.h>
#include <winbio.h>
#pragma comment(lib, "credui.lib")
#pragma comment(lib, "winbio.lib")
#endif

// TOTP algorithm constants
#define TOTP_HMAC_SHA1_BLOCK_SIZE 64
#define TOTP_HMAC_SHA1_OUTPUT_SIZE 20

// Internal helper functions
static lqx10_error_t hmac_sha1(const uint8_t *key, size_t key_len,
                               const uint8_t *data, size_t data_len,
                               uint8_t *output);
static uint32_t hotp_generate(const uint8_t *secret, size_t secret_len, uint64_t counter, uint8_t digits);
static uint64_t get_current_timestamp(void);
static lqx10_error_t secure_compare_constant_time(const void *a, const void *b, size_t len);

// Initialize MFA context
lqx10_error_t lqx10_mfa_init(lqx10_mfa_context_t **mfa_ctx, lqx10_mfa_type_t type) {
    if (!mfa_ctx) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    lqx10_mfa_context_t *ctx = calloc(1, sizeof(lqx10_mfa_context_t));
    if (!ctx) {
        return LQX10_ERROR_MEMORY_ALLOCATION;
    }
    
    ctx->type = type;
    ctx->is_enabled = false;
    ctx->is_verified = false;
    ctx->last_verification = 0;
    ctx->failure_count = 0;
    
    // Initialize type-specific configuration
    switch (type) {
        case LQX10_MFA_TOTP:
            ctx->config.totp.time_step = LQX10_TOTP_WINDOW_SIZE;
            ctx->config.totp.window = 1;
            ctx->config.totp.digits = LQX10_TOTP_DIGITS;
            lqx10_secure_random_bytes(ctx->config.totp.secret, LQX10_TOTP_SECRET_SIZE);
            break;
            
        case LQX10_MFA_FIDO2:
            ctx->config.fido2.touch_required = true;
            lqx10_secure_random_bytes(ctx->config.fido2.challenge, LQX10_FIDO2_CHALLENGE_SIZE);
            break;
            
        case LQX10_MFA_BIOMETRIC:
            ctx->config.biometric.match_threshold = LQX10_BIO_THRESHOLD;
            ctx->config.biometric.template_version = 1;
            break;
            
        case LQX10_MFA_SMART_CARD:
            ctx->config.smart_card.pin_attempts = 0;
            ctx->config.smart_card.pin_required = true;
            break;
            
        default:
            free(ctx);
            return LQX10_ERROR_INVALID_PARAM;
    }
    
    ctx->is_enabled = true;
    *mfa_ctx = ctx;
    return LQX10_SUCCESS;
}

// Destroy MFA context
lqx10_error_t lqx10_mfa_destroy(lqx10_mfa_context_t *mfa_ctx) {
    if (!mfa_ctx) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Securely zero sensitive data
    lqx10_secure_memzero(mfa_ctx, sizeof(lqx10_mfa_context_t));
    free(mfa_ctx);
    
    return LQX10_SUCCESS;
}

// Generate TOTP secret
lqx10_error_t lqx10_totp_generate_secret(uint8_t *secret, size_t secret_len) {
    if (!secret || secret_len < LQX10_TOTP_SECRET_SIZE) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    return lqx10_secure_random_bytes(secret, secret_len);
}

// Generate TOTP code
lqx10_error_t lqx10_totp_generate_code(const uint8_t *secret, 
                                       size_t secret_len,
                                       uint32_t *code,
                                       uint8_t digits,
                                       uint32_t time_step) {
    if (!secret || !code || secret_len == 0 || digits == 0 || digits > 8) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    uint64_t counter = get_current_timestamp() / time_step;
    *code = hotp_generate(secret, secret_len, counter, digits);
    
    return LQX10_SUCCESS;
}

// Verify TOTP code
lqx10_error_t lqx10_totp_verify_code(const uint8_t *secret,
                                     size_t secret_len,
                                     uint32_t code,
                                     uint8_t digits,
                                     uint32_t time_step,
                                     uint8_t window) {
    if (!secret || secret_len == 0 || digits == 0 || digits > 8) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    uint64_t current_counter = get_current_timestamp() / time_step;
    
    // Check within time window
    for (int i = -window; i <= window; i++) {
        uint64_t counter = current_counter + i;
        uint32_t expected_code = hotp_generate(secret, secret_len, counter, digits);
        
        if (code == expected_code) {
            return LQX10_SUCCESS;
        }
    }
    
    return LQX10_ERROR_AUTHENTICATION_FAILURE;
}

// Generate FIDO2 challenge
lqx10_error_t lqx10_fido2_generate_challenge(uint8_t *challenge, size_t challenge_len) {
    if (!challenge || challenge_len < LQX10_FIDO2_CHALLENGE_SIZE) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    return lqx10_secure_random_bytes(challenge, challenge_len);
}

// Register FIDO2 credential
lqx10_error_t lqx10_fido2_register_credential(lqx10_mfa_context_t *mfa_ctx,
                                              const uint8_t *challenge,
                                              size_t challenge_len) {
    if (!mfa_ctx || mfa_ctx->type != LQX10_MFA_FIDO2 || !challenge) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // In production, this would interface with actual FIDO2 hardware
    // For now, simulate the registration process
    
    // Generate credential ID
    lqx10_error_t result = lqx10_secure_random_bytes(mfa_ctx->config.fido2.credential_id, 
                                                     LQX10_FIDO2_CREDENTIAL_ID_SIZE);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Generate key pair (simulated)
    result = lqx10_secure_random_bytes(mfa_ctx->config.fido2.public_key, 
                                       LQX10_FIDO2_PUBLIC_KEY_SIZE);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Store challenge
    memcpy(mfa_ctx->config.fido2.challenge, challenge, 
           min(challenge_len, LQX10_FIDO2_CHALLENGE_SIZE));
    
    return LQX10_SUCCESS;
}

// FIDO2 credential creation
lqx10_error_t lqx10_fido2_create_credential(lqx10_mfa_context_t *mfa_ctx,
                                            const uint8_t *user_id,
                                            size_t user_id_len,
                                            const char *user_name,
                                            const char *display_name) {
    if (!mfa_ctx || !user_id || !user_name || mfa_ctx->type != LQX10_MFA_FIDO2) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Generate new credential ID
    lqx10_secure_random_bytes(mfa_ctx->config.fido2.credential_id, LQX10_FIDO2_CREDENTIAL_ID_SIZE);
    
    // Store user info
    if (user_id_len > sizeof(mfa_ctx->config.fido2.user_id)) {
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    memcpy(mfa_ctx->config.fido2.user_id, user_id, user_id_len);
    mfa_ctx->config.fido2.user_id_len = user_id_len;
    
    // Generate key pair
    lqx10_error_t result = lqx10_dilithium_keygen(mfa_ctx->config.fido2.public_key,
                                                   mfa_ctx->config.fido2.private_key);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    mfa_ctx->config.fido2.keys_generated = true;
    return LQX10_SUCCESS;
}

// Authenticate with FIDO2
lqx10_error_t lqx10_fido2_authenticate(lqx10_mfa_context_t *mfa_ctx,
                                       const uint8_t *challenge,
                                       size_t challenge_len,
                                       uint8_t *signature,
                                       size_t *signature_len) {
    if (!mfa_ctx || !challenge || !signature || !signature_len || 
        mfa_ctx->type != LQX10_MFA_FIDO2 || !mfa_ctx->config.fido2.keys_generated) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Update challenge
    if (challenge_len > LQX10_FIDO2_CHALLENGE_SIZE) {
        challenge_len = LQX10_FIDO2_CHALLENGE_SIZE;
    }
    memcpy(mfa_ctx->config.fido2.challenge, challenge, challenge_len);
    
    // Sign challenge with private key
    return lqx10_dilithium_sign(mfa_ctx->config.fido2.private_key,
                                challenge, challenge_len,
                                signature, signature_len);
}

// Biometric enrollment
lqx10_error_t lqx10_biometric_enroll(lqx10_mfa_context_t *mfa_ctx,
                                     const uint8_t *template_data,
                                     size_t template_len) {
    if (!mfa_ctx || !template_data || mfa_ctx->type != LQX10_MFA_BIOMETRIC) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (template_len > LQX10_BIO_TEMPLATE_SIZE) {
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Store biometric template
    memcpy(mfa_ctx->config.biometric.template_data, template_data, template_len);
    mfa_ctx->config.biometric.template_size = template_len;
    mfa_ctx->config.biometric.template_enrolled = true;
    
#ifdef _WIN32
    // Windows biometric enrollment
    WINBIO_SESSION_HANDLE sessionHandle = NULL;
    HRESULT hr = WinBioOpenSession(
        WINBIO_TYPE_FINGERPRINT,
        WINBIO_POOL_SYSTEM,
        WINBIO_FLAG_DEFAULT,
        NULL, 0,
        NULL,
        &sessionHandle
    );
    
    if (SUCCEEDED(hr)) {
        // Enroll fingerprint
        WINBIO_IDENTITY identity = {0};
        identity.Type = WINBIO_ID_TYPE_GUID;
        CoCreateGuid(&identity.Value.TemplateGuid);
        
        hr = WinBioEnrollBegin(sessionHandle, WINBIO_SUBTYPE_ANY, WINBIO_ANSI_381_POS_UNKNOWN);
        
        if (SUCCEEDED(hr)) {
            // Store enrollment ID
            memcpy(mfa_ctx->config.biometric.enrollment_id, &identity.Value.TemplateGuid, 16);
        }
        
        WinBioCloseSession(sessionHandle);
    }
#endif
    
    return LQX10_SUCCESS;
}

// Biometric verification
lqx10_error_t lqx10_biometric_verify(lqx10_mfa_context_t *mfa_ctx,
                                     const uint8_t *sample_data,
                                     size_t sample_len) {
    if (!mfa_ctx || !sample_data || mfa_ctx->type != LQX10_MFA_BIOMETRIC ||
        !mfa_ctx->config.biometric.template_enrolled) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
#ifdef _WIN32
    // Windows biometric verification
    WINBIO_SESSION_HANDLE sessionHandle = NULL;
    HRESULT hr = WinBioOpenSession(
        WINBIO_TYPE_FINGERPRINT,
        WINBIO_POOL_SYSTEM,
        WINBIO_FLAG_DEFAULT,
        NULL, 0,
        NULL,
        &sessionHandle
    );
    
    if (SUCCEEDED(hr)) {
        WINBIO_UNIT_ID unitId = 0;
        WINBIO_IDENTITY identity = {0};
        WINBIO_BIOMETRIC_SUBTYPE subFactor = 0;
        WINBIO_REJECT_DETAIL rejectDetail = 0;
        
        hr = WinBioIdentify(sessionHandle, &unitId, &identity, &subFactor, &rejectDetail);
        
        WinBioCloseSession(sessionHandle);
        
        if (SUCCEEDED(hr)) {
            return LQX10_SUCCESS;
        }
    }
#endif
    
    // Fallback: Simple template comparison
    if (sample_len != mfa_ctx->config.biometric.template_size) {
        return LQX10_ERROR_AUTHENTICATION_FAILURE;
    }
    
    if (secure_compare_constant_time(sample_data, mfa_ctx->config.biometric.template_data,
                                     sample_len) == LQX10_SUCCESS) {
        return LQX10_SUCCESS;
    }
    
    return LQX10_ERROR_AUTHENTICATION_FAILURE;
}

// Smart card authentication
lqx10_error_t lqx10_smart_card_auth(lqx10_mfa_context_t *mfa_ctx,
                                    const char *pin,
                                    uint8_t *certificate,
                                    size_t *cert_len) {
    if (!mfa_ctx || mfa_ctx->type != LQX10_MFA_SMART_CARD) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (mfa_ctx->config.smart_card.pin_required && !pin) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
#ifdef _WIN32
    // Windows smart card authentication
    SCARDCONTEXT hContext = 0;
    LONG result = SCardEstablishContext(SCARD_SCOPE_USER, NULL, NULL, &hContext);
    
    if (result == SCARD_S_SUCCESS) {
        // List available readers
        DWORD dwReaders = SCARD_AUTOALLOCATE;
        LPTSTR mszReaders = NULL;
        
        result = SCardListReaders(hContext, NULL, (LPTSTR)&mszReaders, &dwReaders);
        
        if (result == SCARD_S_SUCCESS && mszReaders) {
            // Connect to first reader
            SCARDHANDLE hCard = 0;
            DWORD dwActiveProtocol = 0;
            
            result = SCardConnect(hContext, mszReaders, SCARD_SHARE_SHARED,
                                  SCARD_PROTOCOL_T0 | SCARD_PROTOCOL_T1,
                                  &hCard, &dwActiveProtocol);
            
            if (result == SCARD_S_SUCCESS) {
                // Verify PIN if required
                if (mfa_ctx->config.smart_card.pin_required && pin) {
                    // Send VERIFY command
                    BYTE cmd[] = {0x00, 0x20, 0x00, 0x80}; // VERIFY PIN command
                    BYTE response[256];
                    DWORD responseLen = sizeof(response);
                    
                    result = SCardTransmit(hCard, SCARD_PCI_T0, cmd, sizeof(cmd),
                                           NULL, response, &responseLen);
                }
                
                // Read certificate if requested
                if (certificate && cert_len && result == SCARD_S_SUCCESS) {
                    // Read certificate from card
                    BYTE readCmd[] = {0x00, 0xA4, 0x04, 0x00}; // SELECT command
                    BYTE response[1024];
                    DWORD responseLen = sizeof(response);
                    
                    result = SCardTransmit(hCard, SCARD_PCI_T0, readCmd, sizeof(readCmd),
                                           NULL, response, &responseLen);
                    
                    if (result == SCARD_S_SUCCESS && responseLen <= *cert_len) {
                        memcpy(certificate, response, responseLen);
                        *cert_len = responseLen;
                    }
                }
                
                SCardDisconnect(hCard, SCARD_LEAVE_CARD);
            }
            
            SCardFreeMemory(hContext, mszReaders);
        }
        
        SCardReleaseContext(hContext);
        
        if (result == SCARD_S_SUCCESS) {
            mfa_ctx->config.smart_card.authenticated = true;
            return LQX10_SUCCESS;
        }
    }
#endif
    
    return LQX10_ERROR_AUTHENTICATION_FAILURE;
}

// MFA verification
lqx10_error_t lqx10_mfa_verify(lqx10_mfa_context_t *mfa_ctx,
                               const void *auth_data,
                               size_t auth_data_len) {
    if (!mfa_ctx || !mfa_ctx->is_enabled) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    lqx10_error_t result;
    
    switch (mfa_ctx->type) {
        case LQX10_MFA_TOTP:
            if (auth_data_len != sizeof(uint32_t)) {
                return LQX10_ERROR_INVALID_PARAM;
            }
            result = lqx10_totp_verify_code(mfa_ctx->config.totp.secret,
                                            LQX10_TOTP_SECRET_SIZE,
                                            *((uint32_t*)auth_data),
                                            mfa_ctx->config.totp.digits,
                                            mfa_ctx->config.totp.time_step,
                                            mfa_ctx->config.totp.window);
            break;
            
        case LQX10_MFA_FIDO2:
            // FIDO2 verification handled externally
            result = LQX10_SUCCESS;
            break;
            
        case LQX10_MFA_BIOMETRIC:
            result = lqx10_biometric_verify(mfa_ctx, auth_data, auth_data_len);
            break;
            
        case LQX10_MFA_SMART_CARD:
            result = lqx10_smart_card_auth(mfa_ctx, auth_data, NULL, NULL);
            break;
            
        default:
            return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (result == LQX10_SUCCESS) {
        mfa_ctx->is_verified = true;
        mfa_ctx->last_verification = time(NULL);
        mfa_ctx->failure_count = 0;
    } else {
        mfa_ctx->failure_count++;
        if (mfa_ctx->failure_count >= LQX10_MFA_MAX_FAILURES) {
            mfa_ctx->is_enabled = false; // Lock out after too many failures
        }
    }
    
    return result;
}

// Internal helper functions
static lqx10_error_t hmac_sha1(const uint8_t *key, size_t key_len,
                               const uint8_t *data, size_t data_len,
                               uint8_t *output) {
    uint8_t k_ipad[TOTP_HMAC_SHA1_BLOCK_SIZE];
    uint8_t k_opad[TOTP_HMAC_SHA1_BLOCK_SIZE];
    uint8_t tk[TOTP_HMAC_SHA1_OUTPUT_SIZE];
    
    // If key is longer than block size, hash it
    if (key_len > TOTP_HMAC_SHA1_BLOCK_SIZE) {
        lqx10_blake3_hash(key, key_len, tk, TOTP_HMAC_SHA1_OUTPUT_SIZE);
        key = tk;
        key_len = TOTP_HMAC_SHA1_OUTPUT_SIZE;
    }
    
    // Prepare padded keys
    memset(k_ipad, 0x36, TOTP_HMAC_SHA1_BLOCK_SIZE);
    memset(k_opad, 0x5c, TOTP_HMAC_SHA1_BLOCK_SIZE);
    
    for (size_t i = 0; i < key_len; i++) {
        k_ipad[i] ^= key[i];
        k_opad[i] ^= key[i];
    }
    
    // Inner hash
    uint8_t inner_input[TOTP_HMAC_SHA1_BLOCK_SIZE + data_len];
    memcpy(inner_input, k_ipad, TOTP_HMAC_SHA1_BLOCK_SIZE);
    memcpy(inner_input + TOTP_HMAC_SHA1_BLOCK_SIZE, data, data_len);
    
    uint8_t inner_hash[TOTP_HMAC_SHA1_OUTPUT_SIZE];
    lqx10_blake3_hash(inner_input, TOTP_HMAC_SHA1_BLOCK_SIZE + data_len,
                      inner_hash, TOTP_HMAC_SHA1_OUTPUT_SIZE);
    
    // Outer hash
    uint8_t outer_input[TOTP_HMAC_SHA1_BLOCK_SIZE + TOTP_HMAC_SHA1_OUTPUT_SIZE];
    memcpy(outer_input, k_opad, TOTP_HMAC_SHA1_BLOCK_SIZE);
    memcpy(outer_input + TOTP_HMAC_SHA1_BLOCK_SIZE, inner_hash, TOTP_HMAC_SHA1_OUTPUT_SIZE);
    
    lqx10_blake3_hash(outer_input, TOTP_HMAC_SHA1_BLOCK_SIZE + TOTP_HMAC_SHA1_OUTPUT_SIZE,
                      output, TOTP_HMAC_SHA1_OUTPUT_SIZE);
    
    // Clean up
    lqx10_secure_memzero(k_ipad, TOTP_HMAC_SHA1_BLOCK_SIZE);
    lqx10_secure_memzero(k_opad, TOTP_HMAC_SHA1_BLOCK_SIZE);
    lqx10_secure_memzero(tk, TOTP_HMAC_SHA1_OUTPUT_SIZE);
    
    return LQX10_SUCCESS;
}

static uint32_t hotp_generate(const uint8_t *secret, size_t secret_len, uint64_t counter, uint8_t digits) {
    // Convert counter to big-endian
    uint8_t counter_bytes[8];
    for (int i = 7; i >= 0; i--) {
        counter_bytes[i] = counter & 0xff;
        counter >>= 8;
    }
    
    // Calculate HMAC
    uint8_t hmac[TOTP_HMAC_SHA1_OUTPUT_SIZE];
    hmac_sha1(secret, secret_len, counter_bytes, 8, hmac);
    
    // Dynamic truncation
    int offset = hmac[TOTP_HMAC_SHA1_OUTPUT_SIZE - 1] & 0xf;
    uint32_t code = ((hmac[offset] & 0x7f) << 24) |
                    ((hmac[offset + 1] & 0xff) << 16) |
                    ((hmac[offset + 2] & 0xff) << 8) |
                    (hmac[offset + 3] & 0xff);
    
    // Calculate modulo
    uint32_t modulo = 1;
    for (uint8_t i = 0; i < digits; i++) {
        modulo *= 10;
    }
    
    return code % modulo;
}

static uint64_t get_current_timestamp(void) {
    return (uint64_t)time(NULL);
}

static lqx10_error_t secure_compare_constant_time(const void *a, const void *b, size_t len) {
    const uint8_t *pa = a;
    const uint8_t *pb = b;
    uint8_t diff = 0;
    
    for (size_t i = 0; i < len; i++) {
        diff |= pa[i] ^ pb[i];
    }
    
    return diff == 0 ? LQX10_SUCCESS : LQX10_ERROR_AUTHENTICATION_FAILURE;
}

// Biometric verification stub implementation
static lqx10_error_t lqx10_biometric_verify(lqx10_mfa_context_t *mfa_ctx,
                                             const uint8_t *bio_data,
                                             size_t bio_data_len) {
    if (!mfa_ctx || !bio_data || bio_data_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Placeholder implementation - in real system would use biometric matching
    // For now, just verify that bio_data matches a simple pattern
    if (bio_data_len >= 16) {
        uint32_t checksum = 0;
        for (size_t i = 0; i < 16; i++) {
            checksum ^= bio_data[i];
        }
        
        // Simple validation - in production would be cryptographic template matching
        if (checksum == mfa_ctx->config.biometric.template_hash[0]) {
            return LQX10_SUCCESS;
        }
    }
    
    return LQX10_ERROR_AUTH_FAILURE;
}

// Smart card authentication stub implementation  
static lqx10_error_t lqx10_smart_card_auth(lqx10_mfa_context_t *mfa_ctx,
                                            const uint8_t *card_data,
                                            uint8_t *challenge,
                                            uint8_t *response) {
    if (!mfa_ctx || !card_data) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Placeholder implementation - in real system would communicate with smart card
    // For now, just verify a simple challenge-response
    
    if (challenge && response) {
        // Generate challenge
        lqx10_secure_random_bytes_pure(challenge, 32);
        
        // Expected response would be HMAC of challenge with card's private key
        // For stub, just XOR with card ID
        for (int i = 0; i < 32; i++) {
            response[i] = challenge[i] ^ mfa_ctx->config.smart_card.card_id[i % 16];
        }
        
        return LQX10_SUCCESS;
    }
    
    // Simple card presence check
    if (card_data[0] == 0x3B) { // ATR byte for smart card
        return LQX10_SUCCESS;
    }
    
    return LQX10_ERROR_AUTH_FAILURE;
}
