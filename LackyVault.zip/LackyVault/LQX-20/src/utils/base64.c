/**
 * @file base64.c
 * @brief Base64 Encoding/Decoding Implementation
 * 
 * RFC 4648 compliant Base64 implementation for LQX-10 utilities.
 * Zero-dependency implementation for data encoding.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../../include/lqx10_utils.h"
#include <string.h>

// Base64 encoding table
static const char base64_encode_table[] = 
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

// Base64 decoding table
static const int base64_decode_table[256] = {
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,  // 0-15
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,  // 16-31
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,62,-1,-1,-1,63,  // 32-47
    52,53,54,55,56,57,58,59,60,61,-1,-1,-1,-2,-1,-1,  // 48-63
    -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,  // 64-79
    15,16,17,18,19,20,21,22,23,24,25,-1,-1,-1,-1,-1,  // 80-95
    -1,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,  // 96-111
    41,42,43,44,45,46,47,48,49,50,51,-1,-1,-1,-1,-1,  // 112-127
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,  // 128-143
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,  // 144-159
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,  // 160-175
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,  // 176-191
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,  // 192-207
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,  // 208-223
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,  // 224-239
    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1   // 240-255
};

// Calculate encoded length
size_t lqx10_base64_encode_length(size_t input_len) {
    return ((input_len + 2) / 3) * 4;
}

// Calculate decoded length
size_t lqx10_base64_decode_length(const char* input, size_t input_len) {
    if (!input || input_len == 0) {
        return 0;
    }
    
    size_t padding = 0;
    if (input_len >= 2) {
        if (input[input_len - 1] == '=') padding++;
        if (input[input_len - 2] == '=') padding++;
    }
    
    return (input_len * 3) / 4 - padding;
}

// Base64 encode
lqx10_error_t lqx10_base64_encode(const uint8_t* input, size_t input_len,
                                  char* output, size_t* output_len) {
    if (!input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t required_len = lqx10_base64_encode_length(input_len);
    if (*output_len < required_len + 1) { // +1 for null terminator
        *output_len = required_len + 1;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    size_t output_pos = 0;
    
    // Process input in 3-byte groups
    for (size_t i = 0; i < input_len; i += 3) {
        uint32_t group = 0;
        int group_size = 0;
        
        // Build 24-bit group
        for (int j = 0; j < 3 && (i + j) < input_len; j++) {
            group = (group << 8) | input[i + j];
            group_size++;
        }
        
        // Pad group to 24 bits
        group <<= (3 - group_size) * 8;
        
        // Extract 6-bit values and encode
        for (int j = 3; j >= 0; j--) {
            if (j < group_size + 1 || (j == 3 && group_size == 1) || (j >= 2 && group_size == 2)) {
                output[output_pos++] = base64_encode_table[(group >> (j * 6)) & 0x3F];
            } else {
                output[output_pos++] = '=';
            }
        }
    }
    
    output[output_pos] = '\0';
    *output_len = output_pos;
    return LQX10_SUCCESS;
}

// Base64 decode
lqx10_error_t lqx10_base64_decode(const char* input, size_t input_len,
                                  uint8_t* output, size_t* output_len) {
    if (!input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Remove any whitespace and validate length
    if (input_len % 4 != 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t required_len = lqx10_base64_decode_length(input, input_len);
    if (*output_len < required_len) {
        *output_len = required_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    size_t output_pos = 0;
    
    // Process input in 4-character groups
    for (size_t i = 0; i < input_len; i += 4) {
        uint32_t group = 0;
        int valid_chars = 0;
        
        // Decode 4 characters into 24-bit group
        for (int j = 0; j < 4; j++) {
            char c = input[i + j];
            int value = base64_decode_table[(unsigned char)c];
            
            if (value == -1) {
                return LQX10_ERROR_INVALID_PARAM; // Invalid character
            } else if (value == -2) {
                break; // Padding character
            } else {
                group = (group << 6) | value;
                valid_chars++;
            }
        }
        
        // Extract bytes from group
        group <<= (4 - valid_chars) * 6;
        
        for (int j = 2; j >= 0; j--) {
            if (j < valid_chars - 1) {
                output[output_pos++] = (uint8_t)((group >> (j * 8)) & 0xFF);
            }
        }
    }
    
    *output_len = output_pos;
    return LQX10_SUCCESS;
}

// URL-safe Base64 encode (RFC 4648 Section 5)
lqx10_error_t lqx10_base64_encode_urlsafe(const uint8_t* input, size_t input_len,
                                          char* output, size_t* output_len) {
    lqx10_error_t result = lqx10_base64_encode(input, input_len, output, output_len);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Replace + with - and / with _
    for (size_t i = 0; i < *output_len; i++) {
        if (output[i] == '+') {
            output[i] = '-';
        } else if (output[i] == '/') {
            output[i] = '_';
        }
    }
    
    return LQX10_SUCCESS;
}

// URL-safe Base64 decode
lqx10_error_t lqx10_base64_decode_urlsafe(const char* input, size_t input_len,
                                          uint8_t* output, size_t* output_len) {
    if (!input || input_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Create a copy and replace URL-safe characters
    char* temp_input = malloc(input_len + 1);
    if (!temp_input) {
        return LQX10_ERROR_MEMORY_ALLOC;
    }
    
    memcpy(temp_input, input, input_len);
    temp_input[input_len] = '\0';
    
    // Replace - with + and _ with /
    for (size_t i = 0; i < input_len; i++) {
        if (temp_input[i] == '-') {
            temp_input[i] = '+';
        } else if (temp_input[i] == '_') {
            temp_input[i] = '/';
        }
    }
    
    lqx10_error_t result = lqx10_base64_decode(temp_input, input_len, output, output_len);
    
    // Clear and free temporary buffer
    memset(temp_input, 0, input_len);
    free(temp_input);
    
    return result;
}
