#include "../../include/lqx10_core.h"
#include "../../include/lqx10_crypto.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
#pragma comment(lib, "kernel32.lib")
#else
#include <sys/time.h>
#include <unistd.h>
#endif

// Test configuration
#define PERFORMANCE_ITERATIONS 1000
#define LARGE_DATA_SIZE (1024 * 1024) // 1MB
#define BENCHMARK_WARMUP 100

// Timing utilities
static uint64_t get_time_microseconds(void) {
#ifdef _WIN32
    LARGE_INTEGER frequency, counter;
    QueryPerformanceFrequency(&frequency);
    QueryPerformanceCounter(&counter);
    return (counter.QuadPart * 1000000) / frequency.QuadPart;
#else
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec * 1000000ULL + tv.tv_usec;
#endif
}

// Performance measurement structure
typedef struct {
    const char *test_name;
    uint64_t total_time_us;
    uint64_t iterations;
    size_t data_size;
    double throughput_mbps;
} lqx10_perf_result_t;

// Test result reporting
static void print_perf_result(const lqx10_perf_result_t *result) {
    double avg_time_us = (double)result->total_time_us / result->iterations;
    printf("%-30s: %8.2f µs/op, %8.2f MB/s\n", 
           result->test_name, avg_time_us, result->throughput_mbps);
}

// =================== CRYPTOGRAPHIC FUNCTIONALITY TESTS ===================

static lqx10_error_t test_aes_functionality(void) {
    printf("Testing AES-256 functionality...\n");
    
    const uint8_t key[32] = {
        0x60, 0x3d, 0xeb, 0x10, 0x15, 0xca, 0x71, 0xbe, 0x2b, 0x73, 0xae, 0xf0, 0x85, 0x7d, 0x77, 0x81,
        0x1f, 0x35, 0x2c, 0x07, 0x3b, 0x61, 0x08, 0xd7, 0x2d, 0x98, 0x10, 0xa3, 0x09, 0x14, 0xdf, 0xf4
    };
    
    const uint8_t iv[16] = {
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f
    };
    
    const char *test_message = "Hello, LQX-10 Cryptographic Primitive! This is a test message for AES encryption.";
    size_t message_len = strlen(test_message);
    
    uint8_t ciphertext[256];
    uint8_t decrypted[256];
    size_t ciphertext_len = sizeof(ciphertext);
    size_t decrypted_len = sizeof(decrypted);
    
    // Test encryption
    lqx10_error_t result = lqx10_aes_encrypt_pure(key, iv, (uint8_t*)test_message, message_len,
                                                  ciphertext, &ciphertext_len);
    if (result != LQX10_SUCCESS) {
        printf("AES encryption failed: %d\n", result);
        return result;
    }
    
    // Test decryption
    result = lqx10_aes_decrypt_pure(key, iv, ciphertext, ciphertext_len,
                                    decrypted, &decrypted_len);
    if (result != LQX10_SUCCESS) {
        printf("AES decryption failed: %d\n", result);
        return result;
    }
    
    // Verify round-trip
    if (decrypted_len != message_len || memcmp(test_message, decrypted, message_len) != 0) {
        printf("AES round-trip verification failed\n");
        return LQX10_ERROR_CRYPTO_FAILURE;
    }
    
    printf("✓ AES-256 functionality test passed\n");
    return LQX10_SUCCESS;
}

static lqx10_error_t test_post_quantum_functionality(void) {
    printf("Testing Post-Quantum cryptography functionality...\n");
    
    uint8_t public_key[LQX10_KYBER_PUBLIC_KEY_SIZE];
    uint8_t secret_key[LQX10_KYBER_SECRET_KEY_SIZE];
    uint8_t ciphertext[LQX10_KYBER_CIPHERTEXT_SIZE];
    uint8_t shared_secret1[LQX10_KYBER_SHARED_SECRET_SIZE];
    uint8_t shared_secret2[LQX10_KYBER_SHARED_SECRET_SIZE];
    
    // Test Kyber key generation
    lqx10_error_t result = lqx10_kyber_keygen_pure(public_key, secret_key);
    if (result != LQX10_SUCCESS) {
        printf("Kyber key generation failed: %d\n", result);
        return result;
    }
    
    // Test encapsulation
    result = lqx10_kyber_encaps_pure(public_key, ciphertext, shared_secret1);
    if (result != LQX10_SUCCESS) {
        printf("Kyber encapsulation failed: %d\n", result);
        return result;
    }
    
    // Test decapsulation
    result = lqx10_kyber_decaps_pure(secret_key, ciphertext, shared_secret2);
    if (result != LQX10_SUCCESS) {
        printf("Kyber decapsulation failed: %d\n", result);
        return result;
    }
    
    // Verify shared secrets match
    bool secrets_equal;
    result = lqx10_constant_time_compare(shared_secret1, shared_secret2, 
                                        LQX10_KYBER_SHARED_SECRET_SIZE, &secrets_equal);
    if (result != LQX10_SUCCESS || !secrets_equal) {
        printf("Kyber shared secret verification failed\n");
        return LQX10_ERROR_CRYPTO_FAILURE;
    }
    
    printf("✓ Post-Quantum cryptography functionality test passed\n");
    return LQX10_SUCCESS;
}

static lqx10_error_t test_hybrid_crypto_functionality(void) {
    printf("Testing Hybrid cryptography functionality...\n");
    
    lqx10_hybrid_keys_t hybrid_keys;
    
    // Generate hybrid keys
    lqx10_error_t result = lqx10_hybrid_keygen(&hybrid_keys);
    if (result != LQX10_SUCCESS) {
        printf("Hybrid key generation failed: %d\n", result);
        return result;
    }
    
    const char *test_message = "This is a test message for hybrid encryption using both classical and post-quantum cryptography.";
    size_t message_len = strlen(test_message);
    
    uint8_t ciphertext[2048];
    uint8_t decrypted[256];
    size_t ciphertext_len = sizeof(ciphertext);
    size_t decrypted_len = sizeof(decrypted);
    
    // Test hybrid encryption
    result = lqx10_hybrid_encrypt(&hybrid_keys, (uint8_t*)test_message, message_len,
                                  ciphertext, &ciphertext_len);
    if (result != LQX10_SUCCESS) {
        printf("Hybrid encryption failed: %d\n", result);
        return result;
    }
    
    // Test hybrid decryption
    result = lqx10_hybrid_decrypt(&hybrid_keys, ciphertext, ciphertext_len,
                                  decrypted, &decrypted_len);
    if (result != LQX10_SUCCESS) {
        printf("Hybrid decryption failed: %d\n", result);
        return result;
    }
    
    // Verify round-trip
    if (decrypted_len != message_len || memcmp(test_message, decrypted, message_len) != 0) {
        printf("Hybrid crypto round-trip verification failed\n");
        return LQX10_ERROR_CRYPTO_FAILURE;
    }
    
    printf("✓ Hybrid cryptography functionality test passed\n");
    return LQX10_SUCCESS;
}

static lqx10_error_t test_entropy_functionality(void) {
    printf("Testing Entropy management functionality...\n");
    
    lqx10_entropy_state_t entropy_ctx;
    
    // Initialize entropy context
    lqx10_error_t result = lqx10_entropy_init(&entropy_ctx);
    if (result != LQX10_SUCCESS) {
        printf("Entropy initialization failed: %d\n", result);
        return result;
    }
    
    // Test entropy extraction
    uint8_t random_data1[64];
    uint8_t random_data2[64];
    
    result = lqx10_entropy_extract(&entropy_ctx, random_data1, sizeof(random_data1));
    if (result != LQX10_SUCCESS) {
        printf("First entropy extraction failed: %d\n", result);
        return result;
    }
    
    result = lqx10_entropy_extract(&entropy_ctx, random_data2, sizeof(random_data2));
    if (result != LQX10_SUCCESS) {
        printf("Second entropy extraction failed: %d\n", result);
        return result;
    }
    
    // Verify randomness (should be different)
    bool data_equal;
    result = lqx10_constant_time_compare(random_data1, random_data2, sizeof(random_data1), &data_equal);
    if (result != LQX10_SUCCESS) {
        printf("Entropy comparison failed: %d\n", result);
        return result;
    }
    
    if (data_equal) {
        printf("Entropy extraction produced identical outputs (very unlikely)\n");
        return LQX10_ERROR_ENTROPY_FAILURE;
    }
    
    printf("✓ Entropy management functionality test passed\n");
    return LQX10_SUCCESS;
}

// =================== PERFORMANCE BENCHMARKS ===================

static lqx10_error_t benchmark_aes_encryption(lqx10_perf_result_t *result) {
    const uint8_t key[32] = {0}; // Zero key for benchmark
    const uint8_t iv[16] = {0};  // Zero IV for benchmark
    
    uint8_t *plaintext = malloc(LARGE_DATA_SIZE);
    uint8_t *ciphertext = malloc(LARGE_DATA_SIZE + 32); // Extra space for padding
    
    if (!plaintext || !ciphertext) {
        free(plaintext);
        free(ciphertext);
        return LQX10_ERROR_MEMORY_ALLOCATION;
    }
    
    // Fill plaintext with test data
    for (size_t i = 0; i < LARGE_DATA_SIZE; i++) {
        plaintext[i] = (uint8_t)(i & 0xff);
    }
    
    // Warmup
    for (int i = 0; i < BENCHMARK_WARMUP; i++) {
        size_t ciphertext_len = LARGE_DATA_SIZE + 32;
        lqx10_aes_encrypt_pure(key, iv, plaintext, LARGE_DATA_SIZE, ciphertext, &ciphertext_len);
    }
    
    // Benchmark
    uint64_t start_time = get_time_microseconds();
    
    for (int i = 0; i < PERFORMANCE_ITERATIONS; i++) {
        size_t ciphertext_len = LARGE_DATA_SIZE + 32;
        lqx10_error_t res = lqx10_aes_encrypt_pure(key, iv, plaintext, LARGE_DATA_SIZE, 
                                                   ciphertext, &ciphertext_len);
        if (res != LQX10_SUCCESS) {
            free(plaintext);
            free(ciphertext);
            return res;
        }
    }
    
    uint64_t end_time = get_time_microseconds();
    
    result->test_name = "AES-256 Encryption";
    result->total_time_us = end_time - start_time;
    result->iterations = PERFORMANCE_ITERATIONS;
    result->data_size = LARGE_DATA_SIZE;
    result->throughput_mbps = ((double)LARGE_DATA_SIZE * PERFORMANCE_ITERATIONS * 8.0) / 
                             (result->total_time_us * 1.048576); // Convert to Mbps
    
    free(plaintext);
    free(ciphertext);
    return LQX10_SUCCESS;
}

static lqx10_error_t benchmark_sha256_hash(lqx10_perf_result_t *result) {
    uint8_t *input_data = malloc(LARGE_DATA_SIZE);
    uint8_t hash_output[32];
    
    if (!input_data) {
        return LQX10_ERROR_MEMORY_ALLOCATION;
    }
    
    // Fill input with test data
    for (size_t i = 0; i < LARGE_DATA_SIZE; i++) {
        input_data[i] = (uint8_t)(i & 0xff);
    }
    
    // Warmup
    for (int i = 0; i < BENCHMARK_WARMUP; i++) {
        lqx10_sha256_hash(input_data, LARGE_DATA_SIZE, hash_output);
    }
    
    // Benchmark
    uint64_t start_time = get_time_microseconds();
    
    for (int i = 0; i < PERFORMANCE_ITERATIONS; i++) {
        lqx10_error_t res = lqx10_sha256_hash(input_data, LARGE_DATA_SIZE, hash_output);
        if (res != LQX10_SUCCESS) {
            free(input_data);
            return res;
        }
    }
    
    uint64_t end_time = get_time_microseconds();
    
    result->test_name = "SHA-256 Hashing";
    result->total_time_us = end_time - start_time;
    result->iterations = PERFORMANCE_ITERATIONS;
    result->data_size = LARGE_DATA_SIZE;
    result->throughput_mbps = ((double)LARGE_DATA_SIZE * PERFORMANCE_ITERATIONS * 8.0) / 
                             (result->total_time_us * 1.048576);
    
    free(input_data);
    return LQX10_SUCCESS;
}

static lqx10_error_t benchmark_blake3_hash(lqx10_perf_result_t *result) {
    uint8_t *input_data = malloc(LARGE_DATA_SIZE);
    uint8_t hash_output[32];
    
    if (!input_data) {
        return LQX10_ERROR_MEMORY_ALLOCATION;
    }
    
    // Fill input with test data
    for (size_t i = 0; i < LARGE_DATA_SIZE; i++) {
        input_data[i] = (uint8_t)(i & 0xff);
    }
    
    // Warmup
    for (int i = 0; i < BENCHMARK_WARMUP; i++) {
        lqx10_blake3_hash_pure(input_data, LARGE_DATA_SIZE, hash_output, 32);
    }
    
    // Benchmark
    uint64_t start_time = get_time_microseconds();
    
    for (int i = 0; i < PERFORMANCE_ITERATIONS; i++) {
        lqx10_error_t res = lqx10_blake3_hash_pure(input_data, LARGE_DATA_SIZE, hash_output, 32);
        if (res != LQX10_SUCCESS) {
            free(input_data);
            return res;
        }
    }
    
    uint64_t end_time = get_time_microseconds();
    
    result->test_name = "BLAKE3 Hashing";
    result->total_time_us = end_time - start_time;
    result->iterations = PERFORMANCE_ITERATIONS;
    result->data_size = LARGE_DATA_SIZE;
    result->throughput_mbps = ((double)LARGE_DATA_SIZE * PERFORMANCE_ITERATIONS * 8.0) / 
                             (result->total_time_us * 1.048576);
    
    free(input_data);
    return LQX10_SUCCESS;
}

static lqx10_error_t benchmark_kyber_operations(lqx10_perf_result_t *result) {
    uint8_t public_key[LQX10_KYBER_PUBLIC_KEY_SIZE];
    uint8_t secret_key[LQX10_KYBER_SECRET_KEY_SIZE];
    uint8_t ciphertext[LQX10_KYBER_CIPHERTEXT_SIZE];
    uint8_t shared_secret[LQX10_KYBER_SHARED_SECRET_SIZE];
    
    // Generate keys once
    lqx10_error_t res = lqx10_kyber_keygen_pure(public_key, secret_key);
    if (res != LQX10_SUCCESS) {
        return res;
    }
    
    // Warmup
    for (int i = 0; i < BENCHMARK_WARMUP; i++) {
        lqx10_kyber_encaps_pure(public_key, ciphertext, shared_secret);
    }
    
    // Benchmark encapsulation
    uint64_t start_time = get_time_microseconds();
    
    for (int i = 0; i < PERFORMANCE_ITERATIONS; i++) {
        res = lqx10_kyber_encaps_pure(public_key, ciphertext, shared_secret);
        if (res != LQX10_SUCCESS) {
            return res;
        }
    }
    
    uint64_t end_time = get_time_microseconds();
    
    result->test_name = "Kyber-512 Encapsulation";
    result->total_time_us = end_time - start_time;
    result->iterations = PERFORMANCE_ITERATIONS;
    result->data_size = 0; // Not applicable for PQ crypto
    result->throughput_mbps = 0; // Operations per second instead
    
    return LQX10_SUCCESS;
}

// =================== MAIN TEST RUNNER ===================

lqx10_error_t lqx10_run_comprehensive_tests(void) {
    printf("=== LQX-10 Cryptographic Primitive Comprehensive Test Suite ===\n\n");
    
    // Run cryptographic self-tests first
    printf("Running built-in cryptographic self-tests...\n");
    lqx10_error_t result = lqx10_crypto_selftest();
    if (result != LQX10_SUCCESS) {
        printf("❌ Built-in self-tests failed: %d\n", result);
        return result;
    }
    printf("✓ Built-in self-tests passed\n\n");
    
    // Run functionality tests
    printf("=== Functionality Tests ===\n");
    
    result = test_aes_functionality();
    if (result != LQX10_SUCCESS) return result;
    
    result = test_post_quantum_functionality();
    if (result != LQX10_SUCCESS) return result;
    
    result = test_hybrid_crypto_functionality();
    if (result != LQX10_SUCCESS) return result;
    
    result = test_entropy_functionality();
    if (result != LQX10_SUCCESS) return result;
    
    printf("\n=== Performance Benchmarks ===\n");
    printf("Running %d iterations with %dMB data size...\n\n", PERFORMANCE_ITERATIONS, LARGE_DATA_SIZE / (1024*1024));
    
    lqx10_perf_result_t perf_result;
    
    // AES Encryption Benchmark
    result = benchmark_aes_encryption(&perf_result);
    if (result != LQX10_SUCCESS) {
        printf("AES encryption benchmark failed: %d\n", result);
        return result;
    }
    print_perf_result(&perf_result);
    
    // SHA-256 Benchmark
    result = benchmark_sha256_hash(&perf_result);
    if (result != LQX10_SUCCESS) {
        printf("SHA-256 benchmark failed: %d\n", result);
        return result;
    }
    print_perf_result(&perf_result);
    
    // BLAKE3 Benchmark
    result = benchmark_blake3_hash(&perf_result);
    if (result != LQX10_SUCCESS) {
        printf("BLAKE3 benchmark failed: %d\n", result);
        return result;
    }
    print_perf_result(&perf_result);
    
    // Kyber Benchmark
    result = benchmark_kyber_operations(&perf_result);
    if (result != LQX10_SUCCESS) {
        printf("Kyber benchmark failed: %d\n", result);
        return result;
    }
    
    // Print special result for Kyber (ops/sec instead of throughput)
    double avg_time_us = (double)perf_result.total_time_us / perf_result.iterations;
    double ops_per_sec = 1000000.0 / avg_time_us;
    printf("%-30s: %8.2f µs/op, %8.0f ops/sec\n", 
           perf_result.test_name, avg_time_us, ops_per_sec);
    
    printf("\n=== All Tests Completed Successfully ===\n");
    printf("✓ LQX-10 Cryptographic Primitive is ready for production deployment\n");
    
    return LQX10_SUCCESS;
} 