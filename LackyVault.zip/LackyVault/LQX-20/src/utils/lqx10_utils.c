#include "../../include/lqx10_utils.h"
#include "../../include/lqx10_crypto.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <stdarg.h>

#ifdef _WIN32
#include <windows.h>
#include <intrin.h>
#include <psapi.h>
#include <tlhelp32.h>
#pragma comment(lib, "psapi.lib")
#else
#include <sys/time.h>
#include <sys/sysinfo.h>
#include <unistd.h>
#include <dlfcn.h>
#endif

// Global state for utilities
static FILE *g_log_file = NULL;
static lqx10_log_level_t g_log_level = LQX10_LOG_INFO;
static lqx10_memory_pool_t *g_secure_pool = NULL;
static uint64_t g_benchmark_start_time = 0;

// Internal helper functions
static uint64_t get_nanoseconds(void);
static bool is_debugger_present_advanced(void);
static bool is_virtual_machine(void);
static uint32_t calculate_crc32(const uint8_t *data, size_t len);

// Hex encoding
lqx10_error_t lqx10_hex_encode(const uint8_t *input, size_t input_len,
                               char *output, size_t *output_len) {
    if (!input || !output || !output_len || input_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t required_len = input_len * 2 + 1; // +1 for null terminator
    if (*output_len < required_len) {
        *output_len = required_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    const char hex_chars[] = "0123456789ABCDEF";
    for (size_t i = 0; i < input_len; i++) {
        output[i * 2] = hex_chars[(input[i] >> 4) & 0x0F];
        output[i * 2 + 1] = hex_chars[input[i] & 0x0F];
    }
    output[input_len * 2] = '\0';
    *output_len = required_len;
    
    return LQX10_SUCCESS;
}

// Hex decoding
lqx10_error_t lqx10_hex_decode(const char *input, size_t input_len,
                               uint8_t *output, size_t *output_len) {
    if (!input || !output || !output_len || input_len == 0 || input_len % 2 != 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t required_len = input_len / 2;
    if (*output_len < required_len) {
        *output_len = required_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    for (size_t i = 0; i < input_len; i += 2) {
        char hex_byte[3] = {input[i], input[i + 1], '\0'};
        output[i / 2] = (uint8_t)strtol(hex_byte, NULL, 16);
    }
    *output_len = required_len;
    
    return LQX10_SUCCESS;
}

// Base64 encoding
lqx10_error_t lqx10_base64_encode(const uint8_t *input, size_t input_len,
                                  char *output, size_t *output_len) {
    if (!input || !output || !output_len || input_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    const char base64_chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    size_t required_len = ((input_len + 2) / 3) * 4 + 1; // +1 for null terminator
    
    if (*output_len < required_len) {
        *output_len = required_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    size_t output_pos = 0;
    for (size_t i = 0; i < input_len; i += 3) {
        uint32_t triple = (input[i] << 16);
        if (i + 1 < input_len) triple |= (input[i + 1] << 8);
        if (i + 2 < input_len) triple |= input[i + 2];
        
        output[output_pos++] = base64_chars[(triple >> 18) & 0x3F];
        output[output_pos++] = base64_chars[(triple >> 12) & 0x3F];
        output[output_pos++] = (i + 1 < input_len) ? base64_chars[(triple >> 6) & 0x3F] : '=';
        output[output_pos++] = (i + 2 < input_len) ? base64_chars[triple & 0x3F] : '=';
    }
    output[output_pos] = '\0';
    *output_len = required_len;
    
    return LQX10_SUCCESS;
}

// Memory pool creation
lqx10_error_t lqx10_memory_pool_create(lqx10_memory_pool_t **pool, size_t pool_size) {
    if (!pool || pool_size == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    lqx10_memory_pool_t *new_pool = malloc(sizeof(lqx10_memory_pool_t));
    if (!new_pool) {
        return LQX10_ERROR_MEMORY_ALLOCATION;
    }
    
    new_pool->pool_memory = malloc(pool_size);
    if (!new_pool->pool_memory) {
        free(new_pool);
        return LQX10_ERROR_MEMORY_ALLOCATION;
    }
    
    new_pool->pool_size = pool_size;
    new_pool->used_size = 0;
    new_pool->allocation_count = 0;
    new_pool->is_locked = false;
    
    // Lock memory to prevent swapping
#ifdef _WIN32
    if (VirtualLock(new_pool->pool_memory, pool_size)) {
        new_pool->is_locked = true;
    }
#else
    if (mlock(new_pool->pool_memory, pool_size) == 0) {
        new_pool->is_locked = true;
    }
#endif
    
    *pool = new_pool;
    return LQX10_SUCCESS;
}

// Memory pool destruction
lqx10_error_t lqx10_memory_pool_destroy(lqx10_memory_pool_t *pool) {
    if (!pool) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Securely zero memory before freeing
    lqx10_secure_memzero(pool->pool_memory, pool->pool_size);
    
    // Unlock memory if it was locked
    if (pool->is_locked) {
#ifdef _WIN32
        VirtualUnlock(pool->pool_memory, pool->pool_size);
#else
        munlock(pool->pool_memory, pool->pool_size);
#endif
    }
    
    free(pool->pool_memory);
    free(pool);
    
    return LQX10_SUCCESS;
}

// High-resolution time
lqx10_error_t lqx10_get_high_resolution_time(uint64_t *time_ns) {
    if (!time_ns) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    *time_ns = get_nanoseconds();
    return LQX10_SUCCESS;
}

// Benchmark start
lqx10_error_t lqx10_benchmark_start(const char *operation_name) {
    if (!operation_name) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    g_benchmark_start_time = get_nanoseconds();
    return LQX10_SUCCESS;
}

// Benchmark end
lqx10_error_t lqx10_benchmark_end(const char *operation_name, 
                                  size_t bytes_processed,
                                  lqx10_benchmark_result_t *result) {
    if (!operation_name || !result) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    uint64_t end_time = get_nanoseconds();
    uint64_t elapsed_ns = end_time - g_benchmark_start_time;
    
    result->operation_name = operation_name;
    result->operations_performed = 1;
    result->total_time_seconds = elapsed_ns / 1e9;
    result->operations_per_second = 1.0 / result->total_time_seconds;
    result->average_time_per_operation = result->total_time_seconds;
    result->bytes_processed = bytes_processed;
    result->throughput_mbps = (bytes_processed / (1024.0 * 1024.0)) / result->total_time_seconds;
    
    return LQX10_SUCCESS;
}

// Logging initialization
lqx10_error_t lqx10_log_init(const char *log_file_path, lqx10_log_level_t min_level) {
    if (g_log_file) {
        fclose(g_log_file);
    }
    
    if (log_file_path) {
        g_log_file = fopen(log_file_path, "a");
        if (!g_log_file) {
            return LQX10_ERROR_CRYPTO_FAILURE;
        }
    }
    
    g_log_level = min_level;
    return LQX10_SUCCESS;
}

// Log message
lqx10_error_t lqx10_log_message(lqx10_log_level_t level, const char *format, ...) {
    if (!format || level < g_log_level) {
        return LQX10_SUCCESS;
    }
    
    const char *level_strings[] = {"TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL"};
    FILE *output = g_log_file ? g_log_file : stdout;
    
    // Get current time
    time_t now = time(NULL);
    char time_str[64];
    strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", localtime(&now));
    
    // Format message
    fprintf(output, "[%s] [%s] ", time_str, level_strings[level]);
    
    va_list args;
    va_start(args, format);
    vfprintf(output, format, args);
    va_end(args);
    
    fprintf(output, "\n");
    fflush(output);
    
    return LQX10_SUCCESS;
}

// Security check
lqx10_error_t lqx10_security_check(lqx10_security_status_t *status) {
    if (!status) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    status->debugger_detected = is_debugger_present_advanced();
    status->vm_detected = is_virtual_machine();
    status->analysis_tools_detected = false; // Simplified for now
    status->integrity_hash = 0; // Would calculate actual hash
    status->runtime_checksum = get_nanoseconds(); // Use time as checksum
    
    return LQX10_SUCCESS;
}

// Generate UUID
lqx10_error_t lqx10_generate_uuid(char *uuid_str, size_t uuid_str_len) {
    if (!uuid_str || uuid_str_len < 37) { // UUID string is 36 chars + null terminator
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    uint8_t uuid_bytes[16];
    lqx10_error_t result = lqx10_secure_random_bytes(uuid_bytes, 16);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Set version (4) and variant bits
    uuid_bytes[6] = (uuid_bytes[6] & 0x0F) | 0x40; // Version 4
    uuid_bytes[8] = (uuid_bytes[8] & 0x3F) | 0x80; // Variant bits
    
    snprintf(uuid_str, uuid_str_len, 
             "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x",
             uuid_bytes[0], uuid_bytes[1], uuid_bytes[2], uuid_bytes[3],
             uuid_bytes[4], uuid_bytes[5], uuid_bytes[6], uuid_bytes[7],
             uuid_bytes[8], uuid_bytes[9], uuid_bytes[10], uuid_bytes[11],
             uuid_bytes[12], uuid_bytes[13], uuid_bytes[14], uuid_bytes[15]);
    
    return LQX10_SUCCESS;
}

// Internal helper functions
static uint64_t get_nanoseconds(void) {
#ifdef _WIN32
    LARGE_INTEGER frequency, counter;
    QueryPerformanceFrequency(&frequency);
    QueryPerformanceCounter(&counter);
    return (counter.QuadPart * 1000000000ULL) / frequency.QuadPart;
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000000000ULL + ts.tv_nsec;
#endif
}

static bool is_debugger_present_advanced(void) {
#ifdef _WIN32
    // Multiple debugger detection methods
    if (IsDebuggerPresent()) return true;
    
    // Check PEB
    BOOL remote_debugger = FALSE;
    CheckRemoteDebuggerPresent(GetCurrentProcess(), &remote_debugger);
    if (remote_debugger) return true;
    
    // Timing check
    uint64_t start = get_nanoseconds();
    Sleep(1);
    uint64_t end = get_nanoseconds();
    if ((end - start) > 10000000) return true; // More than 10ms for 1ms sleep
    
    return false;
#else
    // Linux debugger detection would go here
    return false;
#endif
}

static bool is_virtual_machine(void) {
#ifdef _WIN32
    // Check for VM artifacts
    HKEY hkey;
    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, "HARDWARE\\DESCRIPTION\\System", 0, KEY_READ, &hkey) == ERROR_SUCCESS) {
        char system_bios[256];
        DWORD size = sizeof(system_bios);
        if (RegQueryValueEx(hkey, "SystemBiosVersion", NULL, NULL, (LPBYTE)system_bios, &size) == ERROR_SUCCESS) {
            if (strstr(system_bios, "VBOX") || strstr(system_bios, "VirtualBox") || 
                strstr(system_bios, "VMware") || strstr(system_bios, "QEMU")) {
                RegCloseKey(hkey);
                return true;
            }
        }
        RegCloseKey(hkey);
    }
    return false;
#else
    // Linux VM detection would go here
    return false;
#endif
}

static uint32_t calculate_crc32(const uint8_t *data, size_t len) {
    uint32_t crc = 0xFFFFFFFF;
    static uint32_t crc_table[256];
    static bool table_generated = false;
    
    // Generate CRC table if not done yet
    if (!table_generated) {
        for (uint32_t i = 0; i < 256; i++) {
            uint32_t c = i;
            for (int j = 0; j < 8; j++) {
                if (c & 1) {
                    c = 0xEDB88320 ^ (c >> 1);
                } else {
                    c = c >> 1;
                }
            }
            crc_table[i] = c;
        }
        table_generated = true;
    }
    
    // Calculate CRC
    for (size_t i = 0; i < len; i++) {
        crc = crc_table[(crc ^ data[i]) & 0xFF] ^ (crc >> 8);
    }
    
    return crc ^ 0xFFFFFFFF;
}
