/**
 * @file hex.c
 * @brief Hexadecimal Encoding/Decoding Implementation
 * 
 * Efficient hexadecimal string conversion utilities for LQX-10.
 * Zero-dependency implementation for data representation.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../../include/lqx10_utils.h"
#include <string.h>
#include <ctype.h>

// Hex encoding table (lowercase)
static const char hex_encode_table_lower[] = "0123456789abcdef";

// Hex encoding table (uppercase)
static const char hex_encode_table_upper[] = "0123456789ABCDEF";

// Convert hex character to value
static int hex_char_to_value(char c) {
    if (c >= '0' && c <= '9') {
        return c - '0';
    } else if (c >= 'a' && c <= 'f') {
        return c - 'a' + 10;
    } else if (c >= 'A' && c <= 'F') {
        return c - 'A' + 10;
    }
    return -1; // Invalid hex character
}

// Calculate hex encoded length
size_t lqx10_hex_encode_length(size_t input_len) {
    return input_len * 2;
}

// Calculate hex decoded length
size_t lqx10_hex_decode_length(size_t input_len) {
    return input_len / 2;
}

// Hex encode (lowercase)
lqx10_error_t lqx10_hex_encode(const uint8_t* input, size_t input_len,
                               char* output, size_t* output_len) {
    if (!input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t required_len = lqx10_hex_encode_length(input_len);
    if (*output_len < required_len + 1) { // +1 for null terminator
        *output_len = required_len + 1;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    for (size_t i = 0; i < input_len; i++) {
        output[i * 2] = hex_encode_table_lower[(input[i] >> 4) & 0x0F];
        output[i * 2 + 1] = hex_encode_table_lower[input[i] & 0x0F];
    }
    
    output[required_len] = '\0';
    *output_len = required_len;
    return LQX10_SUCCESS;
}

// Hex encode (uppercase)
lqx10_error_t lqx10_hex_encode_upper(const uint8_t* input, size_t input_len,
                                     char* output, size_t* output_len) {
    if (!input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t required_len = lqx10_hex_encode_length(input_len);
    if (*output_len < required_len + 1) { // +1 for null terminator
        *output_len = required_len + 1;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    for (size_t i = 0; i < input_len; i++) {
        output[i * 2] = hex_encode_table_upper[(input[i] >> 4) & 0x0F];
        output[i * 2 + 1] = hex_encode_table_upper[input[i] & 0x0F];
    }
    
    output[required_len] = '\0';
    *output_len = required_len;
    return LQX10_SUCCESS;
}

// Hex decode
lqx10_error_t lqx10_hex_decode(const char* input, size_t input_len,
                               uint8_t* output, size_t* output_len) {
    if (!input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Input length must be even
    if (input_len % 2 != 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t required_len = lqx10_hex_decode_length(input_len);
    if (*output_len < required_len) {
        *output_len = required_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    for (size_t i = 0; i < input_len; i += 2) {
        int high_nibble = hex_char_to_value(input[i]);
        int low_nibble = hex_char_to_value(input[i + 1]);
        
        if (high_nibble == -1 || low_nibble == -1) {
            return LQX10_ERROR_INVALID_PARAM;
        }
        
        output[i / 2] = (uint8_t)((high_nibble << 4) | low_nibble);
    }
    
    *output_len = required_len;
    return LQX10_SUCCESS;
}

// Hex encode with separator
lqx10_error_t lqx10_hex_encode_separated(const uint8_t* input, size_t input_len,
                                         char separator, char* output, size_t* output_len) {
    if (!input || !output || !output_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (input_len == 0) {
        if (*output_len < 1) {
            *output_len = 1;
            return LQX10_ERROR_BUFFER_TOO_SMALL;
        }
        output[0] = '\0';
        *output_len = 0;
        return LQX10_SUCCESS;
    }
    
    size_t required_len = input_len * 2 + (input_len - 1); // 2 chars per byte + separators
    if (*output_len < required_len + 1) { // +1 for null terminator
        *output_len = required_len + 1;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    size_t output_pos = 0;
    for (size_t i = 0; i < input_len; i++) {
        if (i > 0) {
            output[output_pos++] = separator;
        }
        output[output_pos++] = hex_encode_table_lower[(input[i] >> 4) & 0x0F];
        output[output_pos++] = hex_encode_table_lower[input[i] & 0x0F];
    }
    
    output[output_pos] = '\0';
    *output_len = output_pos;
    return LQX10_SUCCESS;
}

// Validate hex string
bool lqx10_hex_is_valid(const char* input, size_t input_len) {
    if (!input || input_len % 2 != 0) {
        return false;
    }
    
    for (size_t i = 0; i < input_len; i++) {
        if (hex_char_to_value(input[i]) == -1) {
            return false;
        }
    }
    
    return true;
}

// Compare hex strings (constant time)
bool lqx10_hex_compare_constant_time(const char* hex1, const char* hex2, size_t len) {
    if (!hex1 || !hex2) {
        return false;
    }
    
    int result = 0;
    for (size_t i = 0; i < len; i++) {
        result |= (hex1[i] ^ hex2[i]);
    }
    
    return result == 0;
}

// Convert single byte to hex
void lqx10_byte_to_hex(uint8_t byte, char output[3]) {
    output[0] = hex_encode_table_lower[(byte >> 4) & 0x0F];
    output[1] = hex_encode_table_lower[byte & 0x0F];
    output[2] = '\0';
}

// Convert hex pair to byte
lqx10_error_t lqx10_hex_to_byte(const char hex[2], uint8_t* byte) {
    if (!hex || !byte) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    int high_nibble = hex_char_to_value(hex[0]);
    int low_nibble = hex_char_to_value(hex[1]);
    
    if (high_nibble == -1 || low_nibble == -1) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    *byte = (uint8_t)((high_nibble << 4) | low_nibble);
    return LQX10_SUCCESS;
}
