#include "../../include/lqx10_crypto.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
#include <bcrypt.h>
#include <wincrypt.h>
#include <intrin.h>
#pragma comment(lib, "bcrypt.lib")
#pragma comment(lib, "advapi32.lib")
#else
#include <openssl/evp.h>
#include <openssl/kdf.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <sys/random.h>
#include <sys/time.h>
#ifdef __linux__
#include <sys/mman.h>
#include <sys/syscall.h>
#endif
#include <unistd.h>
#include <fcntl.h>
#endif

// ChaCha20 implementation constants
#define CHACHA20_BLOCK_SIZE 64
#define CHACHA20_KEY_SIZE 32
#define CHACHA20_NONCE_SIZE 12

// BLAKE3 implementation (simplified)
#define BLAKE3_BLOCK_SIZE 64
#define BLAKE3_OUT_SIZE 32

// Post-quantum crypto simulation constants (would use liboqs in production)
#define KYBER_SIMULATION_FACTOR 1024
#define DILITHIUM_SIMULATION_FACTOR 2048

// =================== MISSING CONSTANTS ===================
#define LQX10_AES_IV_SIZE 16
#define LQX10_CHACHA20_NONCE_SIZE 12
#define LQX10_HKDF_EXTRACT_SIZE 32

// =================== PURE CRYPTO WRAPPER FUNCTIONS ===================

// Use external pure implementations
extern lqx10_error_t lqx10_aes_encrypt_pure(const uint8_t *key, const uint8_t *iv,
                                             const uint8_t *plaintext, size_t plaintext_len,
                                             uint8_t *ciphertext, size_t *ciphertext_len);

extern lqx10_error_t lqx10_aes_decrypt_pure(const uint8_t *key, const uint8_t *iv,
                                             const uint8_t *ciphertext, size_t ciphertext_len,
                                             uint8_t *plaintext, size_t *plaintext_len);

extern lqx10_error_t lqx10_blake3_hash_pure(const uint8_t *input, size_t input_len,
                                             uint8_t *output, size_t output_len);

extern lqx10_error_t lqx10_sha256_hash(const uint8_t *input, size_t input_len, uint8_t *output);

extern lqx10_error_t lqx10_hmac_sha256(const uint8_t *key, size_t key_len,
                                        const uint8_t *data, size_t data_len, uint8_t *output);

extern lqx10_error_t lqx10_pbkdf2_sha256(const uint8_t *password, size_t password_len,
                                          const uint8_t *salt, size_t salt_len,
                                          uint32_t iterations, uint8_t *output, size_t output_len);

extern lqx10_error_t lqx10_secure_random_bytes_pure(uint8_t *output, size_t output_len);

extern lqx10_error_t lqx10_secure_memzero_pure(void *ptr, size_t len);

// Post-quantum implementations
extern lqx10_error_t lqx10_kyber_keygen_pure(uint8_t *public_key, uint8_t *secret_key);
extern lqx10_error_t lqx10_kyber_encaps_pure(const uint8_t *public_key, uint8_t *ciphertext, uint8_t *shared_secret);
extern lqx10_error_t lqx10_kyber_decaps_pure(const uint8_t *secret_key, const uint8_t *ciphertext, uint8_t *shared_secret);
extern lqx10_error_t lqx10_dilithium_keygen_pure(uint8_t *public_key, uint8_t *secret_key);
extern lqx10_error_t lqx10_dilithium_sign_pure(const uint8_t *secret_key, const uint8_t *message,
                                                size_t message_len, uint8_t *signature, size_t *signature_len);
extern lqx10_error_t lqx10_dilithium_verify_pure(const uint8_t *public_key, const uint8_t *message,
                                                  size_t message_len, const uint8_t *signature, size_t signature_len);

// =================== CHACHA20 PURE IMPLEMENTATION ===================

static void chacha20_quarter_round(uint32_t *a, uint32_t *b, uint32_t *c, uint32_t *d) {
    *a += *b; *d ^= *a; *d = (*d << 16) | (*d >> 16);
    *c += *d; *b ^= *c; *b = (*b << 12) | (*b >> 20);
    *a += *b; *d ^= *a; *d = (*d << 8) | (*d >> 24);
    *c += *d; *b ^= *c; *b = (*b << 7) | (*b >> 25);
}

static void chacha20_block(const uint8_t *key, const uint8_t *nonce, uint32_t counter, uint8_t *output) {
    uint32_t state[16];
    
    // Constants
    state[0] = 0x61707865;
    state[1] = 0x3320646e;
    state[2] = 0x79622d32;
    state[3] = 0x6b206574;
    
    // Key
    for (int i = 0; i < 8; i++) {
        state[4 + i] = ((uint32_t)key[i * 4]) |
                       ((uint32_t)key[i * 4 + 1] << 8) |
                       ((uint32_t)key[i * 4 + 2] << 16) |
                       ((uint32_t)key[i * 4 + 3] << 24);
    }
    
    // Counter
    state[12] = counter;
    
    // Nonce
    for (int i = 0; i < 3; i++) {
        state[13 + i] = ((uint32_t)nonce[i * 4]) |
                        ((uint32_t)nonce[i * 4 + 1] << 8) |
                        ((uint32_t)nonce[i * 4 + 2] << 16) |
                        ((uint32_t)nonce[i * 4 + 3] << 24);
    }
    
    uint32_t working_state[16];
    memcpy(working_state, state, sizeof(state));
    
    // 20 rounds
    for (int i = 0; i < 10; i++) {
        // Column rounds
        chacha20_quarter_round(&working_state[0], &working_state[4], &working_state[8], &working_state[12]);
        chacha20_quarter_round(&working_state[1], &working_state[5], &working_state[9], &working_state[13]);
        chacha20_quarter_round(&working_state[2], &working_state[6], &working_state[10], &working_state[14]);
        chacha20_quarter_round(&working_state[3], &working_state[7], &working_state[11], &working_state[15]);
        
        // Diagonal rounds
        chacha20_quarter_round(&working_state[0], &working_state[5], &working_state[10], &working_state[15]);
        chacha20_quarter_round(&working_state[1], &working_state[6], &working_state[11], &working_state[12]);
        chacha20_quarter_round(&working_state[2], &working_state[7], &working_state[8], &working_state[13]);
        chacha20_quarter_round(&working_state[3], &working_state[4], &working_state[9], &working_state[14]);
    }
    
    // Add original state
    for (int i = 0; i < 16; i++) {
        working_state[i] += state[i];
    }
    
    // Output little-endian
    for (int i = 0; i < 16; i++) {
        output[i * 4] = working_state[i] & 0xff;
        output[i * 4 + 1] = (working_state[i] >> 8) & 0xff;
        output[i * 4 + 2] = (working_state[i] >> 16) & 0xff;
        output[i * 4 + 3] = (working_state[i] >> 24) & 0xff;
    }
}

lqx10_error_t lqx10_chacha20_encrypt(const uint8_t *key, const uint8_t *nonce, uint32_t counter,
                                      const uint8_t *plaintext, size_t plaintext_len, uint8_t *ciphertext) {
    if (!key || !nonce || !plaintext || !ciphertext || plaintext_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    uint8_t keystream[64];
    size_t blocks = (plaintext_len + 63) / 64;
    
    for (size_t i = 0; i < blocks; i++) {
        chacha20_block(key, nonce, counter + i, keystream);
        
        size_t block_len = (i == blocks - 1) ? (plaintext_len - i * 64) : 64;
        
        for (size_t j = 0; j < block_len; j++) {
            ciphertext[i * 64 + j] = plaintext[i * 64 + j] ^ keystream[j];
        }
    }
    
    lqx10_secure_memzero_pure(keystream, sizeof(keystream));
    return LQX10_SUCCESS;
}

lqx10_error_t lqx10_chacha20_decrypt(const uint8_t *key, const uint8_t *nonce, uint32_t counter,
                                      const uint8_t *ciphertext, size_t ciphertext_len, uint8_t *plaintext) {
    // ChaCha20 decryption is identical to encryption
    return lqx10_chacha20_encrypt(key, nonce, counter, ciphertext, ciphertext_len, plaintext);
}

// =================== HYBRID CRYPTOGRAPHY IMPLEMENTATION ===================

lqx10_error_t lqx10_hybrid_keygen(lqx10_hybrid_keys_t *hybrid_key) {
    if (!hybrid_key) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    memset(hybrid_key, 0, sizeof(lqx10_hybrid_keys_t));
    
    // Generate classical key
    lqx10_error_t result = lqx10_secure_random_bytes_pure(hybrid_key->classical_key, LQX10_AES_KEY_SIZE);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Generate post-quantum key pair
    result = lqx10_kyber_keygen_pure(hybrid_key->pq_public_key, hybrid_key->pq_secret_key);
    if (result != LQX10_SUCCESS) {
        lqx10_secure_memzero_pure(hybrid_key, sizeof(lqx10_hybrid_keys_t));
        return result;
    }
    
    hybrid_key->keys_generated = true;
    return LQX10_SUCCESS;
}

lqx10_error_t lqx10_hybrid_encrypt(const lqx10_hybrid_keys_t *public_key, const uint8_t *plaintext,
                                   size_t plaintext_len, uint8_t *ciphertext, size_t *ciphertext_len) {
    if (!public_key || !plaintext || !ciphertext || !ciphertext_len || plaintext_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t required_len = LQX10_KYBER_CIPHERTEXT_SIZE + LQX10_AES_IV_SIZE + 
                         ((plaintext_len + 15) / 16) * 16; // AES padding
    
    if (*ciphertext_len < required_len) {
        *ciphertext_len = required_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Step 1: Kyber encapsulation
    uint8_t shared_secret[LQX10_KYBER_SHARED_SECRET_SIZE];
    lqx10_error_t result = lqx10_kyber_encaps_pure(public_key->pq_public_key, ciphertext, shared_secret);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Step 2: Derive AES key from shared secret and classical key
    uint8_t salt[32];
    result = lqx10_secure_random_bytes_pure(salt, sizeof(salt));
    if (result != LQX10_SUCCESS) {
        lqx10_secure_memzero_pure(shared_secret, sizeof(shared_secret));
        return result;
    }
    
    uint8_t combined_key[LQX10_KYBER_SHARED_SECRET_SIZE + LQX10_AES_KEY_SIZE];
    memcpy(combined_key, shared_secret, LQX10_KYBER_SHARED_SECRET_SIZE);
    memcpy(combined_key + LQX10_KYBER_SHARED_SECRET_SIZE, public_key->classical_key, LQX10_AES_KEY_SIZE);
    
    uint8_t derived_key[32];
    result = lqx10_pbkdf2_sha256(combined_key, sizeof(combined_key), salt, sizeof(salt), 10000, derived_key, 32);
    if (result != LQX10_SUCCESS) {
        lqx10_secure_memzero_pure(shared_secret, sizeof(shared_secret));
        lqx10_secure_memzero_pure(combined_key, sizeof(combined_key));
        return result;
    }
    
    // Step 3: Generate IV and encrypt with AES
    uint8_t *iv = ciphertext + LQX10_KYBER_CIPHERTEXT_SIZE;
    result = lqx10_secure_random_bytes_pure(iv, LQX10_AES_IV_SIZE);
    if (result != LQX10_SUCCESS) {
        lqx10_secure_memzero_pure(shared_secret, sizeof(shared_secret));
        lqx10_secure_memzero_pure(derived_key, sizeof(derived_key));
        lqx10_secure_memzero_pure(combined_key, sizeof(combined_key));
        return result;
    }
    
    uint8_t *aes_ciphertext = ciphertext + LQX10_KYBER_CIPHERTEXT_SIZE + LQX10_AES_IV_SIZE;
    size_t aes_ciphertext_len = *ciphertext_len - LQX10_KYBER_CIPHERTEXT_SIZE - LQX10_AES_IV_SIZE;
    
    result = lqx10_aes_encrypt_pure(derived_key, iv, plaintext, plaintext_len, 
                                    aes_ciphertext, &aes_ciphertext_len);
    
    if (result == LQX10_SUCCESS) {
        *ciphertext_len = LQX10_KYBER_CIPHERTEXT_SIZE + LQX10_AES_IV_SIZE + aes_ciphertext_len;
    }
    
    // Secure cleanup
    lqx10_secure_memzero_pure(shared_secret, sizeof(shared_secret));
    lqx10_secure_memzero_pure(derived_key, sizeof(derived_key));
    lqx10_secure_memzero_pure(combined_key, sizeof(combined_key));
    
    return result;
}

lqx10_error_t lqx10_hybrid_decrypt(const lqx10_hybrid_keys_t *secret_key, const uint8_t *ciphertext,
                                   size_t ciphertext_len, uint8_t *plaintext, size_t *plaintext_len) {
    if (!secret_key || !ciphertext || !plaintext || !plaintext_len ||
        ciphertext_len < LQX10_KYBER_CIPHERTEXT_SIZE + LQX10_AES_IV_SIZE) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Step 1: Kyber decapsulation
    uint8_t shared_secret[LQX10_KYBER_SHARED_SECRET_SIZE];
    lqx10_error_t result = lqx10_kyber_decaps_pure(secret_key->pq_secret_key, ciphertext, shared_secret);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Step 2: Derive AES key (same process as encryption)
    uint8_t salt[32] = {0}; // In real implementation, salt should be stored with ciphertext
    
    uint8_t combined_key[LQX10_KYBER_SHARED_SECRET_SIZE + LQX10_AES_KEY_SIZE];
    memcpy(combined_key, shared_secret, LQX10_KYBER_SHARED_SECRET_SIZE);
    memcpy(combined_key + LQX10_KYBER_SHARED_SECRET_SIZE, secret_key->classical_key, LQX10_AES_KEY_SIZE);
    
    uint8_t derived_key[32];
    result = lqx10_pbkdf2_sha256(combined_key, sizeof(combined_key), salt, sizeof(salt), 10000, derived_key, 32);
    if (result != LQX10_SUCCESS) {
        lqx10_secure_memzero_pure(shared_secret, sizeof(shared_secret));
        lqx10_secure_memzero_pure(combined_key, sizeof(combined_key));
        return result;
    }
    
    // Step 3: Extract IV and decrypt with AES
    const uint8_t *iv = ciphertext + LQX10_KYBER_CIPHERTEXT_SIZE;
    const uint8_t *aes_ciphertext = ciphertext + LQX10_KYBER_CIPHERTEXT_SIZE + LQX10_AES_IV_SIZE;
    size_t aes_ciphertext_len = ciphertext_len - LQX10_KYBER_CIPHERTEXT_SIZE - LQX10_AES_IV_SIZE;
    
    result = lqx10_aes_decrypt_pure(derived_key, iv, aes_ciphertext, aes_ciphertext_len,
                                    plaintext, plaintext_len);
    
    // Secure cleanup
    lqx10_secure_memzero_pure(shared_secret, sizeof(shared_secret));
    lqx10_secure_memzero_pure(derived_key, sizeof(derived_key));
    lqx10_secure_memzero_pure(combined_key, sizeof(combined_key));
    
    return result;
}

// =================== ENTROPY MANAGEMENT ===================

lqx10_error_t lqx10_entropy_init(lqx10_entropy_state_t *ctx) {
    if (!ctx) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    memset(ctx, 0, sizeof(lqx10_entropy_state_t));
    
    // Check for hardware RNG availability
#ifdef _WIN32
    ctx->hardware_rng_available = true; // Windows always has RtlGenRandom
#else
    // Check for hardware entropy sources
    int fd = open("/dev/hwrng", O_RDONLY | O_NONBLOCK);
    ctx->hardware_rng_available = (fd >= 0);
    if (fd >= 0) close(fd);
#endif
    
    return lqx10_entropy_gather(ctx);
}

lqx10_error_t lqx10_entropy_gather(lqx10_entropy_state_t *ctx) {
    if (!ctx) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Gather entropy from multiple sources
    uint8_t temp_entropy[256];
    
    // System randomness
    lqx10_error_t result = lqx10_secure_random_bytes_pure(temp_entropy, 64);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Mix into pool
    for (size_t i = 0; i < 64; i++) {
        ctx->entropy_pool[(ctx->pool_index + i) % sizeof(ctx->entropy_pool)] ^= temp_entropy[i];
    }
    ctx->pool_index = (ctx->pool_index + 64) % sizeof(ctx->entropy_pool);
    
    // Timing entropy
#ifdef _WIN32
    LARGE_INTEGER counter;
    QueryPerformanceCounter(&counter);
    uint64_t timing = counter.QuadPart;
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    uint64_t timing = ts.tv_sec * 1000000000ULL + ts.tv_nsec;
#endif
    
    memcpy(temp_entropy, &timing, sizeof(timing));
    for (size_t i = 0; i < sizeof(timing); i++) {
        ctx->entropy_pool[(ctx->pool_index + i) % sizeof(ctx->entropy_pool)] ^= temp_entropy[i];
    }
    ctx->pool_index = (ctx->pool_index + sizeof(timing)) % sizeof(ctx->entropy_pool);
    
    ctx->reseed_counter++;
    
    // Secure cleanup
    lqx10_secure_memzero_pure(temp_entropy, sizeof(temp_entropy));
    
    return LQX10_SUCCESS;
}

lqx10_error_t lqx10_entropy_extract(lqx10_entropy_state_t *ctx, uint8_t *output, size_t output_len) {
    if (!ctx || !output || output_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Reseed if needed
    if (ctx->reseed_counter % 1000 == 0) {
        lqx10_error_t result = lqx10_entropy_gather(ctx);
        if (result != LQX10_SUCCESS) {
            return result;
        }
    }
    
    // Extract entropy using HKDF-like construction
    uint8_t prk[32];
    lqx10_error_t result = lqx10_sha256_hash(ctx->entropy_pool, sizeof(ctx->entropy_pool), prk);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Expand to required length
    size_t extracted = 0;
    uint8_t counter = 1;
    
    while (extracted < output_len) {
        uint8_t info[1] = {counter};
        uint8_t okm[32];
        
        result = lqx10_hmac_sha256(prk, sizeof(prk), info, sizeof(info), okm);
        if (result != LQX10_SUCCESS) {
            lqx10_secure_memzero_pure(prk, sizeof(prk));
            return result;
        }
        
        size_t copy_len = LQX10_MIN(sizeof(okm), output_len - extracted);
        memcpy(output + extracted, okm, copy_len);
        extracted += copy_len;
        counter++;
        
        lqx10_secure_memzero_pure(okm, sizeof(okm));
    }
    
    // Update pool state
    ctx->pool_index = (ctx->pool_index + output_len) % sizeof(ctx->entropy_pool);
    
    // Secure cleanup
    lqx10_secure_memzero_pure(prk, sizeof(prk));
    
    return LQX10_SUCCESS;
}

// =================== MEMORY PROTECTION ===================

lqx10_error_t lqx10_mlock_memory(void *ptr, size_t len) {
    if (!ptr || len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
#ifdef _WIN32
    return VirtualLock(ptr, len) ? LQX10_SUCCESS : LQX10_ERROR_CRYPTO_FAILURE;
#else
    return (mlock(ptr, len) == 0) ? LQX10_SUCCESS : LQX10_ERROR_CRYPTO_FAILURE;
#endif
}

lqx10_error_t lqx10_munlock_memory(void *ptr, size_t len) {
    if (!ptr || len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Zero memory before unlocking
    lqx10_secure_memzero_pure(ptr, len);
    
#ifdef _WIN32
    return VirtualUnlock(ptr, len) ? LQX10_SUCCESS : LQX10_ERROR_CRYPTO_FAILURE;
#else
    return (munlock(ptr, len) == 0) ? LQX10_SUCCESS : LQX10_ERROR_CRYPTO_FAILURE;
#endif
}

// =================== TIMING ATTACK PROTECTION ===================

lqx10_error_t lqx10_constant_time_compare(const uint8_t *a, const uint8_t *b, size_t len, bool *equal) {
    if (!a || !b || !equal || len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    volatile uint8_t result = 0;
    for (size_t i = 0; i < len; i++) {
        result |= a[i] ^ b[i];
    }
    
    *equal = (result == 0);
    return LQX10_SUCCESS;
}

// =================== HKDF EXPAND IMPLEMENTATION ===================

lqx10_error_t lqx10_hkdf_expand(const uint8_t *prk, size_t prk_len,
                                const uint8_t *info, size_t info_len,
                                uint8_t *output, size_t output_len) {
    if (!prk || prk_len == 0 || !output || output_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // HKDF-Expand can produce at most 255 * HashLen octets
    if (output_len > 255 * 32) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    size_t hash_len = 32; // SHA-256 output length
    size_t n = (output_len + hash_len - 1) / hash_len; // Ceiling division
    
    uint8_t *t_prev = NULL;
    uint8_t t_current[32];
    size_t output_offset = 0;
    
    for (size_t i = 1; i <= n; i++) {
        // Prepare HMAC input: T(i-1) || info || i
        size_t hmac_input_len = (t_prev ? hash_len : 0) + info_len + 1;
        uint8_t *hmac_input = malloc(hmac_input_len);
        if (!hmac_input) {
            return LQX10_ERROR_MEMORY_ALLOCATION;
        }
        
        size_t offset = 0;
        if (t_prev) {
            memcpy(hmac_input + offset, t_prev, hash_len);
            offset += hash_len;
        }
        
        if (info && info_len > 0) {
            memcpy(hmac_input + offset, info, info_len);
            offset += info_len;
        }
        
        hmac_input[offset] = (uint8_t)i;
        
        // Compute T(i) = HMAC-SHA256(PRK, T(i-1) || info || i)
        lqx10_error_t result = lqx10_hmac_sha256(prk, prk_len, hmac_input, hmac_input_len, t_current);
        
        lqx10_secure_memzero_pure(hmac_input, hmac_input_len);
        free(hmac_input);
        
        if (result != LQX10_SUCCESS) {
            return result;
        }
        
        // Copy appropriate portion to output
        size_t copy_len = LQX10_MIN(hash_len, output_len - output_offset);
        memcpy(output + output_offset, t_current, copy_len);
        output_offset += copy_len;
        
        t_prev = t_current;
    }
    
    // Secure cleanup
    lqx10_secure_memzero_pure(t_current, sizeof(t_current));
    
    return LQX10_SUCCESS;
}

// =================== CRYPTOGRAPHIC SELF-TESTS ===================

static lqx10_error_t lqx10_test_aes256(void) {
    // NIST AES-256 test vectors
    const uint8_t key[32] = {
        0x60, 0x3d, 0xeb, 0x10, 0x15, 0xca, 0x71, 0xbe, 0x2b, 0x73, 0xae, 0xf0, 0x85, 0x7d, 0x77, 0x81,
        0x1f, 0x35, 0x2c, 0x07, 0x3b, 0x61, 0x08, 0xd7, 0x2d, 0x98, 0x10, 0xa3, 0x09, 0x14, 0xdf, 0xf4
    };
    
    const uint8_t iv[16] = {
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f
    };
    
    const uint8_t plaintext[16] = {
        0x6b, 0xc1, 0xbe, 0xe2, 0x2e, 0x40, 0x9f, 0x96, 0xe9, 0x3d, 0x7e, 0x11, 0x73, 0x93, 0x17, 0x2a
    };
    
    const uint8_t expected_ciphertext[16] = {
        0xf5, 0x8c, 0x4c, 0x04, 0xd6, 0xe5, 0xf1, 0xba, 0x77, 0x9e, 0xab, 0xfb, 0x5f, 0x7b, 0xfb, 0xd6
    };
    
    uint8_t ciphertext[32];
    uint8_t decrypted[16];
    size_t ciphertext_len = sizeof(ciphertext);
    size_t decrypted_len = sizeof(decrypted);
    
    // Test encryption
    lqx10_error_t result = lqx10_aes_encrypt_pure(key, iv, plaintext, sizeof(plaintext), 
                                                  ciphertext, &ciphertext_len);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Test decryption
    result = lqx10_aes_decrypt_pure(key, iv, ciphertext, ciphertext_len, 
                                    decrypted, &decrypted_len);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Verify decryption matches original plaintext
    bool equal;
    result = lqx10_constant_time_compare(plaintext, decrypted, sizeof(plaintext), &equal);
    if (result != LQX10_SUCCESS || !equal) {
        return LQX10_ERROR_CRYPTO_FAILURE;
    }
    
    return LQX10_SUCCESS;
}

static lqx10_error_t lqx10_test_sha256(void) {
    // NIST SHA-256 test vector
    const uint8_t input[] = "abc";
    const uint8_t expected[32] = {
        0xba, 0x78, 0x16, 0xbf, 0x8f, 0x01, 0xcf, 0xea, 0x41, 0x41, 0x40, 0xde, 0x5d, 0xae, 0x22, 0x23,
        0xb0, 0x03, 0x61, 0xa3, 0x96, 0x17, 0x7a, 0x9c, 0xb4, 0x10, 0xff, 0x61, 0xf2, 0x00, 0x15, 0xad
    };
    
    uint8_t output[32];
    lqx10_error_t result = lqx10_sha256_hash(input, 3, output);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    bool equal;
    result = lqx10_constant_time_compare(expected, output, 32, &equal);
    if (result != LQX10_SUCCESS || !equal) {
        return LQX10_ERROR_CRYPTO_FAILURE;
    }
    
    return LQX10_SUCCESS;
}

static lqx10_error_t lqx10_test_hmac_sha256(void) {
    // NIST HMAC-SHA256 test vector
    const uint8_t key[] = "key";
    const uint8_t data[] = "The quick brown fox jumps over the lazy dog";
    const uint8_t expected[32] = {
        0xf7, 0xbc, 0x83, 0xf4, 0x30, 0x53, 0x84, 0x24, 0xb1, 0x32, 0x98, 0xe6, 0xaa, 0x6f, 0xb1, 0x43,
        0xef, 0x4d, 0x59, 0xa1, 0x49, 0x46, 0x17, 0x59, 0x97, 0x47, 0x9d, 0xbc, 0x2d, 0x1a, 0x3c, 0xd8
    };
    
    uint8_t output[32];
    lqx10_error_t result = lqx10_hmac_sha256(key, 3, data, strlen((char*)data), output);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    bool equal;
    result = lqx10_constant_time_compare(expected, output, 32, &equal);
    if (result != LQX10_SUCCESS || !equal) {
        return LQX10_ERROR_CRYPTO_FAILURE;
    }
    
    return LQX10_SUCCESS;
}

static lqx10_error_t lqx10_test_pbkdf2(void) {
    // PBKDF2-HMAC-SHA256 test vector
    const uint8_t password[] = "password";
    const uint8_t salt[] = "salt";
    const uint8_t expected[32] = {
        0x12, 0x0f, 0xb6, 0xcf, 0xfc, 0xf8, 0xb3, 0x2c, 0x43, 0xe7, 0x22, 0x52, 0x56, 0xc4, 0xf8, 0x37,
        0xa8, 0x65, 0x48, 0xc9, 0x2c, 0xcc, 0x35, 0x48, 0x08, 0x05, 0x98, 0x7c, 0xb7, 0x0b, 0xe1, 0x7b
    };
    
    uint8_t output[32];
    lqx10_error_t result = lqx10_pbkdf2_sha256(password, 8, salt, 4, 1, output, 32);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    bool equal;
    result = lqx10_constant_time_compare(expected, output, 32, &equal);
    if (result != LQX10_SUCCESS || !equal) {
        return LQX10_ERROR_CRYPTO_FAILURE;
    }
    
    return LQX10_SUCCESS;
}

static lqx10_error_t lqx10_test_blake3(void) {
    // BLAKE3 test vector
    const uint8_t input[] = "hello world";
    const uint8_t expected[32] = {
        0xd7, 0x4f, 0x86, 0x76, 0xeb, 0x86, 0x72, 0xb4, 0x6c, 0xfc, 0x76, 0x2f, 0x59, 0x86, 0x5b, 0x17,
        0x07, 0x3b, 0x49, 0x20, 0xd1, 0x45, 0x4a, 0x3c, 0x5c, 0x9b, 0x2e, 0x21, 0x5d, 0x7c, 0x31, 0xb8
    };
    
    uint8_t output[32];
    lqx10_error_t result = lqx10_blake3_hash_pure(input, strlen((char*)input), output, 32);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    bool equal;
    result = lqx10_constant_time_compare(expected, output, 32, &equal);
    if (result != LQX10_SUCCESS || !equal) {
        return LQX10_ERROR_CRYPTO_FAILURE;
    }
    
    return LQX10_SUCCESS;
}

static lqx10_error_t lqx10_test_kyber(void) {
    uint8_t public_key[LQX10_KYBER_PUBLIC_KEY_SIZE];
    uint8_t secret_key[LQX10_KYBER_SECRET_KEY_SIZE];
    uint8_t ciphertext[LQX10_KYBER_CIPHERTEXT_SIZE];
    uint8_t shared_secret1[LQX10_KYBER_SHARED_SECRET_SIZE];
    uint8_t shared_secret2[LQX10_KYBER_SHARED_SECRET_SIZE];
    
    // Test key generation
    lqx10_error_t result = lqx10_kyber_keygen_pure(public_key, secret_key);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Test encapsulation
    result = lqx10_kyber_encaps_pure(public_key, ciphertext, shared_secret1);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Test decapsulation
    result = lqx10_kyber_decaps_pure(secret_key, ciphertext, shared_secret2);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Verify shared secrets match
    bool equal;
    result = lqx10_constant_time_compare(shared_secret1, shared_secret2, 
                                        LQX10_KYBER_SHARED_SECRET_SIZE, &equal);
    if (result != LQX10_SUCCESS || !equal) {
        return LQX10_ERROR_CRYPTO_FAILURE;
    }
    
    // Secure cleanup
    lqx10_secure_memzero_pure(secret_key, sizeof(secret_key));
    lqx10_secure_memzero_pure(shared_secret1, sizeof(shared_secret1));
    lqx10_secure_memzero_pure(shared_secret2, sizeof(shared_secret2));
    
    return LQX10_SUCCESS;
}

static lqx10_error_t lqx10_test_random_bytes(void) {
    uint8_t random1[32], random2[32];
    
    // Generate two random sequences
    lqx10_error_t result = lqx10_secure_random_bytes_pure(random1, sizeof(random1));
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    result = lqx10_secure_random_bytes_pure(random2, sizeof(random2));
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Verify they are different (extremely high probability)
    bool equal;
    result = lqx10_constant_time_compare(random1, random2, sizeof(random1), &equal);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    if (equal) {
        // This should almost never happen with a good RNG
        return LQX10_ERROR_ENTROPY_FAILURE;
    }
    
    return LQX10_SUCCESS;
}

lqx10_error_t lqx10_crypto_selftest(void) {
    lqx10_error_t result;
    
    // Test AES-256
    result = lqx10_test_aes256();
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Test SHA-256
    result = lqx10_test_sha256();
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Test HMAC-SHA256
    result = lqx10_test_hmac_sha256();
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Test PBKDF2
    result = lqx10_test_pbkdf2();
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Test BLAKE3
    result = lqx10_test_blake3();
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Test Kyber (post-quantum)
    result = lqx10_test_kyber();
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Test random number generation
    result = lqx10_test_random_bytes();
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    return LQX10_SUCCESS;
}

// Wrapper function implementations
lqx10_error_t lqx10_blake3_hash(const uint8_t *input,
                                size_t input_len,
                                uint8_t *output,
                                size_t output_len) {
    return lqx10_blake3_hash_pure(input, input_len, output, output_len);
}

// lqx10_hkdf_expand implementation is above at line 486
