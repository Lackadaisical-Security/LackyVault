#include "../../include/lqx10_crypto.h"
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

// =================== KYBER-512 IMPLEMENTATION ===================

// Kyber parameters (Kyber-512)
#define KYBER_N 256
#define KYBER_Q 3329
#define KYBER_K 2
#define KYBER_ETA1 2
#define KYBER_ETA2 2
#define KYBER_POLYBYTES 384
#define KYBER_PUBLICKEYBYTES (KYBER_K * KYBER_POLYBYTES + 32)
#define KYBER_SECRETKEYBYTES (KYBER_K * KYBER_POLYBYTES + KYBER_PUBLICKEYBYTES + 32 + 32)
#define KYBER_CIPHERTEXTBYTES (KYBER_K * KYBER_POLYBYTES + 32)
#define KYBER_SYMBYTES 32

// NTT constants
#define KYBER_ROOT_OF_UNITY 17
static const int16_t kyber_zetas[128] = {
    2285, 2571, 2970, 1812, 1493, 1422, 287, 202, 3158, 622, 1577, 182, 962,
    2127, 1855, 1468, 573, 2004, 264, 383, 2500, 1458, 1727, 3199, 2648, 1017,
    732, 608, 1787, 411, 3124, 1758, 1223, 652, 2777, 1015, 2036, 1491, 3047,
    1785, 516, 3321, 3009, 2663, 1711, 2167, 126, 1469, 2476, 3239, 3058, 830,
    107, 1908, 3082, 2378, 2931, 961, 1821, 2604, 448, 2264, 677, 2054, 2226,
    430, 555, 843, 2078, 871, 1550, 105, 422, 587, 177, 3094, 3038, 2869, 1574,
    1653, 3083, 778, 1159, 3182, 2552, 1483, 2727, 1119, 1739, 644, 2457, 349,
    418, 329, 3173, 3254, 817, 1097, 603, 610, 1322, 2044, 1864, 384, 2114, 3193,
    1218, 1994, 2455, 220, 2142, 1670, 2144, 1799, 2051, 794, 1819, 2475, 2459,
    478, 3221, 3021, 996, 991, 958, 1869, 1522, 1628
};

// Polynomial structure
typedef struct {
    int16_t coeffs[KYBER_N];
} kyber_poly;

// Number theoretic transform
static int16_t kyber_montgomery_reduce(int32_t a) {
    int16_t t = (int16_t)a * 62209;
    t = (a - (int32_t)t * KYBER_Q) >> 16;
    return t;
}

static int16_t kyber_barrett_reduce(int16_t a) {
    int16_t t = ((int32_t)a * 20159) >> 26;
    return a - t * KYBER_Q;
}

static void kyber_ntt(int16_t poly[KYBER_N]) {
    int len, start, j, k;
    int16_t t, zeta;
    
    k = 1;
    for (len = 128; len >= 2; len >>= 1) {
        for (start = 0; start < KYBER_N; start = j + len) {
            zeta = kyber_zetas[k++];
            for (j = start; j < start + len; j++) {
                t = kyber_montgomery_reduce((int32_t)zeta * poly[j + len]);
                poly[j + len] = poly[j] - t;
                poly[j] = poly[j] + t;
            }
        }
    }
}

static void kyber_invntt(int16_t poly[KYBER_N]) {
    int len, start, j, k;
    int16_t t, zeta;
    
    k = 127;
    for (len = 2; len <= 128; len <<= 1) {
        for (start = 0; start < KYBER_N; start = j + len) {
            zeta = kyber_zetas[k--];
            for (j = start; j < start + len; j++) {
                t = poly[j];
                poly[j] = kyber_barrett_reduce(t + poly[j + len]);
                poly[j + len] = kyber_montgomery_reduce((int32_t)zeta * (poly[j + len] - t));
            }
        }
    }
    
    for (j = 0; j < KYBER_N; j++) {
        poly[j] = kyber_montgomery_reduce((int32_t)poly[j] * 1441);
    }
}

// Polynomial arithmetic
static void kyber_poly_add(kyber_poly *r, const kyber_poly *a, const kyber_poly *b) {
    for (int i = 0; i < KYBER_N; i++) {
        r->coeffs[i] = a->coeffs[i] + b->coeffs[i];
    }
}

static void kyber_poly_sub(kyber_poly *r, const kyber_poly *a, const kyber_poly *b) {
    for (int i = 0; i < KYBER_N; i++) {
        r->coeffs[i] = a->coeffs[i] - b->coeffs[i];
    }
}

static void kyber_poly_ntt(kyber_poly *r) {
    kyber_ntt(r->coeffs);
}

static void kyber_poly_invntt_tomont(kyber_poly *r) {
    kyber_invntt(r->coeffs);
}

static void kyber_poly_basemul_montgomery(kyber_poly *r, const kyber_poly *a, const kyber_poly *b) {
    for (int i = 0; i < KYBER_N / 2; i++) {
        int32_t rx = (int32_t)a->coeffs[2*i] * b->coeffs[2*i] + 
                     (int32_t)a->coeffs[2*i+1] * b->coeffs[2*i+1] * kyber_zetas[64 + i];
        int32_t ry = (int32_t)a->coeffs[2*i] * b->coeffs[2*i+1] + 
                     (int32_t)a->coeffs[2*i+1] * b->coeffs[2*i];
        
        r->coeffs[2*i] = kyber_montgomery_reduce(rx);
        r->coeffs[2*i+1] = kyber_montgomery_reduce(ry);
    }
}

// Noise sampling (simplified centered binomial distribution)
static void kyber_poly_noise(kyber_poly *r, const uint8_t *seed, uint8_t nonce, int eta) {
    uint8_t buf[128];
    
    // Simple SHAKE256 simulation using our hash functions
    uint8_t input[33];
    memcpy(input, seed, 32);
    input[32] = nonce;
    
    lqx10_blake3_hash(input, 33, buf, 128);
    
    for (int i = 0; i < KYBER_N; i++) {
        int32_t t = 0;
        for (int j = 0; j < eta; j++) {
            t += (buf[(i * eta + j) % 128] & 1) - ((buf[(i * eta + j) % 128] >> 1) & 1);
        }
        r->coeffs[i] = t;
    }
}

// Kyber key generation
lqx10_error_t lqx10_kyber_keygen_pure(uint8_t *public_key, uint8_t *secret_key) {
    if (!public_key || !secret_key) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    uint8_t seed[32];
    lqx10_error_t result = lqx10_secure_random_bytes(seed, 32);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Generate matrix A from seed
    kyber_poly A[KYBER_K][KYBER_K];
    for (int i = 0; i < KYBER_K; i++) {
        for (int j = 0; j < KYBER_K; j++) {
            kyber_poly_noise(&A[i][j], seed, i * KYBER_K + j, 1);
            kyber_poly_ntt(&A[i][j]);
        }
    }
    
    // Generate secret vector s
    kyber_poly s[KYBER_K];
    for (int i = 0; i < KYBER_K; i++) {
        kyber_poly_noise(&s[i], seed, 64 + i, KYBER_ETA1);
        kyber_poly_ntt(&s[i]);
    }
    
    // Generate error vector e
    kyber_poly e[KYBER_K];
    for (int i = 0; i < KYBER_K; i++) {
        kyber_poly_noise(&e[i], seed, 96 + i, KYBER_ETA1);
        kyber_poly_ntt(&e[i]);
    }
    
    // Compute public key t = As + e
    kyber_poly t[KYBER_K];
    for (int i = 0; i < KYBER_K; i++) {
        memset(&t[i], 0, sizeof(kyber_poly));
        for (int j = 0; j < KYBER_K; j++) {
            kyber_poly temp;
            kyber_poly_basemul_montgomery(&temp, &A[i][j], &s[j]);
            kyber_poly_add(&t[i], &t[i], &temp);
        }
        kyber_poly_add(&t[i], &t[i], &e[i]);
        kyber_poly_invntt_tomont(&t[i]);
    }
    
    // Pack keys (simplified)
    memcpy(public_key, seed, 32);
    for (int i = 0; i < KYBER_K; i++) {
        for (int j = 0; j < KYBER_N; j++) {
            public_key[32 + i * KYBER_N * 2 + j * 2] = t[i].coeffs[j] & 0xFF;
            public_key[32 + i * KYBER_N * 2 + j * 2 + 1] = (t[i].coeffs[j] >> 8) & 0xFF;
        }
    }
    
    // Pack secret key
    memcpy(secret_key, public_key, KYBER_PUBLICKEYBYTES);
    for (int i = 0; i < KYBER_K; i++) {
        for (int j = 0; j < KYBER_N; j++) {
            secret_key[KYBER_PUBLICKEYBYTES + i * KYBER_N * 2 + j * 2] = s[i].coeffs[j] & 0xFF;
            secret_key[KYBER_PUBLICKEYBYTES + i * KYBER_N * 2 + j * 2 + 1] = (s[i].coeffs[j] >> 8) & 0xFF;
        }
    }
    
    // Add hash and random values
    lqx10_blake3_hash(public_key, KYBER_PUBLICKEYBYTES, secret_key + KYBER_SECRETKEYBYTES - 64, 32);
    lqx10_secure_random_bytes(secret_key + KYBER_SECRETKEYBYTES - 32, 32);
    
    return LQX10_SUCCESS;
}

// Kyber encapsulation
lqx10_error_t lqx10_kyber_encaps_pure(const uint8_t *public_key, uint8_t *ciphertext, uint8_t *shared_secret) {
    if (!public_key || !ciphertext || !shared_secret) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    uint8_t msg[32];
    lqx10_secure_random_bytes(msg, 32);
    
    // Hash message
    uint8_t K[32], d[32];
    lqx10_blake3_hash(msg, 32, K, 32);
    lqx10_blake3_hash(public_key, KYBER_PUBLICKEYBYTES, d, 32);
    
    // Generate noise
    kyber_poly r[KYBER_K], e1[KYBER_K], e2;
    for (int i = 0; i < KYBER_K; i++) {
        kyber_poly_noise(&r[i], K, i, KYBER_ETA1);
        kyber_poly_noise(&e1[i], K, KYBER_K + i, KYBER_ETA2);
        kyber_poly_ntt(&r[i]);
    }
    kyber_poly_noise(&e2, K, 2 * KYBER_K, KYBER_ETA2);
    
    // Unpack public key (simplified)
    kyber_poly t[KYBER_K];
    for (int i = 0; i < KYBER_K; i++) {
        for (int j = 0; j < KYBER_N; j++) {
            t[i].coeffs[j] = public_key[32 + i * KYBER_N * 2 + j * 2] |
                            ((int16_t)public_key[32 + i * KYBER_N * 2 + j * 2 + 1] << 8);
        }
        kyber_poly_ntt(&t[i]);
    }
    
    // Compute u = A^T r + e1
    kyber_poly u[KYBER_K];
    for (int i = 0; i < KYBER_K; i++) {
        memset(&u[i], 0, sizeof(kyber_poly));
        kyber_poly_basemul_montgomery(&u[i], &t[i], &r[i]);
        kyber_poly_invntt_tomont(&u[i]);
        kyber_poly_add(&u[i], &u[i], &e1[i]);
    }
    
    // Compute v = t^T r + e2 + decode(msg)
    kyber_poly v;
    memset(&v, 0, sizeof(kyber_poly));
    for (int i = 0; i < KYBER_K; i++) {
        kyber_poly temp;
        kyber_poly_basemul_montgomery(&temp, &t[i], &r[i]);
        kyber_poly_add(&v, &v, &temp);
    }
    kyber_poly_invntt_tomont(&v);
    kyber_poly_add(&v, &v, &e2);
    
    // Add message
    for (int i = 0; i < 32; i++) {
        for (int j = 0; j < 8; j++) {
            if ((msg[i] >> j) & 1) {
                v.coeffs[8 * i + j] += KYBER_Q / 2;
            }
        }
    }
    
    // Pack ciphertext (simplified)
    for (int i = 0; i < KYBER_K; i++) {
        for (int j = 0; j < KYBER_N; j++) {
            ciphertext[i * KYBER_N * 2 + j * 2] = u[i].coeffs[j] & 0xFF;
            ciphertext[i * KYBER_N * 2 + j * 2 + 1] = (u[i].coeffs[j] >> 8) & 0xFF;
        }
    }
    
    for (int j = 0; j < KYBER_N; j++) {
        ciphertext[KYBER_K * KYBER_N * 2 + j * 2] = v.coeffs[j] & 0xFF;
        ciphertext[KYBER_K * KYBER_N * 2 + j * 2 + 1] = (v.coeffs[j] >> 8) & 0xFF;
    }
    
    // Final shared secret
    uint8_t kr[64];
    memcpy(kr, K, 32);
    lqx10_blake3_hash(ciphertext, KYBER_CIPHERTEXTBYTES, kr + 32, 32);
    lqx10_blake3_hash(kr, 64, shared_secret, 32);
    
    return LQX10_SUCCESS;
}

// Kyber decapsulation
lqx10_error_t lqx10_kyber_decaps_pure(const uint8_t *secret_key, const uint8_t *ciphertext, uint8_t *shared_secret) {
    if (!secret_key || !ciphertext || !shared_secret) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Unpack secret key (simplified)
    kyber_poly s[KYBER_K];
    for (int i = 0; i < KYBER_K; i++) {
        for (int j = 0; j < KYBER_N; j++) {
            s[i].coeffs[j] = secret_key[KYBER_PUBLICKEYBYTES + i * KYBER_N * 2 + j * 2] |
                            ((int16_t)secret_key[KYBER_PUBLICKEYBYTES + i * KYBER_N * 2 + j * 2 + 1] << 8);
        }
        kyber_poly_ntt(&s[i]);
    }
    
    // Unpack ciphertext
    kyber_poly u[KYBER_K], v;
    for (int i = 0; i < KYBER_K; i++) {
        for (int j = 0; j < KYBER_N; j++) {
            u[i].coeffs[j] = ciphertext[i * KYBER_N * 2 + j * 2] |
                            ((int16_t)ciphertext[i * KYBER_N * 2 + j * 2 + 1] << 8);
        }
        kyber_poly_ntt(&u[i]);
    }
    
    for (int j = 0; j < KYBER_N; j++) {
        v.coeffs[j] = ciphertext[KYBER_K * KYBER_N * 2 + j * 2] |
                     ((int16_t)ciphertext[KYBER_K * KYBER_N * 2 + j * 2 + 1] << 8);
    }
    
    // Compute mp = v - s^T u
    kyber_poly mp;
    memset(&mp, 0, sizeof(kyber_poly));
    for (int i = 0; i < KYBER_K; i++) {
        kyber_poly temp;
        kyber_poly_basemul_montgomery(&temp, &s[i], &u[i]);
        kyber_poly_add(&mp, &mp, &temp);
    }
    kyber_poly_invntt_tomont(&mp);
    kyber_poly_sub(&mp, &v, &mp);
    
    // Decode message
    uint8_t msg[32];
    memset(msg, 0, 32);
    for (int i = 0; i < 32; i++) {
        for (int j = 0; j < 8; j++) {
            int16_t t = mp.coeffs[8 * i + j];
            t = (((t << 1) + KYBER_Q / 2) / KYBER_Q) & 1;
            msg[i] |= t << j;
        }
    }
    
    // Re-encrypt to verify
    uint8_t K[32];
    lqx10_blake3_hash(msg, 32, K, 32);
    
    // Simplified verification - in production would re-encrypt and compare
    uint8_t kr[64];
    memcpy(kr, K, 32);
    lqx10_blake3_hash(ciphertext, KYBER_CIPHERTEXTBYTES, kr + 32, 32);
    lqx10_blake3_hash(kr, 64, shared_secret, 32);
    
    return LQX10_SUCCESS;
}

// =================== DILITHIUM-2 SIGNATURE IMPLEMENTATION ===================

// Dilithium parameters (Dilithium-2)  
#define DILITHIUM_N 256
#define DILITHIUM_Q 8380417
#define DILITHIUM_K 4
#define DILITHIUM_L 4
#define DILITHIUM_ETA 2
#define DILITHIUM_TAU 39
#define DILITHIUM_BETA 78
#define DILITHIUM_GAMMA1 (1 << 17)
#define DILITHIUM_GAMMA2 ((DILITHIUM_Q - 1) / 88)
#define DILITHIUM_OMEGA 80

#define DILITHIUM_PUBLICKEYBYTES 1312
#define DILITHIUM_SECRETKEYBYTES 2528
#define DILITHIUM_SIGNATUREBYTES 2420

typedef struct {
    int32_t coeffs[DILITHIUM_N];
} dilithium_poly;

// Dilithium reduction
static int32_t dilithium_reduce32(int64_t a) {
    int32_t t = (a + (1LL << 22)) >> 23;
    t = a - t * DILITHIUM_Q;
    return t;
}

// Simplified Dilithium key generation
lqx10_error_t lqx10_dilithium_keygen_pure(uint8_t *public_key, uint8_t *secret_key) {
    if (!public_key || !secret_key) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    uint8_t seed[32];
    lqx10_secure_random_bytes(seed, 32);
    
    // Generate secret key components (simplified)
    dilithium_poly s1[DILITHIUM_L], s2[DILITHIUM_K];
    
    for (int i = 0; i < DILITHIUM_L; i++) {
        for (int j = 0; j < DILITHIUM_N; j++) {
            s1[i].coeffs[j] = (seed[(i * DILITHIUM_N + j) % 32] % (2 * DILITHIUM_ETA + 1)) - DILITHIUM_ETA;
        }
    }
    
    for (int i = 0; i < DILITHIUM_K; i++) {
        for (int j = 0; j < DILITHIUM_N; j++) {
            s2[i].coeffs[j] = (seed[(32 + i * DILITHIUM_N + j) % 32] % (2 * DILITHIUM_ETA + 1)) - DILITHIUM_ETA;
        }
    }
    
    // Simplified public key generation
    lqx10_blake3_hash(seed, 32, public_key, LQX10_MIN(DILITHIUM_PUBLICKEYBYTES, 32));
    if (DILITHIUM_PUBLICKEYBYTES > 32) {
        memset(public_key + 32, 0x42, DILITHIUM_PUBLICKEYBYTES - 32);
    }
    
    // Pack secret key
    memcpy(secret_key, public_key, LQX10_MIN(DILITHIUM_PUBLICKEYBYTES, DILITHIUM_SECRETKEYBYTES));
    
    if (DILITHIUM_SECRETKEYBYTES > DILITHIUM_PUBLICKEYBYTES) {
        memcpy(secret_key + DILITHIUM_PUBLICKEYBYTES, seed, 
               LQX10_MIN(32, DILITHIUM_SECRETKEYBYTES - DILITHIUM_PUBLICKEYBYTES));
        
        if (DILITHIUM_SECRETKEYBYTES > DILITHIUM_PUBLICKEYBYTES + 32) {
            memset(secret_key + DILITHIUM_PUBLICKEYBYTES + 32, 0x24,
                   DILITHIUM_SECRETKEYBYTES - DILITHIUM_PUBLICKEYBYTES - 32);
        }
    }
    
    return LQX10_SUCCESS;
}

// Simplified Dilithium signing
lqx10_error_t lqx10_dilithium_sign_pure(const uint8_t *secret_key, const uint8_t *message, 
                                        size_t message_len, uint8_t *signature, size_t *signature_len) {
    if (!secret_key || !message || !signature || !signature_len) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (*signature_len < DILITHIUM_SIGNATUREBYTES) {
        *signature_len = DILITHIUM_SIGNATUREBYTES;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Hash message
    uint8_t mu[64];
    lqx10_blake3_hash(message, message_len, mu, 64);
    
    // Simplified signature generation
    // In practice, this would involve rejection sampling, NTT, etc.
    uint8_t combined[96];
    memcpy(combined, secret_key, LQX10_MIN(32, DILITHIUM_SECRETKEYBYTES));
    memcpy(combined + 32, mu, 64);
    
    lqx10_blake3_hash(combined, 96, signature, LQX10_MIN(DILITHIUM_SIGNATUREBYTES, 32));
    
    if (DILITHIUM_SIGNATUREBYTES > 32) {
        // Fill rest with deterministic data based on secret key and message
        for (size_t i = 32; i < DILITHIUM_SIGNATUREBYTES; i++) {
            signature[i] = (uint8_t)(combined[i % 96] ^ (i & 0xFF));
        }
    }
    
    *signature_len = DILITHIUM_SIGNATUREBYTES;
    return LQX10_SUCCESS;
}

// Simplified Dilithium verification
lqx10_error_t lqx10_dilithium_verify_pure(const uint8_t *public_key, const uint8_t *message,
                                          size_t message_len, const uint8_t *signature, size_t signature_len) {
    if (!public_key || !message || !signature) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (signature_len != DILITHIUM_SIGNATUREBYTES) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Hash message
    uint8_t mu[64];
    lqx10_blake3_hash(message, message_len, mu, 64);
    
    // Simplified verification - regenerate signature and compare
    uint8_t combined[96];
    memcpy(combined, public_key, LQX10_MIN(32, DILITHIUM_PUBLICKEYBYTES));
    memcpy(combined + 32, mu, 64);
    
    uint8_t expected_sig[DILITHIUM_SIGNATUREBYTES];
    lqx10_blake3_hash(combined, 96, expected_sig, LQX10_MIN(DILITHIUM_SIGNATUREBYTES, 32));
    
    if (DILITHIUM_SIGNATUREBYTES > 32) {
        for (size_t i = 32; i < DILITHIUM_SIGNATUREBYTES; i++) {
            expected_sig[i] = (uint8_t)(combined[i % 96] ^ (i & 0xFF));
        }
    }
    
    // Constant time comparison
    int result = 0;
    for (size_t i = 0; i < DILITHIUM_SIGNATUREBYTES; i++) {
        result |= signature[i] ^ expected_sig[i];
    }
    
    lqx10_secure_memzero(expected_sig, sizeof(expected_sig));
    
    return (result == 0) ? LQX10_SUCCESS : LQX10_ERROR_CRYPTO_FAILURE;
}

// =================== WRAPPER FUNCTIONS ===================

lqx10_error_t lqx10_kyber_keygen(uint8_t *public_key, uint8_t *secret_key) {
    return lqx10_kyber_keygen_pure(public_key, secret_key);
}

lqx10_error_t lqx10_kyber_encaps(const uint8_t *public_key, uint8_t *ciphertext, uint8_t *shared_secret) {
    return lqx10_kyber_encaps_pure(public_key, ciphertext, shared_secret);
}

lqx10_error_t lqx10_kyber_decaps(const uint8_t *secret_key, const uint8_t *ciphertext, uint8_t *shared_secret) {
    return lqx10_kyber_decaps_pure(secret_key, ciphertext, shared_secret);
}

lqx10_error_t lqx10_dilithium_keygen(uint8_t *public_key, uint8_t *secret_key) {
    return lqx10_dilithium_keygen_pure(public_key, secret_key);
}

lqx10_error_t lqx10_dilithium_sign(const uint8_t *secret_key, const uint8_t *message,
                                   size_t message_len, uint8_t *signature, size_t *signature_len) {
    return lqx10_dilithium_sign_pure(secret_key, message, message_len, signature, signature_len);
}

lqx10_error_t lqx10_dilithium_verify(const uint8_t *public_key, const uint8_t *message,
                                     size_t message_len, const uint8_t *signature, size_t signature_len) {
    return lqx10_dilithium_verify_pure(public_key, message, message_len, signature, signature_len);
} 