#include "../../include/lqx10_crypto.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
#include <intrin.h>
#else
#include <sys/time.h>
#include <unistd.h>
#include <fcntl.h>
#ifdef __linux__
#include <sys/mman.h>
#include <sys/syscall.h>
#endif
#endif

// =================== AES-256 PURE IMPLEMENTATION ===================

// AES S-box
static const uint8_t sbox[256] = {
    0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
    0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
    0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
    0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
    0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
    0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
    0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
    0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
    0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
    0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
    0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
    0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
    0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
    0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
    0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
    0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
};

// AES inverse S-box
static const uint8_t inv_sbox[256] = {
    0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb,
    0x7c, 0xe3, 0x39, 0x82, 0x9b, 0x2f, 0xff, 0x87, 0x34, 0x8e, 0x43, 0x44, 0xc4, 0xde, 0xe9, 0xcb,
    0x54, 0x7b, 0x94, 0x32, 0xa6, 0xc2, 0x23, 0x3d, 0xee, 0x4c, 0x95, 0x0b, 0x42, 0xfa, 0xc3, 0x4e,
    0x08, 0x2e, 0xa1, 0x66, 0x28, 0xd9, 0x24, 0xb2, 0x76, 0x5b, 0xa2, 0x49, 0x6d, 0x8b, 0xd1, 0x25,
    0x72, 0xf8, 0xf6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xd4, 0xa4, 0x5c, 0xcc, 0x5d, 0x65, 0xb6, 0x92,
    0x6c, 0x70, 0x48, 0x50, 0xfd, 0xed, 0xb9, 0xda, 0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84,
    0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7, 0xe4, 0x58, 0x05, 0xb8, 0xb3, 0x45, 0x06,
    0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f, 0x0f, 0x02, 0xc1, 0xaf, 0xbd, 0x03, 0x01, 0x13, 0x8a, 0x6b,
    0x3a, 0x91, 0x11, 0x41, 0x4f, 0x67, 0xdc, 0xea, 0x97, 0xf2, 0xcf, 0xce, 0xf0, 0xb4, 0xe6, 0x73,
    0x96, 0xac, 0x74, 0x22, 0xe7, 0xad, 0x35, 0x85, 0xe2, 0xf9, 0x37, 0xe8, 0x1c, 0x75, 0xdf, 0x6e,
    0x47, 0xf1, 0x1a, 0x71, 0x1d, 0x29, 0xc5, 0x89, 0x6f, 0xb7, 0x62, 0x0e, 0xaa, 0x18, 0xbe, 0x1b,
    0xfc, 0x56, 0x3e, 0x4b, 0xc6, 0xd2, 0x79, 0x20, 0x9a, 0xdb, 0xc0, 0xfe, 0x78, 0xcd, 0x5a, 0xf4,
    0x1f, 0xdd, 0xa8, 0x33, 0x88, 0x07, 0xc7, 0x31, 0xb1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xec, 0x5f,
    0x60, 0x51, 0x7f, 0xa9, 0x19, 0xb5, 0x4a, 0x0d, 0x2d, 0xe5, 0x7a, 0x9f, 0x93, 0xc9, 0x9c, 0xef,
    0xa0, 0xe0, 0x3b, 0x4d, 0xae, 0x2a, 0xf5, 0xb0, 0xc8, 0xeb, 0xbb, 0x3c, 0x83, 0x53, 0x99, 0x61,
    0x17, 0x2b, 0x04, 0x7e, 0xba, 0x77, 0xd6, 0x26, 0xe1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0c, 0x7d
};

// AES round constants
static const uint32_t rcon[11] = {
    0x00000000, 0x01000000, 0x02000000, 0x04000000, 0x08000000,
    0x10000000, 0x20000000, 0x40000000, 0x80000000, 0x1b000000, 0x36000000
};

// AES helper functions
static uint32_t sub_word(uint32_t word) {
    return (sbox[word >> 24] << 24) | (sbox[(word >> 16) & 0xff] << 16) | 
           (sbox[(word >> 8) & 0xff] << 8) | sbox[word & 0xff];
}

static uint32_t rot_word(uint32_t word) {
    return (word << 8) | (word >> 24);
}

// AES-256 key expansion
static void aes256_key_expand(const uint8_t *key, uint32_t *round_keys) {
    int i;
    uint32_t temp;
    
    // Copy original key
    for (i = 0; i < 8; i++) {
        round_keys[i] = ((uint32_t*)key)[i];
    }
    
    // Generate round keys
    for (i = 8; i < 60; i++) {
        temp = round_keys[i - 1];
        
        if (i % 8 == 0) {
            temp = sub_word(rot_word(temp)) ^ rcon[i / 8];
        } else if (i % 8 == 4) {
            temp = sub_word(temp);
        }
        
        round_keys[i] = round_keys[i - 8] ^ temp;
    }
}

// AES block operations
static void add_round_key(uint8_t *state, const uint32_t *round_key) {
    for (int i = 0; i < 4; i++) {
        ((uint32_t*)state)[i] ^= round_key[i];
    }
}

static void sub_bytes(uint8_t *state) {
    for (int i = 0; i < 16; i++) {
        state[i] = sbox[state[i]];
    }
}

static void inv_sub_bytes(uint8_t *state) {
    for (int i = 0; i < 16; i++) {
        state[i] = inv_sbox[state[i]];
    }
}

static void shift_rows(uint8_t *state) {
    uint8_t temp;
    
    // Row 1: shift left by 1
    temp = state[1];
    state[1] = state[5];
    state[5] = state[9];
    state[9] = state[13];
    state[13] = temp;
    
    // Row 2: shift left by 2
    temp = state[2];
    state[2] = state[10];
    state[10] = temp;
    temp = state[6];
    state[6] = state[14];
    state[14] = temp;
    
    // Row 3: shift left by 3
    temp = state[3];
    state[3] = state[15];
    state[15] = state[11];
    state[11] = state[7];
    state[7] = temp;
}

static void inv_shift_rows(uint8_t *state) {
    uint8_t temp;
    
    // Row 1: shift right by 1
    temp = state[13];
    state[13] = state[9];
    state[9] = state[5];
    state[5] = state[1];
    state[1] = temp;
    
    // Row 2: shift right by 2
    temp = state[2];
    state[2] = state[10];
    state[10] = temp;
    temp = state[6];
    state[6] = state[14];
    state[14] = temp;
    
    // Row 3: shift right by 3
    temp = state[7];
    state[7] = state[11];
    state[11] = state[15];
    state[15] = state[3];
    state[3] = temp;
}

// Galois field multiplication
static uint8_t gf_mul(uint8_t a, uint8_t b) {
    uint8_t result = 0;
    while (b) {
        if (b & 1) result ^= a;
        a = (a << 1) ^ ((a & 0x80) ? 0x1b : 0);
        b >>= 1;
    }
    return result;
}

static void mix_columns(uint8_t *state) {
    for (int c = 0; c < 4; c++) {
        uint8_t s0 = state[c * 4 + 0];
        uint8_t s1 = state[c * 4 + 1];
        uint8_t s2 = state[c * 4 + 2];
        uint8_t s3 = state[c * 4 + 3];
        
        state[c * 4 + 0] = gf_mul(s0, 0x02) ^ gf_mul(s1, 0x03) ^ s2 ^ s3;
        state[c * 4 + 1] = s0 ^ gf_mul(s1, 0x02) ^ gf_mul(s2, 0x03) ^ s3;
        state[c * 4 + 2] = s0 ^ s1 ^ gf_mul(s2, 0x02) ^ gf_mul(s3, 0x03);
        state[c * 4 + 3] = gf_mul(s0, 0x03) ^ s1 ^ s2 ^ gf_mul(s3, 0x02);
    }
}

static void inv_mix_columns(uint8_t *state) {
    for (int c = 0; c < 4; c++) {
        uint8_t s0 = state[c * 4 + 0];
        uint8_t s1 = state[c * 4 + 1];
        uint8_t s2 = state[c * 4 + 2];
        uint8_t s3 = state[c * 4 + 3];
        
        state[c * 4 + 0] = gf_mul(s0, 0x0e) ^ gf_mul(s1, 0x0b) ^ gf_mul(s2, 0x0d) ^ gf_mul(s3, 0x09);
        state[c * 4 + 1] = gf_mul(s0, 0x09) ^ gf_mul(s1, 0x0e) ^ gf_mul(s2, 0x0b) ^ gf_mul(s3, 0x0d);
        state[c * 4 + 2] = gf_mul(s0, 0x0d) ^ gf_mul(s1, 0x09) ^ gf_mul(s2, 0x0e) ^ gf_mul(s3, 0x0b);
        state[c * 4 + 3] = gf_mul(s0, 0x0b) ^ gf_mul(s1, 0x0d) ^ gf_mul(s2, 0x09) ^ gf_mul(s3, 0x0e);
    }
}

// AES-256 block encryption
static void aes256_encrypt_block(const uint8_t *plaintext, const uint32_t *round_keys, uint8_t *ciphertext) {
    memcpy(ciphertext, plaintext, 16);
    
    add_round_key(ciphertext, &round_keys[0]);
    
    for (int round = 1; round < 14; round++) {
        sub_bytes(ciphertext);
        shift_rows(ciphertext);
        mix_columns(ciphertext);
        add_round_key(ciphertext, &round_keys[round * 4]);
    }
    
    sub_bytes(ciphertext);
    shift_rows(ciphertext);
    add_round_key(ciphertext, &round_keys[56]);
}

// AES-256 block decryption
static void aes256_decrypt_block(const uint8_t *ciphertext, const uint32_t *round_keys, uint8_t *plaintext) {
    memcpy(plaintext, ciphertext, 16);
    
    add_round_key(plaintext, &round_keys[56]);
    
    for (int round = 13; round > 0; round--) {
        inv_shift_rows(plaintext);
        inv_sub_bytes(plaintext);
        add_round_key(plaintext, &round_keys[round * 4]);
        inv_mix_columns(plaintext);
    }
    
    inv_shift_rows(plaintext);
    inv_sub_bytes(plaintext);
    add_round_key(plaintext, &round_keys[0]);
}

// PKCS#7 padding
static size_t pkcs7_pad(uint8_t *data, size_t data_len, size_t block_size) {
    size_t pad_len = block_size - (data_len % block_size);
    for (size_t i = 0; i < pad_len; i++) {
        data[data_len + i] = (uint8_t)pad_len;
    }
    return data_len + pad_len;
}

static size_t pkcs7_unpad(const uint8_t *data, size_t data_len) {
    if (data_len == 0) return 0;
    uint8_t pad_len = data[data_len - 1];
    if (pad_len > data_len || pad_len == 0) return 0;
    
    for (size_t i = data_len - pad_len; i < data_len; i++) {
        if (data[i] != pad_len) return 0;
    }
    return data_len - pad_len;
}

// Pure AES-256-CBC implementation
lqx10_error_t lqx10_aes_encrypt_pure(const uint8_t *key,
                                     const uint8_t *iv,
                                     const uint8_t *plaintext,
                                     size_t plaintext_len,
                                     uint8_t *ciphertext,
                                     size_t *ciphertext_len) {
    if (!key || !iv || !plaintext || !ciphertext || !ciphertext_len || plaintext_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Calculate padded length
    size_t padded_len = ((plaintext_len + 15) / 16) * 16;
    if (*ciphertext_len < padded_len) {
        *ciphertext_len = padded_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Expand key
    uint32_t round_keys[60];
    aes256_key_expand(key, round_keys);
    
    // Copy and pad plaintext
    uint8_t *padded_data = malloc(padded_len);
    if (!padded_data) {
        return LQX10_ERROR_MEMORY_ALLOCATION;
    }
    
    memcpy(padded_data, plaintext, plaintext_len);
    size_t final_len = pkcs7_pad(padded_data, plaintext_len, 16);
    
    // CBC encryption
    uint8_t prev_block[16];
    memcpy(prev_block, iv, 16);
    
    for (size_t i = 0; i < final_len; i += 16) {
        // XOR with previous ciphertext block (or IV)
        for (int j = 0; j < 16; j++) {
            padded_data[i + j] ^= prev_block[j];
        }
        
        // Encrypt block
        aes256_encrypt_block(&padded_data[i], round_keys, &ciphertext[i]);
        
        // Save for next iteration
        memcpy(prev_block, &ciphertext[i], 16);
    }
    
    *ciphertext_len = final_len;
    
    // Secure cleanup
    lqx10_secure_memzero(round_keys, sizeof(round_keys));
    lqx10_secure_memzero(padded_data, padded_len);
    free(padded_data);
    
    return LQX10_SUCCESS;
}

lqx10_error_t lqx10_aes_decrypt_pure(const uint8_t *key,
                                     const uint8_t *iv,
                                     const uint8_t *ciphertext,
                                     size_t ciphertext_len,
                                     uint8_t *plaintext,
                                     size_t *plaintext_len) {
    if (!key || !iv || !ciphertext || !plaintext || !plaintext_len || 
        ciphertext_len == 0 || ciphertext_len % 16 != 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (*plaintext_len < ciphertext_len) {
        *plaintext_len = ciphertext_len;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Expand key
    uint32_t round_keys[60];
    aes256_key_expand(key, round_keys);
    
    // CBC decryption
    uint8_t prev_block[16];
    uint8_t curr_block[16];
    memcpy(prev_block, iv, 16);
    
    for (size_t i = 0; i < ciphertext_len; i += 16) {
        memcpy(curr_block, &ciphertext[i], 16);
        
        // Decrypt block
        aes256_decrypt_block(&ciphertext[i], round_keys, &plaintext[i]);
        
        // XOR with previous ciphertext block (or IV)
        for (int j = 0; j < 16; j++) {
            plaintext[i + j] ^= prev_block[j];
        }
        
        // Save for next iteration
        memcpy(prev_block, curr_block, 16);
    }
    
    // Remove padding
    size_t unpadded_len = pkcs7_unpad(plaintext, ciphertext_len);
    if (unpadded_len == 0) {
        lqx10_secure_memzero(round_keys, sizeof(round_keys));
        return LQX10_ERROR_CRYPTO_FAILURE;
    }
    
    *plaintext_len = unpadded_len;
    
    // Secure cleanup
    lqx10_secure_memzero(round_keys, sizeof(round_keys));
    
    return LQX10_SUCCESS;
}

// =================== AES KEY SCHEDULE ===================

lqx10_error_t lqx10_aes_key_schedule_pure(const uint8_t *key, uint8_t round_keys[14][16]) {
    if (!key || !round_keys) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Copy original key as first round key
    memcpy(round_keys[0], key, 16);
    memcpy(round_keys[1], key + 16, 16);
    
    // AES-256 key expansion
    uint32_t *w = (uint32_t *)round_keys;
    uint32_t temp;
    
    for (int i = 8; i < 60; i++) {
        temp = w[i - 1];
        
        if (i % 8 == 0) {
            // SubWord and RotWord
            temp = (sbox[(temp >> 8) & 0xff] << 24) |
                   (sbox[(temp >> 16) & 0xff] << 16) |
                   (sbox[(temp >> 24) & 0xff] << 8) |
                   sbox[temp & 0xff];
            
            // XOR with round constant
            temp ^= rcon[i / 8];
        } else if (i % 8 == 4) {
            // SubWord only
            temp = (sbox[temp & 0xff]) |
                   (sbox[(temp >> 8) & 0xff] << 8) |
                   (sbox[(temp >> 16) & 0xff] << 16) |
                   (sbox[(temp >> 24) & 0xff] << 24);
        }
        
        w[i] = w[i - 8] ^ temp;
    }
    
    return LQX10_SUCCESS;
}

// =================== SHA-256 PURE IMPLEMENTATION ===================

// SHA-256 constants
static const uint32_t sha256_k[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
};

static uint32_t sha256_rotr(uint32_t x, uint32_t n) {
    return (x >> n) | (x << (32 - n));
}

static uint32_t sha256_ch(uint32_t x, uint32_t y, uint32_t z) {
    return (x & y) ^ (~x & z);
}

static uint32_t sha256_maj(uint32_t x, uint32_t y, uint32_t z) {
    return (x & y) ^ (x & z) ^ (y & z);
}

static uint32_t sha256_sigma0(uint32_t x) {
    return sha256_rotr(x, 2) ^ sha256_rotr(x, 13) ^ sha256_rotr(x, 22);
}

static uint32_t sha256_sigma1(uint32_t x) {
    return sha256_rotr(x, 6) ^ sha256_rotr(x, 11) ^ sha256_rotr(x, 25);
}

static uint32_t sha256_gamma0(uint32_t x) {
    return sha256_rotr(x, 7) ^ sha256_rotr(x, 18) ^ (x >> 3);
}

static uint32_t sha256_gamma1(uint32_t x) {
    return sha256_rotr(x, 17) ^ sha256_rotr(x, 19) ^ (x >> 10);
}

static void sha256_transform(uint32_t state[8], const uint8_t block[64]) {
    uint32_t w[64];
    uint32_t a, b, c, d, e, f, g, h;
    uint32_t t1, t2;
    
    // Prepare message schedule
    for (int i = 0; i < 16; i++) {
        w[i] = (block[i * 4] << 24) | (block[i * 4 + 1] << 16) |
               (block[i * 4 + 2] << 8) | block[i * 4 + 3];
    }
    
    for (int i = 16; i < 64; i++) {
        w[i] = sha256_gamma1(w[i - 2]) + w[i - 7] + sha256_gamma0(w[i - 15]) + w[i - 16];
    }
    
    // Initialize working variables
    a = state[0]; b = state[1]; c = state[2]; d = state[3];
    e = state[4]; f = state[5]; g = state[6]; h = state[7];
    
    // Main loop
    for (int i = 0; i < 64; i++) {
        t1 = h + sha256_sigma1(e) + sha256_ch(e, f, g) + sha256_k[i] + w[i];
        t2 = sha256_sigma0(a) + sha256_maj(a, b, c);
        h = g; g = f; f = e; e = d + t1;
        d = c; c = b; b = a; a = t1 + t2;
    }
    
    // Update state
    state[0] += a; state[1] += b; state[2] += c; state[3] += d;
    state[4] += e; state[5] += f; state[6] += g; state[7] += h;
}

lqx10_error_t lqx10_sha256_hash(const uint8_t *input, size_t input_len, uint8_t *output) {
    if (!input || !output || (input_len > 0 && !input)) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    uint32_t state[8] = {
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
        0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    };
    
    uint64_t total_bits = input_len * 8;
    size_t processed = 0;
    uint8_t block[64];
    
    // Process full 512-bit blocks
    while (processed + 64 <= input_len) {
        sha256_transform(state, input + processed);
        processed += 64;
    }
    
    // Handle final block with padding
    size_t remaining = input_len - processed;
    memcpy(block, input + processed, remaining);
    
    // Add padding bit
    block[remaining] = 0x80;
    remaining++;
    
    // Check if we need another block for length
    if (remaining > 56) {
        memset(block + remaining, 0, 64 - remaining);
        sha256_transform(state, block);
        memset(block, 0, 56);
    } else {
        memset(block + remaining, 0, 56 - remaining);
    }
    
    // Add length in bits (big-endian)
    for (int i = 0; i < 8; i++) {
        block[63 - i] = (total_bits >> (i * 8)) & 0xff;
    }
    
    sha256_transform(state, block);
    
    // Output hash (big-endian)
    for (int i = 0; i < 8; i++) {
        output[i * 4] = (state[i] >> 24) & 0xff;
        output[i * 4 + 1] = (state[i] >> 16) & 0xff;
        output[i * 4 + 2] = (state[i] >> 8) & 0xff;
        output[i * 4 + 3] = state[i] & 0xff;
    }
    
    return LQX10_SUCCESS;
}

// =================== HMAC-SHA256 PURE IMPLEMENTATION ===================

lqx10_error_t lqx10_hmac_sha256(const uint8_t *key, size_t key_len,
                                const uint8_t *data, size_t data_len,
                                uint8_t *output) {
    if (!key || !data || !output || key_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    uint8_t k_ipad[64], k_opad[64];
    uint8_t inner_hash[32];
    
    // Prepare key
    if (key_len > 64) {
        // Hash long keys
        lqx10_sha256_hash(key, key_len, k_ipad);
        memcpy(k_opad, k_ipad, 32);
        memset(k_ipad + 32, 0, 32);
        memset(k_opad + 32, 0, 32);
    } else {
        memcpy(k_ipad, key, key_len);
        memcpy(k_opad, key, key_len);
        memset(k_ipad + key_len, 0, 64 - key_len);
        memset(k_opad + key_len, 0, 64 - key_len);
    }
    
    // XOR with ipad and opad
    for (int i = 0; i < 64; i++) {
        k_ipad[i] ^= 0x36;
        k_opad[i] ^= 0x5c;
    }
    
    // Inner hash: H(K XOR ipad || message)
    uint8_t *inner_input = malloc(64 + data_len);
    if (!inner_input) {
        return LQX10_ERROR_MEMORY_ALLOCATION;
    }
    
    memcpy(inner_input, k_ipad, 64);
    memcpy(inner_input + 64, data, data_len);
    lqx10_sha256_hash(inner_input, 64 + data_len, inner_hash);
    
    // Outer hash: H(K XOR opad || inner_hash)
    uint8_t outer_input[64 + 32];
    memcpy(outer_input, k_opad, 64);
    memcpy(outer_input + 64, inner_hash, 32);
    lqx10_sha256_hash(outer_input, 96, output);
    
    // Secure cleanup
    lqx10_secure_memzero(k_ipad, sizeof(k_ipad));
    lqx10_secure_memzero(k_opad, sizeof(k_opad));
    lqx10_secure_memzero(inner_hash, sizeof(inner_hash));
    lqx10_secure_memzero(inner_input, 64 + data_len);
    lqx10_secure_memzero(outer_input, sizeof(outer_input));
    free(inner_input);
    
    return LQX10_SUCCESS;
}

// =================== PBKDF2 PURE IMPLEMENTATION ===================

lqx10_error_t lqx10_pbkdf2_sha256(const uint8_t *password, size_t password_len,
                                  const uint8_t *salt, size_t salt_len,
                                  uint32_t iterations, uint8_t *output, size_t output_len) {
    if (!password || !salt || !output || password_len == 0 || salt_len == 0 || 
        output_len == 0 || iterations == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    uint32_t block_count = (output_len + 31) / 32;
    uint8_t *salt_block = malloc(salt_len + 4);
    if (!salt_block) {
        return LQX10_ERROR_MEMORY_ALLOCATION;
    }
    
    memcpy(salt_block, salt, salt_len);
    
    for (uint32_t i = 1; i <= block_count; i++) {
        // Append block counter to salt (big-endian)
        salt_block[salt_len] = (i >> 24) & 0xff;
        salt_block[salt_len + 1] = (i >> 16) & 0xff;
        salt_block[salt_len + 2] = (i >> 8) & 0xff;
        salt_block[salt_len + 3] = i & 0xff;
        
        uint8_t u[32], t[32];
        
        // U1 = HMAC(password, salt || i)
        lqx10_hmac_sha256(password, password_len, salt_block, salt_len + 4, u);
        memcpy(t, u, 32);
        
        // U2 through Uc
        for (uint32_t j = 1; j < iterations; j++) {
            lqx10_hmac_sha256(password, password_len, u, 32, u);
            for (int k = 0; k < 32; k++) {
                t[k] ^= u[k];
            }
        }
        
        // Copy to output
        size_t copy_len = (i == block_count) ? (output_len - (i - 1) * 32) : 32;
        memcpy(output + (i - 1) * 32, t, copy_len);
        
        // Secure cleanup
        lqx10_secure_memzero(u, sizeof(u));
        lqx10_secure_memzero(t, sizeof(t));
    }
    
    lqx10_secure_memzero(salt_block, salt_len + 4);
    free(salt_block);
    
    return LQX10_SUCCESS;
}

// =================== SECURE RANDOM BYTES PURE IMPLEMENTATION ===================

lqx10_error_t lqx10_secure_random_bytes_pure(uint8_t *output, size_t output_len) {
    if (!output || output_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }

#ifdef _WIN32
    // Use RtlGenRandom (CryptGenRandom successor)
    HMODULE hAdvApi32 = LoadLibraryA("advapi32.dll");
    if (!hAdvApi32) {
        return LQX10_ERROR_ENTROPY_FAILURE;
    }
    
    typedef BOOLEAN (WINAPI *RtlGenRandomFunc)(PVOID RandomBuffer, ULONG RandomBufferLength);
    RtlGenRandomFunc pRtlGenRandom = (RtlGenRandomFunc)GetProcAddress(hAdvApi32, "SystemFunction036");
    
    if (!pRtlGenRandom) {
        FreeLibrary(hAdvApi32);
        return LQX10_ERROR_ENTROPY_FAILURE;
    }
    
    BOOLEAN result = pRtlGenRandom(output, (ULONG)output_len);
    FreeLibrary(hAdvApi32);
    
    return result ? LQX10_SUCCESS : LQX10_ERROR_ENTROPY_FAILURE;
    
#else
    // Try getrandom() system call first
#ifdef __linux__
    ssize_t result = syscall(SYS_getrandom, output, output_len, 0);
    if (result == (ssize_t)output_len) {
        return LQX10_SUCCESS;
    }
#endif
    
    // Fallback to /dev/urandom
    int fd = open("/dev/urandom", O_RDONLY);
    if (fd < 0) {
        return LQX10_ERROR_ENTROPY_FAILURE;
    }
    
    size_t bytes_read = 0;
    while (bytes_read < output_len) {
        ssize_t result = read(fd, output + bytes_read, output_len - bytes_read);
        if (result <= 0) {
            close(fd);
            return LQX10_ERROR_ENTROPY_FAILURE;
        }
        bytes_read += result;
    }
    
    close(fd);
    return LQX10_SUCCESS;
#endif
}

// =================== SECURE MEMORY ZERO PURE IMPLEMENTATION ===================

lqx10_error_t lqx10_secure_memzero_pure(void *ptr, size_t len) {
    if (!ptr || len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Prevent compiler optimization
    volatile uint8_t *p = (volatile uint8_t*)ptr;
    while (len--) {
        *p++ = 0;
    }
    
    // Memory barrier to ensure writes complete
#ifdef _WIN32
    MemoryBarrier();
#else
    __asm__ __volatile__("" ::: "memory");
#endif
    
    return LQX10_SUCCESS;
}

// =================== WRAPPER FUNCTIONS ===================

// Replace original functions with pure implementations
lqx10_error_t lqx10_aes_encrypt(const uint8_t *key,
                                const uint8_t *iv,
                                const uint8_t *plaintext,
                                size_t plaintext_len,
                                uint8_t *ciphertext,
                                size_t *ciphertext_len) {
    return lqx10_aes_encrypt_pure(key, iv, plaintext, plaintext_len, ciphertext, ciphertext_len);
}

lqx10_error_t lqx10_aes_decrypt(const uint8_t *key,
                                const uint8_t *iv,
                                const uint8_t *ciphertext,
                                size_t ciphertext_len,
                                uint8_t *plaintext,
                                size_t *plaintext_len) {
    return lqx10_aes_decrypt_pure(key, iv, ciphertext, ciphertext_len, plaintext, plaintext_len);
}

lqx10_error_t lqx10_blake3_hash(const uint8_t *input,
                                size_t input_len,
                                uint8_t *output,
                                size_t output_len) {
    // Use SHA-256 as BLAKE3 placeholder for now
    if (output_len < 32) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    uint8_t hash[32];
    lqx10_error_t result = lqx10_sha256_hash(input, input_len, hash);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    memcpy(output, hash, LQX10_MIN(output_len, 32));
    return LQX10_SUCCESS;
}

lqx10_error_t lqx10_kdf_derive(const uint8_t *password,
                               size_t password_len,
                               const uint8_t *salt,
                               size_t salt_len,
                               uint32_t iterations,
                               uint8_t *output,
                               size_t output_len) {
    return lqx10_pbkdf2_sha256(password, password_len, salt, salt_len, iterations, output, output_len);
}

lqx10_error_t lqx10_secure_random_bytes(uint8_t *output, size_t output_len) {
    return lqx10_secure_random_bytes_pure(output, output_len);
}

lqx10_error_t lqx10_secure_memzero(void *ptr, size_t len) {
    return lqx10_secure_memzero_pure(ptr, len);
} 