#include "../../include/lqx10_crypto.h"
#include <stdint.h>
#include <string.h>

// BLAKE3 constants
#define BLAKE3_BLOCK_LEN 64
#define BLAKE3_CHUNK_LEN 1024
#define BLAKE3_KEY_LEN 32
#define BLAKE3_OUT_LEN 32
#define BLAKE3_MAX_DEPTH 54

// BLAKE3 IV
static const uint32_t BLAKE3_IV[8] = {
    0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A,
    0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19
};

// BLAKE3 message permutation
static const uint8_t MSG_SCHEDULE[7][16] = {
    {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
    {2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8},
    {3, 4, 10, 12, 13, 2, 7, 14, 6, 5, 9, 0, 11, 15, 8, 1},
    {10, 7, 12, 9, 14, 3, 13, 15, 4, 0, 11, 2, 5, 8, 1, 6},
    {12, 13, 9, 11, 15, 10, 14, 8, 7, 2, 5, 3, 0, 1, 6, 4},
    {9, 14, 11, 5, 8, 12, 15, 1, 13, 3, 0, 10, 2, 6, 4, 7},
    {11, 15, 5, 0, 1, 9, 8, 6, 14, 10, 2, 12, 3, 4, 7, 13}
};

// BLAKE3 flags
enum blake3_flags {
    CHUNK_START = 1 << 0,
    CHUNK_END = 1 << 1,
    PARENT = 1 << 2,
    ROOT = 1 << 3,
    KEYED_HASH = 1 << 4,
    DERIVE_KEY_CONTEXT = 1 << 5,
    DERIVE_KEY_MATERIAL = 1 << 6,
};

// BLAKE3 hasher state
typedef struct {
    uint32_t key[8];
    uint8_t chunk[BLAKE3_CHUNK_LEN];
    uint8_t cv_stack[BLAKE3_MAX_DEPTH * 32];
    uint8_t cv_stack_len;
    uint32_t flags;
    size_t chunk_counter;
    size_t buf_len;
} blake3_hasher;

// Utility functions
static uint32_t rotr32(uint32_t w, uint32_t c) {
    return (w >> c) | (w << (32 - c));
}

static void words_from_little_endian_bytes(const uint8_t *bytes, size_t bytes_len, uint32_t *out) {
    for (size_t i = 0; i < bytes_len / 4; i++) {
        out[i] = ((uint32_t)bytes[i * 4]) |
                 ((uint32_t)bytes[i * 4 + 1] << 8) |
                 ((uint32_t)bytes[i * 4 + 2] << 16) |
                 ((uint32_t)bytes[i * 4 + 3] << 24);
    }
}

static void words_to_little_endian_bytes(const uint32_t *words, size_t words_len, uint8_t *out) {
    for (size_t i = 0; i < words_len; i++) {
        out[i * 4] = (uint8_t)words[i];
        out[i * 4 + 1] = (uint8_t)(words[i] >> 8);
        out[i * 4 + 2] = (uint8_t)(words[i] >> 16);
        out[i * 4 + 3] = (uint8_t)(words[i] >> 24);
    }
}

// BLAKE3 G function
static void g(uint32_t *state, size_t a, size_t b, size_t c, size_t d, uint32_t x, uint32_t y) {
    state[a] = state[a] + state[b] + x;
    state[d] = rotr32(state[d] ^ state[a], 16);
    state[c] = state[c] + state[d];
    state[b] = rotr32(state[b] ^ state[c], 12);
    state[a] = state[a] + state[b] + y;
    state[d] = rotr32(state[d] ^ state[a], 8);
    state[c] = state[c] + state[d];
    state[b] = rotr32(state[b] ^ state[c], 7);
}

// BLAKE3 round function
static void round_fn(uint32_t state[16], const uint32_t *msg, size_t round) {
    // Select message schedule
    const uint8_t *schedule = MSG_SCHEDULE[round];
    
    // Column step
    g(state, 0, 4, 8, 12, msg[schedule[0]], msg[schedule[1]]);
    g(state, 1, 5, 9, 13, msg[schedule[2]], msg[schedule[3]]);
    g(state, 2, 6, 10, 14, msg[schedule[4]], msg[schedule[5]]);
    g(state, 3, 7, 11, 15, msg[schedule[6]], msg[schedule[7]]);
    
    // Diagonal step
    g(state, 0, 5, 10, 15, msg[schedule[8]], msg[schedule[9]]);
    g(state, 1, 6, 11, 12, msg[schedule[10]], msg[schedule[11]]);
    g(state, 2, 7, 8, 13, msg[schedule[12]], msg[schedule[13]]);
    g(state, 3, 4, 9, 14, msg[schedule[14]], msg[schedule[15]]);
}

// BLAKE3 compress function
static void blake3_compress_in_place(
    uint32_t cv[8],
    const uint8_t block[BLAKE3_BLOCK_LEN],
    uint8_t block_len,
    uint64_t counter,
    uint8_t flags
) {
    uint32_t block_words[16];
    words_from_little_endian_bytes(block, BLAKE3_BLOCK_LEN, block_words);
    
    uint32_t state[16] = {
        cv[0], cv[1], cv[2], cv[3],
        cv[4], cv[5], cv[6], cv[7],
        BLAKE3_IV[0], BLAKE3_IV[1], BLAKE3_IV[2], BLAKE3_IV[3],
        (uint32_t)counter, (uint32_t)(counter >> 32), (uint32_t)block_len, (uint32_t)flags
    };
    
    // 7 rounds
    for (size_t round = 0; round < 7; round++) {
        round_fn(state, block_words, round);
    }
    
    // Finalization
    for (size_t i = 0; i < 8; i++) {
        cv[i] = state[i] ^ state[i + 8];
    }
}

static void blake3_compress_xof(
    const uint32_t cv[8],
    const uint8_t block[BLAKE3_BLOCK_LEN],
    uint8_t block_len,
    uint64_t counter,
    uint8_t flags,
    uint8_t out[64]
) {
    uint32_t cv_copy[8];
    memcpy(cv_copy, cv, sizeof(cv_copy));
    blake3_compress_in_place(cv_copy, block, block_len, counter, flags);
    words_to_little_endian_bytes(cv_copy, 8, out);
    words_to_little_endian_bytes(cv, 8, out + 32);
}

// BLAKE3 chunk processing
static void blake3_chunk_state_init(blake3_hasher *self, const uint32_t key[8], uint8_t flags) {
    memcpy(self->key, key, 32);
    self->chunk_counter = 0;
    self->buf_len = 0;
    self->cv_stack_len = 0;
    self->flags = flags;
}

static size_t blake3_chunk_state_len(const blake3_hasher *self) {
    return BLAKE3_BLOCK_LEN * self->chunk_counter + self->buf_len;
}

static uint32_t blake3_chunk_state_start_flag(const blake3_hasher *self) {
    return self->chunk_counter == 0 ? CHUNK_START : 0;
}

static void blake3_chunk_state_update(blake3_hasher *self, const uint8_t *input, size_t input_len) {
    if (self->buf_len > 0) {
        size_t fill = BLAKE3_BLOCK_LEN - self->buf_len;
        if (input_len <= fill) {
            memcpy(&self->chunk[self->buf_len], input, input_len);
            self->buf_len += input_len;
            return;
        }
        
        memcpy(&self->chunk[self->buf_len], input, fill);
        input += fill;
        input_len -= fill;
        
        uint8_t block_flags = blake3_chunk_state_start_flag(self);
        blake3_compress_in_place(self->key, self->chunk, BLAKE3_BLOCK_LEN, self->chunk_counter, self->flags | block_flags);
        self->chunk_counter++;
        self->buf_len = 0;
        memset(self->chunk, 0, BLAKE3_BLOCK_LEN);
    }
    
    while (input_len > BLAKE3_BLOCK_LEN) {
        uint8_t block_flags = blake3_chunk_state_start_flag(self);
        blake3_compress_in_place(self->key, input, BLAKE3_BLOCK_LEN, self->chunk_counter, self->flags | block_flags);
        self->chunk_counter++;
        input += BLAKE3_BLOCK_LEN;
        input_len -= BLAKE3_BLOCK_LEN;
    }
    
    if (input_len > 0) {
        memcpy(self->chunk, input, input_len);
        self->buf_len = input_len;
    }
}

static void blake3_chunk_state_finalize(const blake3_hasher *self, uint8_t cv[32]) {
    uint8_t block_flags = blake3_chunk_state_start_flag(self) | CHUNK_END;
    uint32_t cv_words[8];
    memcpy(cv_words, self->key, 32);
    blake3_compress_in_place(cv_words, self->chunk, (uint8_t)self->buf_len, self->chunk_counter, self->flags | block_flags);
    words_to_little_endian_bytes(cv_words, 8, cv);
}

// Parent node hashing
static void parent_cv(const uint8_t child_cv_left[32], const uint8_t child_cv_right[32], 
                      const uint32_t key[8], uint8_t flags, uint8_t out[32]) {
    uint8_t block[64];
    memcpy(block, child_cv_left, 32);
    memcpy(block + 32, child_cv_right, 32);
    
    uint32_t cv[8];
    memcpy(cv, key, 32);
    blake3_compress_in_place(cv, block, BLAKE3_BLOCK_LEN, 0, flags | PARENT);
    words_to_little_endian_bytes(cv, 8, out);
}

// BLAKE3 hasher implementation
static void blake3_hasher_init(blake3_hasher *self) {
    blake3_chunk_state_init(self, BLAKE3_IV, 0);
}

void blake3_hasher_init_keyed(blake3_hasher *self, const uint8_t key[32]) {
    uint32_t key_words[8];
    words_from_little_endian_bytes(key, 32, key_words);
    blake3_chunk_state_init(self, key_words, KEYED_HASH);
}

static void blake3_hasher_push_cv(blake3_hasher *self, uint8_t new_cv[32], uint64_t chunk_counter) {
    while (chunk_counter & 1) {
        uint8_t parent_cv_out[32];
        parent_cv(&self->cv_stack[(self->cv_stack_len - 1) * 32], new_cv, self->key, self->flags, parent_cv_out);
        memcpy(new_cv, parent_cv_out, 32);
        self->cv_stack_len -= 1;
        chunk_counter >>= 1;
    }
    
    memcpy(&self->cv_stack[self->cv_stack_len * 32], new_cv, 32);
    self->cv_stack_len += 1;
}

static void blake3_hasher_update(blake3_hasher *self, const uint8_t *input, size_t input_len) {
    while (input_len > 0) {
        if (blake3_chunk_state_len(self) == BLAKE3_CHUNK_LEN) {
            uint8_t chunk_cv[32];
            blake3_chunk_state_finalize(self, chunk_cv);
            uint64_t total_chunks = self->chunk_counter + 1;
            blake3_hasher_push_cv(self, chunk_cv, total_chunks);
            blake3_chunk_state_init(self, self->key, self->flags);
        }
        
        size_t want = BLAKE3_CHUNK_LEN - blake3_chunk_state_len(self);
        size_t take = (input_len < want) ? input_len : want;
        blake3_chunk_state_update(self, input, take);
        input += take;
        input_len -= take;
    }
}

static void blake3_hasher_finalize(const blake3_hasher *self, uint8_t *out, size_t out_len) {
    uint8_t node_cv[32];
    blake3_chunk_state_finalize(self, node_cv);
    
    uint8_t parent_nodes_remaining = self->cv_stack_len;
    while (parent_nodes_remaining > 0) {
        parent_nodes_remaining -= 1;
        uint8_t parent_cv_out[32];
        parent_cv(&self->cv_stack[parent_nodes_remaining * 32], node_cv, self->key, self->flags, parent_cv_out);
        memcpy(node_cv, parent_cv_out, 32);
    }
    
    uint32_t cv_words[8];
    words_from_little_endian_bytes(node_cv, 32, cv_words);
    
    uint8_t wide_buf[64];
    size_t output_block_counter = 0;
    while (out_len > 0) {
        uint8_t block_buffer[BLAKE3_BLOCK_LEN] = {0};
        memcpy(block_buffer, node_cv, 32);
        blake3_compress_xof(cv_words, block_buffer, 32, output_block_counter, self->flags | ROOT, wide_buf);
        size_t take = (out_len < 64) ? out_len : 64;
        memcpy(out, wide_buf, take);
        out += take;
        out_len -= take;
        output_block_counter += 1;
    }
}

// Public BLAKE3 interface
lqx10_error_t lqx10_blake3_hash_pure(const uint8_t *input, size_t input_len, uint8_t *output, size_t output_len) {
    if (!output || output_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (input_len > 0 && !input) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    blake3_hasher hasher;
    blake3_hasher_init(&hasher);
    
    if (input_len > 0) {
        blake3_hasher_update(&hasher, input, input_len);
    }
    
    blake3_hasher_finalize(&hasher, output, output_len);
    
    // Secure cleanup
    lqx10_secure_memzero(&hasher, sizeof(hasher));
    
    return LQX10_SUCCESS;
}

// Replace BLAKE3 implementation
lqx10_error_t lqx10_blake3_hash(const uint8_t *input, size_t input_len, uint8_t *output, size_t output_len) {
    return lqx10_blake3_hash_pure(input, input_len, output, output_len);
} 