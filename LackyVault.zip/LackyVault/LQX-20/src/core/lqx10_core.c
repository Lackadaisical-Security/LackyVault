#include "../../include/lqx10_core.h"
#include "../../include/lqx10_crypto.h"
#include "../../include/lqx10_layers.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#ifdef _WIN32
#include <windows.h>
#include <wincrypt.h>
#include <bcrypt.h>
#ifdef _MSC_VER
#pragma comment(lib, "bcrypt.lib")
#pragma comment(lib, "advapi32.lib")
#endif
#else
#include <sys/random.h>
#include <sys/mman.h>
#include <unistd.h>
#endif

// Global variables for runtime mutation
static uint32_t g_mutation_seed = 0;
static bool g_anti_debug_enabled = true;

// Error string lookup table
static const char* error_strings[] = {
    "Success",
    "Invalid parameter",
    "Buffer too small", 
    "Cryptographic failure",
    "Memory allocation failure",
    "Invalid key",
    "Invalid layer",
    "Authentication failure",
    "Post-quantum failure",
    "Entropy failure",
    "Runtime mutation failure"
};

// Internal helper functions
static lqx10_error_t secure_allocate(void **ptr, size_t size);
static lqx10_error_t secure_deallocate(void *ptr, size_t size);
static lqx10_error_t hardware_random_bytes(uint8_t *output, size_t len);
static lqx10_error_t software_random_bytes(uint8_t *output, size_t len);
static void runtime_mutation_step(lqx10_context_t *ctx);
static bool anti_debug_check_internal(void);

// Initialize LQX-10 context
lqx10_error_t lqx10_init(lqx10_context_t **ctx) {
    if (!ctx) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Allocate secure memory for context
    lqx10_context_t *new_ctx;
    lqx10_error_t result = secure_allocate((void**)&new_ctx, sizeof(lqx10_context_t));
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Initialize context to zero
    LQX10_SECURE_ZERO(new_ctx, sizeof(lqx10_context_t));
    
    // Generate random salt
    result = lqx10_secure_random_bytes(new_ctx->salt, LQX10_SALT_SIZE);
    if (result != LQX10_SUCCESS) {
        secure_deallocate(new_ctx, sizeof(lqx10_context_t));
        return result;
    }
    
    // Initialize key schedule
    result = secure_allocate((void**)&new_ctx->key_schedule, sizeof(lqx10_key_schedule_t));
    if (result != LQX10_SUCCESS) {
        secure_deallocate(new_ctx, sizeof(lqx10_context_t));
        return result;
    }
    
    LQX10_SECURE_ZERO(new_ctx->key_schedule, sizeof(lqx10_key_schedule_t));
    
    // Initialize layer states
    for (int i = 0; i < LQX10_LAYER_COUNT; i++) {
        result = secure_allocate((void**)&new_ctx->layer_states[i], sizeof(lqx10_layer_state_t));
        if (result != LQX10_SUCCESS) {
            // Cleanup on failure
            for (int j = 0; j < i; j++) {
                secure_deallocate(new_ctx->layer_states[j], sizeof(lqx10_layer_state_t));
            }
            secure_deallocate(new_ctx->key_schedule, sizeof(lqx10_key_schedule_t));
            secure_deallocate(new_ctx, sizeof(lqx10_context_t));
            return result;
        }
        
        LQX10_SECURE_ZERO(new_ctx->layer_states[i], sizeof(lqx10_layer_state_t));
        new_ctx->layer_states[i]->type = (lqx10_layer_type_t)i;
    }
    
    // Initialize runtime state
    new_ctx->operation_counter = 0;
    hardware_random_bytes((uint8_t*)&new_ctx->mutation_seed, sizeof(new_ctx->mutation_seed));
    new_ctx->is_initialized = true;
    new_ctx->distress_mode = false;
    
    // Set security flags
    new_ctx->anti_debug_enabled = true;
    new_ctx->runtime_mutation_enabled = true;
    new_ctx->network_camouflage_enabled = true;
    new_ctx->metadata_encryption_enabled = true;
    
    // Perform initial anti-debug check
    if (new_ctx->anti_debug_enabled && !anti_debug_check_internal()) {
        lqx10_destroy(new_ctx);
        return LQX10_ERROR_CRYPTO_FAILURE;
    }
    
    *ctx = new_ctx;
    return LQX10_SUCCESS;
}

// Destroy LQX-10 context
lqx10_error_t lqx10_destroy(lqx10_context_t *ctx) {
    if (!ctx) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Securely zero all sensitive data
    LQX10_SECURE_ZERO(ctx->master_key, sizeof(ctx->master_key));
    LQX10_SECURE_ZERO(ctx->current_iv, sizeof(ctx->current_iv));
    LQX10_SECURE_ZERO(ctx->salt, sizeof(ctx->salt));
    
    // Cleanup layer states
    for (int i = 0; i < LQX10_LAYER_COUNT; i++) {
        if (ctx->layer_states[i]) {
            lqx10_layer_cleanup(ctx->layer_states[i]);
            secure_deallocate(ctx->layer_states[i], sizeof(lqx10_layer_state_t));
        }
    }
    
    // Cleanup key schedule
    if (ctx->key_schedule) {
        LQX10_SECURE_ZERO(ctx->key_schedule, sizeof(lqx10_key_schedule_t));
        secure_deallocate(ctx->key_schedule, sizeof(lqx10_key_schedule_t));
    }
    
    // Zero the context itself
    LQX10_SECURE_ZERO(ctx, sizeof(lqx10_context_t));
    secure_deallocate(ctx, sizeof(lqx10_context_t));
    
    return LQX10_SUCCESS;
}

// Key derivation function using PBKDF2 + Argon2id hybrid
lqx10_error_t lqx10_key_derive(lqx10_context_t *ctx, 
                               const uint8_t *password, 
                               size_t password_len,
                               const uint8_t *salt,
                               size_t salt_len,
                               uint32_t iterations) {
    if (!ctx || !password || password_len == 0 || !salt || salt_len == 0 || iterations == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Anti-debug check
    if (ctx->anti_debug_enabled && !anti_debug_check_internal()) {
        return LQX10_ERROR_CRYPTO_FAILURE;
    }
    
    // Use provided salt or context salt
    const uint8_t *kdf_salt = salt_len > 0 ? salt : ctx->salt;
    size_t kdf_salt_len = salt_len > 0 ? salt_len : LQX10_SALT_SIZE;
    
    // Derive master key using hybrid KDF
    lqx10_error_t result = lqx10_kdf_derive(password, password_len,
                                            kdf_salt, kdf_salt_len,
                                            iterations,
                                            ctx->master_key, LQX10_KEY_SIZE);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Generate IV from master key and salt
    uint8_t iv_material[LQX10_KEY_SIZE + LQX10_SALT_SIZE];
    memcpy(iv_material, ctx->master_key, LQX10_KEY_SIZE);
    memcpy(iv_material + LQX10_KEY_SIZE, kdf_salt, LQX10_MIN(kdf_salt_len, LQX10_SALT_SIZE));
    
    result = lqx10_blake3_hash(iv_material, sizeof(iv_material),
                               ctx->current_iv, LQX10_IV_SIZE);
    if (result != LQX10_SUCCESS) {
        LQX10_SECURE_ZERO(ctx->master_key, LQX10_KEY_SIZE);
        return result;
    }
    
    // Update key schedule
    result = lqx10_key_schedule_update(ctx);
    if (result != LQX10_SUCCESS) {
        LQX10_SECURE_ZERO(ctx->master_key, LQX10_KEY_SIZE);
        LQX10_SECURE_ZERO(ctx->current_iv, LQX10_IV_SIZE);
        return result;
    }
    
    // Initialize all layers with derived keys
    for (int i = 0; i < LQX10_LAYER_COUNT; i++) {
        result = lqx10_layer_init(ctx->layer_states[i], (lqx10_layer_type_t)i,
                                  ctx->key_schedule->round_keys[i]);
        if (result != LQX10_SUCCESS) {
            // Cleanup on failure
            for (int j = 0; j < i; j++) {
                lqx10_layer_cleanup(ctx->layer_states[j]);
            }
            LQX10_SECURE_ZERO(ctx->master_key, LQX10_KEY_SIZE);
            LQX10_SECURE_ZERO(ctx->current_iv, LQX10_IV_SIZE);
            return result;
        }
    }
    
    LQX10_SECURE_ZERO(iv_material, sizeof(iv_material));
    return LQX10_SUCCESS;
}

// Key schedule update
lqx10_error_t lqx10_key_schedule_update(lqx10_context_t *ctx) {
    if (!ctx || !ctx->is_initialized) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Generate round keys for each layer using HKDF
    for (int i = 0; i < LQX10_LAYER_COUNT; i++) {
        uint8_t info[32];
        snprintf((char*)info, sizeof(info), "LQX10_LAYER_%d", i);
        
        lqx10_error_t result = lqx10_hkdf_expand(ctx->master_key, LQX10_KEY_SIZE,
                                                 info, strlen((char*)info),
                                                 ctx->key_schedule->round_keys[i],
                                                 LQX10_KEY_SIZE);
        if (result != LQX10_SUCCESS) {
            return result;
        }
        
        // Generate layer-specific IVs
        uint8_t iv_info[32];
        snprintf((char*)iv_info, sizeof(iv_info), "LQX10_IV_%d", i);
        
        result = lqx10_hkdf_expand(ctx->master_key, LQX10_KEY_SIZE,
                                   iv_info, strlen((char*)iv_info),
                                   ctx->key_schedule->layer_ivs[i],
                                   LQX10_IV_SIZE);
        if (result != LQX10_SUCCESS) {
            return result;
        }
    }
    
    // Fill entropy pool
    lqx10_error_t result = lqx10_secure_random_bytes((uint8_t*)ctx->key_schedule->entropy_pool,
                                                     sizeof(ctx->key_schedule->entropy_pool));
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    ctx->key_schedule->rotation_counter = 0;
    ctx->key_schedule->keys_valid = true;
    
    return LQX10_SUCCESS;
}

// Main encryption function
lqx10_error_t lqx10_encrypt(lqx10_context_t *ctx,
                            const uint8_t *plaintext,
                            size_t plaintext_len,
                            uint8_t *ciphertext,
                            size_t *ciphertext_len) {
    if (!ctx || !plaintext || !ciphertext || !ciphertext_len || plaintext_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (!ctx->is_initialized || !ctx->key_schedule->keys_valid) {
        return LQX10_ERROR_INVALID_KEY;
    }
    
    // Anti-debug check
    if (ctx->anti_debug_enabled && !anti_debug_check_internal()) {
        return LQX10_ERROR_CRYPTO_FAILURE;
    }
    
    // Runtime mutation step
    if (ctx->runtime_mutation_enabled) {
        runtime_mutation_step(ctx);
    }
    
    // Calculate required output size (input + headers + padding)
    size_t required_size = plaintext_len + (LQX10_LAYER_COUNT * 64) + 256;
    if (*ciphertext_len < required_size) {
        *ciphertext_len = required_size;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Process through all 10 layers
    uint8_t *current_input = (uint8_t*)plaintext;
    size_t current_input_len = plaintext_len;
    uint8_t *layer_output = malloc(required_size * 2); // Double buffer for safety
    size_t layer_output_len = required_size * 2;
    
    if (!layer_output) {
        return LQX10_ERROR_MEMORY_ALLOCATION;
    }
    
    for (int layer = 0; layer < LQX10_LAYER_COUNT; layer++) {
        lqx10_error_t result = lqx10_layer_process(ctx, (lqx10_layer_type_t)layer,
                                                   current_input, current_input_len,
                                                   layer_output, &layer_output_len,
                                                   true); // encrypt = true
        if (result != LQX10_SUCCESS) {
            lqx10_secure_zero(layer_output, required_size * 2);
            free(layer_output);
            return result;
        }
        
        // Swap buffers for next layer
        if (layer > 0) {
            lqx10_secure_zero(current_input, current_input_len);
            free(current_input);
        }
        
        current_input = layer_output;
        current_input_len = layer_output_len;
        
        // Allocate new output buffer for next layer
        if (layer < LQX10_LAYER_COUNT - 1) {
            layer_output = malloc(required_size * 2);
            layer_output_len = required_size * 2;
            if (!layer_output) {
                lqx10_secure_zero(current_input, current_input_len);
                free(current_input);
                return LQX10_ERROR_MEMORY_ALLOCATION;
            }
        }
    }
    
    // Copy final result to output
    if (current_input_len <= *ciphertext_len) {
        memcpy(ciphertext, current_input, current_input_len);
        *ciphertext_len = current_input_len;
    } else {
        *ciphertext_len = current_input_len;
        lqx10_secure_zero(current_input, current_input_len);
        free(current_input);
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Increment operation counter
    ctx->operation_counter++;
    
    // Auto-rotate keys if needed
    if (ctx->operation_counter % 10000 == 0) {
        lqx10_key_rotate(ctx);
    }
    
    // Cleanup
    lqx10_secure_zero(current_input, current_input_len);
    free(current_input);
    
    return LQX10_SUCCESS;
}

// Main decryption function
lqx10_error_t lqx10_decrypt(lqx10_context_t *ctx,
                            const uint8_t *ciphertext,
                            size_t ciphertext_len,
                            uint8_t *plaintext,
                            size_t *plaintext_len) {
    if (!ctx || !ciphertext || !plaintext || !plaintext_len || ciphertext_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (!ctx->is_initialized || !ctx->key_schedule->keys_valid) {
        return LQX10_ERROR_INVALID_KEY;
    }
    
    // Anti-debug check
    if (ctx->anti_debug_enabled && !anti_debug_check_internal()) {
        return LQX10_ERROR_CRYPTO_FAILURE;
    }
    
    // Calculate required output size
    size_t required_size = ciphertext_len + 256; // Extra space for decryption
    if (*plaintext_len < required_size) {
        *plaintext_len = required_size;
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Process through all 10 layers in reverse order
    uint8_t *current_input = malloc(ciphertext_len);
    size_t current_input_len = ciphertext_len;
    uint8_t *layer_output = malloc(required_size * 2);
    size_t layer_output_len = required_size * 2;
    
    if (!current_input || !layer_output) {
        if (current_input) free(current_input);
        if (layer_output) free(layer_output);
        return LQX10_ERROR_MEMORY_ALLOCATION;
    }
    
    memcpy(current_input, ciphertext, ciphertext_len);
    
    // Decrypt through layers in reverse order (9 down to 0)
    for (int layer = LQX10_LAYER_COUNT - 1; layer >= 0; layer--) {
        lqx10_error_t result = lqx10_layer_process(ctx, (lqx10_layer_type_t)layer,
                                                   current_input, current_input_len,
                                                   layer_output, &layer_output_len,
                                                   false); // decrypt = false
        if (result != LQX10_SUCCESS) {
            lqx10_secure_zero(current_input, current_input_len);
            lqx10_secure_zero(layer_output, required_size * 2);
            free(current_input);
            free(layer_output);
            return result;
        }
        
        // Swap buffers for next layer
        lqx10_secure_zero(current_input, current_input_len);
        free(current_input);
        
        current_input = layer_output;
        current_input_len = layer_output_len;
        
        // Allocate new output buffer for next layer
        if (layer > 0) {
            layer_output = malloc(required_size * 2);
            layer_output_len = required_size * 2;
            if (!layer_output) {
                lqx10_secure_zero(current_input, current_input_len);
                free(current_input);
                return LQX10_ERROR_MEMORY_ALLOCATION;
            }
        }
    }
    
    // Copy final result to output
    if (current_input_len <= *plaintext_len) {
        memcpy(plaintext, current_input, current_input_len);
        *plaintext_len = current_input_len;
    } else {
        *plaintext_len = current_input_len;
        lqx10_secure_zero(current_input, current_input_len);
        free(current_input);
        return LQX10_ERROR_BUFFER_TOO_SMALL;
    }
    
    // Increment operation counter
    ctx->operation_counter++;
    
    // Cleanup
    lqx10_secure_zero(current_input, current_input_len);
    free(current_input);
    
    return LQX10_SUCCESS;
}

// Key rotation function
lqx10_error_t lqx10_key_rotate(lqx10_context_t *ctx) {
    if (!ctx || !ctx->is_initialized) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Generate new entropy for key rotation
    uint8_t entropy[32];
    lqx10_error_t result = lqx10_secure_random_bytes(entropy, sizeof(entropy));
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Mix entropy with current master key
    uint8_t mixed_key[LQX10_KEY_SIZE];
    for (size_t i = 0; i < LQX10_KEY_SIZE; i++) {
        mixed_key[i] = ctx->master_key[i] ^ entropy[i];
    }
    
    // Hash to create new master key
    result = lqx10_blake3_hash(mixed_key, LQX10_KEY_SIZE, ctx->master_key, LQX10_KEY_SIZE);
    if (result != LQX10_SUCCESS) {
        lqx10_secure_zero(mixed_key, LQX10_KEY_SIZE);
        return result;
    }
    
    // Update key schedule
    result = lqx10_key_schedule_update(ctx);
    
    // Cleanup
    lqx10_secure_zero(entropy, sizeof(entropy));
    lqx10_secure_zero(mixed_key, LQX10_KEY_SIZE);
    
    return result;
}

// Anti-debug check
lqx10_error_t lqx10_anti_debug_check(lqx10_context_t *ctx) {
    if (!ctx) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (!ctx->anti_debug_enabled || !g_anti_debug_enabled) {
        return LQX10_SUCCESS;
    }
    
    return anti_debug_check_internal() ? LQX10_SUCCESS : LQX10_ERROR_CRYPTO_FAILURE;
}

// Error string function
const char* lqx10_error_string(lqx10_error_t error) {
    int error_index = -error;
    if (error_index >= 0 && error_index < (int)(sizeof(error_strings) / sizeof(error_strings[0]))) {
        return error_strings[error_index];
    }
    return "Unknown error";
}

// Secure memory allocation
static lqx10_error_t secure_allocate(void **ptr, size_t size) {
    if (!ptr || size == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
#ifdef _WIN32
    *ptr = VirtualAlloc(NULL, size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!*ptr) {
        return LQX10_ERROR_MEMORY_ALLOCATION;
    }
    
    // Lock memory to prevent swapping
    if (!VirtualLock(*ptr, size)) {
        VirtualFree(*ptr, 0, MEM_RELEASE);
        return LQX10_ERROR_MEMORY_ALLOCATION;
    }
#else
    *ptr = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (*ptr == MAP_FAILED) {
        return LQX10_ERROR_MEMORY_ALLOCATION;
    }
    
    if (mlock(*ptr, size) != 0) {
        munmap(*ptr, size);
        return LQX10_ERROR_MEMORY_ALLOCATION;
    }
#endif
    
    return LQX10_SUCCESS;
}

// Secure memory deallocation
static lqx10_error_t secure_deallocate(void *ptr, size_t size) {
    if (!ptr || size == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Zero memory before freeing
    lqx10_secure_zero(ptr, size);
    
#ifdef _WIN32
    VirtualUnlock(ptr, size);
    VirtualFree(ptr, 0, MEM_RELEASE);
#else
    munlock(ptr, size);
    munmap(ptr, size);
#endif
    
    return LQX10_SUCCESS;
}

// Hardware random bytes
static lqx10_error_t hardware_random_bytes(uint8_t *output, size_t len) {
#ifdef _WIN32
    BCRYPT_ALG_HANDLE hAlgorithm = NULL;
    NTSTATUS status = BCryptOpenAlgorithmProvider(&hAlgorithm, BCRYPT_RNG_ALGORITHM, NULL, 0);
    if (!BCRYPT_SUCCESS(status)) {
        return LQX10_ERROR_ENTROPY_FAILURE;
    }
    
    status = BCryptGenRandom(hAlgorithm, output, (ULONG)len, 0);
    BCryptCloseAlgorithmProvider(hAlgorithm, 0);
    
    return BCRYPT_SUCCESS(status) ? LQX10_SUCCESS : LQX10_ERROR_ENTROPY_FAILURE;
#else
    return (getrandom(output, len, 0) == (ssize_t)len) ? LQX10_SUCCESS : LQX10_ERROR_ENTROPY_FAILURE;
#endif
}

// Anti-debug check implementation
static bool anti_debug_check_internal(void) {
#ifdef _WIN32
    // Check if debugger is present
    if (IsDebuggerPresent()) {
        return false;
    }
    
    // Check remote debugger
    BOOL remote_debugger = FALSE;
    CheckRemoteDebuggerPresent(GetCurrentProcess(), &remote_debugger);
    if (remote_debugger) {
        return false;
    }
    
    // Timing attack detection
    LARGE_INTEGER start, end, freq;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&start);
    
    // Simple operation that should be fast
    volatile int dummy = 0;
    for (int i = 0; i < 1000; i++) {
        dummy += i;
    }
    
    QueryPerformanceCounter(&end);
    double elapsed = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
    
    // If it took too long, might be under debugging
    if (elapsed > 0.001) { // More than 1ms for simple loop
        return false;
    }
    
    return true;
#else
    return true; // Simplified for non-Windows
#endif
}

// Runtime mutation step
static void runtime_mutation_step(lqx10_context_t *ctx) {
    if (!ctx) return;
    
    // Simple mutation: XOR mutation seed with operation counter
    ctx->mutation_seed ^= (uint32_t)(ctx->operation_counter & 0xFFFFFFFF);
    
    // Update global mutation seed
    g_mutation_seed = ctx->mutation_seed;
}

// Context validation function
lqx10_error_t lqx10_context_validate(lqx10_context_t *ctx) {
    if (!ctx) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (!ctx->is_initialized) {
        return LQX10_ERROR_CONTEXT_CORRUPTED;
    }
    
    // Check if key schedule is valid
    if (!ctx->key_schedule || !ctx->key_schedule->keys_valid) {
        return LQX10_ERROR_INVALID_KEY;
    }
    
    // Check layer states
    for (int i = 0; i < LQX10_LAYER_COUNT; i++) {
        if (!ctx->layer_states[i]) {
            return LQX10_ERROR_INVALID_LAYER;
        }
    }
    
    // Basic integrity check
    if (ctx->operation_counter > UINT64_MAX - 1000) {
        return LQX10_ERROR_CONTEXT_CORRUPTED;
    }
    
    return LQX10_SUCCESS;
}

// Version information
lqx10_error_t lqx10_get_version(uint32_t *major, uint32_t *minor, uint32_t *patch) {
    if (!major || !minor || !patch) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    *major = LQX10_VERSION_MAJOR;
    *minor = LQX10_VERSION_MINOR;
    *patch = LQX10_VERSION_PATCH;
    
    return LQX10_SUCCESS;
}

// Secure zero implementation
lqx10_error_t lqx10_secure_zero(void *ptr, size_t len) {
    if (!ptr || len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Use platform-specific secure memory clearing
#ifdef _WIN32
    SecureZeroMemory(ptr, len);
#else
    // Use volatile to prevent compiler optimization
    volatile uint8_t *p = (volatile uint8_t*)ptr;
    while (len--) {
        *p++ = 0;
    }
    // Memory barrier
    __asm__ __volatile__("" ::: "memory");
#endif
    
    return LQX10_SUCCESS;
}

// Secure random bytes implementation
lqx10_error_t lqx10_secure_random_bytes(uint8_t *output, size_t output_len) {
    if (!output || output_len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Try hardware random first
    lqx10_error_t result = hardware_random_bytes(output, output_len);
    if (result == LQX10_SUCCESS) {
        return LQX10_SUCCESS;
    }
    
    // Fallback to software random
    return software_random_bytes(output, output_len);
}

// Software random bytes fallback
static lqx10_error_t software_random_bytes(uint8_t *output, size_t len) {
    if (!output || len == 0) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Simple PRNG based on current time and static seed
    static uint64_t seed = 0;
    if (seed == 0) {
        seed = (uint64_t)time(NULL) ^ (uint64_t)clock();
    }
    
    for (size_t i = 0; i < len; i++) {
        seed = seed * 1103515245 + 12345;
        output[i] = (uint8_t)(seed >> 32);
    }
    
    return LQX10_SUCCESS;
}

// Distress mode functions
lqx10_error_t lqx10_enable_distress_mode(lqx10_context_t *ctx, const uint8_t *distress_key) {
    if (!ctx || !distress_key) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    ctx->distress_mode = true;
    
    // In distress mode, use alternate key derivation
    memcpy(ctx->master_key, distress_key, LQX10_KEY_SIZE);
    
    return lqx10_key_schedule_update(ctx);
}

lqx10_error_t lqx10_disable_distress_mode(lqx10_context_t *ctx) {
    if (!ctx) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    ctx->distress_mode = false;
    return LQX10_SUCCESS;
}

// Runtime mutation
lqx10_error_t lqx10_runtime_mutate(lqx10_context_t *ctx) {
    if (!ctx) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (!ctx->runtime_mutation_enabled) {
        return LQX10_SUCCESS;
    }
    
    runtime_mutation_step(ctx);
    return LQX10_SUCCESS;
}
