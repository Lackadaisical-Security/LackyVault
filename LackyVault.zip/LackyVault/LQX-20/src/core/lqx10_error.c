/**
 * @file lqx10_error.c
 * @brief LQX-10 Error Handling Implementation
 * 
 * Comprehensive error handling and reporting for LQX-10 operations.
 * Provides secure error reporting without information leakage.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../../include/lqx10_core.h"
#include <string.h>
#include <stdio.h>

#ifdef _WIN32
#define SECURE_STRCPY(dest, dest_size, src) strcpy_s(dest, dest_size, src)
#define SECURE_STRNCPY(dest, dest_size, src, count) strncpy_s(dest, dest_size, src, count)
#else
#define SECURE_STRCPY(dest, dest_size, src) strcpy(dest, src)
#define SECURE_STRNCPY(dest, dest_size, src, count) strncpy(dest, src, count)
#endif

// Error code to string mapping - using absolute values for negative error codes
static const char* error_messages[] = {
    "Operation completed successfully",                     // LQX10_SUCCESS = 0
    "Invalid parameter provided",                          // LQX10_ERROR_INVALID_PARAM = -1
    "Output buffer is too small",                          // LQX10_ERROR_BUFFER_TOO_SMALL = -2
    "Cryptographic operation failed",                      // LQX10_ERROR_CRYPTO_FAILURE = -3
    "Memory allocation failed",                            // LQX10_ERROR_MEMORY_ALLOCATION = -4
    "Invalid or corrupted key",                           // LQX10_ERROR_INVALID_KEY = -5
    "Invalid layer configuration",                         // LQX10_ERROR_INVALID_LAYER = -6
    "Authentication verification failed",                  // LQX10_ERROR_AUTHENTICATION_FAILURE = -7
    "Post-quantum operation failed",                       // LQX10_ERROR_POST_QUANTUM_FAILURE = -8
    "Insufficient entropy available",                      // LQX10_ERROR_ENTROPY_FAILURE = -9
    "Runtime mutation failed",                             // LQX10_ERROR_RUNTIME_MUTATION_FAILURE = -10
    "Multi-factor authentication failed",                  // LQX10_ERROR_MFA_FAILURE = -11
    "Context integrity check failed",                      // LQX10_ERROR_CONTEXT_CORRUPTED = -12
    "Anti-debug protection triggered",                     // LQX10_ERROR_ANTI_DEBUG = -13
    "Invalid state error"                                  // LQX10_ERROR_INVALID_STATE = -14
};

#define ERROR_MESSAGES_COUNT (sizeof(error_messages) / sizeof(error_messages[0]))

// Error severity levels
typedef enum {
    LQX10_SEVERITY_INFO = 0,
    LQX10_SEVERITY_WARNING = 1,
    LQX10_SEVERITY_ERROR = 2,
    LQX10_SEVERITY_CRITICAL = 3
} lqx10_severity_t;

// Error context structure
typedef struct {
    lqx10_error_t code;
    lqx10_severity_t severity;
    const char* function;
    const char* file;
    int line;
    char message[256];
} lqx10_error_context_t;

// Error info structure for external API
typedef struct {
    lqx10_error_t code;
    int severity;
    const char* function;
    const char* file;
    int line;
    char message[256];
} lqx10_error_info_t;

// Thread-local error context (simplified for zero dependencies)
static lqx10_error_context_t g_last_error = {0};

// Get error severity level
static lqx10_severity_t get_error_severity(lqx10_error_t error) {
    switch (error) {
        case LQX10_SUCCESS:
            return LQX10_SEVERITY_INFO;
        
        case LQX10_ERROR_INVALID_PARAM:
        case LQX10_ERROR_BUFFER_TOO_SMALL:
            return LQX10_SEVERITY_WARNING;
        
        case LQX10_ERROR_CRYPTO_FAILURE:
        case LQX10_ERROR_MEMORY_ALLOCATION:
        case LQX10_ERROR_INVALID_KEY:
        case LQX10_ERROR_AUTHENTICATION_FAILURE:
        case LQX10_ERROR_MFA_FAILURE:
            return LQX10_SEVERITY_ERROR;
        
        case LQX10_ERROR_CONTEXT_CORRUPTED:
        case LQX10_ERROR_ANTI_DEBUG:
        case LQX10_ERROR_RUNTIME_MUTATION_FAILURE:
            return LQX10_SEVERITY_CRITICAL;
        
        default:
            return LQX10_SEVERITY_ERROR;
    }
}

// Set last error with context information
void lqx10_error_set_context(lqx10_error_t error, const char* function, 
                             const char* file, int line, const char* message) {
    g_last_error.code = error;
    g_last_error.severity = get_error_severity(error);
    g_last_error.function = function;
    g_last_error.file = file;
    g_last_error.line = line;
    
    if (message) {
        SECURE_STRNCPY(g_last_error.message, sizeof(g_last_error.message), message, sizeof(g_last_error.message) - 1);
        g_last_error.message[sizeof(g_last_error.message) - 1] = '\0';
    } else {
        g_last_error.message[0] = '\0';
    }
}

// Get error message string
const char* lqx10_error_string(lqx10_error_t error) {
    int error_index = (error < 0) ? -error : error;
    if (error_index >= 0 && error_index < (int)(sizeof(error_messages) / sizeof(error_messages[0]))) {
        return error_messages[error_index];
    }
    return "Unknown error code";
}

// Get last error information
lqx10_error_t lqx10_error_get_last(lqx10_error_info_t* info) {
    if (!info) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    info->code = g_last_error.code;
    info->severity = (int)g_last_error.severity;
    info->function = g_last_error.function;
    info->file = g_last_error.file;
    info->line = g_last_error.line;
    
    SECURE_STRNCPY(info->message, sizeof(info->message), g_last_error.message, sizeof(info->message) - 1);
    info->message[sizeof(info->message) - 1] = '\0';
    
    return LQX10_SUCCESS;
}

// Clear last error
void lqx10_error_clear(void) {
    memset(&g_last_error, 0, sizeof(g_last_error));
}

// Check if error is critical
bool lqx10_error_is_critical(lqx10_error_t error) {
    return get_error_severity(error) == LQX10_SEVERITY_CRITICAL;
}

// Check if error is recoverable
bool lqx10_error_is_recoverable(lqx10_error_t error) {
    switch (error) {
        case LQX10_SUCCESS:
        case LQX10_ERROR_INVALID_PARAM:
        case LQX10_ERROR_BUFFER_TOO_SMALL:
            return true;
        
        case LQX10_ERROR_CONTEXT_CORRUPTED:
        case LQX10_ERROR_ANTI_DEBUG:
        case LQX10_ERROR_RUNTIME_MUTATION_FAILURE:
            return false;
        
        default:
            return get_error_severity(error) != LQX10_SEVERITY_CRITICAL;
    }
}

// Format error for logging (secure - no sensitive data)
int lqx10_error_format_safe(lqx10_error_t error, char* buffer, size_t buffer_size) {
    if (!buffer || buffer_size == 0) {
        return -1;
    }
    
    const char* error_msg = lqx10_error_string(error);
    lqx10_severity_t severity = get_error_severity(error);
    
    const char* severity_str;
    switch (severity) {
        case LQX10_SEVERITY_INFO: severity_str = "INFO"; break;
        case LQX10_SEVERITY_WARNING: severity_str = "WARN"; break;
        case LQX10_SEVERITY_ERROR: severity_str = "ERROR"; break;
        case LQX10_SEVERITY_CRITICAL: severity_str = "CRITICAL"; break;
        default: severity_str = "UNKNOWN"; break;
    }
    
    return snprintf(buffer, buffer_size, "[%s] LQX10-%04d: %s", 
                   severity_str, error, error_msg);
}

// Validate error code
bool lqx10_error_is_valid(lqx10_error_t error) {
    int error_index = (error < 0) ? -error : error;
    return error_index >= 0 && 
           error_index < (int)(sizeof(error_messages) / sizeof(error_messages[0]));
}

// Convert error to exit code for CLI applications
int lqx10_error_to_exit_code(lqx10_error_t error) {
    switch (error) {
        case LQX10_SUCCESS:
            return 0;
        
        case LQX10_ERROR_INVALID_PARAM:
        case LQX10_ERROR_BUFFER_TOO_SMALL:
            return 1; // Usage error
        
        case LQX10_ERROR_MEMORY_ALLOCATION:
            return 2; // Resource error
        
        case LQX10_ERROR_CRYPTO_FAILURE:
        case LQX10_ERROR_AUTHENTICATION_FAILURE:
        case LQX10_ERROR_MFA_FAILURE:
            return 4; // Security error
        
        case LQX10_ERROR_CONTEXT_CORRUPTED:
        case LQX10_ERROR_ANTI_DEBUG:
        case LQX10_ERROR_RUNTIME_MUTATION_FAILURE:
            return 5; // Critical security error
        
        default:
            return 99; // Unknown error
    }
}

// Macro helpers for error handling
#define LQX10_SET_ERROR(error, msg) \
    lqx10_error_set_context(error, __FUNCTION__, __FILE__, __LINE__, msg)

#define LQX10_RETURN_ON_ERROR(expr) \
    do { \
        lqx10_error_t _err = (expr); \
        if (_err != LQX10_SUCCESS) { \
            LQX10_SET_ERROR(_err, #expr); \
            return _err; \
        } \
    } while (0)

#define LQX10_CHECK_CRITICAL(expr) \
    do { \
        lqx10_error_t _err = (expr); \
        if (lqx10_error_is_critical(_err)) { \
            LQX10_SET_ERROR(_err, "Critical error detected"); \
            return _err; \
        } \
    } while (0)
