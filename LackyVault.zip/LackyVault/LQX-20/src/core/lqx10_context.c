/**
 * @file lqx10_context.c
 * @brief LQX-10 Context Management Implementation
 * 
 * Zero-dependency context management for LQX-10 cryptographic operations.
 * Handles secure memory allocation, key management, and runtime state.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../../include/lqx10_core.h"
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#ifdef _WIN32
#include <windows.h>
#include <wincrypt.h>
#else
#include <sys/mman.h>
#include <unistd.h>
#endif

// Context allocation with secure memory
lqx10_error_t lqx10_context_allocate(lqx10_context_t **ctx) {
    if (!ctx) {
        return LQX10_ERROR_INVALID_PARAM;
    }

    *ctx = NULL;

    // Allocate secure memory for context
    lqx10_context_t *new_ctx = NULL;
    
#ifdef _WIN32
    new_ctx = (lqx10_context_t*)VirtualAlloc(NULL, sizeof(lqx10_context_t), 
                                             MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!new_ctx) {
        return LQX10_ERROR_MEMORY_ALLOC;
    }
    
    // Lock memory to prevent swapping
    if (!VirtualLock(new_ctx, sizeof(lqx10_context_t))) {
        VirtualFree(new_ctx, 0, MEM_RELEASE);
        return LQX10_ERROR_MEMORY_ALLOC;
    }
#else
    new_ctx = (lqx10_context_t*)mmap(NULL, sizeof(lqx10_context_t), 
                                     PROT_READ | PROT_WRITE, 
                                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (new_ctx == MAP_FAILED) {
        return LQX10_ERROR_MEMORY_ALLOC;
    }
    
    // Lock memory to prevent swapping
    if (mlock(new_ctx, sizeof(lqx10_context_t)) != 0) {
        munmap(new_ctx, sizeof(lqx10_context_t));
        return LQX10_ERROR_MEMORY_ALLOC;
    }
#endif

    // Initialize context with secure defaults
    memset(new_ctx, 0, sizeof(lqx10_context_t));
    
    // Set magic number for integrity checking
    new_ctx->magic = LQX10_CONTEXT_MAGIC;
    new_ctx->version = LQX10_VERSION;
    new_ctx->state = LQX10_STATE_INITIALIZED;
    
    // Initialize cryptographic state
    new_ctx->key_schedule_rounds = LQX10_DEFAULT_KEY_ROUNDS;
    new_ctx->layer_mask = 0x3FF; // All 10 layers enabled by default
    new_ctx->runtime_mutation_enabled = true;
    new_ctx->anti_debug_enabled = true;
    
    // Initialize timing for side-channel resistance
    new_ctx->operation_start_time = 0;
    new_ctx->constant_time_mask = 0xFFFFFFFFFFFFFFFF;
    
    *ctx = new_ctx;
    return LQX10_SUCCESS;
}

// Context deallocation with secure cleanup
lqx10_error_t lqx10_context_deallocate(lqx10_context_t *ctx) {
    if (!ctx) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Verify context integrity
    if (ctx->magic != LQX10_CONTEXT_MAGIC) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Secure wipe of sensitive data (multiple passes)
    volatile uint8_t *ptr = (volatile uint8_t*)ctx;
    size_t size = sizeof(lqx10_context_t);
    
    // First pass: zeros
    for (size_t i = 0; i < size; i++) {
        ptr[i] = 0x00;
    }
    
    // Second pass: ones
    for (size_t i = 0; i < size; i++) {
        ptr[i] = 0xFF;
    }
    
    // Third pass: random pattern
    for (size_t i = 0; i < size; i++) {
        ptr[i] = (uint8_t)(0xAA ^ (i & 0xFF));
    }
    
    // Final pass: zeros
    for (size_t i = 0; i < size; i++) {
        ptr[i] = 0x00;
    }

#ifdef _WIN32
    // Unlock and free memory
    VirtualUnlock(ctx, sizeof(lqx10_context_t));
    VirtualFree(ctx, 0, MEM_RELEASE);
#else
    // Unlock and unmap memory
    munlock(ctx, sizeof(lqx10_context_t));
    munmap(ctx, sizeof(lqx10_context_t));
#endif

    return LQX10_SUCCESS;
}

// Context validation
lqx10_error_t lqx10_context_validate(lqx10_context_t *ctx) {
    if (!ctx) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (ctx->magic != LQX10_CONTEXT_MAGIC) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (ctx->version != LQX10_VERSION) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (ctx->state == LQX10_STATE_CORRUPTED) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    return LQX10_SUCCESS;
}

// Context reset (preserves allocated memory)
lqx10_error_t lqx10_context_reset(lqx10_context_t *ctx) {
    if (!ctx) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Preserve structure fields but clear cryptographic state
    uint32_t magic = ctx->magic;
    uint32_t version = ctx->version;
    
    // Clear sensitive data
    memset(ctx->master_key, 0, sizeof(ctx->master_key));
    memset(ctx->derived_keys, 0, sizeof(ctx->derived_keys));
    memset(ctx->layer_keys, 0, sizeof(ctx->layer_keys));
    memset(ctx->iv, 0, sizeof(ctx->iv));
    memset(ctx->salt, 0, sizeof(ctx->salt));
    
    // Reset state
    ctx->magic = magic;
    ctx->version = version;
    ctx->state = LQX10_STATE_INITIALIZED;
    ctx->key_schedule_rounds = LQX10_DEFAULT_KEY_ROUNDS;
    ctx->layer_mask = 0x3FF;
    ctx->runtime_mutation_enabled = true;
    ctx->anti_debug_enabled = true;
    ctx->operation_start_time = 0;
    ctx->constant_time_mask = 0xFFFFFFFFFFFFFFFF;
    
    return LQX10_SUCCESS;
}

// Get context state information
lqx10_error_t lqx10_context_get_info(const lqx10_context_t *ctx, lqx10_context_info_t *info) {
    if (!ctx || !info) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    lqx10_error_t result = lqx10_context_validate((lqx10_context_t*)ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    memset(info, 0, sizeof(lqx10_context_info_t));
    
    info->version = ctx->version;
    info->state = ctx->state;
    info->layer_mask = ctx->layer_mask;
    info->key_schedule_rounds = ctx->key_schedule_rounds;
    info->runtime_mutation_enabled = ctx->runtime_mutation_enabled;
    info->anti_debug_enabled = ctx->anti_debug_enabled;
    
    // Count active layers
    info->active_layers = 0;
    for (int i = 0; i < 10; i++) {
        if (ctx->layer_mask & (1 << i)) {
            info->active_layers++;
        }
    }
    
    return LQX10_SUCCESS;
}

// Set context configuration
lqx10_error_t lqx10_context_configure(lqx10_context_t *ctx, const lqx10_config_t *config) {
    if (!ctx || !config) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    lqx10_error_t result = lqx10_context_validate(ctx);
    if (result != LQX10_SUCCESS) {
        return result;
    }
    
    // Validate configuration parameters
    if (config->key_schedule_rounds < 1000 || config->key_schedule_rounds > 100000) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    if (config->layer_mask == 0 || config->layer_mask > 0x3FF) {
        return LQX10_ERROR_INVALID_PARAM;
    }
    
    // Apply configuration
    ctx->key_schedule_rounds = config->key_schedule_rounds;
    ctx->layer_mask = config->layer_mask;
    ctx->runtime_mutation_enabled = config->runtime_mutation_enabled;
    ctx->anti_debug_enabled = config->anti_debug_enabled;
    
    // Mark as configured
    ctx->state = LQX10_STATE_CONFIGURED;
    
    return LQX10_SUCCESS;
}
