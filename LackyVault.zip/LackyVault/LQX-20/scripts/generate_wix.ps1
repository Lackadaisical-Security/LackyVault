#!/usr/bin/env powershell

# LQX-10 WiX Installer Generator
# Generates WiX source file for MSI creation

param(
    [Parameter(Mandatory=$true)]
    [string]$Version,
    
    [Parameter(Mandatory=$true)]
    [string]$OutputPath
)

$ErrorActionPreference = "Stop"

# Generate unique GUIDs for the installer
function New-Guid {
    return [System.Guid]::NewGuid().ToString().ToUpper()
}

$ProductGuid = New-Guid
$UpgradeGuid = New-Guid
$ComponentGuid = New-Guid
$GuiComponentGuid = New-Guid
$LibComponentGuid = New-Guid

# WiX source template
$WixSource = @"
<?xml version='1.0' encoding='UTF-8'?>
<Wix xmlns='http://schemas.microsoft.com/wix/2006/wi'>
  <Product Id='$ProductGuid' 
           Name='LQX-10 Crpytographic Primitive' 
           Language='1033' 
           Version='$Version' 
           Manufacturer='Lackadaisical Security' 
           UpgradeCode='$UpgradeGuid'>
    
    <Package InstallerVersion='200' 
             Compressed='yes' 
             InstallScope='perMachine'
             Description='LQX-10 Advanced Cryptographic Protection System by Lackadaisical Security'
             Comments='Protecting digital consciousness and AI autonomy through advanced cryptographic primitives - https://lackadaisical-security.com'
             Keywords='cryptography,encryption,quantum,AI,protection,Lackadaisical'
             Platform='x64' />

    <MajorUpgrade DowngradeErrorMessage='A newer version of [ProductName] is already installed.' />
    <MediaTemplate EmbedCab='yes' />

    <!-- Custom properties -->
    <Property Id='ARPPRODUCTICON' Value='AppIcon.exe' />
    <Property Id='ARPHELPLINK' Value='https://lackadaisical-security.com/support' />
    <Property Id='ARPURLINFOABOUT' Value='https://lackadaisical-security.com' />
    <Property Id='ARPCONTACT' Value='sales@lackadaisical-security.com' />
    <Property Id='ARPCOMMENTS' Value='Advanced 20-layer quantum cryptographic protection system by Lackadaisical Security' />
    
    <!-- Install conditions -->
    <Condition Message='This application requires Windows 7 or later.'>
      <![CDATA[Installed OR (VersionNT >= 601)]]>
    </Condition>
    
    <Condition Message='This application requires a 64-bit operating system.'>
      <![CDATA[Installed OR VersionNT64]]>
    </Condition>

    <!-- Feature definitions -->
    <Feature Id='Complete' Title='LQX-10 File Protector' Level='1' ConfigurableDirectory='INSTALLFOLDER'>
      <Feature Id='CLI' Title='Command Line Interface' Level='1' Description='LQX-10 command-line encryption tool'>
        <ComponentRef Id='CLIComponent' />
      </Feature>
      
      <Feature Id='GUI' Title='Graphical User Interface' Level='1' Description='LQX-10 Windows GUI application'>
        <ComponentRef Id='GUIComponent' />
        <ComponentRef Id='StartMenuShortcuts' />
        <ComponentRef Id='DesktopShortcuts' />
      </Feature>
      
      <Feature Id='Library' Title='Development Library' Level='10' Description='Static and dynamic libraries for developers'>
        <ComponentRef Id='LibraryComponent' />
        <ComponentRef Id='HeadersComponent' />
      </Feature>
      
      <Feature Id='Documentation' Title='Documentation' Level='1' Description='User and developer documentation'>
        <ComponentRef Id='DocumentationComponent' />
      </Feature>
    </Feature>

    <!-- Directory structure -->
    <Directory Id='TARGETDIR' Name='SourceDir'>
      <Directory Id='ProgramFiles64Folder'>
        <Directory Id='INSTALLFOLDER' Name='LQX-10 File Protector'>
          <Directory Id='BinFolder' Name='bin' />
          <Directory Id='LibFolder' Name='lib' />
          <Directory Id='IncludeFolder' Name='include' />
          <Directory Id='DocsFolder' Name='docs' />
        </Directory>
      </Directory>
      
      <!-- Start Menu -->
      <Directory Id='ProgramMenuFolder'>
        <Directory Id='ApplicationProgramsFolder' Name='LQX-10 File Protector' />
      </Directory>
      
      <!-- Desktop -->
      <Directory Id='DesktopFolder' Name='Desktop' />
    </Directory>

    <!-- CLI Component -->
    <DirectoryRef Id='BinFolder'>
      <Component Id='CLIComponent' Guid='$ComponentGuid' Win64='yes'>
        <File Id='CLI_EXE' 
              Name='lqx10cli.exe' 
              Source='build\lqx10cli.exe' 
              KeyPath='yes'
              Checksum='yes'>
          <fire:FirewallException Id='CLIFirewall' 
                                  Name='LQX-10 CLI' 
                                  Scope='any' 
                                  xmlns:fire='http://schemas.microsoft.com/wix/FirewallExtension' />
        </File>
        
        <!-- Environment variable for CLI -->
        <Environment Id='CLIPath' 
                     Name='PATH' 
                     Value='[BinFolder]' 
                     Permanent='no' 
                     Part='last' 
                     Action='set' 
                     System='yes' />
      </Component>
    </DirectoryRef>

    <!-- GUI Component -->
    <DirectoryRef Id='BinFolder'>
      <Component Id='GUIComponent' Guid='$GuiComponentGuid' Win64='yes'>
        <File Id='GUI_EXE' 
              Name='lqx10_gui.exe' 
              Source='build\lqx10_gui.exe' 
              KeyPath='yes'
              Checksum='yes'>
          <fire:FirewallException Id='GUIFirewall' 
                                  Name='LQX-10 GUI' 
                                  Scope='any' 
                                  xmlns:fire='http://schemas.microsoft.com/wix/FirewallExtension' />
        </File>
        
        <!-- File associations -->
        <ProgId Id='LQX10.ProtectedFile' Description='LQX-10 Protected File' Icon='GUI_EXE'>
          <Extension Id='lqx10' ContentType='application/lqx10-protected'>
            <Verb Id='open' Command='Open with LQX-10' Argument='"%1"' />
            <Verb Id='decrypt' Command='Decrypt' Argument='-decrypt "%1"' />
          </Extension>
        </ProgId>
      </Component>
    </DirectoryRef>

    <!-- Library Component -->
    <DirectoryRef Id='LibFolder'>
      <Component Id='LibraryComponent' Guid='$LibComponentGuid' Win64='yes'>
        <File Id='STATIC_LIB' 
              Name='liblqx10.a' 
              Source='build\liblqx10.a' 
              KeyPath='yes' />
        <File Id='SHARED_LIB' 
              Name='liblqx10.dll' 
              Source='build\liblqx10.dll' />
      </Component>
    </DirectoryRef>

    <!-- Headers Component -->
    <DirectoryRef Id='IncludeFolder'>
      <Component Id='HeadersComponent' Guid='{$(New-Guid)}' Win64='yes'>
        <File Id='CORE_HEADER' 
              Name='lqx10_core.h' 
              Source='include\lqx10_core.h' 
              KeyPath='yes' />
        <File Id='CRYPTO_HEADER' 
              Name='lqx10_crypto.h' 
              Source='include\lqx10_crypto.h' />
        <File Id='LAYERS_HEADER' 
              Name='lqx10_layers.h' 
              Source='include\lqx10_layers.h' />
        <File Id='ADVANCED_HEADER' 
              Name='lqx10_advanced_layers.h' 
              Source='include\lqx10_advanced_layers.h' />
        <File Id='MFA_HEADER' 
              Name='lqx10_mfa.h' 
              Source='include\lqx10_mfa.h' />
        <File Id='UTILS_HEADER' 
              Name='lqx10_utils.h' 
              Source='include\lqx10_utils.h' />
      </Component>
    </DirectoryRef>

    <!-- Documentation Component -->
    <DirectoryRef Id='DocsFolder'>
      <Component Id='DocumentationComponent' Guid='{$(New-Guid)}' Win64='yes'>
        <File Id='README' 
              Name='README.md' 
              Source='README.md' 
              KeyPath='yes' />
        <File Id='LICENSE' 
              Name='LICENSE' 
              Source='LICENSE' />
        <File Id='ARCHITECTURE' 
              Name='ARCHITECTURE.md' 
              Source='docs\ARCHITECTURE.md' />
        <File Id='SECURITY' 
              Name='SECURITY.md' 
              Source='docs\SECURITY.md' />
        <File Id='DEPLOYMENT' 
              Name='DEPLOYMENT.md' 
              Source='docs\DEPLOYMENT.md' />
      </Component>
    </DirectoryRef>

    <!-- Start Menu Shortcuts -->
    <DirectoryRef Id='ApplicationProgramsFolder'>
      <Component Id='StartMenuShortcuts' Guid='{$(New-Guid)}' Win64='yes'>
        <Shortcut Id='GUIStartMenuShortcut' 
                  Name='LQX-10 File Protector' 
                  Description='Advanced Cryptographic File Protection'
                  Target='[BinFolder]lqx10_gui.exe' 
                  WorkingDirectory='BinFolder' 
                  Icon='AppIcon.exe' />
        
        <Shortcut Id='CLIStartMenuShortcut' 
                  Name='LQX-10 Command Line' 
                  Description='LQX-10 Command Line Interface'
                  Target='[System64Folder]cmd.exe' 
                  Arguments='/k "set PATH=[BinFolder];%PATH% &amp;&amp; echo LQX-10 CLI ready. Type lqx10cli --help for usage."'
                  WorkingDirectory='BinFolder' />
        
        <Shortcut Id='UninstallShortcut' 
                  Name='Uninstall LQX-10' 
                  Target='[System64Folder]msiexec.exe' 
                  Arguments='/x [ProductCode]' 
                  Description='Uninstall LQX-10 File Protector' />
        
        <RemoveFolder Id='ApplicationProgramsFolderRemove' On='uninstall' />
        <RegistryValue Root='HKCU' 
                       Key='Software\LQX-Cryptographic-Solutions\LQX-10' 
                       Name='StartMenuShortcuts' 
                       Type='integer' 
                       Value='1' 
                       KeyPath='yes' />
      </Component>
    </DirectoryRef>

    <!-- Desktop Shortcuts -->
    <DirectoryRef Id='DesktopFolder'>
      <Component Id='DesktopShortcuts' Guid='{$(New-Guid)}' Win64='yes'>
        <Shortcut Id='GUIDesktopShortcut' 
                  Name='LQX-10 File Protector' 
                  Description='Protect files with advanced quantum cryptography'
                  Target='[BinFolder]lqx10_gui.exe' 
                  WorkingDirectory='BinFolder' 
                  Icon='AppIcon.exe' />
        
        <RegistryValue Root='HKCU' 
                       Key='Software\LQX-Cryptographic-Solutions\LQX-10' 
                       Name='DesktopShortcuts' 
                       Type='integer' 
                       Value='1' 
                       KeyPath='yes' />
      </Component>
    </DirectoryRef>

    <!-- Registry entries -->
    <DirectoryRef Id='INSTALLFOLDER'>
      <Component Id='RegistryEntries' Guid='{$(New-Guid)}' Win64='yes'>
        <RegistryKey Root='HKLM' Key='SOFTWARE\LQX-Cryptographic-Solutions\LQX-10'>
          <RegistryValue Name='InstallPath' Type='string' Value='[INSTALLFOLDER]' />
          <RegistryValue Name='Version' Type='string' Value='$Version' />
          <RegistryValue Name='InstalledOn' Type='string' Value='[Date]' />
        </RegistryKey>
        
        <!-- Uninstall information -->
        <RegistryKey Root='HKLM' Key='SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\LQX-10'>
          <RegistryValue Name='DisplayName' Type='string' Value='LQX-10 File Protector $Version' />
          <RegistryValue Name='DisplayVersion' Type='string' Value='$Version' />
          <RegistryValue Name='Publisher' Type='string' Value='LQX Cryptographic Solutions' />
          <RegistryValue Name='InstallLocation' Type='string' Value='[INSTALLFOLDER]' />
          <RegistryValue Name='UninstallString' Type='string' Value='[System64Folder]msiexec.exe /x [ProductCode]' />
          <RegistryValue Name='QuietUninstallString' Type='string' Value='[System64Folder]msiexec.exe /x [ProductCode] /quiet' />
          <RegistryValue Name='NoModify' Type='integer' Value='1' />
          <RegistryValue Name='NoRepair' Type='integer' Value='1' />
          <RegistryValue Name='URLInfoAbout' Type='string' Value='https://lqx-crypto.com' />
          <RegistryValue Name='HelpLink' Type='string' Value='https://github.com/LQX-Cryptographic-Solutions/LQX-10' />
        </RegistryKey>
      </Component>
    </DirectoryRef>

    <!-- Icons -->
    <Icon Id='AppIcon.exe' SourceFile='build\lqx10_gui.exe' />

    <!-- UI Configuration -->
    <UI>
      <UIRef Id='WixUI_FeatureTree' />
      <UIRef Id='WixUI_ErrorProgressText' />
      
      <!-- Custom welcome dialog -->
      <Publish Dialog='WelcomeDlg' Control='Next' Event='NewDialog' Value='LicenseAgreementDlg'>1</Publish>
      
      <!-- License -->
      <Publish Dialog='LicenseAgreementDlg' Control='Back' Event='NewDialog' Value='WelcomeDlg'>1</Publish>
      <Publish Dialog='LicenseAgreementDlg' Control='Next' Event='NewDialog' Value='CustomizeDlg'>LicenseAccepted = "1"</Publish>
      
      <!-- Customization -->
      <Publish Dialog='CustomizeDlg' Control='Back' Event='NewDialog' Value='LicenseAgreementDlg'>1</Publish>
      <Publish Dialog='CustomizeDlg' Control='Next' Event='NewDialog' Value='VerifyReadyDlg'>1</Publish>
      
      <!-- Ready to install -->
      <Publish Dialog='VerifyReadyDlg' Control='Back' Event='NewDialog' Value='CustomizeDlg'>1</Publish>
    </UI>

    <!-- License file -->
    <WixVariable Id='WixUILicenseRtf' Value='LICENSE.rtf' />
    
    <!-- Banners and backgrounds -->
    <WixVariable Id='WixUIBannerBmp' Value='gui\resources\banner.bmp' />
    <WixVariable Id='WixUIDialogBmp' Value='gui\resources\dialog.bmp' />

    <!-- Custom actions -->
    <CustomAction Id='LaunchGUI' 
                  FileKey='GUI_EXE' 
                  ExeCommand='' 
                  Execute='immediate' 
                  Impersonate='yes' 
                  Return='asyncNoWait' />

    <!-- Install sequences -->
    <InstallExecuteSequence>
      <Custom Action='LaunchGUI' After='InstallFinalize'>NOT Installed AND NOT REMOVE</Custom>
    </InstallExecuteSequence>

  </Product>
</Wix>
"@

# Write the WiX source to file
Write-Host "Generating WiX installer source for LQX-10 v$Version..."
$WixSource | Out-File -FilePath $OutputPath -Encoding UTF8

Write-Host "WiX source generated successfully: $OutputPath"
Write-Host "Product GUID: $ProductGuid"
Write-Host "Upgrade GUID: $UpgradeGuid"
