# LQX-10 Build Script
# Production-grade build with security optimizations
param(
    [string]$Configuration = "Release",
    [string]$Platform = "x64",
    [switch]$Clean,
    [switch]$Test,
    [switch]$Install
)

Write-Host "LQX-10 Cryptographic Primitive Build System" -ForegroundColor Cyan
Write-Host "=========================================" -ForegroundColor Cyan

$BuildDir = Join-Path $PSScriptRoot "..\build"
$SrcDir = Join-Path $PSScriptRoot "..\src"
$IncludeDir = Join-Path $PSScriptRoot "..\include"
$TestDir = Join-Path $PSScriptRoot "..\tests"

# Clean build directory if requested
if ($Clean) {
    Write-Host "Cleaning build directory..." -ForegroundColor Yellow
    if (Test-Path $BuildDir) {
        Remove-Item -Recurse -Force $BuildDir
    }
}

# Create build directories
New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null
$ObjectDir = Join-Path $BuildDir "obj"
New-Item -ItemType Directory -Force -Path $ObjectDir | Out-Null

# Compiler settings for security
$CompilerFlags = @(
    "/O2",          # Optimize for speed
    "/GL",          # Global optimization
    "/GS",          # Buffer security check
    "/DYNAMICBASE", # Address space layout randomization
    "/NXCOMPAT",    # Data execution prevention
    "/guard:cf",    # Control flow guard
    "/D_FORTIFY_SOURCE=2",
    "/DWIN32_LEAN_AND_MEAN",
    "/D_CRT_SECURE_NO_WARNINGS",
    "/I$IncludeDir",
    "/Fo$ObjectDir\",
    "/Fe$BuildDir\"
)

$LinkerLibs = @(
    "bcrypt.lib",
    "advapi32.lib",
    "kernel32.lib",
    "user32.lib",
    "crypt32.lib"
)

# Source files to compile
$SourceFiles = @(
    "$SrcDir\core\lqx10_core.c",
    "$SrcDir\crypto\lqx10_crypto.c",
    "$SrcDir\layers\lqx10_layers.c",
    "$SrcDir\layers\lqx10_layers_advanced.c"
)

Write-Host "Compiling LQX-10 Core Library..." -ForegroundColor Green

# Compile each source file
foreach ($file in $SourceFiles) {
    if (Test-Path $file) {
        Write-Host "  Compiling $(Split-Path $file -Leaf)..." -ForegroundColor Gray
        $cmd = "cl.exe $($CompilerFlags -join ' ') /c `"$file`""
        Invoke-Expression $cmd
        if ($LASTEXITCODE -ne 0) {
            Write-Host "Compilation failed for $file" -ForegroundColor Red
            exit 1
        }
    } else {
        Write-Host "Warning: Source file not found: $file" -ForegroundColor Yellow
    }
}

# Link static library
Write-Host "Linking LQX-10 static library..." -ForegroundColor Green
$ObjectFiles = Get-ChildItem "$ObjectDir\*.obj" | ForEach-Object { $_.FullName }
$LibCmd = "lib.exe /OUT:`"$BuildDir\lqx10.lib`" $($ObjectFiles -join ' ')"
Invoke-Expression $LibCmd

if ($LASTEXITCODE -ne 0) {
    Write-Host "Library linking failed" -ForegroundColor Red
    exit 1
}

Write-Host "LQX-10 library built successfully!" -ForegroundColor Green
Write-Host "Output: $BuildDir\lqx10.lib" -ForegroundColor Cyan

# Build tests if requested
if ($Test) {
    Write-Host "Building test suite..." -ForegroundColor Green
    # Test compilation will be implemented when tests are created
}

# Install if requested
if ($Install) {
    Write-Host "Installing LQX-10 components..." -ForegroundColor Green
    $InstallDir = "$env:ProgramFiles\LQX-10"
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
    Copy-Item "$BuildDir\lqx10.lib" $InstallDir
    Copy-Item "$IncludeDir\*.h" $InstallDir
    Write-Host "Installation complete: $InstallDir" -ForegroundColor Cyan
}

Write-Host "Build process completed successfully!" -ForegroundColor Green
