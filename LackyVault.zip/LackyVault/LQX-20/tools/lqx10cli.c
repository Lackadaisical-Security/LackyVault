#include "../include/lqx10_core.h"
#include "../include/lqx10_crypto.h"
#include "../include/lqx10_mfa.h"
#include "../include/lqx10_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
#include <conio.h>
#else
#include <unistd.h>
#include <termios.h>
#endif

#define MAX_FILE_SIZE (1024 * 1024 * 100) // 100MB max file size
#define MAX_PASSWORD_LENGTH 256

// Command types
typedef enum {
    CMD_ENCRYPT,
    CMD_DECRYPT,
    CMD_KEYGEN,
    CMD_BENCHMARK,
    CMD_TEST,
    CMD_VERSION,
    CMD_HELP
} command_type_t;

// CLI options structure
typedef struct {
    command_type_t command;
    char *input_file;
    char *output_file;
    char *key_file;
    char *password;
    char *salt;
    bool verbose;
    bool benchmark;
    uint32_t iterations;
} cli_options_t;

// Function prototypes
static void print_usage(const char *program_name);
static void print_version(void);
static int parse_arguments(int argc, char *argv[], cli_options_t *options);
static int cmd_encrypt(const cli_options_t *options);
static int cmd_decrypt(const cli_options_t *options);
static int cmd_keygen(const cli_options_t *options);
static int cmd_benchmark(const cli_options_t *options);
static int cmd_test(const cli_options_t *options);
static int read_file_contents(const char *filename, uint8_t **data, size_t *size);
static int write_file_contents(const char *filename, const uint8_t *data, size_t size);
static int get_password(const char *prompt, char *password, size_t max_len);
static void secure_zero_string(char *str);

int main(int argc, char *argv[]) {
    cli_options_t options = {0};
    
    printf("LQX-10 Cryptographic Primitive CLI Tool\n");
    printf("=======================================\n\n");
    
    // Initialize logging
    lqx10_log_init(NULL, LQX10_LOG_INFO);
    
    // Parse command line arguments
    int parse_result = parse_arguments(argc, argv, &options);
    if (parse_result != 0) {
        return parse_result;
    }
    
    // Execute command
    int result = 0;
    switch (options.command) {
        case CMD_ENCRYPT:
            result = cmd_encrypt(&options);
            break;
        case CMD_DECRYPT:
            result = cmd_decrypt(&options);
            break;
        case CMD_KEYGEN:
            result = cmd_keygen(&options);
            break;
        case CMD_BENCHMARK:
            result = cmd_benchmark(&options);
            break;
        case CMD_TEST:
            result = cmd_test(&options);
            break;
        case CMD_VERSION:
            print_version();
            break;
        case CMD_HELP:
        default:
            print_usage(argv[0]);
            break;
    }
    
    // Cleanup
    if (options.password) {
        secure_zero_string(options.password);
        free(options.password);
    }
    
    lqx10_log_cleanup();
    return result;
}

static void print_usage(const char *program_name) {
    printf("Usage: %s <command> [options]\n\n", program_name);
    printf("Commands:\n");
    printf("  encrypt    Encrypt a file\n");
    printf("  decrypt    Decrypt a file\n");
    printf("  keygen     Generate cryptographic keys\n");
    printf("  benchmark  Run performance benchmarks\n");
    printf("  test       Run self-tests\n");
    printf("  version    Show version information\n");
    printf("  help       Show this help message\n\n");
    
    printf("Options:\n");
    printf("  -i, --input <file>     Input file\n");
    printf("  -o, --output <file>    Output file\n");
    printf("  -k, --key <file>       Key file\n");
    printf("  -p, --password         Prompt for password\n");
    printf("  -s, --salt             Salt for key derivation\n");
    printf("  -I, --iterations <n>   KDF iterations (default: 100000)\n");
    printf("  -b, --benchmark         Run benchmark tests\n");
    printf("  -v, --verbose          Verbose output\n");
    printf("  -h, --help             Show this help message\n\n");
    
    printf("Examples:\n");
    printf("  %s encrypt -i data.txt -o data.lqx -p\n", program_name);
    printf("  %s decrypt -i data.lqx -o data.txt -p\n", program_name);
    printf("  %s keygen -o master.key\n", program_name);
    printf("  %s benchmark -v\n", program_name);
}

static void print_version(void) {
    uint32_t major, minor, patch;
    lqx10_get_version(&major, &minor, &patch);
    printf("LQX-10 Version %u.%u.%u\n", major, minor, patch);
    printf("Lackadaisical Security - Production Cryptographic Primitive\n");
}

static int parse_arguments(int argc, char *argv[], cli_options_t *options) {
    if (argc < 2) {
        print_usage(argv[0]);
        return -1;
    }
    
    memset(options, 0, sizeof(cli_options_t));
    
    // Parse command
    const char *cmd = argv[1];
    if (strcmp(cmd, "encrypt") == 0) {
        options->command = CMD_ENCRYPT;
    } else if (strcmp(cmd, "decrypt") == 0) {
        options->command = CMD_DECRYPT;
    } else if (strcmp(cmd, "keygen") == 0) {
        options->command = CMD_KEYGEN;
    } else if (strcmp(cmd, "benchmark") == 0) {
        options->command = CMD_BENCHMARK;
    } else if (strcmp(cmd, "test") == 0) {
        options->command = CMD_TEST;
    } else if (strcmp(cmd, "version") == 0) {
        options->command = CMD_VERSION;
    } else if (strcmp(cmd, "help") == 0) {
        options->command = CMD_HELP;
    } else {
        fprintf(stderr, "Error: Unknown command '%s'\n", cmd);
        print_usage(argv[0]);
        return -1;
    }
    
    // Parse options
    for (int i = 2; i < argc; i++) {
        if (strcmp(argv[i], "-i") == 0 || strcmp(argv[i], "--input") == 0) {
            if (i + 1 < argc) {
                options->input_file = argv[++i];
            } else {
                fprintf(stderr, "Error: -i/--input requires an argument\n");
                return -1;
            }
        } else if (strcmp(argv[i], "-o") == 0 || strcmp(argv[i], "--output") == 0) {
            if (i + 1 < argc) {
                options->output_file = argv[++i];
            } else {
                fprintf(stderr, "Error: -o/--output requires an argument\n");
                return -1;
            }
        } else if (strcmp(argv[i], "-p") == 0 || strcmp(argv[i], "--password") == 0) {
            // Flag to prompt for password
            options->password = NULL;  // Will prompt later
        } else if (strcmp(argv[i], "-k") == 0 || strcmp(argv[i], "--key-file") == 0) {
            if (i + 1 < argc) {
                options->key_file = argv[++i];
            } else {
                fprintf(stderr, "Error: -k/--key-file requires an argument\n");
                return -1;
            }
        } else if (strcmp(argv[i], "-s") == 0 || strcmp(argv[i], "--salt") == 0) {
            if (i + 1 < argc) {
                options->salt = argv[++i];
            } else {
                fprintf(stderr, "Error: -s/--salt requires an argument\n");
                return -1;
            }
        } else if (strcmp(argv[i], "-I") == 0 || strcmp(argv[i], "--iterations") == 0) {
            if (i + 1 < argc) {
                options->iterations = atoi(argv[++i]);
                if (options->iterations == 0) {
                    fprintf(stderr, "Error: Invalid iteration count\n");
                    return -1;
                }
            } else {
                fprintf(stderr, "Error: -I/--iterations requires an argument\n");
                return -1;
            }
        } else if (strcmp(argv[i], "-b") == 0 || strcmp(argv[i], "--benchmark") == 0) {
            options->benchmark = true;
        } else if (strcmp(argv[i], "-v") == 0 || strcmp(argv[i], "--verbose") == 0) {
            options->verbose = true;
            lqx10_log_init(NULL, LQX10_LOG_DEBUG);
        } else if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            options->command = CMD_HELP;
            return 0;
        } else {
            fprintf(stderr, "Error: Unknown option '%s'\n", argv[i]);
            print_usage(argv[0]);
            return -1;
        }
    }
    
    // Set defaults
    if (options->iterations == 0) {
        options->iterations = 100000; // Default PBKDF2 iterations
    }
    
    return 0;
}

static int cmd_encrypt(const cli_options_t *options) {
    if (!options->input_file || !options->output_file) {
        fprintf(stderr, "Error: Input and output files required for encryption\n");
        return -1;
    }
    
    // Read input file
    uint8_t *plaintext = NULL;
    size_t plaintext_len = 0;
    if (read_file_contents(options->input_file, &plaintext, &plaintext_len) != 0) {
        fprintf(stderr, "Error: Failed to read input file\n");
        return -1;
    }
    
    // Get password
    char password[256];
    if (options->password) {
        strncpy(password, options->password, sizeof(password) - 1);
    } else {
        if (get_password("Enter password: ", password, sizeof(password)) != 0) {
            free(plaintext);
            return -1;
        }
    }
    
    // Initialize LQX-10
    lqx10_context_t *ctx = NULL;
    lqx10_error_t result = lqx10_init(&ctx);
    if (result != LQX10_SUCCESS) {
        fprintf(stderr, "Error: Failed to initialize LQX-10: %s\n", lqx10_error_string(result));
        free(plaintext);
        secure_zero_string(password);
        return -1;
    }
    
    // Derive key
    uint8_t salt[LQX10_SALT_SIZE];
    if (options->salt) {
        memset(salt, 0, LQX10_SALT_SIZE);
        strncpy((char*)salt, options->salt, LQX10_SALT_SIZE - 1);
    } else {
        lqx10_secure_random_bytes(salt, LQX10_SALT_SIZE);
    }
    
    result = lqx10_key_derive(ctx, (uint8_t*)password, strlen(password),
                              salt, LQX10_SALT_SIZE, options->iterations);
    if (result != LQX10_SUCCESS) {
        fprintf(stderr, "Error: Key derivation failed: %s\n", lqx10_error_string(result));
        lqx10_destroy(ctx);
        free(plaintext);
        secure_zero_string(password);
        return -1;
    }
    
    // Encrypt
    size_t ciphertext_len = plaintext_len + (LQX10_LAYER_COUNT * 64) + 256;
    uint8_t *ciphertext = malloc(ciphertext_len);
    if (!ciphertext) {
        fprintf(stderr, "Error: Memory allocation failed\n");
        lqx10_destroy(ctx);
        free(plaintext);
        secure_zero_string(password);
        return -1;
    }
    
    result = lqx10_encrypt(ctx, plaintext, plaintext_len, ciphertext, &ciphertext_len);
    if (result != LQX10_SUCCESS) {
        fprintf(stderr, "Error: Encryption failed: %s\n", lqx10_error_string(result));
        lqx10_destroy(ctx);
        free(plaintext);
        free(ciphertext);
        secure_zero_string(password);
        return -1;
    }
    
    // Write header + salt + ciphertext
    uint8_t header[16] = "LQX10\x01\x00\x00"; // Magic + version
    size_t total_size = sizeof(header) + LQX10_SALT_SIZE + ciphertext_len;
    uint8_t *output_buffer = malloc(total_size);
    if (!output_buffer) {
        fprintf(stderr, "Error: Memory allocation failed\n");
        lqx10_destroy(ctx);
        free(plaintext);
        free(ciphertext);
        secure_zero_string(password);
        return -1;
    }
    
    memcpy(output_buffer, header, sizeof(header));
    memcpy(output_buffer + sizeof(header), salt, LQX10_SALT_SIZE);
    memcpy(output_buffer + sizeof(header) + LQX10_SALT_SIZE, ciphertext, ciphertext_len);
    
    // Write to file
    if (write_file_contents(options->output_file, output_buffer, total_size) != 0) {
        fprintf(stderr, "Error: Failed to write output file\n");
        lqx10_destroy(ctx);
        free(plaintext);
        free(ciphertext);
        free(output_buffer);
        secure_zero_string(password);
        return -1;
    }
    
    if (options->verbose) {
        printf("Encryption successful:\n");
        printf("  Input size: %zu bytes\n", plaintext_len);
        printf("  Output size: %zu bytes\n", total_size);
        printf("  Iterations: %u\n", options->iterations);
    }
    
    // Cleanup
    lqx10_destroy(ctx);
    lqx10_secure_memzero(plaintext, plaintext_len);
    free(plaintext);
    lqx10_secure_memzero(ciphertext, ciphertext_len);
    free(ciphertext);
    free(output_buffer);
    secure_zero_string(password);
    
    return 0;
}

static int cmd_decrypt(const cli_options_t *options) {
    if (!options->input_file || !options->output_file) {
        fprintf(stderr, "Error: Input and output files required for decryption\n");
        return -1;
    }
    
    // Read input file
    uint8_t *input_data = NULL;
    size_t input_len = 0;
    if (read_file_contents(options->input_file, &input_data, &input_len) != 0) {
        fprintf(stderr, "Error: Failed to read input file\n");
        return -1;
    }
    
    // Verify header
    if (input_len < 16 + LQX10_SALT_SIZE) {
        fprintf(stderr, "Error: Invalid file format\n");
        free(input_data);
        return -1;
    }
    
    if (memcmp(input_data, "LQX10", 5) != 0) {
        fprintf(stderr, "Error: Not an LQX-10 encrypted file\n");
        free(input_data);
        return -1;
    }
    
    // Extract salt and ciphertext
    uint8_t *salt = input_data + 16;
    uint8_t *ciphertext = input_data + 16 + LQX10_SALT_SIZE;
    size_t ciphertext_len = input_len - 16 - LQX10_SALT_SIZE;
    
    // Get password
    char password[256];
    if (options->password) {
        strncpy(password, options->password, sizeof(password) - 1);
    } else {
        if (get_password("Enter password: ", password, sizeof(password)) != 0) {
            free(input_data);
            return -1;
        }
    }
    
    // Initialize LQX-10
    lqx10_context_t *ctx = NULL;
    lqx10_error_t result = lqx10_init(&ctx);
    if (result != LQX10_SUCCESS) {
        fprintf(stderr, "Error: Failed to initialize LQX-10: %s\n", lqx10_error_string(result));
        free(input_data);
        secure_zero_string(password);
        return -1;
    }
    
    // Derive key
    result = lqx10_key_derive(ctx, (uint8_t*)password, strlen(password),
                              salt, LQX10_SALT_SIZE, options->iterations);
    if (result != LQX10_SUCCESS) {
        fprintf(stderr, "Error: Key derivation failed: %s\n", lqx10_error_string(result));
        lqx10_destroy(ctx);
        free(input_data);
        secure_zero_string(password);
        return -1;
    }
    
    // Decrypt
    size_t plaintext_len = ciphertext_len;
    uint8_t *plaintext = malloc(plaintext_len);
    if (!plaintext) {
        fprintf(stderr, "Error: Memory allocation failed\n");
        lqx10_destroy(ctx);
        free(input_data);
        secure_zero_string(password);
        return -1;
    }
    
    result = lqx10_decrypt(ctx, ciphertext, ciphertext_len, plaintext, &plaintext_len);
    if (result != LQX10_SUCCESS) {
        fprintf(stderr, "Error: Decryption failed: %s\n", lqx10_error_string(result));
        lqx10_destroy(ctx);
        free(input_data);
        free(plaintext);
        secure_zero_string(password);
        return -1;
    }
    
    // Write plaintext
    if (write_file_contents(options->output_file, plaintext, plaintext_len) != 0) {
        fprintf(stderr, "Error: Failed to write output file\n");
        lqx10_destroy(ctx);
        free(input_data);
        free(plaintext);
        secure_zero_string(password);
        return -1;
    }
    
    if (options->verbose) {
        printf("Decryption successful:\n");
        printf("  Input size: %zu bytes\n", input_len);
        printf("  Output size: %zu bytes\n", plaintext_len);
    }
    
    // Cleanup
    lqx10_destroy(ctx);
    free(input_data);
    lqx10_secure_memzero(plaintext, plaintext_len);
    free(plaintext);
    secure_zero_string(password);
    
    return 0;
}

static int cmd_keygen(const cli_options_t *options) {
    if (!options->output_file) {
        fprintf(stderr, "Error: Output file required for key generation\n");
        return -1;
    }
    
    // Generate random key
    uint8_t key[LQX10_KEY_SIZE];
    lqx10_error_t result = lqx10_secure_random_bytes(key, LQX10_KEY_SIZE);
    if (result != LQX10_SUCCESS) {
        fprintf(stderr, "Error: Failed to generate key: %s\n", lqx10_error_string(result));
        return -1;
    }
    
    // Write key file
    if (write_file_contents(options->output_file, key, LQX10_KEY_SIZE) != 0) {
        fprintf(stderr, "Error: Failed to write key file\n");
        lqx10_secure_memzero(key, LQX10_KEY_SIZE);
        return -1;
    }
    
    if (options->verbose) {
        printf("Key generation successful:\n");
        printf("  Key size: %d bits\n", LQX10_KEY_SIZE * 8);
        printf("  Output: %s\n", options->output_file);
    }
    
    lqx10_secure_memzero(key, LQX10_KEY_SIZE);
    return 0;
}

static int cmd_benchmark(const cli_options_t *options) {
    (void)options; // Suppress unused parameter warning
    printf("Running LQX-10 performance benchmark...\n\n");
    
    // Test data sizes
    size_t test_sizes[] = {16, 256, 1024, 4096, 16384, 65536, 1048576};
    const char *size_names[] = {"16B", "256B", "1KB", "4KB", "16KB", "64KB", "1MB"};
    int num_sizes = sizeof(test_sizes) / sizeof(test_sizes[0]);
    
    // Initialize context
    lqx10_context_t *ctx = NULL;
    if (lqx10_init(&ctx) != LQX10_SUCCESS) {
        fprintf(stderr, "Error: Failed to initialize context\n");
        return -1;
    }
    
    // Derive test key
    const char *test_password = "benchmark_password";
    uint8_t test_salt[LQX10_SALT_SIZE];
    lqx10_secure_random_bytes(test_salt, LQX10_SALT_SIZE);
    
    if (lqx10_key_derive(ctx, (uint8_t*)test_password, strlen(test_password),
                         test_salt, LQX10_SALT_SIZE, 10000) != LQX10_SUCCESS) {
        fprintf(stderr, "Error: Key derivation failed\n");
        lqx10_destroy(ctx);
        return -1;
    }
    
    printf("Size\tEncrypt (MB/s)\tDecrypt (MB/s)\tTotal (MB/s)\n");
    printf("----\t--------------\t--------------\t------------\n");
    
    for (int i = 0; i < num_sizes; i++) {
        size_t size = test_sizes[i];
        uint8_t *plaintext = malloc(size);
        uint8_t *ciphertext = malloc(size * 2);
        uint8_t *decrypted = malloc(size);
        
        if (!plaintext || !ciphertext || !decrypted) {
            fprintf(stderr, "Error: Memory allocation failed\n");
            free(plaintext);
            free(ciphertext);
            free(decrypted);
            lqx10_destroy(ctx);
            return -1;
        }
        
        // Fill with random data
        lqx10_secure_random_bytes(plaintext, size);
        
        // Benchmark encryption
        clock_t start = clock();
        int iterations = (size < 65536) ? 1000 : 100;
        
        for (int j = 0; j < iterations; j++) {
            size_t cipher_len = size * 2;
            lqx10_encrypt(ctx, plaintext, size, ciphertext, &cipher_len);
        }
        
        clock_t enc_time = clock() - start;
        double enc_speed = (double)(size * iterations) / ((double)enc_time / CLOCKS_PER_SEC) / (1024 * 1024);
        
        // Benchmark decryption
        size_t cipher_len = size * 2;
        lqx10_encrypt(ctx, plaintext, size, ciphertext, &cipher_len);
        
        start = clock();
        for (int j = 0; j < iterations; j++) {
            size_t dec_len = size;
            lqx10_decrypt(ctx, ciphertext, cipher_len, decrypted, &dec_len);
        }
        
        clock_t dec_time = clock() - start;
        double dec_speed = (double)(size * iterations) / ((double)dec_time / CLOCKS_PER_SEC) / (1024 * 1024);
        
        double total_speed = (enc_speed + dec_speed) / 2;
        
        printf("%s\t%.2f\t\t%.2f\t\t%.2f\n", size_names[i], enc_speed, dec_speed, total_speed);
        
        free(plaintext);
        free(ciphertext);
        free(decrypted);
    }
    
    // Test crypto self-test
    printf("\nRunning cryptographic self-test...\n");
    if (lqx10_crypto_selftest() == LQX10_SUCCESS) {
        printf("Crypto self-test: PASSED\n");
    } else {
        printf("Crypto self-test: FAILED\n");
    }
    
    lqx10_destroy(ctx);
    return 0;
}

static int cmd_test(const cli_options_t *options) {
    (void)options; // Suppress unused parameter warning
    printf("Running LQX-10 test suite...\n\n");
    
    int tests_passed = 0;
    int tests_failed = 0;
    
    // Test 1: Context initialization
    printf("Test 1: Context initialization... ");
    lqx10_context_t *ctx = NULL;
    if (lqx10_init(&ctx) == LQX10_SUCCESS && ctx != NULL) {
        printf("PASSED\n");
        tests_passed++;
        lqx10_destroy(ctx);
    } else {
        printf("FAILED\n");
        tests_failed++;
    }
    
    // Test 2: Key derivation
    printf("Test 2: Key derivation... ");
    if (lqx10_init(&ctx) == LQX10_SUCCESS) {
        uint8_t salt[LQX10_SALT_SIZE];
        lqx10_secure_random_bytes(salt, LQX10_SALT_SIZE);
        
        if (lqx10_key_derive(ctx, (uint8_t*)"test", 4, salt, LQX10_SALT_SIZE, 1000) == LQX10_SUCCESS) {
            printf("PASSED\n");
            tests_passed++;
        } else {
            printf("FAILED\n");
            tests_failed++;
        }
        lqx10_destroy(ctx);
    } else {
        printf("FAILED\n");
        tests_failed++;
    }
    
    // Test 3: Encrypt/Decrypt round trip
    printf("Test 3: Encrypt/Decrypt round trip... ");
    if (lqx10_init(&ctx) == LQX10_SUCCESS) {
        uint8_t salt[LQX10_SALT_SIZE];
        lqx10_secure_random_bytes(salt, LQX10_SALT_SIZE);
        lqx10_key_derive(ctx, (uint8_t*)"test", 4, salt, LQX10_SALT_SIZE, 1000);
        
        const char *test_data = "The quick brown fox jumps over the lazy dog";
        size_t test_len = strlen(test_data);
        
        uint8_t ciphertext[1024];
        size_t cipher_len = sizeof(ciphertext);
        
        if (lqx10_encrypt(ctx, (uint8_t*)test_data, test_len, ciphertext, &cipher_len) == LQX10_SUCCESS) {
            uint8_t plaintext[1024];
            size_t plain_len = sizeof(plaintext);
            
            if (lqx10_decrypt(ctx, ciphertext, cipher_len, plaintext, &plain_len) == LQX10_SUCCESS &&
                plain_len == test_len &&
                memcmp(plaintext, test_data, test_len) == 0) {
                printf("PASSED\n");
                tests_passed++;
            } else {
                printf("FAILED (decryption error)\n");
                tests_failed++;
            }
        } else {
            printf("FAILED (encryption error)\n");
            tests_failed++;
        }
        
        lqx10_destroy(ctx);
    } else {
        printf("FAILED\n");
        tests_failed++;
    }
    
    // Test 4: Anti-debug check
    printf("Test 4: Anti-debug check... ");
    if (lqx10_init(&ctx) == LQX10_SUCCESS) {
        if (lqx10_anti_debug_check(ctx) == LQX10_SUCCESS) {
            printf("PASSED\n");
            tests_passed++;
        } else {
            printf("FAILED (debugger detected)\n");
            tests_failed++;
        }
        lqx10_destroy(ctx);
    } else {
        printf("FAILED\n");
        tests_failed++;
    }
    
    // Test 5: Key rotation
    printf("Test 5: Key rotation... ");
    if (lqx10_init(&ctx) == LQX10_SUCCESS) {
        uint8_t salt[LQX10_SALT_SIZE];
        lqx10_secure_random_bytes(salt, LQX10_SALT_SIZE);
        lqx10_key_derive(ctx, (uint8_t*)"test", 4, salt, LQX10_SALT_SIZE, 1000);
        
        if (lqx10_key_rotate(ctx) == LQX10_SUCCESS) {
            printf("PASSED\n");
            tests_passed++;
        } else {
            printf("FAILED\n");
            tests_failed++;
        }
        lqx10_destroy(ctx);
    } else {
        printf("FAILED\n");
        tests_failed++;
    }
    
    printf("\nTest Summary:\n");
    printf("  Passed: %d\n", tests_passed);
    printf("  Failed: %d\n", tests_failed);
    printf("  Total: %d\n", tests_passed + tests_failed);
    
    return tests_failed > 0 ? -1 : 0;
}

static int read_file_contents(const char *filename, uint8_t **data, size_t *size) {
    FILE *file = fopen(filename, "rb");
    if (!file) {
        return -1;
    }
    
    fseek(file, 0, SEEK_END);
    *size = ftell(file);
    fseek(file, 0, SEEK_SET);
    
    *data = malloc(*size);
    if (!*data) {
        fclose(file);
        return -1;
    }
    
    if (fread(*data, 1, *size, file) != *size) {
        free(*data);
        fclose(file);
        return -1;
    }
    
    fclose(file);
    return 0;
}

static int write_file_contents(const char *filename, const uint8_t *data, size_t size) {
    FILE *file = fopen(filename, "wb");
    if (!file) {
        return -1;
    }
    
    if (fwrite(data, 1, size, file) != size) {
        fclose(file);
        return -1;
    }
    
    fclose(file);
    return 0;
}

static int get_password(const char *prompt, char *password, size_t max_len) {
    printf("%s", prompt);
    fflush(stdout);
    
#ifdef _WIN32
    // Disable echo on Windows
    size_t i = 0;
    int ch;
    
    while (i < max_len - 1) {
        ch = _getch();
        if (ch == '\r' || ch == '\n') {
            break;
        } else if (ch == '\b' && i > 0) {
            i--;
            printf("\b \b");
            fflush(stdout);
        } else if (ch >= 32 && ch <= 126) {
            password[i++] = (char)ch;
            printf("*");
            fflush(stdout);
        }
    }
    password[i] = '\0';
    printf("\n");
#else
    // Use termios on Unix-like systems
    struct termios old_term, new_term;
    tcgetattr(STDIN_FILENO, &old_term);
    new_term = old_term;
    new_term.c_lflag &= ~(ECHO | ICANON);
    tcsetattr(STDIN_FILENO, TCSANOW, &new_term);
    
    size_t i = 0;
    int ch;
    
    while (i < max_len - 1) {
        ch = getchar();
        if (ch == '\n' || ch == '\r') {
            break;
        } else if (ch == 127 && i > 0) {  // Backspace
            i--;
            printf("\b \b");
            fflush(stdout);
        } else if (ch >= 32 && ch <= 126) {
            password[i++] = (char)ch;
            printf("*");
            fflush(stdout);
        }
    }
    password[i] = '\0';
    
    tcsetattr(STDIN_FILENO, TCSANOW, &old_term);
    printf("\n");
#endif
    
    return 0;
}

static void secure_zero_string(char *str) {
    if (str) {
        size_t len = strlen(str);
        lqx10_secure_memzero(str, len);
    }
}
