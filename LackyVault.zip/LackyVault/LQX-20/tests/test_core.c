#include "../include/lqx10_core.h"
#include "../include/lqx10_crypto.h"
#include "../include/lqx10_layers.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <time.h>

// Test framework macros
#define TEST_ASSERT(condition, message) \
    do { \
        if (!(condition)) { \
            printf("FAIL: %s - %s\n", __func__, message); \
            return 0; \
        } \
    } while(0)

#define TEST_PASS() \
    do { \
        printf("PASS: %s\n", __func__); \
        return 1; \
    } while(0)

#define RUN_TEST(test_func) \
    do { \
        printf("Running %s...\n", #test_func); \
        if (test_func()) { \
            tests_passed++; \
        } else { \
            tests_failed++; \
        } \
        total_tests++; \
    } while(0)

// Global test counters
static int total_tests = 0;
static int tests_passed = 0;
static int tests_failed = 0;

// Test data
static const uint8_t test_password[] = "SecurePassword123!@#";
static const uint8_t test_salt[] = {
    0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC, 0xDE, 0xF0,
    0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88,
    0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00,
    0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF
};

static const uint8_t test_plaintext[] = "This is a test message for LQX-10 encryption. It contains various characters and should be properly encrypted and decrypted.";

// Test functions
int test_context_initialization() {
    lqx10_context_t *ctx = NULL;
    lqx10_error_t result;

    // Test successful initialization
    result = lqx10_init(&ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Context initialization failed");
    TEST_ASSERT(ctx != NULL, "Context pointer is NULL");
    TEST_ASSERT(ctx->is_initialized == true, "Context not marked as initialized");
    
    // Test initialization flags
    TEST_ASSERT(ctx->anti_debug_enabled == true, "Anti-debug not enabled by default");
    TEST_ASSERT(ctx->runtime_mutation_enabled == true, "Runtime mutation not enabled by default");
    TEST_ASSERT(ctx->network_camouflage_enabled == true, "Network camouflage not enabled by default");
    TEST_ASSERT(ctx->metadata_encryption_enabled == true, "Metadata encryption not enabled by default");
    
    // Test layer states allocation
    for (int i = 0; i < LQX10_LAYER_COUNT; i++) {
        TEST_ASSERT(ctx->layer_states[i] != NULL, "Layer state not allocated");
        TEST_ASSERT(ctx->layer_states[i]->type == (lqx10_layer_type_t)i, "Layer type mismatch");
    }
    
    // Test key schedule allocation
    TEST_ASSERT(ctx->key_schedule != NULL, "Key schedule not allocated");
    
    // Clean up
    result = lqx10_destroy(ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Context destruction failed");
    
    TEST_PASS();
}

int test_context_destruction() {
    lqx10_context_t *ctx = NULL;
    lqx10_error_t result;

    // Initialize context
    result = lqx10_init(&ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Context initialization failed");
    
    // Test destruction
    result = lqx10_destroy(ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Context destruction failed");
    
    // Test double destruction (should be safe)
    result = lqx10_destroy(NULL);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "Double destruction should return error");
    
    TEST_PASS();
}

int test_key_derivation() {
    lqx10_context_t *ctx = NULL;
    lqx10_error_t result;
    uint8_t derived_key1[LQX10_KEY_SIZE];
    uint8_t derived_key2[LQX10_KEY_SIZE];

    // Initialize context
    result = lqx10_init(&ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Context initialization failed");
    
    // Test key derivation
    result = lqx10_key_derive(ctx, test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 10000);
    TEST_ASSERT(result == LQX10_SUCCESS, "Key derivation failed");
    
    // Save derived key
    memcpy(derived_key1, ctx->master_key, LQX10_KEY_SIZE);
    
    // Test deterministic derivation (same password/salt should give same key)
    result = lqx10_key_derive(ctx, test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 10000);
    TEST_ASSERT(result == LQX10_SUCCESS, "Second key derivation failed");
    TEST_ASSERT(memcmp(derived_key1, ctx->master_key, LQX10_KEY_SIZE) == 0,
               "Key derivation not deterministic");
    
    // Test different salt produces different key
    uint8_t different_salt[LQX10_SALT_SIZE];
    memcpy(different_salt, test_salt, sizeof(test_salt));
    different_salt[0] ^= 0xFF; // Change first byte
    
    result = lqx10_key_derive(ctx, test_password, sizeof(test_password) - 1,
                              different_salt, sizeof(different_salt), 10000);
    TEST_ASSERT(result == LQX10_SUCCESS, "Key derivation with different salt failed");
    TEST_ASSERT(memcmp(derived_key1, ctx->master_key, LQX10_KEY_SIZE) != 0,
               "Different salt produced same key");
    
    // Test invalid parameters
    result = lqx10_key_derive(NULL, test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 10000);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL context should fail");
    
    result = lqx10_key_derive(ctx, NULL, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 10000);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL password should fail");
    
    result = lqx10_key_derive(ctx, test_password, 0,
                              test_salt, sizeof(test_salt), 10000);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "Zero password length should fail");
    
    result = lqx10_key_derive(ctx, test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 0);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "Zero iterations should fail");
    
    lqx10_destroy(ctx);
    TEST_PASS();
}

int test_basic_encryption_decryption() {
    lqx10_context_t *ctx = NULL;
    lqx10_error_t result;
    uint8_t ciphertext[sizeof(test_plaintext) + 256]; // Extra space for expansion
    uint8_t decrypted[sizeof(test_plaintext) + 256];
    size_t ciphertext_len = sizeof(ciphertext);
    size_t decrypted_len = sizeof(decrypted);

    // Initialize and derive key
    result = lqx10_init(&ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Context initialization failed");
    
    result = lqx10_key_derive(ctx, test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 10000);
    TEST_ASSERT(result == LQX10_SUCCESS, "Key derivation failed");
    
    // Test encryption
    result = lqx10_encrypt(ctx, test_plaintext, sizeof(test_plaintext) - 1,
                           ciphertext, &ciphertext_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "Encryption failed");
    TEST_ASSERT(ciphertext_len > sizeof(test_plaintext) - 1, "Ciphertext too small");
    
    // Verify ciphertext is different from plaintext
    TEST_ASSERT(memcmp(test_plaintext, ciphertext, sizeof(test_plaintext) - 1) != 0,
               "Ciphertext same as plaintext");
    
    // Test decryption
    result = lqx10_decrypt(ctx, ciphertext, ciphertext_len,
                           decrypted, &decrypted_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "Decryption failed");
    TEST_ASSERT(decrypted_len == sizeof(test_plaintext) - 1, "Decrypted length mismatch");
    
    // Verify decrypted text matches original
    TEST_ASSERT(memcmp(test_plaintext, decrypted, sizeof(test_plaintext) - 1) == 0,
               "Decrypted text doesn't match original");
    
    lqx10_destroy(ctx);
    TEST_PASS();
}

int test_key_rotation() {
    lqx10_context_t *ctx = NULL;
    lqx10_error_t result;
    uint8_t old_key[LQX10_KEY_SIZE];
    uint8_t new_key[LQX10_KEY_SIZE];

    // Initialize and derive key
    result = lqx10_init(&ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Context initialization failed");
    
    result = lqx10_key_derive(ctx, test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 10000);
    TEST_ASSERT(result == LQX10_SUCCESS, "Key derivation failed");
    
    // Save current key
    memcpy(old_key, ctx->master_key, LQX10_KEY_SIZE);
    
    // Test key rotation
    result = lqx10_key_rotate(ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Key rotation failed");
    
    // Verify key changed
    memcpy(new_key, ctx->master_key, LQX10_KEY_SIZE);
    TEST_ASSERT(memcmp(old_key, new_key, LQX10_KEY_SIZE) != 0,
               "Key did not change after rotation");
    
    // Test invalid context
    result = lqx10_key_rotate(NULL);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL context should fail");
    
    lqx10_destroy(ctx);
    TEST_PASS();
}

int test_error_handling() {
    lqx10_context_t *ctx = NULL;
    lqx10_error_t result;
    uint8_t buffer[256];
    size_t buffer_len = sizeof(buffer);

    // Test operations on uninitialized context
    result = lqx10_encrypt(NULL, test_plaintext, sizeof(test_plaintext) - 1,
                           buffer, &buffer_len);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL context should fail");
    
    result = lqx10_decrypt(NULL, buffer, buffer_len,
                           buffer, &buffer_len);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL context should fail");
    
    // Initialize context
    result = lqx10_init(&ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Context initialization failed");
    
    // Test operations without key derivation
    result = lqx10_encrypt(ctx, test_plaintext, sizeof(test_plaintext) - 1,
                           buffer, &buffer_len);
    TEST_ASSERT(result != LQX10_SUCCESS, "Encryption without key should fail");
    
    // Test with too small buffer
    result = lqx10_key_derive(ctx, test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 10000);
    TEST_ASSERT(result == LQX10_SUCCESS, "Key derivation failed");
    
    buffer_len = 10; // Too small
    result = lqx10_encrypt(ctx, test_plaintext, sizeof(test_plaintext) - 1,
                           buffer, &buffer_len);
    TEST_ASSERT(result == LQX10_ERROR_BUFFER_TOO_SMALL, "Small buffer should fail");
    
    lqx10_destroy(ctx);
    TEST_PASS();
}

int test_error_strings() {
    const char *error_str;
    
    error_str = lqx10_error_string(LQX10_SUCCESS);
    TEST_ASSERT(error_str != NULL, "Error string is NULL");
    TEST_ASSERT(strlen(error_str) > 0, "Error string is empty");
    
    error_str = lqx10_error_string(LQX10_ERROR_INVALID_PARAM);
    TEST_ASSERT(error_str != NULL, "Error string is NULL");
    TEST_ASSERT(strlen(error_str) > 0, "Error string is empty");
    
    error_str = lqx10_error_string(LQX10_ERROR_CRYPTO_FAILURE);
    TEST_ASSERT(error_str != NULL, "Error string is NULL");
    TEST_ASSERT(strlen(error_str) > 0, "Error string is empty");
    
    // Test invalid error code
    error_str = lqx10_error_string((lqx10_error_t)-999);
    TEST_ASSERT(error_str != NULL, "Error string should handle invalid codes");
    
    TEST_PASS();
}

int test_version_info() {
    uint32_t major, minor, patch;
    lqx10_error_t result;
    
    result = lqx10_get_version(&major, &minor, &patch);
    TEST_ASSERT(result == LQX10_SUCCESS, "Version retrieval failed");
    TEST_ASSERT(major == LQX10_VERSION_MAJOR, "Major version mismatch");
    TEST_ASSERT(minor == LQX10_VERSION_MINOR, "Minor version mismatch");
    TEST_ASSERT(patch == LQX10_VERSION_PATCH, "Patch version mismatch");
    
    // Test NULL parameters
    result = lqx10_get_version(NULL, &minor, &patch);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL major should fail");
    
    result = lqx10_get_version(&major, NULL, &patch);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL minor should fail");
    
    result = lqx10_get_version(&major, &minor, NULL);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL patch should fail");
    
    TEST_PASS();
}

int test_secure_memory() {
    uint8_t buffer[256];
    lqx10_error_t result;
    
    // Fill buffer with test data
    for (int i = 0; i < sizeof(buffer); i++) {
        buffer[i] = (uint8_t)i;
    }
    
    // Test secure zero
    result = lqx10_secure_zero(buffer, sizeof(buffer));
    TEST_ASSERT(result == LQX10_SUCCESS, "Secure zero failed");
    
    // Verify buffer is zeroed
    for (int i = 0; i < sizeof(buffer); i++) {
        TEST_ASSERT(buffer[i] == 0, "Buffer not properly zeroed");
    }
    
    // Test NULL pointer
    result = lqx10_secure_zero(NULL, sizeof(buffer));
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL pointer should fail");
    
    // Test zero length (should be safe)
    result = lqx10_secure_zero(buffer, 0);
    TEST_ASSERT(result == LQX10_SUCCESS, "Zero length should succeed");
    
    TEST_PASS();
}

int test_multiple_contexts() {
    lqx10_context_t *ctx1 = NULL, *ctx2 = NULL;
    lqx10_error_t result;
    uint8_t ciphertext1[256], ciphertext2[256];
    size_t len1 = sizeof(ciphertext1), len2 = sizeof(ciphertext2);

    // Initialize multiple contexts
    result = lqx10_init(&ctx1);
    TEST_ASSERT(result == LQX10_SUCCESS, "First context initialization failed");
    
    result = lqx10_init(&ctx2);
    TEST_ASSERT(result == LQX10_SUCCESS, "Second context initialization failed");
    
    // Derive different keys
    result = lqx10_key_derive(ctx1, test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 10000);
    TEST_ASSERT(result == LQX10_SUCCESS, "First key derivation failed");
    
    uint8_t different_salt[LQX10_SALT_SIZE];
    memcpy(different_salt, test_salt, sizeof(test_salt));
    different_salt[0] ^= 0xFF;
    
    result = lqx10_key_derive(ctx2, test_password, sizeof(test_password) - 1,
                              different_salt, sizeof(different_salt), 10000);
    TEST_ASSERT(result == LQX10_SUCCESS, "Second key derivation failed");
    
    // Encrypt same plaintext with both contexts
    result = lqx10_encrypt(ctx1, test_plaintext, sizeof(test_plaintext) - 1,
                           ciphertext1, &len1);
    TEST_ASSERT(result == LQX10_SUCCESS, "First encryption failed");
    
    result = lqx10_encrypt(ctx2, test_plaintext, sizeof(test_plaintext) - 1,
                           ciphertext2, &len2);
    TEST_ASSERT(result == LQX10_SUCCESS, "Second encryption failed");
    
    // Verify ciphertexts are different
    TEST_ASSERT(memcmp(ciphertext1, ciphertext2, LQX10_MIN(len1, len2)) != 0,
               "Different contexts produced same ciphertext");
    
    // Clean up
    lqx10_destroy(ctx1);
    lqx10_destroy(ctx2);
    
    TEST_PASS();
}

int test_stress_operations() {
    lqx10_context_t *ctx = NULL;
    lqx10_error_t result;
    uint8_t plaintext[1024];
    uint8_t ciphertext[1536];
    uint8_t decrypted[1024];
    size_t ciphertext_len, decrypted_len;
    
    // Generate test data
    for (int i = 0; i < sizeof(plaintext); i++) {
        plaintext[i] = (uint8_t)(i * 7 + 13); // Pseudo-random pattern
    }
    
    // Initialize context
    result = lqx10_init(&ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Context initialization failed");
    
    result = lqx10_key_derive(ctx, test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 10000);
    TEST_ASSERT(result == LQX10_SUCCESS, "Key derivation failed");
    
    // Perform multiple encrypt/decrypt cycles
    for (int cycle = 0; cycle < 10; cycle++) {
        ciphertext_len = sizeof(ciphertext);
        decrypted_len = sizeof(decrypted);
        
        result = lqx10_encrypt(ctx, plaintext, sizeof(plaintext),
                               ciphertext, &ciphertext_len);
        TEST_ASSERT(result == LQX10_SUCCESS, "Encryption failed in stress test");
        
        result = lqx10_decrypt(ctx, ciphertext, ciphertext_len,
                               decrypted, &decrypted_len);
        TEST_ASSERT(result == LQX10_SUCCESS, "Decryption failed in stress test");
        
        TEST_ASSERT(decrypted_len == sizeof(plaintext), "Length mismatch in stress test");
        TEST_ASSERT(memcmp(plaintext, decrypted, sizeof(plaintext)) == 0,
                   "Data mismatch in stress test");
        
        // Rotate key every few cycles
        if (cycle % 3 == 0) {
            result = lqx10_key_rotate(ctx);
            TEST_ASSERT(result == LQX10_SUCCESS, "Key rotation failed in stress test");
        }
    }
    
    lqx10_destroy(ctx);
    TEST_PASS();
}

// Main test runner
int main() {
    printf("=== LQX-10 Core Tests ===\n\n");
    
    // Seed random number generator for tests
    srand((unsigned int)time(NULL));
    
    // Run all tests
    RUN_TEST(test_context_initialization);
    RUN_TEST(test_context_destruction);
    RUN_TEST(test_key_derivation);
    RUN_TEST(test_basic_encryption_decryption);
    RUN_TEST(test_key_rotation);
    RUN_TEST(test_error_handling);
    RUN_TEST(test_error_strings);
    RUN_TEST(test_version_info);
    RUN_TEST(test_secure_memory);
    RUN_TEST(test_multiple_contexts);
    RUN_TEST(test_stress_operations);
    
    // Print summary
    printf("\n=== Test Summary ===\n");
    printf("Total Tests: %d\n", total_tests);
    printf("Passed: %d\n", tests_passed);
    printf("Failed: %d\n", tests_failed);
    printf("Success Rate: %.1f%%\n", (double)tests_passed / total_tests * 100.0);
    
    if (tests_failed == 0) {
        printf("\n🎉 ALL TESTS PASSED! 🎉\n");
        return 0;
    } else {
        printf("\n❌ SOME TESTS FAILED ❌\n");
        return 1;
    }
} 