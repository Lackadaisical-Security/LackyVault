/**
 * @file test_utils.c
 * @brief LQX-10 Utility Function Tests
 * 
 * Comprehensive tests for utility functions including Base64, hex,
 * and secure memory operations.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include "../include/lqx10_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

// Test framework macros
#define TEST_ASSERT(condition, message) \
    do { \
        if (!(condition)) { \
            printf("FAIL: %s - %s\n", __func__, message); \
            return false; \
        } \
    } while(0)

#define TEST_PASS() \
    do { \
        return true; \
    } while(0)

// Test Base64 encoding
bool test_utils_base64(void) {
    // Test data
    const uint8_t test_data[] = "Hello, World!";
    size_t test_len = strlen((char*)test_data);
    
    // Encode
    char encoded[100];
    size_t encoded_len = sizeof(encoded);
    
    lqx10_error_t result = lqx10_base64_encode(test_data, test_len, encoded, &encoded_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "Base64 encoding failed");
    
    // Expected result for "Hello, World!"
    const char* expected = "SGVsbG8sIFdvcmxkIQ==";
    TEST_ASSERT(strcmp(encoded, expected) == 0, "Base64 encoding incorrect");
    
    // Decode
    uint8_t decoded[100];
    size_t decoded_len = sizeof(decoded);
    
    result = lqx10_base64_decode(encoded, strlen(encoded), decoded, &decoded_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "Base64 decoding failed");
    TEST_ASSERT(decoded_len == test_len, "Decoded length incorrect");
    TEST_ASSERT(memcmp(decoded, test_data, test_len) == 0, "Decoded data incorrect");
    
    // Test empty string
    char empty_encoded[10];
    size_t empty_encoded_len = sizeof(empty_encoded);
    result = lqx10_base64_encode((uint8_t*)"", 0, empty_encoded, &empty_encoded_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "Empty string encoding failed");
    TEST_ASSERT(empty_encoded_len == 0, "Empty string should produce empty output");
    
    // Test buffer too small
    char small_buffer[5];
    size_t small_len = sizeof(small_buffer);
    result = lqx10_base64_encode(test_data, test_len, small_buffer, &small_len);
    TEST_ASSERT(result == LQX10_ERROR_BUFFER_TOO_SMALL, "Should detect buffer too small");
    
    printf("PASS: %s\n", __func__);
    TEST_PASS();
}

// Test hex encoding
bool test_utils_hex(void) {
    // Test data
    const uint8_t test_data[] = {0x48, 0x65, 0x6C, 0x6C, 0x6F}; // "Hello"
    size_t test_len = sizeof(test_data);
    
    // Encode
    char encoded[20];
    size_t encoded_len = sizeof(encoded);
    
    lqx10_error_t result = lqx10_hex_encode(test_data, test_len, encoded, &encoded_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "Hex encoding failed");
    
    // Expected result
    const char* expected = "48656c6c6f";
    TEST_ASSERT(strcmp(encoded, expected) == 0, "Hex encoding incorrect");
    
    // Test uppercase
    char encoded_upper[20];
    size_t encoded_upper_len = sizeof(encoded_upper);
    
    result = lqx10_hex_encode_upper(test_data, test_len, encoded_upper, &encoded_upper_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "Hex uppercase encoding failed");
    
    const char* expected_upper = "48656C6C6F";
    TEST_ASSERT(strcmp(encoded_upper, expected_upper) == 0, "Hex uppercase encoding incorrect");
    
    // Decode
    uint8_t decoded[10];
    size_t decoded_len = sizeof(decoded);
    
    result = lqx10_hex_decode(encoded, strlen(encoded), decoded, &decoded_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "Hex decoding failed");
    TEST_ASSERT(decoded_len == test_len, "Decoded length incorrect");
    TEST_ASSERT(memcmp(decoded, test_data, test_len) == 0, "Decoded data incorrect");
    
    // Test validation
    bool valid = lqx10_hex_is_valid("48656c6c6f", 10);
    TEST_ASSERT(valid, "Valid hex string should be recognized");
    
    valid = lqx10_hex_is_valid("48656c6g6f", 10);
    TEST_ASSERT(!valid, "Invalid hex string should be rejected");
    
    // Test separated encoding
    char separated[30];
    size_t separated_len = sizeof(separated);
    
    result = lqx10_hex_encode_separated(test_data, test_len, ':', separated, &separated_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "Separated hex encoding failed");
    
    const char* expected_separated = "48:65:6c:6c:6f";
    TEST_ASSERT(strcmp(separated, expected_separated) == 0, "Separated hex encoding incorrect");
    
    printf("PASS: %s\n", __func__);
    TEST_PASS();
}

// Test secure memory operations
bool test_utils_secure_memory(void) {
    // Test secure zero
    uint8_t sensitive_data[] = "SecretPassword123!";
    size_t data_len = strlen((char*)sensitive_data);
    
    // Verify data is not zero initially
    bool has_nonzero = false;
    for (size_t i = 0; i < data_len; i++) {
        if (sensitive_data[i] != 0) {
            has_nonzero = true;
            break;
        }
    }
    TEST_ASSERT(has_nonzero, "Test data should have non-zero bytes");
    
    // Clear memory securely
    lqx10_secure_zero_memory(sensitive_data, data_len);
    
    // Verify all bytes are zero
    for (size_t i = 0; i < data_len; i++) {
        TEST_ASSERT(sensitive_data[i] == 0, "Memory should be zeroed");
    }
    
    // Test secure random bytes
    uint8_t random1[32];
    uint8_t random2[32];
    
    lqx10_error_t result = lqx10_secure_random_bytes(random1, sizeof(random1));
    TEST_ASSERT(result == LQX10_SUCCESS, "Random generation failed");
    
    result = lqx10_secure_random_bytes(random2, sizeof(random2));
    TEST_ASSERT(result == LQX10_SUCCESS, "Random generation failed");
    
    // Random data should be different
    bool different = false;
    for (size_t i = 0; i < sizeof(random1); i++) {
        if (random1[i] != random2[i]) {
            different = true;
            break;
        }
    }
    TEST_ASSERT(different, "Random bytes should be different");
    
    // Test constant-time comparison
    uint8_t data1[] = "password";
    uint8_t data2[] = "password";
    uint8_t data3[] = "Password";
    
    bool equal = lqx10_secure_compare(data1, data2, 8);
    TEST_ASSERT(equal, "Identical data should compare equal");
    
    equal = lqx10_secure_compare(data1, data3, 8);
    TEST_ASSERT(!equal, "Different data should compare not equal");
    
    printf("PASS: %s\n", __func__);
    TEST_PASS();
}

// Run all utility tests
int run_utils_tests(void) {
    printf("Running utility tests...\n");
    
    int passed = 0;
    int failed = 0;
    
    if (test_utils_base64()) {
        passed++;
    } else {
        failed++;
    }
    
    if (test_utils_hex()) {
        passed++;
    } else {
        failed++;
    }
    
    if (test_utils_secure_memory()) {
        passed++;
    } else {
        failed++;
    }
    
    printf("\nUtility tests summary: %d passed, %d failed\n", passed, failed);
    return failed == 0 ? 0 : 1;
}
