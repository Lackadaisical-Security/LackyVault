/**
 * @file test_main.c
 * @brief LQX-10 Test Suite Main Entry Point
 * 
 * Comprehensive test suite for all LQX-10 components including
 * unit tests, integration tests, and security validation.
 * 
 * @copyright Copyright (c) 2024 Lackadaisical Security. All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "../include/lqx10_core.h"

// Test framework definitions
typedef struct {
    const char* name;
    bool (*test_func)(void);
    bool critical;
} test_case_t;

// Test result statistics
typedef struct {
    int total_tests;
    int passed_tests;
    int failed_tests;
    int critical_failures;
} test_stats_t;

// Forward declarations of test functions
extern bool test_core_init_destroy(void);
extern bool test_core_key_derivation(void);
extern bool test_core_context_management(void);
extern bool test_crypto_blake3(void);
extern bool test_crypto_aes_gcm(void);
extern bool test_crypto_chacha20(void);
extern bool test_crypto_post_quantum(void);
extern bool test_layers_key_whitening(void);
extern bool test_layers_entropy_mixer(void);
extern bool test_layers_classical_cipher(void);
extern bool test_layers_integration(void);
extern bool test_mfa_totp(void);
extern bool test_mfa_hotp(void);
extern bool test_mfa_integration(void);
extern bool test_utils_base64(void);
extern bool test_utils_hex(void);
extern bool test_utils_secure_memory(void);

// Test suite configuration
static const test_case_t test_suite[] = {
    // Core tests (critical)
    {"Core: Init/Destroy", test_core_init_destroy, true},
    {"Core: Key Derivation", test_core_key_derivation, true},
    {"Core: Context Management", test_core_context_management, true},
    
    // Crypto tests (critical)
    {"Crypto: BLAKE3 Hash", test_crypto_blake3, true},
    {"Crypto: AES-GCM", test_crypto_aes_gcm, true},
    {"Crypto: ChaCha20", test_crypto_chacha20, true},
    {"Crypto: Post-Quantum", test_crypto_post_quantum, false},
    
    // Layer tests (critical)
    {"Layers: Key Whitening", test_layers_key_whitening, true},
    {"Layers: Entropy Mixer", test_layers_entropy_mixer, true},
    {"Layers: Classical Cipher", test_layers_classical_cipher, true},
    {"Layers: Integration", test_layers_integration, true},
    
    // MFA tests (non-critical)
    {"MFA: TOTP", test_mfa_totp, false},
    {"MFA: HOTP", test_mfa_hotp, false},
    {"MFA: Integration", test_mfa_integration, false},
    
    // Utility tests (non-critical)
    {"Utils: Base64", test_utils_base64, false},
    {"Utils: Hex", test_utils_hex, false},
    {"Utils: Secure Memory", test_utils_secure_memory, true},
};

// Test framework implementation
static void print_test_header(void) {
    printf("=================================================================\n");
    printf("                    LQX-10 Test Suite v1.0.0                   \n");
    printf("         10-Layer Hybrid Cryptographic Transformation Stack     \n");
    printf("=================================================================\n\n");
}

static void print_test_result(const char* test_name, bool passed, bool critical) {
    const char* status = passed ? "PASS" : "FAIL";
    const char* marker = critical ? " [CRITICAL]" : "";
    const char* color = passed ? "\033[32m" : "\033[31m"; // Green/Red
    const char* reset = "\033[0m";
    
    printf("  %-40s %s%s%s%s\n", test_name, color, status, reset, marker);
}

static void print_test_summary(const test_stats_t* stats) {
    printf("\n=================================================================\n");
    printf("                          Test Summary                           \n");
    printf("=================================================================\n");
    printf("Total Tests:        %d\n", stats->total_tests);
    printf("Passed:             %d\n", stats->passed_tests);
    printf("Failed:             %d\n", stats->failed_tests);
    printf("Critical Failures:  %d\n", stats->critical_failures);
    printf("Success Rate:       %.1f%%\n", 
           (float)stats->passed_tests / stats->total_tests * 100.0f);
    
    if (stats->failed_tests == 0) {
        printf("\n\033[32mAll tests passed! LQX-10 is ready for production.\033[0m\n");
    } else if (stats->critical_failures > 0) {
        printf("\n\033[31mCRITICAL FAILURES DETECTED! Do not use in production.\033[0m\n");
    } else {
        printf("\n\033[33mSome non-critical tests failed. Review before production use.\033[0m\n");
    }
    printf("=================================================================\n");
}

// Run security validation tests
static bool run_security_validation(void) {
    printf("\n--- Security Validation ---\n");
    
    // Test 1: Verify no debug symbols in release build
    #ifdef NDEBUG
    printf("  Debug symbols check:     PASS (Release build)\n");
    #else
    printf("  Debug symbols check:     WARN (Debug build - not for production)\n");
    #endif
    
    // Test 2: Verify stack protection
    #ifdef _FORTIFY_SOURCE
    printf("  Stack protection:        PASS (Fortify enabled)\n");
    #else
    printf("  Stack protection:        WARN (Consider enabling fortify)\n");
    #endif
    
    // Test 3: Test secure memory clearing
    uint8_t test_buffer[64];
    memset(test_buffer, 0xAA, sizeof(test_buffer));
    lqx10_secure_zero_memory(test_buffer, sizeof(test_buffer));
    
    bool memory_cleared = true;
    for (size_t i = 0; i < sizeof(test_buffer); i++) {
        if (test_buffer[i] != 0) {
            memory_cleared = false;
            break;
        }
    }
    printf("  Secure memory clear:     %s\n", memory_cleared ? "PASS" : "FAIL");
    
    // Test 4: Test entropy quality
    uint8_t entropy1[32], entropy2[32];
    lqx10_error_t result1 = lqx10_secure_random_bytes(entropy1, sizeof(entropy1));
    lqx10_error_t result2 = lqx10_secure_random_bytes(entropy2, sizeof(entropy2));
    
    bool entropy_different = (result1 == LQX10_SUCCESS && result2 == LQX10_SUCCESS);
    if (entropy_different) {
        entropy_different = (memcmp(entropy1, entropy2, sizeof(entropy1)) != 0);
    }
    printf("  Entropy quality:         %s\n", entropy_different ? "PASS" : "FAIL");
    
    return memory_cleared && entropy_different;
}

// Performance benchmark (basic)
static void run_performance_benchmark(void) {
    printf("\n--- Performance Benchmark ---\n");
    
    const size_t test_sizes[] = {1024, 4096, 16384, 65536};
    const size_t num_sizes = sizeof(test_sizes) / sizeof(test_sizes[0]);
    
    for (size_t i = 0; i < num_sizes; i++) {
        size_t test_size = test_sizes[i];
        uint8_t* test_data = malloc(test_size);
        uint8_t* output_data = malloc(test_size + 1024); // Extra space for overhead
        
        if (!test_data || !output_data) {
            printf("  Failed to allocate memory for benchmark\n");
            free(test_data);
            free(output_data);
            continue;
        }
        
        // Fill with test data
        for (size_t j = 0; j < test_size; j++) {
            test_data[j] = (uint8_t)(j & 0xFF);
        }
        
        // Time a simple encryption operation
        clock_t start = clock();
        
        lqx10_context_t* ctx = NULL;
        if (lqx10_init(&ctx) == LQX10_SUCCESS) {
            uint8_t password[] = "test_password_for_benchmark";
            uint8_t salt[32];
            lqx10_secure_random_bytes(salt, sizeof(salt));
            
            if (lqx10_key_derive(ctx, password, sizeof(password), salt, sizeof(salt), 10000) == LQX10_SUCCESS) {
                size_t output_len = test_size + 1024;
                lqx10_encrypt(ctx, test_data, test_size, output_data, &output_len);
            }
            
            lqx10_destroy(ctx);
        }
        
        clock_t end = clock();
        double time_ms = ((double)(end - start) / CLOCKS_PER_SEC) * 1000.0;
        double throughput_mbps = (test_size / 1024.0 / 1024.0) / (time_ms / 1000.0);
        
        printf("  %6zu bytes:  %8.2f ms  (%6.2f MB/s)\n", 
               test_size, time_ms, throughput_mbps);
        
        free(test_data);
        free(output_data);
    }
}

// Main test runner
int main(int argc, char* argv[]) {
    bool verbose = false;
    bool run_benchmarks = false;
    
    // Parse command line arguments
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-v") == 0 || strcmp(argv[i], "--verbose") == 0) {
            verbose = true;
        } else if (strcmp(argv[i], "-b") == 0 || strcmp(argv[i], "--benchmark") == 0) {
            run_benchmarks = true;
        } else if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            printf("Usage: %s [options]\n", argv[0]);
            printf("Options:\n");
            printf("  -v, --verbose     Verbose output\n");
            printf("  -b, --benchmark   Run performance benchmarks\n");
            printf("  -h, --help        Show this help\n");
            return 0;
        }
    }
    
    print_test_header();
    
    test_stats_t stats = {0};
    const size_t num_tests = sizeof(test_suite) / sizeof(test_suite[0]);
    
    printf("Running %zu tests...\n\n", num_tests);
    
    // Run all tests
    for (size_t i = 0; i < num_tests; i++) {
        const test_case_t* test = &test_suite[i];
        
        if (verbose) {
            printf("Running: %s\n", test->name);
        }
        
        bool passed = test->test_func();
        
        print_test_result(test->name, passed, test->critical);
        
        stats.total_tests++;
        if (passed) {
            stats.passed_tests++;
        } else {
            stats.failed_tests++;
            if (test->critical) {
                stats.critical_failures++;
            }
        }
    }
    
    // Run security validation
    run_security_validation();
    
    // Run benchmarks if requested
    if (run_benchmarks) {
        run_performance_benchmark();
    }
    
    // Print summary
    print_test_summary(&stats);
    
    // Return appropriate exit code
    if (stats.critical_failures > 0) {
        return 2; // Critical failure
    } else if (stats.failed_tests > 0) {
        return 1; // Non-critical failures
    } else {
        return 0; // All passed
    }
}
