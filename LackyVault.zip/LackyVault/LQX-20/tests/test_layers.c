#include "../include/lqx10_core.h"
#include "../include/lqx10_layers.h"
#include "../include/lqx10_crypto.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <time.h>

// Test framework macros
#define TEST_ASSERT(condition, message) \
    do { \
        if (!(condition)) { \
            printf("FAIL: %s - %s\n", __func__, message); \
            return 0; \
        } \
    } while(0)

#define TEST_PASS() \
    do { \
        printf("PASS: %s\n", __func__); \
        return 1; \
    } while(0)

#define RUN_TEST(test_func) \
    do { \
        printf("Running %s...\n", #test_func); \
        if (test_func()) { \
            tests_passed++; \
        } else { \
            tests_failed++; \
        } \
        total_tests++; \
    } while(0)

// Global test counters
static int total_tests = 0;
static int tests_passed = 0;
static int tests_failed = 0;

// Test data
static const uint8_t test_password[] = "LayerTestPassword123!";
static const uint8_t test_salt[] = {
    0xDE, 0xAD, 0xBE, 0xEF, 0xCA, 0xFE, 0xBA, 0xBE,
    0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC, 0xDE, 0xF0,
    0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88,
    0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00
};

static const uint8_t test_data[] = "This is test data for layer processing validation in the LQX-10 cryptographic primitive system.";

// Test layer initialization
int test_layer_initialization() {
    lqx10_context_t *ctx = NULL;
    lqx10_error_t result;

    result = lqx10_init(&ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Context initialization failed");

    // Test all layer states are properly initialized
    for (int i = 0; i < LQX10_LAYER_COUNT; i++) {
        TEST_ASSERT(ctx->layer_states[i] != NULL, "Layer state not allocated");
        TEST_ASSERT(ctx->layer_states[i]->type == (lqx10_layer_type_t)i, "Layer type mismatch");
        TEST_ASSERT(ctx->layer_states[i]->is_initialized == false, "Layer should not be initialized yet");
        TEST_ASSERT(ctx->layer_states[i]->is_active == false, "Layer should not be active yet");
    }

    lqx10_destroy(ctx);
    TEST_PASS();
}

// Test individual layer processing
int test_individual_layer_processing() {
    lqx10_context_t *ctx = NULL;
    lqx10_error_t result;
    uint8_t output[sizeof(test_data) + 256];
    size_t output_len = sizeof(output);

    result = lqx10_init(&ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Context initialization failed");

    result = lqx10_key_derive(ctx, test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 5000);
    TEST_ASSERT(result == LQX10_SUCCESS, "Key derivation failed");

    // Test each layer type
    for (int layer = 0; layer < LQX10_LAYER_COUNT; layer++) {
        output_len = sizeof(output);
        
        // Test encryption direction
        result = lqx10_layer_process(ctx, (lqx10_layer_type_t)layer,
                                     test_data, sizeof(test_data) - 1,
                                     output, &output_len, true);
        TEST_ASSERT(result == LQX10_SUCCESS, "Layer encryption failed");
        TEST_ASSERT(output_len > 0, "Output length is zero");

        // Verify output is different from input (for most layers)
        if (layer != LQX10_LAYER_PADDING_JITTER) { // Padding might not change small inputs
            TEST_ASSERT(memcmp(test_data, output, sizeof(test_data) - 1) != 0,
                       "Layer output same as input");
        }

        // Test decryption direction
        uint8_t decrypted[sizeof(test_data) + 256];
        size_t decrypted_len = sizeof(decrypted);
        
        result = lqx10_layer_process(ctx, (lqx10_layer_type_t)layer,
                                     output, output_len,
                                     decrypted, &decrypted_len, false);
        TEST_ASSERT(result == LQX10_SUCCESS, "Layer decryption failed");
        
        // For reversible layers, verify round-trip
        if (layer == LQX10_LAYER_KEY_WHITENING || 
            layer == LQX10_LAYER_CLASSICAL_CIPHER ||
            layer == LQX10_LAYER_POST_QUANTUM) {
            TEST_ASSERT(decrypted_len == sizeof(test_data) - 1, "Decrypted length mismatch");
            TEST_ASSERT(memcmp(test_data, decrypted, sizeof(test_data) - 1) == 0,
                       "Round-trip failed for reversible layer");
        }
    }

    lqx10_destroy(ctx);
    TEST_PASS();
}

// Test full layer stack processing
int test_full_layer_stack() {
    lqx10_context_t *ctx = NULL;
    lqx10_error_t result;
    uint8_t encrypted[sizeof(test_data) + 512];
    uint8_t decrypted[sizeof(test_data) + 512];
    size_t encrypted_len = sizeof(encrypted);
    size_t decrypted_len = sizeof(decrypted);

    result = lqx10_init(&ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Context initialization failed");

    result = lqx10_key_derive(ctx, test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 5000);
    TEST_ASSERT(result == LQX10_SUCCESS, "Key derivation failed");

    // Test full encryption through all layers
    result = lqx10_encrypt(ctx, test_data, sizeof(test_data) - 1,
                           encrypted, &encrypted_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "Full stack encryption failed");
    TEST_ASSERT(encrypted_len > sizeof(test_data) - 1, "Encrypted data too small");

    // Verify encrypted data is different from original
    TEST_ASSERT(memcmp(test_data, encrypted, sizeof(test_data) - 1) != 0,
               "Encrypted data same as original");

    // Test full decryption through all layers
    result = lqx10_decrypt(ctx, encrypted, encrypted_len,
                           decrypted, &decrypted_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "Full stack decryption failed");
    TEST_ASSERT(decrypted_len == sizeof(test_data) - 1, "Decrypted length mismatch");

    // Verify decrypted data matches original
    TEST_ASSERT(memcmp(test_data, decrypted, sizeof(test_data) - 1) == 0,
               "Decrypted data doesn't match original");

    lqx10_destroy(ctx);
    TEST_PASS();
}

// Test layer state persistence
int test_layer_state_persistence() {
    lqx10_context_t *ctx = NULL;
    lqx10_error_t result;
    uint8_t output1[256], output2[256];
    size_t output1_len = sizeof(output1);
    size_t output2_len = sizeof(output2);

    result = lqx10_init(&ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Context initialization failed");

    result = lqx10_key_derive(ctx, test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 5000);
    TEST_ASSERT(result == LQX10_SUCCESS, "Key derivation failed");

    // Process same data twice through entropy mixer layer
    result = lqx10_layer_process(ctx, LQX10_LAYER_ENTROPY_MIXER,
                                 test_data, sizeof(test_data) - 1,
                                 output1, &output1_len, true);
    TEST_ASSERT(result == LQX10_SUCCESS, "First entropy mixer processing failed");

    output2_len = sizeof(output2);
    result = lqx10_layer_process(ctx, LQX10_LAYER_ENTROPY_MIXER,
                                 test_data, sizeof(test_data) - 1,
                                 output2, &output2_len, true);
    TEST_ASSERT(result == LQX10_SUCCESS, "Second entropy mixer processing failed");

    // Outputs should be different due to state changes
    TEST_ASSERT(output1_len == output2_len, "Output lengths differ");
    TEST_ASSERT(memcmp(output1, output2, output1_len) != 0,
               "Entropy mixer outputs are identical (state not changing)");

    lqx10_destroy(ctx);
    TEST_PASS();
}

// Test layer error handling
int test_layer_error_handling() {
    lqx10_context_t *ctx = NULL;
    lqx10_error_t result;
    uint8_t output[256];
    size_t output_len = sizeof(output);

    result = lqx10_init(&ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Context initialization failed");

    // Test invalid parameters
    result = lqx10_layer_process(NULL, LQX10_LAYER_KEY_WHITENING,
                                 test_data, sizeof(test_data) - 1,
                                 output, &output_len, true);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL context should fail");

    result = lqx10_layer_process(ctx, (lqx10_layer_type_t)999,
                                 test_data, sizeof(test_data) - 1,
                                 output, &output_len, true);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_LAYER, "Invalid layer type should fail");

    result = lqx10_layer_process(ctx, LQX10_LAYER_KEY_WHITENING,
                                 NULL, sizeof(test_data) - 1,
                                 output, &output_len, true);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL input should fail");

    result = lqx10_layer_process(ctx, LQX10_LAYER_KEY_WHITENING,
                                 test_data, sizeof(test_data) - 1,
                                 NULL, &output_len, true);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL output should fail");

    // Test buffer too small
    output_len = 1; // Too small
    result = lqx10_layer_process(ctx, LQX10_LAYER_KEY_WHITENING,
                                 test_data, sizeof(test_data) - 1,
                                 output, &output_len, true);
    TEST_ASSERT(result == LQX10_ERROR_BUFFER_TOO_SMALL, "Small buffer should fail");

    lqx10_destroy(ctx);
    TEST_PASS();
}

// Test layer performance characteristics
int test_layer_performance() {
    lqx10_context_t *ctx = NULL;
    lqx10_error_t result;
    uint8_t large_data[8192];
    uint8_t output[sizeof(large_data) + 512];
    size_t output_len = sizeof(output);
    clock_t start, end;
    double cpu_time_used;

    // Initialize large test data
    for (size_t i = 0; i < sizeof(large_data); i++) {
        large_data[i] = (uint8_t)(i ^ (i >> 8));
    }

    result = lqx10_init(&ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Context initialization failed");

    result = lqx10_key_derive(ctx, test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 5000);
    TEST_ASSERT(result == LQX10_SUCCESS, "Key derivation failed");

    // Test performance of each layer
    for (int layer = 0; layer < LQX10_LAYER_COUNT; layer++) {
        output_len = sizeof(output);
        
        start = clock();
        result = lqx10_layer_process(ctx, (lqx10_layer_type_t)layer,
                                     large_data, sizeof(large_data),
                                     output, &output_len, true);
        end = clock();
        
        TEST_ASSERT(result == LQX10_SUCCESS, "Layer processing failed");
        
        cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;
        printf("Layer %d processing time: %f seconds\n", layer, cpu_time_used);
        
        // Performance should be reasonable (less than 1 second for 8KB)
        TEST_ASSERT(cpu_time_used < 1.0, "Layer processing too slow");
    }

    lqx10_destroy(ctx);
    TEST_PASS();
}

// Test layer security features
int test_layer_security_features() {
    lqx10_context_t *ctx = NULL;
    lqx10_error_t result;
    uint8_t output1[256], output2[256];
    size_t output1_len = sizeof(output1);
    size_t output2_len = sizeof(output2);

    result = lqx10_init(&ctx);
    TEST_ASSERT(result == LQX10_SUCCESS, "Context initialization failed");

    result = lqx10_key_derive(ctx, test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 5000);
    TEST_ASSERT(result == LQX10_SUCCESS, "Key derivation failed");

    // Test runtime mutation layer
    result = lqx10_layer_process(ctx, LQX10_LAYER_RUNTIME_MUTATION,
                                 test_data, sizeof(test_data) - 1,
                                 output1, &output1_len, true);
    TEST_ASSERT(result == LQX10_SUCCESS, "Runtime mutation processing failed");

    // Test decoy injection layer
    output2_len = sizeof(output2);
    result = lqx10_layer_process(ctx, LQX10_LAYER_DECOY_INJECTION,
                                 test_data, sizeof(test_data) - 1,
                                 output2, &output2_len, true);
    TEST_ASSERT(result == LQX10_SUCCESS, "Decoy injection processing failed");

    // Decoy injection should increase data size
    TEST_ASSERT(output2_len > sizeof(test_data) - 1, "Decoy injection didn't expand data");

    // Test network camouflage layer
    output1_len = sizeof(output1);
    result = lqx10_layer_process(ctx, LQX10_LAYER_NETWORK_CAMOUFLAGE,
                                 test_data, sizeof(test_data) - 1,
                                 output1, &output1_len, true);
    TEST_ASSERT(result == LQX10_SUCCESS, "Network camouflage processing failed");

    lqx10_destroy(ctx);
    TEST_PASS();
}

int main() {
    printf("=== LQX-10 Layer System Tests ===\n\n");

    RUN_TEST(test_layer_initialization);
    RUN_TEST(test_individual_layer_processing);
    RUN_TEST(test_full_layer_stack);
    RUN_TEST(test_layer_state_persistence);
    RUN_TEST(test_layer_error_handling);
    RUN_TEST(test_layer_performance);
    RUN_TEST(test_layer_security_features);

    printf("\n=== Test Results ===\n");
    printf("Total tests: %d\n", total_tests);
    printf("Passed: %d\n", tests_passed);
    printf("Failed: %d\n", tests_failed);
    printf("Success rate: %.1f%%\n", (double)tests_passed / total_tests * 100.0);

    return tests_failed == 0 ? 0 : 1;
} 