#include "../include/lqx10_core.h"
#include "../include/lqx10_crypto.h"
#include "../include/lqx10_layers.h"
#include "../include/lqx10_mfa.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
#define GET_TIME() GetTickCount64()
#else
#include <sys/time.h>
static uint64_t GET_TIME() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}
#endif

// Benchmark configuration
#define BENCHMARK_ITERATIONS 1000
#define BENCHMARK_DATA_SIZE 1024
#define BENCHMARK_LARGE_DATA_SIZE (1024 * 1024)

// Test data
static uint8_t test_data[BENCHMARK_LARGE_DATA_SIZE];
static uint8_t output_buffer[BENCHMARK_LARGE_DATA_SIZE + 4096]; // Extra space for overhead

// Benchmark result structure
typedef struct {
    const char *name;
    uint64_t total_time_ms;
    uint64_t operations;
    double ops_per_sec;
    double mb_per_sec;
} benchmark_result_t;

// Initialize test data
static void init_test_data(void) {
    for (size_t i = 0; i < sizeof(test_data); i++) {
        test_data[i] = (uint8_t)(i & 0xFF);
    }
}

// Print benchmark results
static void print_result(const benchmark_result_t *result) {
    printf("%-30s: %8.2f ops/sec, %8.2f MB/sec, %6llu ms total\n",
           result->name, result->ops_per_sec, result->mb_per_sec, 
           (unsigned long long)result->total_time_ms);
}

// Benchmark AES encryption
static benchmark_result_t benchmark_aes_encrypt(void) {
    benchmark_result_t result = {"AES-256 Encrypt", 0, 0, 0.0, 0.0};
    
    uint8_t key[LQX10_AES_KEY_SIZE];
    uint8_t iv[LQX10_IV_SIZE];
    lqx10_secure_random_bytes(key, sizeof(key));
    lqx10_secure_random_bytes(iv, sizeof(iv));
    
    uint64_t start_time = GET_TIME();
    
    for (int i = 0; i < BENCHMARK_ITERATIONS; i++) {
        size_t output_len = sizeof(output_buffer);
        lqx10_aes_encrypt(key, iv, test_data, BENCHMARK_DATA_SIZE, 
                          output_buffer, &output_len);
    }
    
    uint64_t end_time = GET_TIME();
    
    result.total_time_ms = end_time - start_time;
    result.operations = BENCHMARK_ITERATIONS;
    result.ops_per_sec = (double)result.operations * 1000.0 / result.total_time_ms;
    result.mb_per_sec = (double)(result.operations * BENCHMARK_DATA_SIZE) / 
                        (1024.0 * 1024.0) * 1000.0 / result.total_time_ms;
    
    lqx10_secure_memzero(key, sizeof(key));
    return result;
}

// Benchmark ChaCha20 encryption
static benchmark_result_t benchmark_chacha20_encrypt(void) {
    benchmark_result_t result = {"ChaCha20 Encrypt", 0, 0, 0.0, 0.0};
    
    uint8_t key[LQX10_CHACHA20_KEY_SIZE];
    uint8_t nonce[12];
    lqx10_secure_random_bytes(key, sizeof(key));
    lqx10_secure_random_bytes(nonce, sizeof(nonce));
    
    uint64_t start_time = GET_TIME();
    
    for (int i = 0; i < BENCHMARK_ITERATIONS; i++) {
        lqx10_chacha20_crypt(key, nonce, test_data, BENCHMARK_DATA_SIZE, output_buffer);
    }
    
    uint64_t end_time = GET_TIME();
    
    result.total_time_ms = end_time - start_time;
    result.operations = BENCHMARK_ITERATIONS;
    result.ops_per_sec = (double)result.operations * 1000.0 / result.total_time_ms;
    result.mb_per_sec = (double)(result.operations * BENCHMARK_DATA_SIZE) / 
                        (1024.0 * 1024.0) * 1000.0 / result.total_time_ms;
    
    lqx10_secure_memzero(key, sizeof(key));
    return result;
}

// Benchmark BLAKE3 hashing
static benchmark_result_t benchmark_blake3_hash(void) {
    benchmark_result_t result = {"BLAKE3 Hash", 0, 0, 0.0, 0.0};
    
    uint8_t hash_output[LQX10_BLAKE3_HASH_SIZE];
    
    uint64_t start_time = GET_TIME();
    
    for (int i = 0; i < BENCHMARK_ITERATIONS; i++) {
        lqx10_blake3_hash(test_data, BENCHMARK_DATA_SIZE, hash_output, sizeof(hash_output));
    }
    
    uint64_t end_time = GET_TIME();
    
    result.total_time_ms = end_time - start_time;
    result.operations = BENCHMARK_ITERATIONS;
    result.ops_per_sec = (double)result.operations * 1000.0 / result.total_time_ms;
    result.mb_per_sec = (double)(result.operations * BENCHMARK_DATA_SIZE) / 
                        (1024.0 * 1024.0) * 1000.0 / result.total_time_ms;
    
    return result;
}

// Benchmark Kyber KEM
static benchmark_result_t benchmark_kyber_kem(void) {
    benchmark_result_t result = {"Kyber KEM", 0, 0, 0.0, 0.0};
    
    uint8_t public_key[LQX10_KYBER_PUBLIC_KEY_SIZE];
    uint8_t secret_key[LQX10_KYBER_SECRET_KEY_SIZE];
    uint8_t ciphertext[LQX10_KYBER_CIPHERTEXT_SIZE];
    uint8_t shared_secret[LQX10_KYBER_SHARED_SECRET_SIZE];
    
    // Generate keys once
    lqx10_kyber_keygen(public_key, secret_key);
    
    uint64_t start_time = GET_TIME();
    
    for (int i = 0; i < BENCHMARK_ITERATIONS / 10; i++) { // Fewer iterations for expensive ops
        lqx10_kyber_encapsulate(public_key, ciphertext, shared_secret);
        lqx10_kyber_decapsulate(secret_key, ciphertext, shared_secret);
    }
    
    uint64_t end_time = GET_TIME();
    
    result.total_time_ms = end_time - start_time;
    result.operations = (BENCHMARK_ITERATIONS / 10) * 2; // Encap + Decap
    result.ops_per_sec = (double)result.operations * 1000.0 / result.total_time_ms;
    result.mb_per_sec = 0.0; // Not applicable for KEM
    
    lqx10_secure_memzero(secret_key, sizeof(secret_key));
    return result;
}

// Benchmark Dilithium signatures
static benchmark_result_t benchmark_dilithium_sign(void) {
    benchmark_result_t result = {"Dilithium Sign/Verify", 0, 0, 0.0, 0.0};
    
    uint8_t public_key[LQX10_DILITHIUM_PUBLIC_KEY_SIZE];
    uint8_t secret_key[LQX10_DILITHIUM_SECRET_KEY_SIZE];
    uint8_t signature[LQX10_DILITHIUM_SIGNATURE_SIZE];
    size_t signature_len = sizeof(signature);
    
    // Generate keys once
    lqx10_dilithium_keygen(public_key, secret_key);
    
    uint64_t start_time = GET_TIME();
    
    for (int i = 0; i < BENCHMARK_ITERATIONS / 10; i++) { // Fewer iterations for expensive ops
        signature_len = sizeof(signature);
        lqx10_dilithium_sign(secret_key, test_data, 256, signature, &signature_len);
        lqx10_dilithium_verify(public_key, test_data, 256, signature, signature_len);
    }
    
    uint64_t end_time = GET_TIME();
    
    result.total_time_ms = end_time - start_time;
    result.operations = (BENCHMARK_ITERATIONS / 10) * 2; // Sign + Verify
    result.ops_per_sec = (double)result.operations * 1000.0 / result.total_time_ms;
    result.mb_per_sec = 0.0; // Not applicable for signatures
    
    lqx10_secure_memzero(secret_key, sizeof(secret_key));
    return result;
}

// Benchmark hybrid cryptography
static benchmark_result_t benchmark_hybrid_crypto(void) {
    benchmark_result_t result = {"Hybrid Encrypt/Decrypt", 0, 0, 0.0, 0.0};
    
    lqx10_hybrid_keys_t keys;
    lqx10_hybrid_keygen(&keys);
    
    uint64_t start_time = GET_TIME();
    
    for (int i = 0; i < BENCHMARK_ITERATIONS / 20; i++) { // Even fewer iterations
        size_t ciphertext_len = sizeof(output_buffer);
        size_t plaintext_len = BENCHMARK_DATA_SIZE;
        
        lqx10_hybrid_encrypt(&keys, test_data, BENCHMARK_DATA_SIZE, 
                             output_buffer, &ciphertext_len);
        lqx10_hybrid_decrypt(&keys, output_buffer, ciphertext_len, 
                             test_data, &plaintext_len);
    }
    
    uint64_t end_time = GET_TIME();
    
    result.total_time_ms = end_time - start_time;
    result.operations = (BENCHMARK_ITERATIONS / 20) * 2; // Encrypt + Decrypt
    result.ops_per_sec = (double)result.operations * 1000.0 / result.total_time_ms;
    result.mb_per_sec = (double)(result.operations * BENCHMARK_DATA_SIZE) / 
                        (1024.0 * 1024.0) * 1000.0 / result.total_time_ms;
    
    lqx10_secure_memzero(&keys, sizeof(keys));
    return result;
}

// Benchmark full LQX-10 encryption
static benchmark_result_t benchmark_lqx10_full(void) {
    benchmark_result_t result = {"LQX-10 Full Stack", 0, 0, 0.0, 0.0};
    
    lqx10_context_t *ctx = NULL;
    lqx10_init(&ctx);
    
    const char *password = "benchmark_password_123";
    uint8_t salt[LQX10_SALT_SIZE];
    lqx10_secure_random_bytes(salt, sizeof(salt));
    
    lqx10_key_derive(ctx, (const uint8_t*)password, strlen(password), 
                     salt, sizeof(salt), 10000);
    
    uint64_t start_time = GET_TIME();
    
    for (int i = 0; i < BENCHMARK_ITERATIONS / 50; i++) { // Very few iterations for full stack
        size_t ciphertext_len = sizeof(output_buffer);
        size_t plaintext_len = BENCHMARK_DATA_SIZE;
        
        lqx10_encrypt(ctx, test_data, BENCHMARK_DATA_SIZE, output_buffer, &ciphertext_len);
        lqx10_decrypt(ctx, output_buffer, ciphertext_len, test_data, &plaintext_len);
    }
    
    uint64_t end_time = GET_TIME();
    
    result.total_time_ms = end_time - start_time;
    result.operations = (BENCHMARK_ITERATIONS / 50) * 2; // Encrypt + Decrypt
    result.ops_per_sec = (double)result.operations * 1000.0 / result.total_time_ms;
    result.mb_per_sec = (double)(result.operations * BENCHMARK_DATA_SIZE) / 
                        (1024.0 * 1024.0) * 1000.0 / result.total_time_ms;
    
    lqx10_destroy(ctx);
    return result;
}

// Benchmark key derivation
static benchmark_result_t benchmark_key_derivation(void) {
    benchmark_result_t result = {"Key Derivation (PBKDF2)", 0, 0, 0.0, 0.0};
    
    const char *password = "test_password_for_kdf";
    uint8_t salt[32];
    uint8_t output[32];
    lqx10_secure_random_bytes(salt, sizeof(salt));
    
    uint64_t start_time = GET_TIME();
    
    for (int i = 0; i < 100; i++) { // Very few iterations for expensive KDF
        lqx10_kdf_derive((const uint8_t*)password, strlen(password),
                         salt, sizeof(salt), 10000, output, sizeof(output));
    }
    
    uint64_t end_time = GET_TIME();
    
    result.total_time_ms = end_time - start_time;
    result.operations = 100;
    result.ops_per_sec = (double)result.operations * 1000.0 / result.total_time_ms;
    result.mb_per_sec = 0.0; // Not applicable for KDF
    
    return result;
}

// Main benchmark function
int main(int argc, char *argv[]) {
    printf("LQX-10 Cryptographic Primitive Benchmark Suite\n");
    printf("==============================================\n\n");
    
    // Initialize test data
    init_test_data();
    
    // Run benchmarks
    benchmark_result_t results[] = {
        benchmark_aes_encrypt(),
        benchmark_chacha20_encrypt(),
        benchmark_blake3_hash(),
        benchmark_key_derivation(),
        benchmark_kyber_kem(),
        benchmark_dilithium_sign(),
        benchmark_hybrid_crypto(),
        benchmark_lqx10_full()
    };
    
    // Print results
    printf("Benchmark Results (%d iterations, %d bytes data):\n", 
           BENCHMARK_ITERATIONS, BENCHMARK_DATA_SIZE);
    printf("%-30s   %12s   %12s   %10s\n", "Operation", "Ops/Sec", "MB/Sec", "Time (ms)");
    printf("%-30s   %12s   %12s   %10s\n", "----------", "-------", "------", "---------");
    
    for (size_t i = 0; i < sizeof(results) / sizeof(results[0]); i++) {
        print_result(&results[i]);
    }
    
    printf("\nBenchmark completed successfully.\n");
    
    // Clean up test data
    lqx10_secure_memzero(test_data, sizeof(test_data));
    lqx10_secure_memzero(output_buffer, sizeof(output_buffer));
    
    return 0;
} 