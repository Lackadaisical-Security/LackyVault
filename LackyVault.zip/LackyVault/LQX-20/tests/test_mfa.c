#include "../include/lqx10_core.h"
#include "../include/lqx10_mfa.h"
#include "../include/lqx10_crypto.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <time.h>

// Test framework macros
#define TEST_ASSERT(condition, message) \
    do { \
        if (!(condition)) { \
            printf("FAIL: %s - %s\n", __func__, message); \
            return 0; \
        } \
    } while(0)

#define TEST_PASS() \
    do { \
        printf("PASS: %s\n", __func__); \
        return 1; \
    } while(0)

#define RUN_TEST(test_func) \
    do { \
        printf("Running %s...\n", #test_func); \
        if (test_func()) { \
            tests_passed++; \
        } else { \
            tests_failed++; \
        } \
        total_tests++; \
    } while(0)

// Global test counters
static int total_tests = 0;
static int tests_passed = 0;
static int tests_failed = 0;

// Test data
static const uint8_t test_biometric_data[] = {
    0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC, 0xDE, 0xF0,
    0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88,
    0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00,
    0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF
};

// Test MFA context initialization
int test_mfa_context_initialization() {
    lqx10_mfa_context_t *mfa_ctx = NULL;
    lqx10_error_t result;

    // Test TOTP initialization
    result = lqx10_mfa_init(&mfa_ctx, LQX10_MFA_TOTP);
    TEST_ASSERT(result == LQX10_SUCCESS, "TOTP MFA context initialization failed");
    TEST_ASSERT(mfa_ctx != NULL, "MFA context pointer is NULL");
    TEST_ASSERT(mfa_ctx->type == LQX10_MFA_TOTP, "MFA type mismatch");
    TEST_ASSERT(mfa_ctx->is_enabled == false, "MFA should be disabled initially");
    TEST_ASSERT(mfa_ctx->is_verified == false, "MFA should be unverified initially");

    lqx10_mfa_destroy(mfa_ctx);

    // Test FIDO2 initialization
    result = lqx10_mfa_init(&mfa_ctx, LQX10_MFA_FIDO2);
    TEST_ASSERT(result == LQX10_SUCCESS, "FIDO2 MFA context initialization failed");
    TEST_ASSERT(mfa_ctx->type == LQX10_MFA_FIDO2, "FIDO2 type mismatch");

    lqx10_mfa_destroy(mfa_ctx);

    // Test Biometric initialization
    result = lqx10_mfa_init(&mfa_ctx, LQX10_MFA_BIOMETRIC);
    TEST_ASSERT(result == LQX10_SUCCESS, "Biometric MFA context initialization failed");
    TEST_ASSERT(mfa_ctx->type == LQX10_MFA_BIOMETRIC, "Biometric type mismatch");

    lqx10_mfa_destroy(mfa_ctx);

    // Test Smart Card initialization
    result = lqx10_mfa_init(&mfa_ctx, LQX10_MFA_SMART_CARD);
    TEST_ASSERT(result == LQX10_SUCCESS, "Smart Card MFA context initialization failed");
    TEST_ASSERT(mfa_ctx->type == LQX10_MFA_SMART_CARD, "Smart Card type mismatch");

    lqx10_mfa_destroy(mfa_ctx);

    TEST_PASS();
}

// Test TOTP functionality
int test_totp_functionality() {
    lqx10_mfa_context_t *mfa_ctx = NULL;
    lqx10_error_t result;
    uint8_t secret[LQX10_TOTP_SECRET_SIZE];
    uint32_t totp_code;
    uint64_t current_time = time(NULL);

    result = lqx10_mfa_init(&mfa_ctx, LQX10_MFA_TOTP);
    TEST_ASSERT(result == LQX10_SUCCESS, "TOTP MFA context initialization failed");

    // Generate TOTP secret
    result = lqx10_totp_generate_secret(secret, sizeof(secret));
    TEST_ASSERT(result == LQX10_SUCCESS, "TOTP secret generation failed");

    // Set up TOTP configuration
    memcpy(mfa_ctx->config.totp.secret, secret, sizeof(secret));
    mfa_ctx->config.totp.time_step = LQX10_TOTP_WINDOW_SIZE;
    mfa_ctx->config.totp.digits = LQX10_TOTP_DIGITS;
    mfa_ctx->is_enabled = true;

    // Generate TOTP code
    result = lqx10_totp_generate_code(secret, sizeof(secret), current_time, &totp_code);
    TEST_ASSERT(result == LQX10_SUCCESS, "TOTP code generation failed");
    TEST_ASSERT(totp_code >= 100000 && totp_code <= 999999, "TOTP code out of range");

    // Verify TOTP code
    result = lqx10_totp_verify_code(secret, sizeof(secret), totp_code, current_time, 1);
    TEST_ASSERT(result == LQX10_SUCCESS, "TOTP code verification failed");

    // Test with wrong code
    result = lqx10_totp_verify_code(secret, sizeof(secret), 123456, current_time, 1);
    TEST_ASSERT(result != LQX10_SUCCESS, "Wrong TOTP code should fail verification");

    // Test time window tolerance
    result = lqx10_totp_verify_code(secret, sizeof(secret), totp_code, 
                                    current_time + LQX10_TOTP_WINDOW_SIZE, 1);
    TEST_ASSERT(result == LQX10_SUCCESS, "TOTP should work within time window");

    lqx10_mfa_destroy(mfa_ctx);
    TEST_PASS();
}

// Test FIDO2 functionality
int test_fido2_functionality() {
    lqx10_mfa_context_t *mfa_ctx = NULL;
    lqx10_error_t result;
    uint8_t challenge[LQX10_FIDO2_CHALLENGE_SIZE];
    uint8_t signature[LQX10_FIDO2_SIGNATURE_SIZE];

    result = lqx10_mfa_init(&mfa_ctx, LQX10_MFA_FIDO2);
    TEST_ASSERT(result == LQX10_SUCCESS, "FIDO2 MFA context initialization failed");

    // Generate challenge
    result = lqx10_fido2_generate_challenge(challenge, sizeof(challenge));
    TEST_ASSERT(result == LQX10_SUCCESS, "FIDO2 challenge generation failed");

    // Register credential (simulated)
    result = lqx10_fido2_register_credential(mfa_ctx, challenge, sizeof(challenge));
    TEST_ASSERT(result == LQX10_SUCCESS, "FIDO2 credential registration failed");
    TEST_ASSERT(mfa_ctx->is_enabled == true, "FIDO2 should be enabled after registration");

    // Simulate signature generation (in real implementation, this comes from authenticator)
    memset(signature, 0xAB, sizeof(signature)); // Dummy signature

    // Test authentication
    result = lqx10_fido2_authenticate(mfa_ctx, challenge, sizeof(challenge),
                                      signature, sizeof(signature));
    // Note: This might fail in real implementation without proper signature
    // but we test the API structure

    lqx10_mfa_destroy(mfa_ctx);
    TEST_PASS();
}

// Test biometric functionality
int test_biometric_functionality() {
    lqx10_mfa_context_t *mfa_ctx = NULL;
    lqx10_error_t result;
    float match_score;

    result = lqx10_mfa_init(&mfa_ctx, LQX10_MFA_BIOMETRIC);
    TEST_ASSERT(result == LQX10_SUCCESS, "Biometric MFA context initialization failed");

    // Enroll biometric template
    result = lqx10_biometric_enroll(mfa_ctx, test_biometric_data, sizeof(test_biometric_data));
    TEST_ASSERT(result == LQX10_SUCCESS, "Biometric enrollment failed");
    TEST_ASSERT(mfa_ctx->is_enabled == true, "Biometric should be enabled after enrollment");

    // Test verification with same data (should match)
    result = lqx10_biometric_verify(mfa_ctx, test_biometric_data, 
                                    sizeof(test_biometric_data), &match_score);
    TEST_ASSERT(result == LQX10_SUCCESS, "Biometric verification failed");
    TEST_ASSERT(match_score >= LQX10_BIO_THRESHOLD, "Match score too low");

    // Test verification with different data (should not match)
    uint8_t different_data[sizeof(test_biometric_data)];
    memcpy(different_data, test_biometric_data, sizeof(test_biometric_data));
    different_data[0] ^= 0xFF; // Change first byte

    result = lqx10_biometric_verify(mfa_ctx, different_data, 
                                    sizeof(different_data), &match_score);
    // Should either fail or return low match score
    if (result == LQX10_SUCCESS) {
        TEST_ASSERT(match_score < LQX10_BIO_THRESHOLD, "Match score should be low for different data");
    }

    lqx10_mfa_destroy(mfa_ctx);
    TEST_PASS();
}

// Test smart card functionality
int test_smartcard_functionality() {
    lqx10_mfa_context_t *mfa_ctx = NULL;
    lqx10_error_t result;
    const uint8_t test_pin[] = "1234";

    result = lqx10_mfa_init(&mfa_ctx, LQX10_MFA_SMART_CARD);
    TEST_ASSERT(result == LQX10_SUCCESS, "Smart Card MFA context initialization failed");

    // Test card detection
    result = lqx10_smartcard_detect(mfa_ctx);
    // This might fail if no card is present, but we test the API

    // Test authentication with PIN
    result = lqx10_smartcard_authenticate(mfa_ctx, test_pin, sizeof(test_pin) - 1);
    // This might fail without actual smart card, but we test the API structure

    lqx10_mfa_destroy(mfa_ctx);
    TEST_PASS();
}

// Test multi-factor verification
int test_multi_factor_verification() {
    lqx10_mfa_context_t *totp_ctx = NULL;
    lqx10_mfa_context_t *bio_ctx = NULL;
    lqx10_mfa_context_t *contexts[2];
    lqx10_error_t result;
    uint8_t secret[LQX10_TOTP_SECRET_SIZE];
    uint32_t totp_code;

    // Initialize TOTP context
    result = lqx10_mfa_init(&totp_ctx, LQX10_MFA_TOTP);
    TEST_ASSERT(result == LQX10_SUCCESS, "TOTP context initialization failed");

    result = lqx10_totp_generate_secret(secret, sizeof(secret));
    TEST_ASSERT(result == LQX10_SUCCESS, "TOTP secret generation failed");

    memcpy(totp_ctx->config.totp.secret, secret, sizeof(secret));
    totp_ctx->is_enabled = true;

    result = lqx10_totp_generate_code(secret, sizeof(secret), time(NULL), &totp_code);
    TEST_ASSERT(result == LQX10_SUCCESS, "TOTP code generation failed");

    result = lqx10_totp_verify_code(secret, sizeof(secret), totp_code, time(NULL), 1);
    if (result == LQX10_SUCCESS) {
        totp_ctx->is_verified = true;
    }

    // Initialize Biometric context
    result = lqx10_mfa_init(&bio_ctx, LQX10_MFA_BIOMETRIC);
    TEST_ASSERT(result == LQX10_SUCCESS, "Biometric context initialization failed");

    result = lqx10_biometric_enroll(bio_ctx, test_biometric_data, sizeof(test_biometric_data));
    if (result == LQX10_SUCCESS) {
        bio_ctx->is_enabled = true;
        
        float match_score;
        result = lqx10_biometric_verify(bio_ctx, test_biometric_data, 
                                        sizeof(test_biometric_data), &match_score);
        if (result == LQX10_SUCCESS && match_score >= LQX10_BIO_THRESHOLD) {
            bio_ctx->is_verified = true;
        }
    }

    // Test multi-factor verification
    contexts[0] = totp_ctx;
    contexts[1] = bio_ctx;

    // Test requiring all factors
    result = lqx10_mfa_verify_multi(contexts, 2, true);
    // Result depends on whether both factors are verified

    // Test requiring any factor
    result = lqx10_mfa_verify_multi(contexts, 2, false);
    // Should succeed if at least one factor is verified

    lqx10_mfa_destroy(totp_ctx);
    lqx10_mfa_destroy(bio_ctx);
    TEST_PASS();
}

// Test MFA error handling
int test_mfa_error_handling() {
    lqx10_mfa_context_t *mfa_ctx = NULL;
    lqx10_error_t result;

    // Test NULL pointer handling
    result = lqx10_mfa_init(NULL, LQX10_MFA_TOTP);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL context pointer should fail");

    result = lqx10_mfa_destroy(NULL);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL context should fail");

    // Test invalid MFA type
    result = lqx10_mfa_init(&mfa_ctx, (lqx10_mfa_type_t)999);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "Invalid MFA type should fail");

    // Initialize valid context for further tests
    result = lqx10_mfa_init(&mfa_ctx, LQX10_MFA_TOTP);
    TEST_ASSERT(result == LQX10_SUCCESS, "Valid TOTP context initialization failed");

    // Test NULL parameters for TOTP functions
    result = lqx10_totp_generate_secret(NULL, LQX10_TOTP_SECRET_SIZE);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL secret buffer should fail");

    uint32_t code;
    result = lqx10_totp_generate_code(NULL, LQX10_TOTP_SECRET_SIZE, time(NULL), &code);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL secret should fail");

    result = lqx10_totp_generate_code(mfa_ctx->config.totp.secret, 
                                      LQX10_TOTP_SECRET_SIZE, time(NULL), NULL);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL code pointer should fail");

    lqx10_mfa_destroy(mfa_ctx);
    TEST_PASS();
}

int main() {
    printf("=== LQX-10 Multi-Factor Authentication Tests ===\n\n");

    RUN_TEST(test_mfa_context_initialization);
    RUN_TEST(test_totp_functionality);
    RUN_TEST(test_fido2_functionality);
    RUN_TEST(test_biometric_functionality);
    RUN_TEST(test_smartcard_functionality);
    RUN_TEST(test_multi_factor_verification);
    RUN_TEST(test_mfa_error_handling);

    printf("\n=== Test Results ===\n");
    printf("Total tests: %d\n", total_tests);
    printf("Passed: %d\n", tests_passed);
    printf("Failed: %d\n", tests_failed);
    printf("Success rate: %.1f%%\n", (double)tests_passed / total_tests * 100.0);

    return tests_failed == 0 ? 0 : 1;
} 