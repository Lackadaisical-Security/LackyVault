#include "../include/lqx10_crypto.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <time.h>

// Test framework macros
#define TEST_ASSERT(condition, message) \
    do { \
        if (!(condition)) { \
            printf("FAIL: %s - %s\n", __func__, message); \
            return 0; \
        } \
    } while(0)

#define TEST_PASS() \
    do { \
        printf("PASS: %s\n", __func__); \
        return 1; \
    } while(0)

#define RUN_TEST(test_func) \
    do { \
        printf("Running %s...\n", #test_func); \
        if (test_func()) { \
            tests_passed++; \
        } else { \
            tests_failed++; \
        } \
        total_tests++; \
    } while(0)

// Global test counters
static int total_tests = 0;
static int tests_passed = 0;
static int tests_failed = 0;

// Test data
static const uint8_t test_key_256[] = {
    0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF,
    0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10,
    0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88,
    0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00
};

static const uint8_t test_iv[] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F
};

static const uint8_t test_nonce[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x4A,
    0x00, 0x00, 0x00, 0x00
};

static const uint8_t test_plaintext[] = "Hello, LQX-10! This is a test message for cryptographic operations.";

static const uint8_t test_password[] = "TestPassword123";
static const uint8_t test_salt[] = {
    0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC, 0xDE, 0xF0,
    0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88
};

// Test AES encryption/decryption
int test_aes_encrypt_decrypt() {
    uint8_t ciphertext[sizeof(test_plaintext) + 16]; // Extra space for padding
    uint8_t decrypted[sizeof(test_plaintext)];
    size_t ciphertext_len = sizeof(ciphertext);
    size_t decrypted_len = sizeof(decrypted);
    lqx10_error_t result;

    // Test AES encryption
    result = lqx10_aes_encrypt(test_key_256, test_iv, test_plaintext, 
                               sizeof(test_plaintext) - 1, ciphertext, &ciphertext_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "AES encryption failed");
    TEST_ASSERT(ciphertext_len >= sizeof(test_plaintext) - 1, "Ciphertext too small");
    
    // Verify ciphertext is different from plaintext
    TEST_ASSERT(memcmp(test_plaintext, ciphertext, sizeof(test_plaintext) - 1) != 0,
               "Ciphertext identical to plaintext");

    // Test AES decryption
    result = lqx10_aes_decrypt(test_key_256, test_iv, ciphertext, ciphertext_len,
                               decrypted, &decrypted_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "AES decryption failed");
    TEST_ASSERT(decrypted_len == sizeof(test_plaintext) - 1, "Decrypted length mismatch");
    
    // Verify decrypted text matches original
    TEST_ASSERT(memcmp(test_plaintext, decrypted, sizeof(test_plaintext) - 1) == 0,
               "Decrypted text doesn't match original");

    // Test with invalid parameters
    result = lqx10_aes_encrypt(NULL, test_iv, test_plaintext, 
                               sizeof(test_plaintext) - 1, ciphertext, &ciphertext_len);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL key should fail");

    result = lqx10_aes_encrypt(test_key_256, NULL, test_plaintext, 
                               sizeof(test_plaintext) - 1, ciphertext, &ciphertext_len);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL IV should fail");

    TEST_PASS();
}

// Test ChaCha20 encryption/decryption
int test_chacha20_crypt() {
    uint8_t ciphertext[sizeof(test_plaintext)];
    uint8_t decrypted[sizeof(test_plaintext)];
    lqx10_error_t result;

    // Test ChaCha20 encryption
    result = lqx10_chacha20_crypt(test_key_256, test_nonce, test_plaintext,
                                  sizeof(test_plaintext) - 1, ciphertext);
    TEST_ASSERT(result == LQX10_SUCCESS, "ChaCha20 encryption failed");
    
    // Verify ciphertext is different from plaintext
    TEST_ASSERT(memcmp(test_plaintext, ciphertext, sizeof(test_plaintext) - 1) != 0,
               "Ciphertext identical to plaintext");

    // Test ChaCha20 decryption (same operation as encryption)
    result = lqx10_chacha20_crypt(test_key_256, test_nonce, ciphertext,
                                  sizeof(test_plaintext) - 1, decrypted);
    TEST_ASSERT(result == LQX10_SUCCESS, "ChaCha20 decryption failed");
    
    // Verify decrypted text matches original
    TEST_ASSERT(memcmp(test_plaintext, decrypted, sizeof(test_plaintext) - 1) == 0,
               "Decrypted text doesn't match original");

    // Test with invalid parameters
    result = lqx10_chacha20_crypt(NULL, test_nonce, test_plaintext,
                                  sizeof(test_plaintext) - 1, ciphertext);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL key should fail");

    TEST_PASS();
}

// Test BLAKE3 hashing
int test_blake3_hash() {
    uint8_t hash1[LQX10_BLAKE3_HASH_SIZE];
    uint8_t hash2[LQX10_BLAKE3_HASH_SIZE];
    uint8_t modified_input[sizeof(test_plaintext)];
    lqx10_error_t result;

    // Test basic hashing
    result = lqx10_blake3_hash(test_plaintext, sizeof(test_plaintext) - 1,
                               hash1, sizeof(hash1));
    TEST_ASSERT(result == LQX10_SUCCESS, "BLAKE3 hashing failed");

    // Test deterministic hashing (same input should give same hash)
    result = lqx10_blake3_hash(test_plaintext, sizeof(test_plaintext) - 1,
                               hash2, sizeof(hash2));
    TEST_ASSERT(result == LQX10_SUCCESS, "Second BLAKE3 hashing failed");
    TEST_ASSERT(memcmp(hash1, hash2, sizeof(hash1)) == 0,
               "BLAKE3 hashing not deterministic");

    // Test different input produces different hash
    memcpy(modified_input, test_plaintext, sizeof(test_plaintext));
    modified_input[0] ^= 0xFF; // Change first byte

    result = lqx10_blake3_hash(modified_input, sizeof(test_plaintext) - 1,
                               hash2, sizeof(hash2));
    TEST_ASSERT(result == LQX10_SUCCESS, "Modified input hashing failed");
    TEST_ASSERT(memcmp(hash1, hash2, sizeof(hash1)) != 0,
               "Different inputs produced same hash");

    // Test with invalid parameters
    result = lqx10_blake3_hash(NULL, sizeof(test_plaintext) - 1,
                               hash1, sizeof(hash1));
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL input should fail");

    result = lqx10_blake3_hash(test_plaintext, sizeof(test_plaintext) - 1,
                               NULL, sizeof(hash1));
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL output should fail");

    TEST_PASS();
}

// Test KDF (Key Derivation Function)
int test_kdf_derive() {
    uint8_t key1[32];
    uint8_t key2[32];
    uint8_t different_salt[16];
    lqx10_error_t result;

    // Test basic key derivation
    result = lqx10_kdf_derive(test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 10000,
                              key1, sizeof(key1));
    TEST_ASSERT(result == LQX10_SUCCESS, "KDF derivation failed");

    // Test deterministic derivation
    result = lqx10_kdf_derive(test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 10000,
                              key2, sizeof(key2));
    TEST_ASSERT(result == LQX10_SUCCESS, "Second KDF derivation failed");
    TEST_ASSERT(memcmp(key1, key2, sizeof(key1)) == 0,
               "KDF not deterministic");

    // Test different salt produces different key
    memcpy(different_salt, test_salt, sizeof(test_salt));
    different_salt[0] ^= 0xFF;

    result = lqx10_kdf_derive(test_password, sizeof(test_password) - 1,
                              different_salt, sizeof(different_salt), 10000,
                              key2, sizeof(key2));
    TEST_ASSERT(result == LQX10_SUCCESS, "KDF with different salt failed");
    TEST_ASSERT(memcmp(key1, key2, sizeof(key1)) != 0,
               "Different salt produced same key");

    // Test different iteration count
    result = lqx10_kdf_derive(test_password, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 20000,
                              key2, sizeof(key2));
    TEST_ASSERT(result == LQX10_SUCCESS, "KDF with different iterations failed");
    TEST_ASSERT(memcmp(key1, key2, sizeof(key1)) != 0,
               "Different iterations produced same key");

    // Test invalid parameters
    result = lqx10_kdf_derive(NULL, sizeof(test_password) - 1,
                              test_salt, sizeof(test_salt), 10000,
                              key1, sizeof(key1));
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL password should fail");

    result = lqx10_kdf_derive(test_password, 0,
                              test_salt, sizeof(test_salt), 10000,
                              key1, sizeof(key1));
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "Zero password length should fail");

    TEST_PASS();
}

// Test HKDF expand
int test_hkdf_expand() {
    uint8_t prk[32];
    uint8_t okm1[64];
    uint8_t okm2[64];
    uint8_t info[] = "LQX-10 Test Info";
    lqx10_error_t result;

    // Generate PRK first
    result = lqx10_blake3_hash(test_key_256, sizeof(test_key_256),
                               prk, sizeof(prk));
    TEST_ASSERT(result == LQX10_SUCCESS, "PRK generation failed");

    // Test HKDF expand
    result = lqx10_hkdf_expand(prk, sizeof(prk), info, sizeof(info) - 1,
                               okm1, sizeof(okm1));
    TEST_ASSERT(result == LQX10_SUCCESS, "HKDF expand failed");

    // Test deterministic expansion
    result = lqx10_hkdf_expand(prk, sizeof(prk), info, sizeof(info) - 1,
                               okm2, sizeof(okm2));
    TEST_ASSERT(result == LQX10_SUCCESS, "Second HKDF expand failed");
    TEST_ASSERT(memcmp(okm1, okm2, sizeof(okm1)) == 0,
               "HKDF expand not deterministic");

    // Test different info produces different output
    uint8_t different_info[] = "Different Info";
    result = lqx10_hkdf_expand(prk, sizeof(prk), different_info, sizeof(different_info) - 1,
                               okm2, sizeof(okm2));
    TEST_ASSERT(result == LQX10_SUCCESS, "HKDF expand with different info failed");
    TEST_ASSERT(memcmp(okm1, okm2, sizeof(okm1)) != 0,
               "Different info produced same output");

    TEST_PASS();
}

// Test Kyber key encapsulation
int test_kyber_kem() {
    uint8_t public_key[LQX10_KYBER_PUBLIC_KEY_SIZE];
    uint8_t secret_key[LQX10_KYBER_SECRET_KEY_SIZE];
    uint8_t ciphertext[LQX10_KYBER_CIPHERTEXT_SIZE];
    uint8_t shared_secret1[LQX10_KYBER_SHARED_SECRET_SIZE];
    uint8_t shared_secret2[LQX10_KYBER_SHARED_SECRET_SIZE];
    lqx10_error_t result;

    // Test key generation
    result = lqx10_kyber_keygen(public_key, secret_key);
    TEST_ASSERT(result == LQX10_SUCCESS, "Kyber key generation failed");

    // Test encapsulation
    result = lqx10_kyber_encapsulate(public_key, ciphertext, shared_secret1);
    TEST_ASSERT(result == LQX10_SUCCESS, "Kyber encapsulation failed");

    // Test decapsulation
    result = lqx10_kyber_decapsulate(secret_key, ciphertext, shared_secret2);
    TEST_ASSERT(result == LQX10_SUCCESS, "Kyber decapsulation failed");

    // Verify shared secrets match
    TEST_ASSERT(memcmp(shared_secret1, shared_secret2, LQX10_KYBER_SHARED_SECRET_SIZE) == 0,
               "Kyber shared secrets don't match");

    // Test with invalid parameters
    result = lqx10_kyber_keygen(NULL, secret_key);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL public key should fail");

    result = lqx10_kyber_encapsulate(NULL, ciphertext, shared_secret1);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL public key should fail");

    TEST_PASS();
}

// Test Dilithium digital signatures
int test_dilithium_signatures() {
    uint8_t public_key[LQX10_DILITHIUM_PUBLIC_KEY_SIZE];
    uint8_t secret_key[LQX10_DILITHIUM_SECRET_KEY_SIZE];
    uint8_t signature[LQX10_DILITHIUM_SIGNATURE_SIZE];
    size_t signature_len = sizeof(signature);
    lqx10_error_t result;

    // Test key generation
    result = lqx10_dilithium_keygen(public_key, secret_key);
    TEST_ASSERT(result == LQX10_SUCCESS, "Dilithium key generation failed");

    // Test signing
    result = lqx10_dilithium_sign(secret_key, test_plaintext, sizeof(test_plaintext) - 1,
                                  signature, &signature_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "Dilithium signing failed");
    TEST_ASSERT(signature_len <= LQX10_DILITHIUM_SIGNATURE_SIZE, "Signature too large");

    // Test verification
    result = lqx10_dilithium_verify(public_key, test_plaintext, sizeof(test_plaintext) - 1,
                                    signature, signature_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "Dilithium verification failed");

    // Test verification with modified message (should fail)
    uint8_t modified_message[sizeof(test_plaintext)];
    memcpy(modified_message, test_plaintext, sizeof(test_plaintext));
    modified_message[0] ^= 0xFF;

    result = lqx10_dilithium_verify(public_key, modified_message, sizeof(test_plaintext) - 1,
                                    signature, signature_len);
    TEST_ASSERT(result != LQX10_SUCCESS, "Modified message verification should fail");

    // Test with invalid parameters
    result = lqx10_dilithium_sign(NULL, test_plaintext, sizeof(test_plaintext) - 1,
                                  signature, &signature_len);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL secret key should fail");

    TEST_PASS();
}

// Test hybrid cryptography
int test_hybrid_crypto() {
    lqx10_hybrid_keys_t keys;
    uint8_t ciphertext[sizeof(test_plaintext) + 256];
    uint8_t decrypted[sizeof(test_plaintext)];
    size_t ciphertext_len = sizeof(ciphertext);
    size_t decrypted_len = sizeof(decrypted);
    lqx10_error_t result;

    // Test hybrid key generation
    result = lqx10_hybrid_keygen(&keys);
    TEST_ASSERT(result == LQX10_SUCCESS, "Hybrid key generation failed");
    TEST_ASSERT(keys.keys_generated == true, "Keys not marked as generated");

    // Test hybrid encryption
    result = lqx10_hybrid_encrypt(&keys, test_plaintext, sizeof(test_plaintext) - 1,
                                  ciphertext, &ciphertext_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "Hybrid encryption failed");
    TEST_ASSERT(ciphertext_len > sizeof(test_plaintext) - 1, "Ciphertext too small");

    // Test hybrid decryption
    result = lqx10_hybrid_decrypt(&keys, ciphertext, ciphertext_len,
                                  decrypted, &decrypted_len);
    TEST_ASSERT(result == LQX10_SUCCESS, "Hybrid decryption failed");
    TEST_ASSERT(decrypted_len == sizeof(test_plaintext) - 1, "Decrypted length mismatch");

    // Verify decrypted text matches original
    TEST_ASSERT(memcmp(test_plaintext, decrypted, sizeof(test_plaintext) - 1) == 0,
               "Decrypted text doesn't match original");

    // Test with uninitialized keys
    lqx10_hybrid_keys_t uninitialized_keys = {0};
    result = lqx10_hybrid_encrypt(&uninitialized_keys, test_plaintext, sizeof(test_plaintext) - 1,
                                  ciphertext, &ciphertext_len);
    TEST_ASSERT(result != LQX10_SUCCESS, "Uninitialized keys should fail");

    TEST_PASS();
}

// Test entropy and random number generation
int test_entropy_random() {
    lqx10_entropy_state_t entropy_state;
    uint8_t random1[64];
    uint8_t random2[64];
    uint8_t entropy_output[32];
    lqx10_error_t result;

    // Test entropy initialization
    result = lqx10_entropy_init(&entropy_state);
    TEST_ASSERT(result == LQX10_SUCCESS, "Entropy initialization failed");

    // Test entropy gathering
    result = lqx10_entropy_gather(&entropy_state);
    TEST_ASSERT(result == LQX10_SUCCESS, "Entropy gathering failed");

    // Test entropy extraction
    result = lqx10_entropy_extract(&entropy_state, entropy_output, sizeof(entropy_output));
    TEST_ASSERT(result == LQX10_SUCCESS, "Entropy extraction failed");

    // Test random byte generation
    result = lqx10_random_bytes(random1, sizeof(random1));
    TEST_ASSERT(result == LQX10_SUCCESS, "Random bytes generation failed");

    result = lqx10_random_bytes(random2, sizeof(random2));
    TEST_ASSERT(result == LQX10_SUCCESS, "Second random bytes generation failed");

    // Verify randomness (should be different)
    TEST_ASSERT(memcmp(random1, random2, sizeof(random1)) != 0,
               "Random bytes are identical");

    // Test secure random bytes
    result = lqx10_secure_random_bytes(random1, sizeof(random1));
    TEST_ASSERT(result == LQX10_SUCCESS, "Secure random bytes generation failed");

    // Test with invalid parameters
    result = lqx10_random_bytes(NULL, sizeof(random1));
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL output should fail");

    result = lqx10_random_bytes(random1, 0);
    TEST_ASSERT(result == LQX10_SUCCESS, "Zero length should succeed");

    TEST_PASS();
}

// Test memory protection functions
int test_memory_protection() {
    uint8_t buffer[4096];
    lqx10_error_t result;

    // Test memory locking
    result = lqx10_mlock_memory(buffer, sizeof(buffer));
    TEST_ASSERT(result == LQX10_SUCCESS, "Memory locking failed");

    // Test memory unlocking
    result = lqx10_munlock_memory(buffer, sizeof(buffer));
    TEST_ASSERT(result == LQX10_SUCCESS, "Memory unlocking failed");

    // Test secure memory zeroing
    memset(buffer, 0xAA, sizeof(buffer));
    result = lqx10_secure_memzero(buffer, sizeof(buffer));
    TEST_ASSERT(result == LQX10_SUCCESS, "Secure memory zero failed");

    // Verify buffer is zeroed
    for (int i = 0; i < sizeof(buffer); i++) {
        TEST_ASSERT(buffer[i] == 0, "Buffer not properly zeroed");
    }

    // Test with invalid parameters
    result = lqx10_mlock_memory(NULL, sizeof(buffer));
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL pointer should fail");

    TEST_PASS();
}

// Test constant-time comparison
int test_constant_time_compare() {
    uint8_t data1[] = "Hello, World!";
    uint8_t data2[] = "Hello, World!";
    uint8_t data3[] = "Hello, LQX10!";
    bool result_equal;
    lqx10_error_t result;

    // Test identical data
    result = lqx10_constant_time_compare(data1, data2, sizeof(data1) - 1, &result_equal);
    TEST_ASSERT(result == LQX10_SUCCESS, "Constant time compare failed");
    TEST_ASSERT(result_equal == true, "Identical data should be equal");

    // Test different data
    result = lqx10_constant_time_compare(data1, data3, sizeof(data1) - 1, &result_equal);
    TEST_ASSERT(result == LQX10_SUCCESS, "Constant time compare failed");
    TEST_ASSERT(result_equal == false, "Different data should not be equal");

    // Test with invalid parameters
    result = lqx10_constant_time_compare(NULL, data2, sizeof(data1) - 1, &result_equal);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL pointer should fail");

    result = lqx10_constant_time_compare(data1, data2, sizeof(data1) - 1, NULL);
    TEST_ASSERT(result == LQX10_ERROR_INVALID_PARAM, "NULL result should fail");

    TEST_PASS();
}

// Test cryptographic self-tests
int test_crypto_selftest() {
    lqx10_error_t result;

    result = lqx10_crypto_selftest();
    TEST_ASSERT(result == LQX10_SUCCESS, "Crypto self-test failed");

    TEST_PASS();
}

// Main test runner
int main() {
    printf("=== LQX-10 Cryptography Tests ===\n\n");
    
    // Seed random number generator for tests
    srand((unsigned int)time(NULL));
    
    // Run all tests
    RUN_TEST(test_aes_encrypt_decrypt);
    RUN_TEST(test_chacha20_crypt);
    RUN_TEST(test_blake3_hash);
    RUN_TEST(test_kdf_derive);
    RUN_TEST(test_hkdf_expand);
    RUN_TEST(test_kyber_kem);
    RUN_TEST(test_dilithium_signatures);
    RUN_TEST(test_hybrid_crypto);
    RUN_TEST(test_entropy_random);
    RUN_TEST(test_memory_protection);
    RUN_TEST(test_constant_time_compare);
    RUN_TEST(test_crypto_selftest);
    
    // Print summary
    printf("\n=== Test Summary ===\n");
    printf("Total Tests: %d\n", total_tests);
    printf("Passed: %d\n", tests_passed);
    printf("Failed: %d\n", tests_failed);
    printf("Success Rate: %.1f%%\n", (double)tests_passed / total_tests * 100.0);
    
    if (tests_failed == 0) {
        printf("\n🎉 ALL CRYPTO TESTS PASSED! 🎉\n");
        return 0;
    } else {
        printf("\n❌ SOME CRYPTO TESTS FAILED ❌\n");
        return 1;
    }
} 