#ifndef LQX10_LAYERS_H
#define LQX10_LAYERS_H

#include "lqx10_core.h"
#include "lqx10_crypto.h"
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

// Layer-specific structures and constants
#define LQX10_LAYER_STATE_SIZE 256
#define LQX10_DECOY_BLOCK_SIZE 64
#define LQX10_METADATA_SIZE 128
#define LQX10_PADDING_MAX_SIZE 512

// Layer overhead constants
#define LQX10_LAYER7_OVERHEAD 64

// Layer state structure
struct lqx10_layer_state {
    lqx10_layer_type_t type;
    uint8_t layer_key[LQX10_KEY_SIZE];
    uint8_t layer_iv[LQX10_IV_SIZE];
    uint8_t state_buffer[256];
    uint64_t operation_count;
    uint32_t entropy_pool[64];
    bool is_initialized;
    bool is_active;
      // Layer-specific state
    union layer_data {
        struct {
            uint8_t whitening_key[LQX10_KEY_SIZE];
            uint32_t rotation_counter;
            uint8_t whitening_mask[256];
            uint8_t entropy[32];
            uint8_t whitening_matrix[256][256];
        } key_whitening;
        
        struct {
            uint8_t entropy_pool[256];
            uint32_t pool_index;
            uint32_t mixer_rounds;
            uint32_t mix_schedule[64];
            uint64_t jitter_accumulator;
        } entropy_mixer;
          struct {
            uint8_t cipher_state[128];
            uint32_t round_keys[15][4]; // AES-256 round keys
            uint32_t rounds;
        } classical_cipher;
        
        struct {
            uint8_t pq_state[1024];
            uint32_t lattice_params[16];
            uint32_t lattice_dimension;
            lqx10_hybrid_keys_t hybrid_keys;
            lqx10_signature_keys_t sig_keys;
            uint8_t session_key[LQX10_KEY_SIZE];
        } post_quantum;
        
        struct {
            uint8_t camouflage_pattern[64];
            uint8_t traffic_pattern[256];
            uint32_t network_seed;
            uint32_t packet_delay;
            uint16_t fake_port;
            uint32_t protocol_mimics[16];
        } network_camouflage;
          struct {
            uint8_t padding_state[32];
            uint8_t padding_schedule[128];
            uint64_t timing_jitter[32];
            uint32_t size_variance[16];
            uint32_t jitter_seed;
        } padding_jitter;
        
        struct {
            uint8_t mutation_targets[128];
            uint8_t mutation_code[512];
            uint32_t instruction_pool[128];
            uint64_t mutation_seed;
            uint32_t mutation_counter;
            uint8_t mutation_table[256];
            uint64_t mutation_key;
        } runtime_mutation;
        
        struct {
            uint8_t decoy_patterns[256];
            uint8_t decoy_data[128];
            uint32_t decoy_count;
            uint64_t injection_pattern;
            uint32_t injection_counter;
        } decoy_injection;
          struct {
            uint8_t metadata_key[LQX10_KEY_SIZE];
            uint8_t signature_state[64];
            uint8_t hmac_key[LQX10_KEY_SIZE];
            uint64_t sequence_counter;
        } metadata_signature;
        
        struct {
            uint8_t shroud_key[LQX10_KEY_SIZE];
            uint8_t final_state[128];
            uint8_t final_iv[16];
            uint8_t steganographic_mask[256];
            bool obfuscation_enabled;
        } final_shroud;
    } layer_data;
};

// Layer function pointers for polymorphic operation
typedef struct {
    lqx10_error_t (*init)(lqx10_layer_state_t *state, const uint8_t *key);
    lqx10_error_t (*process)(lqx10_layer_state_t *state,
                             const uint8_t *input,
                             size_t input_len,
                             uint8_t *output,
                             size_t *output_len,
                             bool encrypt);
    lqx10_error_t (*cleanup)(lqx10_layer_state_t *state);
} lqx10_layer_interface_t;

// Layer 1: Key Whitening & Quantum Entropy
lqx10_error_t lqx10_layer1_key_whitening_init(lqx10_layer_state_t *state, 
                                               const uint8_t *key);
lqx10_error_t lqx10_layer1_key_whitening_process(lqx10_layer_state_t *state,
                                                  const uint8_t *input,
                                                  size_t input_len,
                                                  uint8_t *output,
                                                  size_t *output_len,
                                                  bool encrypt);

// Layer 2: Entropy Mixer & KDF
lqx10_error_t lqx10_layer2_entropy_mixer_init(lqx10_layer_state_t *state,
                                               const uint8_t *key);
lqx10_error_t lqx10_layer2_entropy_mixer_process(lqx10_layer_state_t *state,
                                                  const uint8_t *input,
                                                  size_t input_len,
                                                  uint8_t *output,
                                                  size_t *output_len,
                                                  bool encrypt);

// Layer 3: Classical Cipher Block Embed
lqx10_error_t lqx10_layer3_classical_cipher_init(lqx10_layer_state_t *state,
                                                  const uint8_t *key);
lqx10_error_t lqx10_layer3_classical_cipher_process(lqx10_layer_state_t *state,
                                                     const uint8_t *input,
                                                     size_t input_len,
                                                     uint8_t *output,
                                                     size_t *output_len,
                                                     bool encrypt);

// Layer 4: Post-Quantum Cipher
lqx10_error_t lqx10_layer4_post_quantum_init(lqx10_layer_state_t *state,
                                              const uint8_t *key);
lqx10_error_t lqx10_layer4_post_quantum_process(lqx10_layer_state_t *state,
                                                 const uint8_t *input,
                                                 size_t input_len,
                                                 uint8_t *output,
                                                 size_t *output_len,
                                                 bool encrypt);

// Layer 5: Network Camouflage
lqx10_error_t lqx10_layer5_network_camouflage_init(lqx10_layer_state_t *state,
                                                    const uint8_t *key);
lqx10_error_t lqx10_layer5_network_camouflage_process(lqx10_layer_state_t *state,
                                                       const uint8_t *input,
                                                       size_t input_len,
                                                       uint8_t *output,
                                                       size_t *output_len,
                                                       bool encrypt);

// Layer 6: Padding & Jitter Engine
lqx10_error_t lqx10_layer6_padding_jitter_init(lqx10_layer_state_t *state,
                                                const uint8_t *key);
lqx10_error_t lqx10_layer6_padding_jitter_process(lqx10_layer_state_t *state,
                                                   const uint8_t *input,
                                                   size_t input_len,
                                                   uint8_t *output,
                                                   size_t *output_len,
                                                   bool encrypt);

// Layer 7: Self-Mutating Runtime Engine
lqx10_error_t lqx10_layer7_runtime_mutation_init(lqx10_layer_state_t *state,
                                                  const uint8_t *key);
lqx10_error_t lqx10_layer7_runtime_mutation_process(lqx10_layer_state_t *state,
                                                     const uint8_t *input,
                                                     size_t input_len,
                                                     uint8_t *output,
                                                     size_t *output_len,
                                                     bool encrypt);

// Layer 8: Decoy Injection Layer
lqx10_error_t lqx10_layer8_decoy_injection_init(lqx10_layer_state_t *state,
                                                 const uint8_t *key);
lqx10_error_t lqx10_layer8_decoy_injection_process(lqx10_layer_state_t *state,
                                                   const uint8_t *input,
                                                   size_t input_len,
                                                   uint8_t *output,
                                                   size_t *output_len,
                                                   bool encrypt);

// Layer 9: Metadata Signature Layer
lqx10_error_t lqx10_layer9_metadata_signature_init(lqx10_layer_state_t *state,
                                                   const uint8_t *key);
lqx10_error_t lqx10_layer9_metadata_signature_process(lqx10_layer_state_t *state,
                                                      const uint8_t *input,
                                                      size_t input_len,
                                                      uint8_t *output,
                                                      size_t *output_len,
                                                      bool encrypt);

// Layer 10: Final Shroud Layer
lqx10_error_t lqx10_layer10_final_shroud_init(lqx10_layer_state_t *state,
                                              const uint8_t *key);
lqx10_error_t lqx10_layer10_final_shroud_process(lqx10_layer_state_t *state,
                                                 const uint8_t *input,
                                                 size_t input_len,
                                                 uint8_t *output,
                                                 size_t *output_len,
                                                 bool encrypt);

// Simplified layer function names used in implementation
lqx10_error_t lqx10_layer_key_whitening_process(lqx10_layer_state_t *state,
                                                const uint8_t *input,
                                                size_t input_len,
                                                uint8_t *output,
                                                size_t *output_len,
                                                bool encrypt);

lqx10_error_t lqx10_layer_entropy_mixer_process(lqx10_layer_state_t *state,
                                               const uint8_t *input,
                                               size_t input_len,
                                               uint8_t *output,
                                               size_t *output_len,
                                               bool encrypt);

lqx10_error_t lqx10_layer_classical_cipher_process(lqx10_layer_state_t *state,
                                                  const uint8_t *input,
                                                  size_t input_len,
                                                  uint8_t *output,
                                                  size_t *output_len,
                                                  bool encrypt);

lqx10_error_t lqx10_layer_post_quantum_process(lqx10_layer_state_t *state,
                                              const uint8_t *input,
                                              size_t input_len,
                                              uint8_t *output,
                                              size_t *output_len,
                                              bool encrypt);

lqx10_error_t lqx10_layer_network_camouflage_process(lqx10_layer_state_t *state,
                                                    const uint8_t *input,
                                                    size_t input_len,
                                                    uint8_t *output,
                                                    size_t *output_len,
                                                    bool encrypt);

lqx10_error_t lqx10_layer_padding_jitter_process(lqx10_layer_state_t *state,
                                                const uint8_t *input,
                                                size_t input_len,
                                                uint8_t *output,
                                                size_t *output_len,
                                                bool encrypt);

lqx10_error_t lqx10_layer_runtime_mutation_process(lqx10_layer_state_t *state,
                                                  const uint8_t *input,
                                                  size_t input_len,
                                                  uint8_t *output,
                                                  size_t *output_len,
                                                  bool encrypt);

lqx10_error_t lqx10_layer_decoy_injection_process(lqx10_layer_state_t *state,
                                                 const uint8_t *input,
                                                 size_t input_len,
                                                 uint8_t *output,
                                                 size_t *output_len,
                                                 bool encrypt);

lqx10_error_t lqx10_layer_metadata_signature_process(lqx10_layer_state_t *state,
                                                    const uint8_t *input,
                                                    size_t input_len,
                                                    uint8_t *output,
                                                    size_t *output_len,
                                                    bool encrypt);

lqx10_error_t lqx10_layer_final_shroud_process(lqx10_layer_state_t *state,
                                              const uint8_t *input,
                                              size_t input_len,
                                              uint8_t *output,
                                              size_t *output_len,
                                              bool encrypt);

// Missing constants for compilation
#define LQX10_LAYER1_OVERHEAD 64
#define LQX10_LAYER2_OVERHEAD 32
#define LQX10_LAYER3_OVERHEAD 16
#define LQX10_LAYER4_OVERHEAD 1104  // PQ_CIPHERTEXT_SIZE (1088) + IV (16)
#define LQX10_LAYER5_OVERHEAD 48
#define LQX10_LAYER6_OVERHEAD 32
#define LQX10_LAYER7_OVERHEAD 64
#define LQX10_LAYER8_OVERHEAD 96
#define LQX10_LAYER9_OVERHEAD 80
#define LQX10_LAYER10_OVERHEAD 128

// Forward declarations for implementation functions
uint8_t lqx10_gf256_multiply(uint8_t a, uint8_t b);

// Layer management functions
lqx10_error_t lqx10_layer_init(lqx10_layer_state_t *state,
                               lqx10_layer_type_t type,
                               const uint8_t *key);

lqx10_error_t lqx10_layer_cleanup(lqx10_layer_state_t *state);

lqx10_error_t lqx10_get_layer_interface(lqx10_layer_type_t type,
                                        lqx10_layer_interface_t **interface);

// Layer state management
lqx10_error_t lqx10_layer_serialize_state(const lqx10_layer_state_t *state,
                                           uint8_t *buffer,
                                           size_t *buffer_len);

lqx10_error_t lqx10_layer_deserialize_state(lqx10_layer_state_t *state,
                                             const uint8_t *buffer,
                                             size_t buffer_len);

// Layer security functions
lqx10_error_t lqx10_layer_rotate_keys(lqx10_layer_state_t *state);
lqx10_error_t lqx10_layer_reset_state(lqx10_layer_state_t *state);

// Layer forward/reverse function declarations
lqx10_error_t lqx10_layer8_forward(lqx10_context_t* ctx, const uint8_t* input, 
                                   size_t input_len, uint8_t* output, size_t* output_len);
lqx10_error_t lqx10_layer8_reverse(lqx10_context_t* ctx, const uint8_t* input, 
                                   size_t input_len, uint8_t* output, size_t* output_len);
lqx10_error_t lqx10_layer9_forward(lqx10_context_t* ctx, const uint8_t* input, 
                                   size_t input_len, uint8_t* output, size_t* output_len);
lqx10_error_t lqx10_layer9_reverse(lqx10_context_t* ctx, const uint8_t* input, 
                                   size_t input_len, uint8_t* output, size_t* output_len);
lqx10_error_t lqx10_layer10_forward(lqx10_context_t* ctx, const uint8_t* input, 
                                    size_t input_len, uint8_t* output, size_t* output_len);
lqx10_error_t lqx10_layer10_reverse(lqx10_context_t* ctx, const uint8_t* input, 
                                    size_t input_len, uint8_t* output, size_t* output_len);

#endif // LQX10_LAYERS_H
