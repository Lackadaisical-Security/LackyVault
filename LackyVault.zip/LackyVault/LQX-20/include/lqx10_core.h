#ifndef LQX10_CORE_H
#define LQX10_CORE_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

// LQX-10 Version and Constants
#define LQX10_VERSION_MAJOR 1
#define LQX10_VERSION_MINOR 0
#define LQX10_VERSION_PATCH 0

// Core Configuration
#define LQX10_LAYER_COUNT 10
#define LQX10_KEY_SIZE 32      // 256-bit keys
#define LQX10_BLOCK_SIZE 16    // 128-bit blocks
#define LQX10_IV_SIZE 16       // 128-bit IV
#define LQX10_TAG_SIZE 16      // 128-bit authentication tag
#define LQX10_SALT_SIZE 32     // 256-bit salt
#define LQX10_MAX_BUFFER_SIZE (1024 * 1024 * 16) // 16MB max buffer

// Context validation constants
#define LQX10_CONTEXT_MAGIC         0x4C5158FF  // "LQX" in hex + marker
#define LQX10_VERSION               0x00010000  // Version 1.0.0
#define LQX10_DEFAULT_KEY_ROUNDS    10000       // Default key derivation rounds

// Context states
#define LQX10_STATE_UNINITIALIZED   0x00
#define LQX10_STATE_INITIALIZED     0x01
#define LQX10_STATE_CONFIGURED      0x02
#define LQX10_STATE_ACTIVE          0x03
#define LQX10_STATE_CORRUPTED       0xFF

// Error Codes
typedef enum {
    LQX10_SUCCESS = 0,
    LQX10_ERROR_INVALID_PARAM = -1,
    LQX10_ERROR_BUFFER_TOO_SMALL = -2,
    LQX10_ERROR_CRYPTO_FAILURE = -3,
    LQX10_ERROR_MEMORY_ALLOCATION = -4,
    LQX10_ERROR_INVALID_KEY = -5,
    LQX10_ERROR_INVALID_LAYER = -6,
    LQX10_ERROR_AUTHENTICATION_FAILURE = -7,
    LQX10_ERROR_POST_QUANTUM_FAILURE = -8,
    LQX10_ERROR_ENTROPY_FAILURE = -9,
    LQX10_ERROR_RUNTIME_MUTATION_FAILURE = -10,
    // Additional error codes found in source files
    LQX10_ERROR_AUTH_FAILURE = -7,              // Alias for AUTHENTICATION_FAILURE
    LQX10_ERROR_MEMORY_ALLOC = -4,              // Alias for MEMORY_ALLOCATION  
    LQX10_ERROR_MFA_FAILURE = -11,
    LQX10_ERROR_CONTEXT_CORRUPTED = -12,
    LQX10_ERROR_ANTI_DEBUG = -13,
    LQX10_ERROR_RUNTIME_MUTATION = -10,         // Alias for RUNTIME_MUTATION_FAILURE
    LQX10_ERROR_INVALID_STATE = -14,            // Invalid state error
    LQX10_ERROR_UNKNOWN = -99
} lqx10_error_t;

// Layer Types
typedef enum {
    LQX10_LAYER_KEY_WHITENING = 0,
    LQX10_LAYER_ENTROPY_MIXER = 1,
    LQX10_LAYER_CLASSICAL_CIPHER = 2,
    LQX10_LAYER_POST_QUANTUM = 3,
    LQX10_LAYER_NETWORK_CAMOUFLAGE = 4,
    LQX10_LAYER_PADDING_JITTER = 5,
    LQX10_LAYER_RUNTIME_MUTATION = 6,
    LQX10_LAYER_DECOY_INJECTION = 7,
    LQX10_LAYER_METADATA_SIGNATURE = 8,
    LQX10_LAYER_FINAL_SHROUD = 9
} lqx10_layer_type_t;

// Quad-Layer Crypto Types
typedef enum {
    LQX10_CRYPTO_CLASSICAL = 0,
    LQX10_CRYPTO_POST_QUANTUM = 1,
    LQX10_CRYPTO_QUANTUM_SAFE = 2,
    LQX10_CRYPTO_HYBRID = 3
} lqx10_crypto_type_t;

// Forward declarations
typedef struct lqx10_context lqx10_context_t;
typedef struct lqx10_key_schedule lqx10_key_schedule_t;
typedef struct lqx10_layer_state lqx10_layer_state_t;
typedef struct lqx10_reality_anchor lqx10_reality_anchor_t;

// Reality Anchor structure for tamper detection and validation
struct lqx10_reality_anchor {
    uint64_t entropy_signature;
    uint64_t hardware_fingerprint;
    uint64_t quantum_proof;
    uint64_t temporal_signature;
    uint8_t anchor_hash[32];
    uint32_t validation_rounds;
    bool is_valid;
};

// Key schedule structure
struct lqx10_key_schedule {
    uint8_t round_keys[LQX10_LAYER_COUNT][LQX10_KEY_SIZE];
    uint8_t layer_ivs[LQX10_LAYER_COUNT][LQX10_IV_SIZE];
    uint64_t rotation_counter;
    uint32_t entropy_pool[256];
    bool keys_valid;
};

// Context structure (opaque to users)
struct lqx10_context {
    // Magic number and version for validation
    uint32_t magic;
    uint32_t version;
    uint32_t state;
    
    // Core state
    uint8_t master_key[LQX10_KEY_SIZE];
    uint8_t current_iv[LQX10_IV_SIZE];
    uint8_t salt[LQX10_SALT_SIZE];
    uint8_t iv[LQX10_IV_SIZE];
    
    // Derived keys for layers
    uint8_t derived_keys[LQX10_LAYER_COUNT][LQX10_KEY_SIZE];
    uint8_t layer_keys[LQX10_LAYER_COUNT][LQX10_KEY_SIZE];
    
    // Layer states
    lqx10_layer_state_t *layer_states[LQX10_LAYER_COUNT];
    
    // Key schedule
    lqx10_key_schedule_t *key_schedule;
    uint32_t key_schedule_rounds;
    uint32_t layer_mask;
    
    // Runtime state
    uint64_t operation_counter;
    uint64_t operation_start_time;
    uint64_t constant_time_mask;
    uint32_t mutation_seed;
    bool is_initialized;
    bool distress_mode;
    
    // Security flags
    bool anti_debug_enabled;
    bool runtime_mutation_enabled;
    bool network_camouflage_enabled;
    bool metadata_encryption_enabled;
    
    // Reality anchor for tamper detection
    lqx10_reality_anchor_t reality_anchor;
};

// Configuration structure for context setup
typedef struct lqx10_config {
    uint32_t key_schedule_rounds;
    uint32_t layer_mask;
    bool runtime_mutation_enabled;
    bool anti_debug_enabled;
    bool network_camouflage_enabled;
    bool metadata_encryption_enabled;
} lqx10_config_t;

// Context information structure for status queries
typedef struct lqx10_context_info {
    uint32_t version;
    uint32_t state;
    uint64_t operation_counter;
    uint32_t active_layers;
    uint32_t layer_mask;
    uint32_t key_schedule_rounds;
    bool is_initialized;
    bool distress_mode;
    bool reality_anchor_valid;
    bool runtime_mutation_enabled;
    bool anti_debug_enabled;
} lqx10_context_info_t;

// Core API Functions
lqx10_error_t lqx10_init(lqx10_context_t **ctx);
lqx10_error_t lqx10_destroy(lqx10_context_t *ctx);

// Key management
lqx10_error_t lqx10_key_derive(lqx10_context_t *ctx, 
                               const uint8_t *password, 
                               size_t password_len,
                               const uint8_t *salt,
                               size_t salt_len,
                               uint32_t iterations);

lqx10_error_t lqx10_key_rotate(lqx10_context_t *ctx);
lqx10_error_t lqx10_key_schedule_update(lqx10_context_t *ctx);

// Core encryption/decryption
lqx10_error_t lqx10_encrypt(lqx10_context_t *ctx,
                            const uint8_t *plaintext,
                            size_t plaintext_len,
                            uint8_t *ciphertext,
                            size_t *ciphertext_len);

lqx10_error_t lqx10_decrypt(lqx10_context_t *ctx,
                            const uint8_t *ciphertext,
                            size_t ciphertext_len,
                            uint8_t *plaintext,
                            size_t *plaintext_len);

// Layer operations
lqx10_error_t lqx10_layer_process(lqx10_context_t *ctx,
                                  lqx10_layer_type_t layer,
                                  const uint8_t *input,
                                  size_t input_len,
                                  uint8_t *output,
                                  size_t *output_len,
                                  bool encrypt);

// Security features
lqx10_error_t lqx10_enable_distress_mode(lqx10_context_t *ctx, const uint8_t *distress_key);
lqx10_error_t lqx10_disable_distress_mode(lqx10_context_t *ctx);
lqx10_error_t lqx10_runtime_mutate(lqx10_context_t *ctx);
lqx10_error_t lqx10_anti_debug_check(lqx10_context_t *ctx);

// Reality Anchor API functions
lqx10_error_t lqx10_reality_anchor_init(lqx10_context_t *ctx);
lqx10_error_t lqx10_reality_anchor_validate(lqx10_context_t *ctx);
lqx10_error_t lqx10_reality_anchor_refresh(lqx10_context_t *ctx);

// Configuration and info functions
lqx10_error_t lqx10_context_configure(lqx10_context_t *ctx, const lqx10_config_t *config);
lqx10_error_t lqx10_context_get_info(const lqx10_context_t *ctx, lqx10_context_info_t *info);

// Utility functions
const char* lqx10_error_string(lqx10_error_t error);
lqx10_error_t lqx10_get_version(uint32_t *major, uint32_t *minor, uint32_t *patch);
lqx10_error_t lqx10_secure_zero(void *ptr, size_t len);
lqx10_error_t lqx10_secure_random_bytes(uint8_t *output, size_t output_len);

// Missing function declarations
lqx10_error_t lqx10_layer_init(lqx10_layer_state_t *state, lqx10_layer_type_t type, const uint8_t *key);
lqx10_error_t lqx10_layer_cleanup(lqx10_layer_state_t *state);
lqx10_error_t lqx10_context_validate(lqx10_context_t *ctx);

// Internal helper macros
#define LQX10_SECURE_ZERO(ptr, len) lqx10_secure_zero(ptr, len)
#define LQX10_MIN(a, b) ((a) < (b) ? (a) : (b))
#define LQX10_MAX(a, b) ((a) > (b) ? (a) : (b))

// Compiler attributes for security
#ifdef _MSC_VER
    #define LQX10_NOINLINE __declspec(noinline)
    #define LQX10_FORCE_INLINE __forceinline
    #define LQX10_ALIGN(x) __declspec(align(x))
#elif defined(__GNUC__)
    #define LQX10_NOINLINE __attribute__((noinline))
    #define LQX10_FORCE_INLINE __attribute__((always_inline)) inline
    #define LQX10_ALIGN(x) __attribute__((aligned(x)))
#else
    #define LQX10_NOINLINE
    #define LQX10_FORCE_INLINE inline
    #define LQX10_ALIGN(x)
#endif

#endif // LQX10_CORE_H
