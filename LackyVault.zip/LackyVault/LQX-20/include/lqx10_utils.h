#ifndef LQX10_UTILS_H
#define LQX10_UTILS_H

#include "lqx10_core.h"

// Utility constants
#define LQX10_HEX_BUFFER_SIZE 1024
#define LQX10_BASE64_BUFFER_SIZE 1024
#define LQX10_LOG_MESSAGE_SIZE 512

// Logging levels
typedef enum {
    LQX10_LOG_TRACE = 0,
    LQX10_LOG_DEBUG = 1,
    LQX10_LOG_INFO = 2,
    LQX10_LOG_WARN = 3,
    LQX10_LOG_ERROR = 4,
    LQX10_LOG_FATAL = 5
} lqx10_log_level_t;

// Benchmark results
typedef struct {
    const char *operation_name;
    uint64_t operations_performed;
    double total_time_seconds;
    double operations_per_second;
    double average_time_per_operation;
    size_t bytes_processed;
    double throughput_mbps;
} lqx10_benchmark_result_t;

// Memory pool for secure allocations
typedef struct {
    void *pool_memory;
    size_t pool_size;
    size_t used_size;
    size_t allocation_count;
    bool is_locked;
} lqx10_memory_pool_t;

// Anti-debug and security utilities
typedef struct {
    bool debugger_detected;
    bool vm_detected;
    bool analysis_tools_detected;
    uint32_t integrity_hash;
    uint64_t runtime_checksum;
} lqx10_security_status_t;

// Encoding/Decoding functions
lqx10_error_t lqx10_hex_encode(const uint8_t *input, size_t input_len,
                               char *output, size_t *output_len);
lqx10_error_t lqx10_hex_decode(const char *input, size_t input_len,
                               uint8_t *output, size_t *output_len);
lqx10_error_t lqx10_base64_encode(const uint8_t *input, size_t input_len,
                                  char *output, size_t *output_len);
lqx10_error_t lqx10_base64_decode(const char *input, size_t input_len,
                                  uint8_t *output, size_t *output_len);

// Secure memory management
lqx10_error_t lqx10_memory_pool_create(lqx10_memory_pool_t **pool, size_t pool_size);
lqx10_error_t lqx10_memory_pool_destroy(lqx10_memory_pool_t *pool);
lqx10_error_t lqx10_memory_pool_alloc(lqx10_memory_pool_t *pool, 
                                      size_t size, void **ptr);
lqx10_error_t lqx10_memory_pool_free(lqx10_memory_pool_t *pool, void *ptr);

// Timing and benchmarking
lqx10_error_t lqx10_benchmark_start(const char *operation_name);
lqx10_error_t lqx10_benchmark_end(const char *operation_name, 
                                  size_t bytes_processed,
                                  lqx10_benchmark_result_t *result);
lqx10_error_t lqx10_get_high_resolution_time(uint64_t *time_ns);
lqx10_error_t lqx10_sleep_microseconds(uint64_t microseconds);

// Logging and debugging
lqx10_error_t lqx10_log_init(const char *log_file_path, lqx10_log_level_t min_level);
lqx10_error_t lqx10_log_message(lqx10_log_level_t level, const char *format, ...);
lqx10_error_t lqx10_log_hex_dump(lqx10_log_level_t level, const char *label, 
                                 const uint8_t *data, size_t data_len);
lqx10_error_t lqx10_log_cleanup(void);

// Security and anti-analysis
lqx10_error_t lqx10_security_check(lqx10_security_status_t *status);
lqx10_error_t lqx10_anti_debug_init(void);
lqx10_error_t lqx10_detect_virtualization(bool *is_vm);
lqx10_error_t lqx10_detect_analysis_tools(bool *tools_present);
lqx10_error_t lqx10_integrity_check(uint32_t expected_hash, bool *integrity_ok);

// System information
lqx10_error_t lqx10_get_system_entropy(uint8_t *output, size_t output_len);
lqx10_error_t lqx10_get_cpu_features(uint32_t *features);
lqx10_error_t lqx10_get_memory_info(size_t *total_memory, size_t *available_memory);

// Network utilities
lqx10_error_t lqx10_generate_fake_traffic(const uint8_t *real_data, size_t real_len,
                                          uint8_t *fake_traffic, size_t *fake_len);
lqx10_error_t lqx10_obfuscate_packet(const uint8_t *packet, size_t packet_len,
                                     uint8_t *obfuscated, size_t *obfuscated_len);

// Configuration management
lqx10_error_t lqx10_config_load(const char *config_file);
lqx10_error_t lqx10_config_get_string(const char *key, char *value, size_t value_len);
lqx10_error_t lqx10_config_get_int(const char *key, int *value);
lqx10_error_t lqx10_config_get_bool(const char *key, bool *value);

// Error handling utilities
const char* lqx10_get_error_description(lqx10_error_t error);
lqx10_error_t lqx10_dump_error_state(char *buffer, size_t buffer_len);

// Miscellaneous utilities
lqx10_error_t lqx10_generate_uuid(char *uuid_str, size_t uuid_str_len);
lqx10_error_t lqx10_calculate_checksum(const uint8_t *data, size_t data_len, 
                                       uint32_t *checksum);
lqx10_error_t lqx10_secure_compare(const void *a, const void *b, size_t len, bool *equal);

#endif // LQX10_UTILS_H
