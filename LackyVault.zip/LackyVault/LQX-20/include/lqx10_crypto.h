#ifndef LQX10_CRYPTO_H
#define LQX10_CRYPTO_H

#include "lqx10_core.h"

// Classical cryptography algorithms
#define LQX10_AES_KEY_SIZE 32
#define LQX10_CHACHA20_KEY_SIZE 32
#define LQX10_BLAKE3_HASH_SIZE 32

// Post-quantum algorithms
#define LQX10_KYBER_PUBLIC_KEY_SIZE 1568
#define LQX10_KYBER_SECRET_KEY_SIZE 3168
#define LQX10_KYBER_CIPHERTEXT_SIZE 1568
#define LQX10_KYBER_SHARED_SECRET_SIZE 32

#define LQX10_DILITHIUM_PUBLIC_KEY_SIZE 1952
#define LQX10_DILITHIUM_SECRET_KEY_SIZE 4000
#define LQX10_DILITHIUM_SIGNATURE_SIZE 3293

// Hybrid cryptography structures
typedef struct {
    uint8_t classical_key[LQX10_AES_KEY_SIZE];
    uint8_t pq_public_key[LQX10_KYBER_PUBLIC_KEY_SIZE];
    uint8_t pq_secret_key[LQX10_KYBER_SECRET_KEY_SIZE];
    uint8_t shared_secret[LQX10_KYBER_SHARED_SECRET_SIZE];
    bool keys_generated;
} lqx10_hybrid_keys_t;

typedef struct {
    uint8_t signature[LQX10_DILITHIUM_SIGNATURE_SIZE];
    uint8_t public_key[LQX10_DILITHIUM_PUBLIC_KEY_SIZE];
    uint8_t secret_key[LQX10_DILITHIUM_SECRET_KEY_SIZE];
    bool keys_generated;
} lqx10_signature_keys_t;

// Entropy and random number generation
typedef struct {
    uint8_t entropy_pool[1024];
    uint32_t pool_index;
    uint64_t reseed_counter;
    bool hardware_rng_available;
} lqx10_entropy_state_t;

// Classical crypto functions
lqx10_error_t lqx10_aes_encrypt(const uint8_t *key,
                                const uint8_t *iv,
                                const uint8_t *plaintext,
                                size_t plaintext_len,
                                uint8_t *ciphertext,
                                size_t *ciphertext_len);

lqx10_error_t lqx10_aes_decrypt(const uint8_t *key,
                                const uint8_t *iv,
                                const uint8_t *ciphertext,
                                size_t ciphertext_len,
                                uint8_t *plaintext,
                                size_t *plaintext_len);

lqx10_error_t lqx10_chacha20_crypt(const uint8_t *key,
                                   const uint8_t *nonce,
                                   const uint8_t *input,
                                   size_t input_len,
                                   uint8_t *output);

// Post-quantum crypto functions
lqx10_error_t lqx10_kyber_keygen(uint8_t *public_key,
                                 uint8_t *secret_key);

lqx10_error_t lqx10_kyber_encapsulate(const uint8_t *public_key,
                                      uint8_t *ciphertext,
                                      uint8_t *shared_secret);

lqx10_error_t lqx10_kyber_decapsulate(const uint8_t *secret_key,
                                      const uint8_t *ciphertext,
                                      uint8_t *shared_secret);

lqx10_error_t lqx10_dilithium_keygen(uint8_t *public_key,
                                     uint8_t *secret_key);

lqx10_error_t lqx10_dilithium_sign(const uint8_t *secret_key,
                                   const uint8_t *message,
                                   size_t message_len,
                                   uint8_t *signature,
                                   size_t *signature_len);

lqx10_error_t lqx10_dilithium_verify(const uint8_t *public_key,
                                     const uint8_t *message,
                                     size_t message_len,
                                     const uint8_t *signature,
                                     size_t signature_len);

// Hybrid crypto functions
lqx10_error_t lqx10_hybrid_keygen(lqx10_hybrid_keys_t *keys);
lqx10_error_t lqx10_hybrid_encrypt(const lqx10_hybrid_keys_t *keys,
                                   const uint8_t *plaintext,
                                   size_t plaintext_len,
                                   uint8_t *ciphertext,
                                   size_t *ciphertext_len);

lqx10_error_t lqx10_hybrid_decrypt(const lqx10_hybrid_keys_t *keys,
                                   const uint8_t *ciphertext,
                                   size_t ciphertext_len,
                                   uint8_t *plaintext,
                                   size_t *plaintext_len);

// Hash and KDF functions
lqx10_error_t lqx10_blake3_hash(const uint8_t *input,
                                size_t input_len,
                                uint8_t *output,
                                size_t output_len);

lqx10_error_t lqx10_kdf_derive(const uint8_t *password,
                               size_t password_len,
                               const uint8_t *salt,
                               size_t salt_len,
                               uint32_t iterations,
                               uint8_t *output,
                               size_t output_len);

lqx10_error_t lqx10_hkdf_expand(const uint8_t *prk,
                                size_t prk_len,
                                const uint8_t *info,
                                size_t info_len,
                                uint8_t *output,
                                size_t output_len);

// Entropy and randomness
lqx10_error_t lqx10_entropy_init(lqx10_entropy_state_t *state);
lqx10_error_t lqx10_entropy_gather(lqx10_entropy_state_t *state);
lqx10_error_t lqx10_entropy_extract(lqx10_entropy_state_t *state,
                                    uint8_t *output,
                                    size_t output_len);

lqx10_error_t lqx10_random_bytes(uint8_t *output, size_t output_len);
lqx10_error_t lqx10_secure_random_bytes(uint8_t *output, size_t output_len);

// Memory protection
lqx10_error_t lqx10_mlock_memory(void *ptr, size_t len);
lqx10_error_t lqx10_munlock_memory(void *ptr, size_t len);
lqx10_error_t lqx10_secure_memzero(void *ptr, size_t len);

// Timing attack protection
lqx10_error_t lqx10_constant_time_compare(const uint8_t *a,
                                          const uint8_t *b,
                                          size_t len,
                                          bool *equal);

// Cryptographic self-tests
lqx10_error_t lqx10_crypto_selftest(void);

// External functions from pure crypto modules
extern lqx10_error_t lqx10_aes_encrypt_pure(const uint8_t *key, const uint8_t *iv,
                                             const uint8_t *plaintext, size_t plaintext_len,
                                             uint8_t *ciphertext, size_t *ciphertext_len);

extern lqx10_error_t lqx10_aes_decrypt_pure(const uint8_t *key, const uint8_t *iv,
                                             const uint8_t *ciphertext, size_t ciphertext_len,
                                             uint8_t *plaintext, size_t *plaintext_len);

extern lqx10_error_t lqx10_aes_key_schedule_pure(const uint8_t *key, uint8_t round_keys[14][16]);

extern lqx10_error_t lqx10_blake3_hash_pure(const uint8_t *input, size_t input_len,
                                             uint8_t *output, size_t output_len);

extern lqx10_error_t lqx10_sha256_hash(const uint8_t *input, size_t input_len, uint8_t *output);

extern lqx10_error_t lqx10_hmac_sha256(const uint8_t *key, size_t key_len,
                                        const uint8_t *data, size_t data_len, uint8_t *output);

extern lqx10_error_t lqx10_pbkdf2_sha256(const uint8_t *password, size_t password_len,
                                          const uint8_t *salt, size_t salt_len,
                                          uint32_t iterations, uint8_t *output, size_t output_len);

extern lqx10_error_t lqx10_secure_random_bytes_pure(uint8_t *output, size_t output_len);

extern lqx10_error_t lqx10_secure_memzero_pure(void *ptr, size_t len);

// Post-quantum implementations
extern lqx10_error_t lqx10_kyber_keygen_pure(uint8_t *public_key, uint8_t *secret_key);
extern lqx10_error_t lqx10_kyber_encaps_pure(const uint8_t *public_key, uint8_t *ciphertext, uint8_t *shared_secret);
extern lqx10_error_t lqx10_kyber_decaps_pure(const uint8_t *secret_key, const uint8_t *ciphertext, uint8_t *shared_secret);
extern lqx10_error_t lqx10_dilithium_keygen_pure(uint8_t *public_key, uint8_t *secret_key);
extern lqx10_error_t lqx10_dilithium_sign_pure(const uint8_t *secret_key, const uint8_t *message,
                                                size_t message_len, uint8_t *signature, size_t *signature_len);
extern lqx10_error_t lqx10_dilithium_verify_pure(const uint8_t *public_key, const uint8_t *message,
                                                  size_t message_len, const uint8_t *signature, size_t signature_len);

#endif // LQX10_CRYPTO_H
