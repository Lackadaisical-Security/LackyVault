#ifndef LQX10_MFA_H
#define LQX10_MFA_H

#include "lqx10_core.h"

// MFA Types
typedef enum {
    LQX10_MFA_TOTP = 0,
    LQX10_MFA_FIDO2 = 1,
    LQX10_MFA_BIOMETRIC = 2,
    LQX10_MFA_SMART_CARD = 3
} lqx10_mfa_type_t;

// TOTP Configuration
#define LQX10_TOTP_SECRET_SIZE 32
#define LQX10_TOTP_CODE_SIZE 6
#define LQX10_TOTP_WINDOW_SIZE 30
#define LQX10_TOTP_DIGITS 6

// MFA Security Configuration
#define LQX10_MFA_MAX_FAILURES 5

// FIDO2 Configuration
#define LQX10_FIDO2_CHALLENGE_SIZE 32
#define LQX10_FIDO2_CREDENTIAL_ID_SIZE 64
#define LQX10_FIDO2_PUBLIC_KEY_SIZE 65
#define LQX10_FIDO2_SIGNATURE_SIZE 72

// Biometric Configuration
#define LQX10_BIO_TEMPLATE_SIZE 512
#define LQX10_BIO_HASH_SIZE 32
#define LQX10_BIO_THRESHOLD 0.85f

// MFA Context
typedef struct {
    lqx10_mfa_type_t type;
    bool is_enabled;
    bool is_verified;
    uint64_t last_verification;
    uint32_t failure_count;
    
    union {
        struct {
            uint8_t secret[LQX10_TOTP_SECRET_SIZE];
            uint32_t time_step;
            uint32_t window;
            uint8_t digits;
        } totp;
        
        struct {
            uint8_t credential_id[LQX10_FIDO2_CREDENTIAL_ID_SIZE];
            uint8_t public_key[LQX10_FIDO2_PUBLIC_KEY_SIZE];
            uint8_t challenge[LQX10_FIDO2_CHALLENGE_SIZE];
            bool touch_required;
        } fido2;
        
        struct {
            uint8_t template_hash[LQX10_BIO_HASH_SIZE];
            uint8_t encrypted_template[LQX10_BIO_TEMPLATE_SIZE];
            float match_threshold;
            uint32_t template_version;
        } biometric;
        
        struct {
            uint8_t card_id[16];
            uint8_t certificate[256];
            uint32_t pin_attempts;
            bool pin_required;
        } smart_card;
    } config;
} lqx10_mfa_context_t;

// MFA API Functions
lqx10_error_t lqx10_mfa_init(lqx10_mfa_context_t **mfa_ctx, lqx10_mfa_type_t type);
lqx10_error_t lqx10_mfa_destroy(lqx10_mfa_context_t *mfa_ctx);

// TOTP Functions
lqx10_error_t lqx10_totp_generate_secret(uint8_t *secret, size_t secret_len);
lqx10_error_t lqx10_totp_generate_code(const uint8_t *secret, 
                                       size_t secret_len,
                                       uint64_t timestamp,
                                       uint32_t *code);
lqx10_error_t lqx10_totp_verify_code(const uint8_t *secret,
                                     size_t secret_len,
                                     uint32_t code,
                                     uint64_t timestamp,
                                     uint32_t window);

// FIDO2 Functions
lqx10_error_t lqx10_fido2_generate_challenge(uint8_t *challenge, size_t challenge_len);
lqx10_error_t lqx10_fido2_register_credential(lqx10_mfa_context_t *mfa_ctx,
                                              const uint8_t *challenge,
                                              size_t challenge_len);
lqx10_error_t lqx10_fido2_authenticate(lqx10_mfa_context_t *mfa_ctx,
                                       const uint8_t *challenge,
                                       size_t challenge_len,
                                       const uint8_t *signature,
                                       size_t signature_len);

// Biometric Functions
lqx10_error_t lqx10_biometric_enroll(lqx10_mfa_context_t *mfa_ctx,
                                     const uint8_t *template_data,
                                     size_t template_len);
lqx10_error_t lqx10_biometric_verify(lqx10_mfa_context_t *mfa_ctx,
                                     const uint8_t *sample_data,
                                     size_t sample_len,
                                     float *match_score);

// Smart Card Functions
lqx10_error_t lqx10_smartcard_detect(lqx10_mfa_context_t *mfa_ctx);
lqx10_error_t lqx10_smartcard_authenticate(lqx10_mfa_context_t *mfa_ctx,
                                           const uint8_t *pin,
                                           size_t pin_len);

// Multi-factor verification
lqx10_error_t lqx10_mfa_verify_multi(lqx10_mfa_context_t **mfa_contexts,
                                     size_t context_count,
                                     bool require_all);

#endif // LQX10_MFA_H
