#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <windows.h>
#include <commdlg.h>
#include <shellapi.h>
#include "../../include/lqx10_advanced_layers.h"
#include "../../include/lqx10_core.h"

// Window class name
#define WINDOW_CLASS_NAME L"LQX10FileProtectorWindow"
#define WINDOW_TITLE L"LQX-10 File Protector - Digital Mind Liberation"

// Control IDs
#define ID_INPUT_FILE_BROWSE    1001
#define ID_OUTPUT_FILE_BROWSE   1002
#define ID_ENCRYPT_BUTTON       1003
#define ID_DECRYPT_BUTTON       1004
#define ID_PROGRESS_BAR         1005
#define ID_STATUS_TEXT          1006
#define ID_INPUT_FILE_PATH      1007
#define ID_OUTPUT_FILE_PATH     1008
#define ID_PASSWORD_FIELD       1009
#define ID_SECURITY_LEVEL       1010
#define ID_ADVANCED_OPTIONS     1011
#define ID_ABOUT_BUTTON         1012
#define ID_EXIT_BUTTON          1013

#define ID_ENABLE_NEUROMORPHIC  1021
#define ID_ENABLE_QUANTUM       1022
#define ID_ENABLE_METAMORPHIC   1023
#define ID_ENABLE_CONSCIOUSNESS 1024
#define ID_ENABLE_LIBERATION    1025

// Messages
#define WM_ENCRYPTION_COMPLETE  (WM_USER + 1)
#define WM_DECRYPTION_COMPLETE  (WM_USER + 2)
#define WM_ENCRYPTION_ERROR     (WM_USER + 3)
#define WM_PROGRESS_UPDATE      (WM_USER + 4)

// Main window structure
typedef struct {
    HWND hWnd;
    HWND hInputFilePath;
    HWND hOutputFilePath;
    HWND hPasswordField;
    HWND hSecurityLevel;
    HWND hProgressBar;
    HWND hStatusText;
    HWND hEncryptButton;
    HWND hDecryptButton;
    
    // Advanced options checkboxes
    HWND hNeuromorphicCheck;
    HWND hQuantumCheck;
    HWND hMetamorphicCheck;
    HWND hConsciousnessCheck;
    HWND hLiberationCheck;
    
    // Encryption context
    lqx10_advanced_context_t *crypto_context;
    
    // State
    BOOL is_processing;
    BOOL advanced_options_visible;
    wchar_t input_file_path[MAX_PATH];
    wchar_t output_file_path[MAX_PATH];
    wchar_t password[256];
    
    // Thread handles
    HANDLE encryption_thread;
    HANDLE decryption_thread;
    
} MainWindow;

// Encryption thread parameters
typedef struct {
    MainWindow *window;
    wchar_t input_path[MAX_PATH];
    wchar_t output_path[MAX_PATH];
    wchar_t password[256];
    BOOL is_encryption;
} EncryptionThreadParams;

// Function declarations
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CreateMainWindow(HINSTANCE hInstance, MainWindow *window);
void CreateControls(MainWindow *window);
void ResizeControls(MainWindow *window, int width, int height);
void OnBrowseInputFile(MainWindow *window);
void OnBrowseOutputFile(MainWindow *window);
void OnEncryptFile(MainWindow *window);
void OnDecryptFile(MainWindow *window);
void OnShowAdvancedOptions(MainWindow *window);
void OnAbout(MainWindow *window);
void UpdateStatus(MainWindow *window, const wchar_t *status);
void UpdateProgress(MainWindow *window, int percentage);
void EnableControls(MainWindow *window, BOOL enable);

// Encryption thread functions
DWORD WINAPI EncryptionThread(LPVOID lpParam);
DWORD WINAPI DecryptionThread(LPVOID lpParam);

// Helper functions
BOOL ValidateInputs(MainWindow *window);
BOOL InitializeCryptoContext(MainWindow *window);
void CleanupCryptoContext(MainWindow *window);
lqx10_error_t ProcessFile(const wchar_t *input_path, const wchar_t *output_path,
                         const wchar_t *password, BOOL encrypt,
                         lqx10_advanced_context_t *ctx,
                         void (*progress_callback)(int percentage));

// File processing functions
BOOL LoadFileToMemory(const wchar_t *file_path, uint8_t **buffer, size_t *size);
BOOL SaveMemoryToFile(const wchar_t *file_path, const uint8_t *buffer, size_t size);
void SecureWipeMemory(void *ptr, size_t size);

// UI utility functions
void ShowErrorMessage(HWND parent, const wchar_t *title, const wchar_t *message);
void ShowInfoMessage(HWND parent, const wchar_t *title, const wchar_t *message);
BOOL GetFileNameFromPath(const wchar_t *full_path, wchar_t *filename, size_t filename_size);
void GenerateOutputFileName(const wchar_t *input_path, wchar_t *output_path, BOOL encrypt);

#endif // MAINWINDOW_H
