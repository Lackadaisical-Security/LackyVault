#ifndef RESOURCE_H
#define RESOURCE_H

// Resource IDs for LQX-10 File Protector
// Built for Windows API using mingw-w64/gcc

// Icons
#define IDI_APP_ICON                101
#define IDI_SMALL_ICON              102
#define IDI_SHIELD_ICON             103

// Bitmaps
#define IDB_BANNER                  201
#define IDB_DIALOG                  202
#define IDB_LOGO                    203

// Strings
#define IDS_APP_TITLE               301
#define IDS_ENCRYPT_SUCCESS         302
#define IDS_DECRYPT_SUCCESS         303
#define IDS_ERROR_TITLE             304
#define IDS_WARNING_TITLE           305

// Menus
#define IDM_MAIN_MENU               401
#define IDM_FILE_MENU               402
#define IDM_HELP_MENU               403

// Menu items
#define ID_FILE_OPEN                501
#define ID_FILE_SAVE                502
#define ID_FILE_EXIT                503
#define ID_HELP_ABOUT               504

// Dialogs
#define IDD_ABOUT_DIALOG            601
#define IDD_SETTINGS_DIALOG         602
#define IDD_PROGRESS_DIALOG         603

// Dialog controls
#define IDC_STATIC                  -1
#define IDC_OK                      IDOK
#define IDC_CANCEL                  IDCANCEL

// Version information
#define IDV_VERSION_INFO            701

#endif // RESOURCE_H 