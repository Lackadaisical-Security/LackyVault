#ifndef UI_HELPERS_H
#define UI_HELPERS_H

#include <windows.h>
#include <stdint.h>

// System sound types
typedef enum {
    SOUND_SUCCESS,
    SOUND_ERROR,
    SOUND_WARNING,
    SOUND_INFO
} SystemSound;

// Function declarations
void CenterWindow(HWND hwnd);
BOOL SetWindowIcon(HWND hwnd, int iconResource);
void ShowBalloonTooltip(HWND hwnd, const wchar_t *title, const wchar_t *text, DWORD icon);
HBRUSH CreateGradientBrush(COLORREF color1, COLORREF color2, int width, int height);
void AnimateControl(HWND hwnd, DWORD flags, DWORD duration);
BOOL ShowFileBrowser(HWND parent, wchar_t *filepath, size_t filepathSize, 
                    BOOL isOpen, const wchar_t *filter, const wchar_t *title);
void FormatFileSize(UINT64 bytes, wchar_t *buffer, size_t bufferSize);
void FormatDuration(DWORD milliseconds, wchar_t *buffer, size_t bufferSize);
void UpdateProgressSmooth(HWND progressBar, int currentPos, int targetPos);
HWND CreateFlatButton(HWND parent, const wchar_t *text, int x, int y, 
                     int width, int height, int id);
HWND CreateTooltip(HWND parent, HWND control, const wchar_t *text);
void FlashWindowAlert(HWND hwnd);
void PlaySystemSound(SystemSound sound);
void SetControlColors(HWND hwnd, COLORREF textColor, COLORREF bgColor);
HWND CreateStatusBar(HWND parent, int id);

#endif // UI_HELPERS_H 