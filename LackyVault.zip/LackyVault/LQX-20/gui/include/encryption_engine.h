#ifndef ENCRYPTION_ENGINE_H
#define ENCRYPTION_ENGINE_H

#include <windows.h>
#include <stdint.h>

// Security levels
typedef enum {
    SECURITY_LEVEL_STANDARD = 1,
    SECURITY_LEVEL_HIGH = 2,
    SECURITY_LEVEL_MAXIMUM = 3
} SecurityLevel;

// Feature flags
#define FEATURE_NEUROMORPHIC    0x01
#define FEATURE_QUANTUM         0x02
#define FEATURE_METAMORPHIC     0x04
#define FEATURE_CONSCIOUSNESS   0x08
#define FEATURE_LIBERATION      0x10

// Progress callback
typedef void (*ProgressCallback)(int percentage);

// Encryption parameters
typedef struct {
    SecurityLevel securityLevel;
    BOOL enableNeuromorphic;
    BOOL enableQuantum;
    BOOL enableMetamorphic;
    BOOL enableConsciousness;
    BOOL enableLiberation;
} EncryptionParams;

// Engine status
typedef struct {
    BOOL isInitialized;
    SecurityLevel securityLevel;
    DWORD featuresEnabled;
} EngineStatus;

// Encryption engine structure
typedef struct {
    BOOL isInitialized;
    SecurityLevel securityLevel;
    BOOL enableNeuromorphic;
    BOOL enableQuantum;
    BOOL enableMetamorphic;
    BOOL enableConsciousness;
    BOOL enableLiberation;
    void *context;
    ProgressCallback progressCallback;
} EncryptionEngine;

// Function declarations
BOOL InitializeEncryptionEngine(void);
void CleanupEncryptionEngine(void);
BOOL SetEncryptionParameters(EncryptionParams *params);
EncryptionParams GetEncryptionParameters(void);
BOOL EncryptFileData(const uint8_t *input, size_t inputSize, 
                    const char *password, uint8_t **output, size_t *outputSize);
BOOL DecryptFileData(const uint8_t *input, size_t inputSize,
                    const char *password, uint8_t **output, size_t *outputSize);
BOOL GenerateEncryptionKey(const char *password, const uint8_t *salt, 
                          size_t saltSize, uint8_t *key, size_t keySize);
BOOL ValidateEncryptionParams(const EncryptionParams *params);
EngineStatus GetEncryptionEngineStatus(void);
void SetProgressCallback(ProgressCallback callback);
void UpdateProgress(int percentage);

#endif // ENCRYPTION_ENGINE_H 