#ifndef FILE_PROCESSOR_H
#define FILE_PROCESSOR_H

#include <windows.h>
#include <stdint.h>

// Forward declarations
struct MainWindow;
struct EncryptionThreadParams;

// File processing statistics
typedef struct {
    DWORD filesProcessed;
    UINT64 bytesProcessed;
    UINT64 startTime;
    UINT64 endTime;
    DWORD errorsEncountered;
} FileProcessingStats;

// Thread parameters for encryption/decryption
typedef struct EncryptionThreadParams {
    struct MainWindow *window;
    wchar_t input_path[MAX_PATH];
    wchar_t output_path[MAX_PATH];
    wchar_t password[256];
    BOOL is_encryption;
} EncryptionThreadParams;

// Function declarations
BOOL InitializeFileProcessor(void);
DWORD GetFileSize64(HANDLE hFile, DWORD *lpFileSizeHigh);
BOOL SecureDeleteFile(const wchar_t *filepath);
DWORD WINAPI EncryptionThread(LPVOID lpParam);
DWORD WINAPI DecryptionThread(LPVOID lpParam);
FileProcessingStats GetProcessingStats(void);
BOOL ValidateFileForProcessing(const wchar_t *filepath);
void GenerateSecureOutputFilename(const wchar_t *input_path, wchar_t *output_path, 
                                 size_t output_size, BOOL encrypt);

#endif // FILE_PROCESSOR_H 