#include "../include/file_processor.h"
#include "../include/mainwindow.h"
#include "../../include/lqx10_advanced_layers.h"
#include "../../include/lqx10_core.h"
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// File processing implementations for LQX-20 File Protector
// Built for Windows API using mingw-w64/gcc
// Copyright (c) 2025 Lackadaisical Security

// Global processing statistics
static FileProcessingStats g_stats = {0};

// Initialize file processor
BOOL InitializeFileProcessor(void) {
    memset(&g_stats, 0, sizeof(FileProcessingStats));
    
    // Initialize LQX-10 cryptographic engine
    lqx10_advanced_context_t *ctx = NULL;
    lqx10_error_t result = lqx10_advanced_init(&ctx);
    if (result != LQX10_SUCCESS) {
        return FALSE;
    }
    
    lqx10_advanced_destroy(ctx);
    return TRUE;
}

// Get file size using Windows API
DWORD GetFileSize64(HANDLE hFile, DWORD *lpFileSizeHigh) {
    LARGE_INTEGER fileSize;
    if (!GetFileSizeEx(hFile, &fileSize)) {
        return INVALID_FILE_SIZE;
    }
    
    if (lpFileSizeHigh) {
        *lpFileSizeHigh = fileSize.HighPart;
    }
    return fileSize.LowPart;
}

// Secure file deletion with multiple passes
BOOL SecureDeleteFile(const wchar_t *filepath) {
    HANDLE hFile = CreateFileW(filepath, GENERIC_WRITE, 0, NULL, 
                              OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        return FALSE;
    }
    
    DWORD fileSize = GetFileSize(hFile, NULL);
    if (fileSize == INVALID_FILE_SIZE) {
        CloseHandle(hFile);
        return FALSE;
    }
    
    // Multiple overwrite passes for security
    BYTE *buffer = (BYTE*)malloc(65536); // 64KB buffer
    if (!buffer) {
        CloseHandle(hFile);
        return FALSE;
    }
    
    // Pass 1: All zeros
    memset(buffer, 0x00, 65536);
    DWORD written;
    SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
    for (DWORD pos = 0; pos < fileSize; pos += 65536) {
        DWORD toWrite = min(65536, fileSize - pos);
        WriteFile(hFile, buffer, toWrite, &written, NULL);
    }
    FlushFileBuffers(hFile);
    
    // Pass 2: All ones
    memset(buffer, 0xFF, 65536);
    SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
    for (DWORD pos = 0; pos < fileSize; pos += 65536) {
        DWORD toWrite = min(65536, fileSize - pos);
        WriteFile(hFile, buffer, toWrite, &written, NULL);
    }
    FlushFileBuffers(hFile);
    
    // Pass 3: Random data
    srand((unsigned int)time(NULL));
    for (int i = 0; i < 65536; i++) {
        buffer[i] = (BYTE)(rand() & 0xFF);
    }
    SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
    for (DWORD pos = 0; pos < fileSize; pos += 65536) {
        DWORD toWrite = min(65536, fileSize - pos);
        WriteFile(hFile, buffer, toWrite, &written, NULL);
    }
    FlushFileBuffers(hFile);
    
    free(buffer);
    CloseHandle(hFile);
    
    // Finally delete the file
    return DeleteFileW(filepath);
}

// Process file encryption with LQX-20
DWORD WINAPI EncryptionThread(LPVOID lpParam) {
    EncryptionThreadParams *params = (EncryptionThreadParams*)lpParam;
    if (!params) {
        return ERROR_INVALID_PARAMETER;
    }
    
    g_stats.filesProcessed = 0;
    g_stats.bytesProcessed = 0;
    g_stats.startTime = GetTickCount64();
    
    lqx20_advanced_context_t *ctx = NULL;
    lqx20_error_t result = lqx20_advanced_init(&ctx);
    if (result != LQX20_SUCCESS) {
        PostMessage(params->window->hWnd, WM_ENCRYPTION_ERROR, result, 0);
        free(params);
        return result;
    }
    
    // Configure advanced features
    ctx->metamorphic_mode = SendMessage(params->window->hMetamorphicCheck, BM_GETCHECK, 0, 0) == BST_CHECKED;
    ctx->neuromorphic_mode = SendMessage(params->window->hNeuromorphicCheck, BM_GETCHECK, 0, 0) == BST_CHECKED;
    ctx->quantum_mode = SendMessage(params->window->hQuantumCheck, BM_GETCHECK, 0, 0) == BST_CHECKED;
    
    // Derive key from password or use quantum entropy
    if (wcslen(params->password) > 0) {
        char password_utf8[512];
        WideCharToMultiByte(CP_UTF8, 0, params->password, -1, password_utf8, 512, NULL, NULL);
        
        uint8_t salt[64];
                 lqx10_secure_random_bytes(salt, sizeof(salt));
         result = lqx10_advanced_key_derive(ctx, (uint8_t*)password_utf8, strlen(password_utf8), 
                                          salt, sizeof(salt), 100000);
     } else {
         // Use quantum entropy for keyless encryption
         result = lqx10_advanced_quantum_key_generate(ctx, 256);
    }
    
    if (result != LQX20_SUCCESS) {
        lqx20_advanced_destroy(ctx);
        PostMessage(params->window->hWnd, WM_ENCRYPTION_ERROR, result, 0);
        free(params);
        return result;
    }
    
    // Load file into memory
    uint8_t *fileData = NULL;
    size_t fileSize = 0;
         if (!LoadFileToMemory(params->input_path, &fileData, &fileSize)) {
         lqx10_advanced_destroy(ctx);
        PostMessage(params->window->hWnd, WM_ENCRYPTION_ERROR, ERROR_FILE_NOT_FOUND, 0);
        free(params);
        return ERROR_FILE_NOT_FOUND;
    }
    
    // Update progress
    PostMessage(params->window->hWnd, WM_PROGRESS_UPDATE, 25, 0);
    
    // Encrypt with LQX-20 advanced layers
    size_t encryptedSize = fileSize + 4096; // Extra space for metadata
    uint8_t *encryptedData = (uint8_t*)malloc(encryptedSize);
    if (!encryptedData) {
        free(fileData);
        lqx20_advanced_destroy(ctx);
        PostMessage(params->window->hWnd, WM_ENCRYPTION_ERROR, ERROR_NOT_ENOUGH_MEMORY, 0);
        free(params);
        return ERROR_NOT_ENOUGH_MEMORY;
    }
    
    PostMessage(params->window->hWnd, WM_PROGRESS_UPDATE, 50, 0);
    
         result = lqx10_advanced_encrypt_all_layers(ctx, fileData, fileSize, 
                                              encryptedData, &encryptedSize);
    if (result != LQX20_SUCCESS) {
        free(fileData);
        free(encryptedData);
                 lqx10_advanced_destroy(ctx);
         PostMessage(params->window->hWnd, WM_ENCRYPTION_ERROR, result, 0);
         free(params);
         return result;
     }
     
     PostMessage(params->window->hWnd, WM_PROGRESS_UPDATE, 75, 0);
     
     // Save encrypted file
     if (!SaveMemoryToFile(params->output_path, encryptedData, encryptedSize)) {
         free(fileData);
         free(encryptedData);
         lqx10_advanced_destroy(ctx);
        PostMessage(params->window->hWnd, WM_ENCRYPTION_ERROR, ERROR_WRITE_FAULT, 0);
        free(params);
        return ERROR_WRITE_FAULT;
    }
    
    // Update statistics
    g_stats.filesProcessed = 1;
    g_stats.bytesProcessed = fileSize;
    g_stats.endTime = GetTickCount64();
    
    // Secure cleanup
    SecureWipeMemory(fileData, fileSize);
    SecureWipeMemory(encryptedData, encryptedSize);
    free(fileData);
    free(encryptedData);
         lqx10_advanced_destroy(ctx);
     
     PostMessage(params->window->hWnd, WM_ENCRYPTION_COMPLETE, 0, 0);
    free(params);
    return 0;
}

// Process file decryption with LQX-20
DWORD WINAPI DecryptionThread(LPVOID lpParam) {
    EncryptionThreadParams *params = (EncryptionThreadParams*)lpParam;
    if (!params) {
        return ERROR_INVALID_PARAMETER;
    }
    
    g_stats.filesProcessed = 0;
    g_stats.bytesProcessed = 0;
    g_stats.startTime = GetTickCount64();
    
    lqx20_advanced_context_t *ctx = NULL;
    lqx20_error_t result = lqx20_advanced_init(&ctx);
    if (result != LQX20_SUCCESS) {
        PostMessage(params->window->hWnd, WM_DECRYPTION_COMPLETE + 1, result, 0);
        free(params);
        return result;
    }
    
    // Configure advanced features (same as encryption)
    ctx->metamorphic_mode = SendMessage(params->window->hMetamorphicCheck, BM_GETCHECK, 0, 0) == BST_CHECKED;
    ctx->neuromorphic_mode = SendMessage(params->window->hNeuromorphicCheck, BM_GETCHECK, 0, 0) == BST_CHECKED;
    ctx->quantum_mode = SendMessage(params->window->hQuantumCheck, BM_GETCHECK, 0, 0) == BST_CHECKED;
    
    // Derive key from password
    if (wcslen(params->password) > 0) {
        char password_utf8[512];
        WideCharToMultiByte(CP_UTF8, 0, params->password, -1, password_utf8, 512, NULL, NULL);
        
        // For decryption, we need to use the same salt that was used during encryption
        // This would normally be stored in the encrypted file header
        uint8_t salt[64] = {0}; // Placeholder - should be extracted from file
        result = lqx20_advanced_key_derive(ctx, (uint8_t*)password_utf8, strlen(password_utf8), 
                                         salt, sizeof(salt), 100000);
    } else {
        // Use quantum entropy for keyless decryption
        result = lqx20_advanced_quantum_key_generate(ctx, 256);
    }
    
    if (result != LQX20_SUCCESS) {
        lqx20_advanced_destroy(ctx);
        PostMessage(params->window->hWnd, WM_ENCRYPTION_ERROR, result, 0);
        free(params);
        return result;
    }
    
    // Load encrypted file
    uint8_t *encryptedData = NULL;
    size_t encryptedSize = 0;
    if (!LoadFileToMemory(params->input_path, &encryptedData, &encryptedSize)) {
        lqx20_advanced_destroy(ctx);
        PostMessage(params->window->hWnd, WM_ENCRYPTION_ERROR, ERROR_FILE_NOT_FOUND, 0);
        free(params);
        return ERROR_FILE_NOT_FOUND;
    }
    
    PostMessage(params->window->hWnd, WM_PROGRESS_UPDATE, 25, 0);
    
    // Decrypt with LQX-20 advanced layers
    size_t decryptedSize = encryptedSize; // Will be adjusted during decryption
    uint8_t *decryptedData = (uint8_t*)malloc(decryptedSize);
    if (!decryptedData) {
        free(encryptedData);
        lqx20_advanced_destroy(ctx);
        PostMessage(params->window->hWnd, WM_ENCRYPTION_ERROR, ERROR_NOT_ENOUGH_MEMORY, 0);
        free(params);
        return ERROR_NOT_ENOUGH_MEMORY;
    }
    
    PostMessage(params->window->hWnd, WM_PROGRESS_UPDATE, 50, 0);
    
    result = lqx20_advanced_decrypt_all_layers(ctx, encryptedData, encryptedSize, 
                                             decryptedData, &decryptedSize);
    if (result != LQX20_SUCCESS) {
        free(encryptedData);
        free(decryptedData);
        lqx20_advanced_destroy(ctx);
        PostMessage(params->window->hWnd, WM_ENCRYPTION_ERROR, result, 0);
        free(params);
        return result;
    }
    
    PostMessage(params->window->hWnd, WM_PROGRESS_UPDATE, 75, 0);
    
    // Save decrypted file
    if (!SaveMemoryToFile(params->output_path, decryptedData, decryptedSize)) {
        free(encryptedData);
        free(decryptedData);
        lqx20_advanced_destroy(ctx);
        PostMessage(params->window->hWnd, WM_ENCRYPTION_ERROR, ERROR_WRITE_FAULT, 0);
        free(params);
        return ERROR_WRITE_FAULT;
    }
    
    // Update statistics
    g_stats.filesProcessed = 1;
    g_stats.bytesProcessed = decryptedSize;
    g_stats.endTime = GetTickCount64();
    
    // Secure cleanup
    SecureWipeMemory(encryptedData, encryptedSize);
    SecureWipeMemory(decryptedData, decryptedSize);
    free(encryptedData);
    free(decryptedData);
    lqx20_advanced_destroy(ctx);
    
    PostMessage(params->window->hWnd, WM_DECRYPTION_COMPLETE, 0, 0);
    free(params);
    return 0;
}

// Get processing statistics
FileProcessingStats GetProcessingStats(void) {
    return g_stats;
}

// Validate file for processing
BOOL ValidateFileForProcessing(const wchar_t *filepath) {
    if (!filepath || wcslen(filepath) == 0) {
        return FALSE;
    }
    
    // Check if file exists and is readable
    DWORD attrs = GetFileAttributesW(filepath);
    if (attrs == INVALID_FILE_ATTRIBUTES) {
        return FALSE;
    }
    
    // Check if it's a directory
    if (attrs & FILE_ATTRIBUTE_DIRECTORY) {
        return FALSE;
    }
    
    // Try to open the file
    HANDLE hFile = CreateFileW(filepath, GENERIC_READ, FILE_SHARE_READ, NULL, 
                              OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        return FALSE;
    }
    
    CloseHandle(hFile);
    return TRUE;
}

// Generate secure output filename
void GenerateSecureOutputFilename(const wchar_t *input_path, wchar_t *output_path, 
                                 size_t output_size, BOOL encrypt) {
    if (!input_path || !output_path || output_size == 0) {
        return;
    }
    
    wcsncpy_s(output_path, output_size / sizeof(wchar_t), input_path, _TRUNCATE);
    
    if (encrypt) {
        // Add .lqx20 extension for encrypted files
        wchar_t *ext = wcsrchr(output_path, L'.');
        if (ext) {
            wcscpy_s(ext, output_size / sizeof(wchar_t) - (ext - output_path), L".lqx20");
        } else {
            wcscat_s(output_path, output_size / sizeof(wchar_t), L".lqx20");
        }
    } else {
        // Remove .lqx20 extension for decrypted files
        wchar_t *ext = wcsrchr(output_path, L'.');
        if (ext && wcscmp(ext, L".lqx20") == 0) {
            *ext = L'\0';
        } else {
            wcscat_s(output_path, output_size / sizeof(wchar_t), L".decrypted");
        }
    }
} 