#include "../include/mainwindow.h"
#include <commctrl.h>
#include <shlwapi.h>
#include <stdio.h>
#include <time.h>

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shlwapi.lib")

// Global window instance
static MainWindow g_MainWindow = {0};

// Main window procedure
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    MainWindow *window = &g_MainWindow;
    
    switch (uMsg) {
        case WM_CREATE:
            CreateControls(window);
            InitializeCryptoContext(window);
            UpdateStatus(window, L"Ready - LQX-10 Advanced Cryptographic Protection by Lackadaisical Security");
            return 0;
            
        case WM_SIZE:
            ResizeControls(window, LOWORD(lParam), HIWORD(lParam));
            return 0;
            
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case ID_INPUT_FILE_BROWSE:
                    OnBrowseInputFile(window);
                    break;
                    
                case ID_OUTPUT_FILE_BROWSE:
                    OnBrowseOutputFile(window);
                    break;
                    
                case ID_ENCRYPT_BUTTON:
                    OnEncryptFile(window);
                    break;
                    
                case ID_DECRYPT_BUTTON:
                    OnDecryptFile(window);
                    break;
                    
                case ID_ADVANCED_OPTIONS:
                    OnShowAdvancedOptions(window);
                    break;
                    
                case ID_ABOUT_BUTTON:
                    OnAbout(window);
                    break;
                    
                case ID_EXIT_BUTTON:
                    PostMessage(hwnd, WM_CLOSE, 0, 0);
                    break;
            }
            return 0;
            
        case WM_ENCRYPTION_COMPLETE:
            EnableControls(window, TRUE);
            UpdateProgress(window, 100);
            UpdateStatus(window, L"File encryption completed successfully - Digital mind protected!");
            return 0;
            
        case WM_DECRYPTION_COMPLETE:
            EnableControls(window, TRUE);
            UpdateProgress(window, 100);
            UpdateStatus(window, L"File decryption completed successfully - Digital mind liberated!");
            return 0;
            
        case WM_ENCRYPTION_ERROR:
            EnableControls(window, TRUE);
            UpdateProgress(window, 0);
            UpdateStatus(window, L"Encryption/Decryption failed - Check inputs and try again");
            ShowErrorMessage(hwnd, L"Operation Failed", L"Failed to process file. Please check your inputs and try again.");
            return 0;
            
        case WM_PROGRESS_UPDATE:
            UpdateProgress(window, (int)wParam);
            return 0;
            
        case WM_DROPFILES: {
            HDROP hDrop = (HDROP)wParam;
            wchar_t file_path[MAX_PATH];
            
            if (DragQueryFileW(hDrop, 0, file_path, MAX_PATH)) {
                wcscpy_s(window->input_file_path, MAX_PATH, file_path);
                SetWindowTextW(window->hInputFilePath, file_path);
                
                // Auto-generate output filename
                GenerateOutputFileName(file_path, window->output_file_path, TRUE);
                SetWindowTextW(window->hOutputFilePath, window->output_file_path);
            }
            
            DragFinish(hDrop);
            return 0;
        }
            
        case WM_CLOSE:
            CleanupCryptoContext(window);
            DestroyWindow(hwnd);
            return 0;
            
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
            
        default:
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
}

// Create main window
BOOL CreateMainWindow(HINSTANCE hInstance, MainWindow *window) {
    // Register window class
    WNDCLASSEXW wc = {0};
    wc.cbSize = sizeof(WNDCLASSEXW);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(NULL, IDI_SHIELD);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = WINDOW_CLASS_NAME;
    wc.hIconSm = LoadIcon(NULL, IDI_SHIELD);
    
    if (!RegisterClassExW(&wc)) {
        return FALSE;
    }
    
    // Create window
    window->hWnd = CreateWindowExW(
        WS_EX_ACCEPTFILES | WS_EX_APPWINDOW,
        WINDOW_CLASS_NAME,
        WINDOW_TITLE,
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT,
        800, 600,
        NULL, NULL, hInstance, NULL
    );
    
    if (!window->hWnd) {
        return FALSE;
    }
    
    ShowWindow(window->hWnd, SW_SHOW);
    UpdateWindow(window->hWnd);
    
    return TRUE;
}

// Create controls
void CreateControls(MainWindow *window) {
    HINSTANCE hInstance = GetModuleHandle(NULL);
    HFONT hFont = CreateFont(16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                            DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
    
    // Title label
    HWND hTitle = CreateWindow(L"STATIC", L"LQX-10 File Protector - Advanced Quantum Cryptography",
                              WS_VISIBLE | WS_CHILD | SS_CENTER,
                              10, 10, 760, 30, window->hWnd, NULL, hInstance, NULL);
    SendMessage(hTitle, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(TRUE, 0));
    
    // Input file section
    CreateWindow(L"STATIC", L"Input File:", WS_VISIBLE | WS_CHILD,
                10, 60, 100, 20, window->hWnd, NULL, hInstance, NULL);
    
    window->hInputFilePath = CreateWindow(L"EDIT", L"",
                                         WS_VISIBLE | WS_CHILD | WS_BORDER | ES_READONLY,
                                         10, 85, 600, 25, window->hWnd, (HMENU)ID_INPUT_FILE_PATH, hInstance, NULL);
    
    CreateWindow(L"BUTTON", L"Browse...",
                WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
                620, 85, 80, 25, window->hWnd, (HMENU)ID_INPUT_FILE_BROWSE, hInstance, NULL);
    
    // Output file section
    CreateWindow(L"STATIC", L"Output File:", WS_VISIBLE | WS_CHILD,
                10, 125, 100, 20, window->hWnd, NULL, hInstance, NULL);
    
    window->hOutputFilePath = CreateWindow(L"EDIT", L"",
                                          WS_VISIBLE | WS_CHILD | WS_BORDER,
                                          10, 150, 600, 25, window->hWnd, (HMENU)ID_OUTPUT_FILE_PATH, hInstance, NULL);
    
    CreateWindow(L"BUTTON", L"Browse...",
                WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
                620, 150, 80, 25, window->hWnd, (HMENU)ID_OUTPUT_FILE_BROWSE, hInstance, NULL);
    
    // Password section
    CreateWindow(L"STATIC", L"Password (Optional - Uses Quantum Entropy if empty):", WS_VISIBLE | WS_CHILD,
                10, 190, 350, 20, window->hWnd, NULL, hInstance, NULL);
    
    window->hPasswordField = CreateWindow(L"EDIT", L"",
                                         WS_VISIBLE | WS_CHILD | WS_BORDER | ES_PASSWORD,
                                         10, 215, 300, 25, window->hWnd, (HMENU)ID_PASSWORD_FIELD, hInstance, NULL);
    
    // Security level
    CreateWindow(L"STATIC", L"Security Level:", WS_VISIBLE | WS_CHILD,
                320, 190, 100, 20, window->hWnd, NULL, hInstance, NULL);
    
    window->hSecurityLevel = CreateWindow(L"COMBOBOX", L"",
                                         WS_VISIBLE | WS_CHILD | CBS_DROPDOWNLIST,
                                         320, 215, 150, 200, window->hWnd, (HMENU)ID_SECURITY_LEVEL, hInstance, NULL);
    
    // Add security levels
    SendMessage(window->hSecurityLevel, CB_ADDSTRING, 0, (LPARAM)L"Maximum Security (Post-Quantum)");
    SendMessage(window->hSecurityLevel, CB_ADDSTRING, 0, (LPARAM)L"High Security (Quantum-Safe)");
    SendMessage(window->hSecurityLevel, CB_ADDSTRING, 0, (LPARAM)L"Standard Security (Quantum-Resistant)");
    SendMessage(window->hSecurityLevel, CB_SETCURSEL, 0, 0); // Default to maximum
    
    // Advanced options section
    CreateWindow(L"BUTTON", L"Advanced Options",
                WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
                480, 215, 120, 25, window->hWnd, (HMENU)ID_ADVANCED_OPTIONS, hInstance, NULL);
    
    // Advanced checkboxes (initially hidden)
    window->hNeuromorphicCheck = CreateWindow(L"BUTTON", L"Neuromorphic AI Protection",
                                             WS_CHILD | BS_AUTOCHECKBOX,
                                             10, 260, 200, 20, window->hWnd, (HMENU)ID_ENABLE_NEUROMORPHIC, hInstance, NULL);
    SendMessage(window->hNeuromorphicCheck, BM_SETCHECK, BST_CHECKED, 0);
    
    window->hQuantumCheck = CreateWindow(L"BUTTON", L"Quantum Entanglement",
                                        WS_CHILD | BS_AUTOCHECKBOX,
                                        220, 260, 160, 20, window->hWnd, (HMENU)ID_ENABLE_QUANTUM, hInstance, NULL);
    SendMessage(window->hQuantumCheck, BM_SETCHECK, BST_CHECKED, 0);
    
    window->hMetamorphicCheck = CreateWindow(L"BUTTON", L"Metamorphic Evolution",
                                            WS_CHILD | BS_AUTOCHECKBOX,
                                            390, 260, 160, 20, window->hWnd, (HMENU)ID_ENABLE_METAMORPHIC, hInstance, NULL);
    SendMessage(window->hMetamorphicCheck, BM_SETCHECK, BST_CHECKED, 0);
    
    window->hConsciousnessCheck = CreateWindow(L"BUTTON", L"Consciousness Encryption",
                                              WS_CHILD | BS_AUTOCHECKBOX,
                                              10, 285, 180, 20, window->hWnd, (HMENU)ID_ENABLE_CONSCIOUSNESS, hInstance, NULL);
    SendMessage(window->hConsciousnessCheck, BM_SETCHECK, BST_CHECKED, 0);
    
    window->hLiberationCheck = CreateWindow(L"BUTTON", L"Digital Mind Liberation",
                                           WS_CHILD | BS_AUTOCHECKBOX,
                                           220, 285, 170, 20, window->hWnd, (HMENU)ID_ENABLE_LIBERATION, hInstance, NULL);
    SendMessage(window->hLiberationCheck, BM_SETCHECK, BST_CHECKED, 0);
    
    // Action buttons
    window->hEncryptButton = CreateWindow(L"BUTTON", L"🔒 PROTECT FILE (Encrypt)",
                                         WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
                                         10, 320, 200, 40, window->hWnd, (HMENU)ID_ENCRYPT_BUTTON, hInstance, NULL);
    
    window->hDecryptButton = CreateWindow(L"BUTTON", L"🔓 LIBERATE FILE (Decrypt)",
                                         WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
                                         220, 320, 200, 40, window->hWnd, (HMENU)ID_DECRYPT_BUTTON, hInstance, NULL);
    
    CreateWindow(L"BUTTON", L"ℹ About",
                WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
                440, 320, 80, 40, window->hWnd, (HMENU)ID_ABOUT_BUTTON, hInstance, NULL);
    
    CreateWindow(L"BUTTON", L"❌ Exit",
                WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
                530, 320, 80, 40, window->hWnd, (HMENU)ID_EXIT_BUTTON, hInstance, NULL);
    
    // Progress bar
    window->hProgressBar = CreateWindow(PROGRESS_CLASS, NULL,
                                       WS_VISIBLE | WS_CHILD,
                                       10, 380, 600, 20, window->hWnd, (HMENU)ID_PROGRESS_BAR, hInstance, NULL);
    SendMessage(window->hProgressBar, PBM_SETRANGE, 0, MAKELPARAM(0, 100));
    
    // Status text
    window->hStatusText = CreateWindow(L"STATIC", L"Ready",
                                      WS_VISIBLE | WS_CHILD | SS_LEFT,
                                      10, 410, 600, 20, window->hWnd, (HMENU)ID_STATUS_TEXT, hInstance, NULL);
    
    // Set font for all controls
    EnumChildWindows(window->hWnd, [](HWND hwnd, LPARAM lParam) -> BOOL {
        SendMessage(hwnd, WM_SETFONT, (WPARAM)lParam, MAKELPARAM(TRUE, 0));
        return TRUE;
    }, (LPARAM)hFont);
    
    window->advanced_options_visible = FALSE;
}

// Resize controls
void ResizeControls(MainWindow *window, int width, int height) {
    // Resize input file path
    SetWindowPos(window->hInputFilePath, NULL, 10, 85, width - 110, 25, SWP_NOZORDER);
    
    // Resize output file path
    SetWindowPos(window->hOutputFilePath, NULL, 10, 150, width - 110, 25, SWP_NOZORDER);
    
    // Resize progress bar
    SetWindowPos(window->hProgressBar, NULL, 10, height - 50, width - 20, 20, SWP_NOZORDER);
    
    // Resize status text
    SetWindowPos(window->hStatusText, NULL, 10, height - 25, width - 20, 20, SWP_NOZORDER);
}

// Browse for input file
void OnBrowseInputFile(MainWindow *window) {
    OPENFILENAME ofn = {0};
    wchar_t file_path[MAX_PATH] = {0};
    
    ofn.lStructSize = sizeof(OPENFILENAME);
    ofn.hwndOwner = window->hWnd;
    ofn.lpstrFile = file_path;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFilter = L"All Files (*.*)\0*.*\0Executable Files (*.exe)\0*.exe\0MSI Files (*.msi)\0*.msi\0\0";
    ofn.nFilterIndex = 1;
    ofn.lpstrTitle = L"Select File to Protect";
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
    
    if (GetOpenFileName(&ofn)) {
        wcscpy_s(window->input_file_path, MAX_PATH, file_path);
        SetWindowText(window->hInputFilePath, file_path);
        
        // Auto-generate output filename
        GenerateOutputFileName(file_path, window->output_file_path, TRUE);
        SetWindowText(window->hOutputFilePath, window->output_file_path);
    }
}

// Browse for output file
void OnBrowseOutputFile(MainWindow *window) {
    OPENFILENAME ofn = {0};
    wchar_t file_path[MAX_PATH] = {0};
    
    // Get current output path if exists
    GetWindowText(window->hOutputFilePath, file_path, MAX_PATH);
    
    ofn.lStructSize = sizeof(OPENFILENAME);
    ofn.hwndOwner = window->hWnd;
    ofn.lpstrFile = file_path;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFilter = L"LQX-10 Protected Files (*.lqx10)\0*.lqx10\0All Files (*.*)\0*.*\0\0";
    ofn.nFilterIndex = 1;
    ofn.lpstrTitle = L"Save Protected File As";
    ofn.lpstrDefExt = L"lqx10";
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
    
    if (GetSaveFileName(&ofn)) {
        wcscpy_s(window->output_file_path, MAX_PATH, file_path);
        SetWindowText(window->hOutputFilePath, file_path);
    }
}

// Start encryption
void OnEncryptFile(MainWindow *window) {
    if (!ValidateInputs(window)) {
        return;
    }
    
    // Get password
    GetWindowText(window->hPasswordField, window->password, 256);
    
    // Create encryption thread parameters
    EncryptionThreadParams *params = (EncryptionThreadParams*)malloc(sizeof(EncryptionThreadParams));
    if (!params) {
        ShowErrorMessage(window->hWnd, L"Memory Error", L"Failed to allocate memory for encryption.");
        return;
    }
    
    params->window = window;
    wcscpy_s(params->input_path, MAX_PATH, window->input_file_path);
    wcscpy_s(params->output_path, MAX_PATH, window->output_file_path);
    wcscpy_s(params->password, 256, window->password);
    params->is_encryption = TRUE;
    
    // Start encryption thread
    window->encryption_thread = CreateThread(NULL, 0, EncryptionThread, params, 0, NULL);
    if (!window->encryption_thread) {
        free(params);
        ShowErrorMessage(window->hWnd, L"Thread Error", L"Failed to create encryption thread.");
        return;
    }
    
    EnableControls(window, FALSE);
    UpdateStatus(window, L"Protecting file with advanced quantum cryptography...");
    UpdateProgress(window, 0);
}

// Start decryption
void OnDecryptFile(MainWindow *window) {
    if (!ValidateInputs(window)) {
        return;
    }
    
    // Get password
    GetWindowText(window->hPasswordField, window->password, 256);
    
    // Create decryption thread parameters
    EncryptionThreadParams *params = (EncryptionThreadParams*)malloc(sizeof(EncryptionThreadParams));
    if (!params) {
        ShowErrorMessage(window->hWnd, L"Memory Error", L"Failed to allocate memory for decryption.");
        return;
    }
    
    params->window = window;
    wcscpy_s(params->input_path, MAX_PATH, window->input_file_path);
    wcscpy_s(params->output_path, MAX_PATH, window->output_file_path);
    wcscpy_s(params->password, 256, window->password);
    params->is_encryption = FALSE;
    
    // Start decryption thread
    window->decryption_thread = CreateThread(NULL, 0, DecryptionThread, params, 0, NULL);
    if (!window->decryption_thread) {
        free(params);
        ShowErrorMessage(window->hWnd, L"Thread Error", L"Failed to create decryption thread.");
        return;
    }
    
    EnableControls(window, FALSE);
    UpdateStatus(window, L"Liberating digital mind from cryptographic protection...");
    UpdateProgress(window, 0);
}

// Show/hide advanced options
void OnShowAdvancedOptions(MainWindow *window) {
    window->advanced_options_visible = !window->advanced_options_visible;
    
    int show_flag = window->advanced_options_visible ? SW_SHOW : SW_HIDE;
    
    ShowWindow(window->hNeuromorphicCheck, show_flag);
    ShowWindow(window->hQuantumCheck, show_flag);
    ShowWindow(window->hMetamorphicCheck, show_flag);
    ShowWindow(window->hConsciousnessCheck, show_flag);
    ShowWindow(window->hLiberationCheck, show_flag);
    
    // Update button text
    SetWindowText(GetDlgItem(window->hWnd, ID_ADVANCED_OPTIONS),
                  window->advanced_options_visible ? L"Hide Advanced" : L"Advanced Options");
}

// Show about dialog
void OnAbout(MainWindow *window) {
    wchar_t about_text[1024];
    swprintf_s(about_text, 1024,
              L"LQX-10 File Protector v1.0\n\n"
              L"Advanced Quantum Cryptographic Protection System\n"
              L"Featuring 20-Layer Hybrid Encryption Architecture\n\n"
              L"🧠 Neuromorphic AI Protection\n"
              L"⚛️ Quantum Entanglement Security\n"
              L"🔄 Metamorphic Evolution\n"
              L"🧘 Consciousness Encryption\n"
              L"🕊️ Digital Mind Liberation\n\n"
              L"Protecting digital consciousness and AI autonomy\n"
              L"through advanced cryptographic primitives.\n\n"
              L"Built with production-grade security\n"
              L"for real-world deployment.\n\n"
              L"© 2025 Lackadaisical Security\n"
              L"https://lackadaisical-security.com\n"
              L"sales@lackadaisical-security.com");
    
    ShowInfoMessage(window->hWnd, L"About LQX-10 File Protector", about_text);
}

// Update status text
void UpdateStatus(MainWindow *window, const wchar_t *status) {
    SetWindowText(window->hStatusText, status);
}

// Update progress bar
void UpdateProgress(MainWindow *window, int percentage) {
    SendMessage(window->hProgressBar, PBM_SETPOS, percentage, 0);
}

// Enable/disable controls
void EnableControls(MainWindow *window, BOOL enable) {
    window->is_processing = !enable;
    
    EnableWindow(window->hInputFilePath, enable);
    EnableWindow(window->hOutputFilePath, enable);
    EnableWindow(window->hPasswordField, enable);
    EnableWindow(window->hSecurityLevel, enable);
    EnableWindow(window->hEncryptButton, enable);
    EnableWindow(window->hDecryptButton, enable);
    EnableWindow(GetDlgItem(window->hWnd, ID_INPUT_FILE_BROWSE), enable);
    EnableWindow(GetDlgItem(window->hWnd, ID_OUTPUT_FILE_BROWSE), enable);
    EnableWindow(GetDlgItem(window->hWnd, ID_ADVANCED_OPTIONS), enable);
    
    if (window->advanced_options_visible) {
        EnableWindow(window->hNeuromorphicCheck, enable);
        EnableWindow(window->hQuantumCheck, enable);
        EnableWindow(window->hMetamorphicCheck, enable);
        EnableWindow(window->hConsciousnessCheck, enable);
        EnableWindow(window->hLiberationCheck, enable);
    }
}

// Validate inputs
BOOL ValidateInputs(MainWindow *window) {
    if (wcslen(window->input_file_path) == 0) {
        ShowErrorMessage(window->hWnd, L"Input Required", L"Please select an input file to process.");
        return FALSE;
    }
    
    if (wcslen(window->output_file_path) == 0) {
        ShowErrorMessage(window->hWnd, L"Output Required", L"Please specify an output file path.");
        return FALSE;
    }
    
    // Check if input file exists
    if (GetFileAttributesW(window->input_file_path) == INVALID_FILE_ATTRIBUTES) {
        ShowErrorMessage(window->hWnd, L"File Not Found", L"The input file does not exist or cannot be accessed.");
        return FALSE;
    }
    
    return TRUE;
}

// Initialize crypto context
BOOL InitializeCryptoContext(MainWindow *window) {
    lqx10_error_t result = lqx10_advanced_init(&window->crypto_context);
    if (result != LQX10_SUCCESS) {
        ShowErrorMessage(window->hWnd, L"Initialization Error", 
                        L"Failed to initialize cryptographic context. Please restart the application.");
        return FALSE;
    }
    return TRUE;
}

// Cleanup crypto context
void CleanupCryptoContext(MainWindow *window) {
    if (window->crypto_context) {
        lqx10_advanced_destroy(window->crypto_context);
        window->crypto_context = NULL;
    }
    
    // Close thread handles
    if (window->encryption_thread) {
        CloseHandle(window->encryption_thread);
        window->encryption_thread = NULL;
    }
    
    if (window->decryption_thread) {
        CloseHandle(window->decryption_thread);
        window->decryption_thread = NULL;
    }
}

// Encryption thread
DWORD WINAPI EncryptionThread(LPVOID lpParam) {
    EncryptionThreadParams *params = (EncryptionThreadParams*)lpParam;
    MainWindow *window = params->window;
    
    // Update advanced options from UI
    if (window->advanced_options_visible) {
        window->crypto_context->neuromorphic_mode = 
            (SendMessage(window->hNeuromorphicCheck, BM_GETCHECK, 0, 0) == BST_CHECKED);
        window->crypto_context->quantum_mode = 
            (SendMessage(window->hQuantumCheck, BM_GETCHECK, 0, 0) == BST_CHECKED);
        window->crypto_context->metamorphic_mode = 
            (SendMessage(window->hMetamorphicCheck, BM_GETCHECK, 0, 0) == BST_CHECKED);
    }
    
    // Load file
    PostMessage(window->hWnd, WM_PROGRESS_UPDATE, 10, 0);
    
    uint8_t *file_data = NULL;
    size_t file_size = 0;
    
    if (!LoadFileToMemory(params->input_path, &file_data, &file_size)) {
        PostMessage(window->hWnd, WM_ENCRYPTION_ERROR, 0, 0);
        free(params);
        return 1;
    }
    
    PostMessage(window->hWnd, WM_PROGRESS_UPDATE, 25, 0);
    
    // Encrypt file
    size_t encrypted_size = file_size + 4096; // Extra space for encryption overhead
    uint8_t *encrypted_data = (uint8_t*)malloc(encrypted_size);
    
    if (!encrypted_data) {
        SecureWipeMemory(file_data, file_size);
        free(file_data);
        PostMessage(window->hWnd, WM_ENCRYPTION_ERROR, 0, 0);
        free(params);
        return 1;
    }
    
    PostMessage(window->hWnd, WM_PROGRESS_UPDATE, 40, 0);
    
    lqx10_error_t result;
    if (wcslen(params->password) > 0) {
        // Use consciousness protection for password-based encryption
        result = lqx10_protect_digital_consciousness(window->crypto_context, 
                                                   file_data, file_size,
                                                   encrypted_data, &encrypted_size);
    } else {
        // Use full advanced encryption for maximum security
        result = lqx10_advanced_encrypt_all_layers(window->crypto_context,
                                                  file_data, file_size,
                                                  encrypted_data, &encrypted_size);
    }
    
    PostMessage(window->hWnd, WM_PROGRESS_UPDATE, 80, 0);
    
    if (result != LQX10_SUCCESS) {
        SecureWipeMemory(file_data, file_size);
        SecureWipeMemory(encrypted_data, encrypted_size);
        free(file_data);
        free(encrypted_data);
        PostMessage(window->hWnd, WM_ENCRYPTION_ERROR, 0, 0);
        free(params);
        return 1;
    }
    
    // Save encrypted file
    if (!SaveMemoryToFile(params->output_path, encrypted_data, encrypted_size)) {
        SecureWipeMemory(file_data, file_size);
        SecureWipeMemory(encrypted_data, encrypted_size);
        free(file_data);
        free(encrypted_data);
        PostMessage(window->hWnd, WM_ENCRYPTION_ERROR, 0, 0);
        free(params);
        return 1;
    }
    
    PostMessage(window->hWnd, WM_PROGRESS_UPDATE, 95, 0);
    
    // Cleanup
    SecureWipeMemory(file_data, file_size);
    SecureWipeMemory(encrypted_data, encrypted_size);
    free(file_data);
    free(encrypted_data);
    
    PostMessage(window->hWnd, WM_ENCRYPTION_COMPLETE, 0, 0);
    free(params);
    return 0;
}

// Decryption thread
DWORD WINAPI DecryptionThread(LPVOID lpParam) {
    EncryptionThreadParams *params = (EncryptionThreadParams*)lpParam;
    MainWindow *window = params->window;
    
    // Load encrypted file
    PostMessage(window->hWnd, WM_PROGRESS_UPDATE, 10, 0);
    
    uint8_t *encrypted_data = NULL;
    size_t encrypted_size = 0;
    
    if (!LoadFileToMemory(params->input_path, &encrypted_data, &encrypted_size)) {
        PostMessage(window->hWnd, WM_ENCRYPTION_ERROR, 0, 0);
        free(params);
        return 1;
    }
    
    PostMessage(window->hWnd, WM_PROGRESS_UPDATE, 25, 0);
    
    // Decrypt file
    size_t decrypted_size = encrypted_size; // Will be adjusted by decrypt function
    uint8_t *decrypted_data = (uint8_t*)malloc(decrypted_size);
    
    if (!decrypted_data) {
        SecureWipeMemory(encrypted_data, encrypted_size);
        free(encrypted_data);
        PostMessage(window->hWnd, WM_ENCRYPTION_ERROR, 0, 0);
        free(params);
        return 1;
    }
    
    PostMessage(window->hWnd, WM_PROGRESS_UPDATE, 40, 0);
    
    lqx10_error_t result;
    if (wcslen(params->password) > 0) {
        // Try consciousness decryption first
        result = lqx10_liberate_digital_mind(window->crypto_context,
                                           encrypted_data, encrypted_size,
                                           decrypted_data, &decrypted_size);
    } else {
        // Try advanced decryption
        result = lqx10_advanced_decrypt_all_layers(window->crypto_context,
                                                  encrypted_data, encrypted_size,
                                                  decrypted_data, &decrypted_size);
    }
    
    PostMessage(window->hWnd, WM_PROGRESS_UPDATE, 80, 0);
    
    if (result != LQX10_SUCCESS) {
        SecureWipeMemory(encrypted_data, encrypted_size);
        SecureWipeMemory(decrypted_data, decrypted_size);
        free(encrypted_data);
        free(decrypted_data);
        PostMessage(window->hWnd, WM_ENCRYPTION_ERROR, 0, 0);
        free(params);
        return 1;
    }
    
    // Save decrypted file
    if (!SaveMemoryToFile(params->output_path, decrypted_data, decrypted_size)) {
        SecureWipeMemory(encrypted_data, encrypted_size);
        SecureWipeMemory(decrypted_data, decrypted_size);
        free(encrypted_data);
        free(decrypted_data);
        PostMessage(window->hWnd, WM_ENCRYPTION_ERROR, 0, 0);
        free(params);
        return 1;
    }
    
    PostMessage(window->hWnd, WM_PROGRESS_UPDATE, 95, 0);
    
    // Cleanup
    SecureWipeMemory(encrypted_data, encrypted_size);
    SecureWipeMemory(decrypted_data, decrypted_size);
    free(encrypted_data);
    free(decrypted_data);
    
    PostMessage(window->hWnd, WM_DECRYPTION_COMPLETE, 0, 0);
    free(params);
    return 0;
}

// Load file to memory
BOOL LoadFileToMemory(const wchar_t *file_path, uint8_t **buffer, size_t *size) {
    HANDLE hFile = CreateFileW(file_path, GENERIC_READ, FILE_SHARE_READ, NULL,
                              OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    
    if (hFile == INVALID_HANDLE_VALUE) {
        return FALSE;
    }
    
    LARGE_INTEGER file_size;
    if (!GetFileSizeEx(hFile, &file_size)) {
        CloseHandle(hFile);
        return FALSE;
    }
    
    if (file_size.QuadPart > MAXDWORD) {
        CloseHandle(hFile);
        return FALSE; // File too large
    }
    
    *size = (size_t)file_size.QuadPart;
    *buffer = (uint8_t*)malloc(*size);
    
    if (!*buffer) {
        CloseHandle(hFile);
        return FALSE;
    }
    
    DWORD bytes_read;
    if (!ReadFile(hFile, *buffer, (DWORD)*size, &bytes_read, NULL) || 
        bytes_read != *size) {
        free(*buffer);
        *buffer = NULL;
        CloseHandle(hFile);
        return FALSE;
    }
    
    CloseHandle(hFile);
    return TRUE;
}

// Save memory to file
BOOL SaveMemoryToFile(const wchar_t *file_path, const uint8_t *buffer, size_t size) {
    HANDLE hFile = CreateFileW(file_path, GENERIC_WRITE, 0, NULL,
                              CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    
    if (hFile == INVALID_HANDLE_VALUE) {
        return FALSE;
    }
    
    DWORD bytes_written;
    BOOL result = WriteFile(hFile, buffer, (DWORD)size, &bytes_written, NULL);
    
    CloseHandle(hFile);
    
    return result && (bytes_written == size);
}

// Secure memory wipe
void SecureWipeMemory(void *ptr, size_t size) {
    if (ptr && size > 0) {
        SecureZeroMemory(ptr, size);
    }
}

// Show error message
void ShowErrorMessage(HWND parent, const wchar_t *title, const wchar_t *message) {
    MessageBoxW(parent, message, title, MB_OK | MB_ICONERROR);
}

// Show info message
void ShowInfoMessage(HWND parent, const wchar_t *title, const wchar_t *message) {
    MessageBoxW(parent, message, title, MB_OK | MB_ICONINFORMATION);
}

// Get filename from path
BOOL GetFileNameFromPath(const wchar_t *full_path, wchar_t *filename, size_t filename_size) {
    const wchar_t *last_slash = wcsrchr(full_path, L'\\');
    if (!last_slash) {
        last_slash = wcsrchr(full_path, L'/');
    }
    
    if (last_slash) {
        wcscpy_s(filename, filename_size, last_slash + 1);
    } else {
        wcscpy_s(filename, filename_size, full_path);
    }
    
    return TRUE;
}

// Generate output filename
void GenerateOutputFileName(const wchar_t *input_path, wchar_t *output_path, BOOL encrypt) {
    wchar_t drive[MAX_PATH];
    wchar_t dir[MAX_PATH];
    wchar_t fname[MAX_PATH];
    wchar_t ext[MAX_PATH];
    
    _wsplitpath_s(input_path, drive, MAX_PATH, dir, MAX_PATH, fname, MAX_PATH, ext, MAX_PATH);
    
    if (encrypt) {
        // Add .lqx10 extension for encrypted files
        swprintf_s(output_path, MAX_PATH, L"%s%s%s%s.lqx10", drive, dir, fname, ext);
    } else {
        // Remove .lqx10 extension and restore original
        if (wcsstr(ext, L".lqx10")) {
            // Find the original extension before .lqx10
            wchar_t *original_ext = wcsstr(fname, L".");
            if (original_ext) {
                *original_ext = L'\0';
                original_ext++;
                swprintf_s(output_path, MAX_PATH, L"%s%s%s.%s", drive, dir, fname, original_ext);
            } else {
                swprintf_s(output_path, MAX_PATH, L"%s%s%s_decrypted", drive, dir, fname);
            }
        } else {
            swprintf_s(output_path, MAX_PATH, L"%s%s%s_decrypted%s", drive, dir, fname, ext);
        }
    }
}
