#include "../include/mainwindow.h"
#include <commctrl.h>

// Application entry point
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    (void)hPrevInstance; // Suppress unused parameter warning
    (void)lpCmdLine;     // Suppress unused parameter warning
    (void)nCmdShow;      // Suppress unused parameter warning
    
    // Initialize common controls
    INITCOMMONCONTROLSEX icex;
    icex.dwSize = sizeof(INITCOMMONCONTROLSEX);
    icex.dwICC = ICC_PROGRESS_CLASS | ICC_STANDARD_CLASSES;
    InitCommonControlsEx(&icex);
    
    // Set DPI awareness for modern Windows displays
    SetProcessDPIAware();
    
    // Create main window
    MainWindow window;
    memset(&window, 0, sizeof(MainWindow));
    
    if (!CreateMainWindow(hInstance, &window)) {
        MessageBoxW(NULL, L"Failed to create main window", L"Error", MB_OK | MB_ICONERROR);
        return 1;
    }
    
    // Message loop
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        // Handle dialog messages for tab navigation
        if (!IsDialogMessage(window.hWnd, &msg)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
    
    return (int)msg.wParam;
}
