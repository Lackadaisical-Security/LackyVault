#include "../include/ui_helpers.h"
#include "../include/mainwindow.h"
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// UI Helper Functions for LQX-10 File Protector
// Built for Windows API using mingw-w64/gcc
// Copyright (c) 2025 Lackadaisical Security

// Center window on screen
void CenterWindow(HWND hwnd) {
    RECT rect;
    GetWindowRect(hwnd, &rect);
    
    int width = rect.right - rect.left;
    int height = rect.bottom - rect.top;
    
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    
    int x = (screenWidth - width) / 2;
    int y = (screenHeight - height) / 2;
    
    SetWindowPos(hwnd, NULL, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
}

// Set window icon
BOOL SetWindowIcon(HWND hwnd, int iconResource) {
    HICON hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(iconResource));
    if (!hIcon) {
        return FALSE;
    }
    
    SendMessage(hwnd, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
    SendMessage(hwnd, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
    
    return TRUE;
}

// Show balloon tooltip
void ShowBalloonTooltip(HWND hwnd, const wchar_t *title, const wchar_t *text, DWORD icon) {
    EDITBALLOONTIP tooltip = {0};
    tooltip.cbStruct = sizeof(EDITBALLOONTIP);
    tooltip.pszTitle = title;
    tooltip.pszText = text;
    tooltip.ttiIcon = icon;
    
    SendMessage(hwnd, EM_SHOWBALLOONTIP, 0, (LPARAM)&tooltip);
}

// Create gradient brush
HBRUSH CreateGradientBrush(COLORREF color1, COLORREF color2, int width, int height) {
    HDC hdc = GetDC(NULL);
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP hBitmap = CreateCompatibleBitmap(hdc, width, height);
    HBITMAP oldBitmap = (HBITMAP)SelectObject(memDC, hBitmap);
    
    // Create gradient effect
    for (int y = 0; y < height; y++) {
        float ratio = (float)y / height;
        
        int r = (int)(GetRValue(color1) * (1 - ratio) + GetRValue(color2) * ratio);
        int g = (int)(GetGValue(color1) * (1 - ratio) + GetGValue(color2) * ratio);
        int b = (int)(GetBValue(color1) * (1 - ratio) + GetBValue(color2) * ratio);
        
        HPEN hPen = CreatePen(PS_SOLID, 1, RGB(r, g, b));
        HPEN oldPen = (HPEN)SelectObject(memDC, hPen);
        
        MoveToEx(memDC, 0, y, NULL);
        LineTo(memDC, width, y);
        
        SelectObject(memDC, oldPen);
        DeleteObject(hPen);
    }
    
    SelectObject(memDC, oldBitmap);
    DeleteDC(memDC);
    ReleaseDC(NULL, hdc);
    
    return CreatePatternBrush(hBitmap);
}

// Animate control
void AnimateControl(HWND hwnd, DWORD flags, DWORD duration) {
    AnimateWindow(hwnd, duration, flags);
}

// Show file browser dialog
BOOL ShowFileBrowser(HWND parent, wchar_t *filepath, size_t filepathSize, 
                    BOOL isOpen, const wchar_t *filter, const wchar_t *title) {
    OPENFILENAME ofn = {0};
    
    ofn.lStructSize = sizeof(OPENFILENAME);
    ofn.hwndOwner = parent;
    ofn.lpstrFile = filepath;
    ofn.nMaxFile = (DWORD)filepathSize / sizeof(wchar_t);
    ofn.lpstrFilter = filter;
    ofn.nFilterIndex = 1;
    ofn.lpstrTitle = title;
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;
    
    if (isOpen) {
        ofn.Flags |= OFN_FILEMUSTEXIST;
        return GetOpenFileName(&ofn);
    } else {
        ofn.Flags |= OFN_OVERWRITEPROMPT;
        ofn.lpstrDefExt = L"lqx10";
        return GetSaveFileName(&ofn);
    }
}

// Format file size
void FormatFileSize(UINT64 bytes, wchar_t *buffer, size_t bufferSize) {
    const wchar_t *units[] = {L"bytes", L"KB", L"MB", L"GB", L"TB"};
    int unitIndex = 0;
    double size = (double)bytes;
    
    while (size >= 1024.0 && unitIndex < 4) {
        size /= 1024.0;
        unitIndex++;
    }
    
    if (unitIndex == 0) {
        swprintf_s(buffer, bufferSize, L"%.0f %s", size, units[unitIndex]);
    } else {
        swprintf_s(buffer, bufferSize, L"%.1f %s", size, units[unitIndex]);
    }
}

// Format duration
void FormatDuration(DWORD milliseconds, wchar_t *buffer, size_t bufferSize) {
    DWORD seconds = milliseconds / 1000;
    DWORD minutes = seconds / 60;
    DWORD hours = minutes / 60;
    
    seconds %= 60;
    minutes %= 60;
    
    if (hours > 0) {
        swprintf_s(buffer, bufferSize, L"%lu:%02lu:%02lu", hours, minutes, seconds);
    } else if (minutes > 0) {
        swprintf_s(buffer, bufferSize, L"%lu:%02lu", minutes, seconds);
    } else {
        swprintf_s(buffer, bufferSize, L"%lu.%03lu sec", seconds, milliseconds % 1000);
    }
}

// Update progress with animation
void UpdateProgressSmooth(HWND progressBar, int currentPos, int targetPos) {
    if (currentPos == targetPos) {
        return;
    }
    
    int step = (targetPos > currentPos) ? 1 : -1;
    
    for (int pos = currentPos; pos != targetPos; pos += step) {
        SendMessage(progressBar, PBM_SETPOS, pos, 0);
        Sleep(10); // Small delay for smooth animation
    }
    
    SendMessage(progressBar, PBM_SETPOS, targetPos, 0);
}

// Create modern flat button
HWND CreateFlatButton(HWND parent, const wchar_t *text, int x, int y, 
                     int width, int height, int id) {
    HWND button = CreateWindow(L"BUTTON", text,
                              WS_VISIBLE | WS_CHILD | BS_FLAT | BS_PUSHBUTTON,
                              x, y, width, height, parent, (HMENU)(LONG_PTR)id, 
                              GetModuleHandle(NULL), NULL);
    
    // Set modern font
    HFONT hFont = CreateFont(16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                            CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
    SendMessage(button, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(TRUE, 0));
    
    return button;
}

// Create tooltip
HWND CreateTooltip(HWND parent, HWND control, const wchar_t *text) {
    HWND tooltip = CreateWindowEx(WS_EX_TOPMOST, TOOLTIPS_CLASS, NULL,
                                 WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP,
                                 CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
                                 parent, NULL, GetModuleHandle(NULL), NULL);
    
    if (!tooltip) {
        return NULL;
    }
    
    TOOLINFO toolInfo = {0};
    toolInfo.cbSize = sizeof(TOOLINFO);
    toolInfo.hwnd = parent;
    toolInfo.uFlags = TTF_IDISHWND | TTF_SUBCLASS;
    toolInfo.uId = (UINT_PTR)control;
    toolInfo.lpszText = (LPWSTR)text;
    
    SendMessage(tooltip, TTM_ADDTOOL, 0, (LPARAM)&toolInfo);
    
    return tooltip;
}

// Flash window to get attention
void FlashWindowAlert(HWND hwnd) {
    FLASHWINFO flash = {0};
    flash.cbSize = sizeof(FLASHWINFO);
    flash.hwnd = hwnd;
    flash.dwFlags = FLASHW_ALL | FLASHW_TIMERNOFG;
    flash.uCount = 3;
    flash.dwTimeout = 0;
    
    FlashWindowEx(&flash);
}

// Play system sound
void PlaySystemSound(SystemSound sound) {
    switch (sound) {
        case SOUND_SUCCESS:
            MessageBeep(MB_OK);
            break;
        case SOUND_ERROR:
            MessageBeep(MB_ICONERROR);
            break;
        case SOUND_WARNING:
            MessageBeep(MB_ICONWARNING);
            break;
        case SOUND_INFO:
            MessageBeep(MB_ICONINFORMATION);
            break;
    }
}

// Set control colors
void SetControlColors(HWND hwnd, COLORREF textColor, COLORREF bgColor) {
    // This would typically be handled in WM_CTLCOLORSTATIC message
    // For now, just store the colors in window data
    SetWindowLongPtr(hwnd, GWLP_USERDATA, MAKELONG(textColor, bgColor));
}

// Create status bar
HWND CreateStatusBar(HWND parent, int id) {
    HWND statusBar = CreateWindowEx(0, STATUSCLASSNAME, NULL,
                                   WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP,
                                   0, 0, 0, 0, parent, (HMENU)(LONG_PTR)id,
                                   GetModuleHandle(NULL), NULL);
    
    // Set default parts
    int parts[] = {300, 500, -1};
    SendMessage(statusBar, SB_SETPARTS, 3, (LPARAM)parts);
    
    return statusBar;
} 