# LackyVault MSI Build Script (PowerShell)
# Advanced MSI builder with comprehensive features

param(
    [string]$Configuration = "Release",
    [string]$Platform = "x64",
    [switch]$Clean = $false,
    [switch]$SkipBuild = $false,
    [switch]$Sign = $false,
    [string]$CertificateThumbprint = "",
    [switch]$Verbose = $false
)

$ErrorActionPreference = "Stop"

# Script configuration
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$BuildDir = Join-Path $ProjectRoot "build"
$InstallerDir = Join-Path $ProjectRoot "installer"
$OutputDir = Join-Path $ProjectRoot "output"
$ConfigDir = Join-Path $ProjectRoot "config"
$ThemesDir = Join-Path $ProjectRoot "themes"

# Version information
$Version = "1.0.0.0"
$ProductName = "LackyVault"
$Manufacturer = "Lackadaisical Security"

Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "LackyVault MSI Build Script" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "Configuration: $Configuration" -ForegroundColor Yellow
Write-Host "Platform: $Platform" -ForegroundColor Yellow
Write-Host "Version: $Version" -ForegroundColor Yellow
Write-Host ""

# Function to check if a command exists
function Test-Command {
    param([string]$Command)
    $null = Get-Command $Command -ErrorAction SilentlyContinue
    return $?
}

# Function to log messages
function Write-BuildLog {
    param([string]$Message, [string]$Level = "Info")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) {
        "Error" { "Red" }
        "Warning" { "Yellow" }
        "Success" { "Green" }
        default { "White" }
    }
    Write-Host "[$timestamp] $Message" -ForegroundColor $color
}

# Check prerequisites
Write-BuildLog "Checking prerequisites..."

if (-not (Test-Command "candle.exe")) {
    Write-BuildLog "ERROR: WiX Toolset not found. Please install WiX Toolset v3.11 or later." "Error"
    Write-BuildLog "Download from: https://wixtoolset.org/releases/" "Error"
    exit 1
}

if (-not (Test-Command "light.exe")) {
    Write-BuildLog "ERROR: WiX light.exe not found." "Error"
    exit 1
}

if (-not (Test-Command "cl.exe")) {
    Write-BuildLog "ERROR: Visual Studio C++ compiler not found." "Error"
    Write-BuildLog "Please run this script from a Visual Studio Developer Command Prompt." "Error"
    exit 1
}

Write-BuildLog "Prerequisites check passed." "Success"

# Create directories
Write-BuildLog "Creating build directories..."
@($BuildDir, $OutputDir, "$BuildDir\config", "$BuildDir\themes", "$BuildDir\privacy\tor", 
  "$BuildDir\privacy\steganography", "$BuildDir\drivers\ledger", "$BuildDir\drivers\trezor") | 
ForEach-Object {
    if (-not (Test-Path $_)) {
        New-Item -ItemType Directory -Path $_ -Force | Out-Null
    }
}

# Clean previous build
if ($Clean) {
    Write-BuildLog "Cleaning previous build..."
    Get-ChildItem $BuildDir -Include "*.obj", "*.wixobj", "*.dll" -Recurse | Remove-Item -Force
    Get-ChildItem $OutputDir -Include "*.msi", "*.zip" -Recurse | Remove-Item -Force
}

# Build custom actions DLL
if (-not $SkipBuild) {
    Write-BuildLog "Building Custom Actions DLL..."
    
    $CustomActionsSrc = Join-Path $InstallerDir "LackyVaultCustomActions.c"
    $CustomActionsDef = Join-Path $InstallerDir "LackyVaultCustomActions.def"
    $CustomActionsDll = Join-Path $BuildDir "LackyVaultCustomActions.dll"
    
    $compilerArgs = @(
        "/LD",
        "/I`"$env:WindowsSdkDir\Include\$env:WindowsSDKVersion\um`"",
        "/I`"$env:WindowsSdkDir\Include\$env:WindowsSDKVersion\shared`"",
        "`"$CustomActionsSrc`"",
        "/DEF:`"$CustomActionsDef`"",
        "/Fe:`"$CustomActionsDll`"",
        "/Fo:`"$BuildDir\`"",
        "msi.lib", "ole32.lib", "oleaut32.lib", "shell32.lib", "advapi32.lib", "crypt32.lib"
    )
    
    $process = Start-Process -FilePath "cl.exe" -ArgumentList $compilerArgs -Wait -PassThru -NoNewWindow
    if ($process.ExitCode -ne 0) {
        Write-BuildLog "ERROR: Failed to build custom actions DLL" "Error"
        exit 1
    }
    
    Write-BuildLog "Custom actions DLL built successfully." "Success"
    
    # Build main application (placeholder)
    Write-BuildLog "Preparing main application..."
    $mainExe = Join-Path $BuildDir "LackyVault.exe"
    if (-not (Test-Path $mainExe)) {
        # Create placeholder executable for testing
        "" | Out-File -FilePath $mainExe -Encoding ASCII
        Write-BuildLog "Created placeholder executable for testing." "Warning"
    }
}

# Copy installation files
Write-BuildLog "Preparing installation files..."

# Copy configuration files
if (Test-Path $ConfigDir) {
    Copy-Item "$ConfigDir\*" "$BuildDir\config\" -Force
    Write-BuildLog "Copied configuration files."
}

# Copy theme files
if (Test-Path $ThemesDir) {
    Copy-Item "$ThemesDir\*" "$BuildDir\themes\" -Force
    Write-BuildLog "Copied theme files."
}

# Copy documentation
@("README.md", "LICENSE.txt") | ForEach-Object {
    $srcFile = Join-Path $ProjectRoot $_
    if (Test-Path $srcFile) {
        Copy-Item $srcFile $BuildDir -Force
    }
}

# Copy icon
$iconSrc = Join-Path $ProjectRoot "src\resources\icons\lacky_vault.ico"
if (Test-Path $iconSrc) {
    Copy-Item $iconSrc $BuildDir -Force
    Write-BuildLog "Copied application icon."
}

# Create WiX variables file
$wixVars = @"
<?xml version="1.0" encoding="utf-8"?>
<Include>
  <SetProperty Id="BuildDir" Value="$BuildDir" />
  <SetProperty Id="ProjectRoot" Value="$ProjectRoot" />
  <SetProperty Id="Version" Value="$Version" />
  <SetProperty Id="Configuration" Value="$Configuration" />
  <SetProperty Id="Platform" Value="$Platform" />
</Include>
"@

$wixVarsFile = Join-Path $BuildDir "Variables.wxi"
$wixVars | Out-File -FilePath $wixVarsFile -Encoding UTF8

# Compile WiX source
Write-BuildLog "Compiling WiX source files..."
$candleArgs = @(
    "-dBuildDir=$BuildDir",
    "-dProjectRoot=$ProjectRoot",
    "-ext", "WixUtilExtension",
    "-o", "$BuildDir\LackyVault.wixobj",
    "$InstallerDir\LackyVault.wxs"
)

$process = Start-Process -FilePath "candle.exe" -ArgumentList $candleArgs -Wait -PassThru -NoNewWindow
if ($process.ExitCode -ne 0) {
    Write-BuildLog "ERROR: Failed to compile WiX source" "Error"
    exit 1
}

Write-BuildLog "WiX source compiled successfully." "Success"

# Link MSI package
Write-BuildLog "Linking MSI package..."
$outputMsi = Join-Path $OutputDir "LackyVault.msi"
$lightArgs = @(
    "-ext", "WixUIExtension",
    "-ext", "WixUtilExtension",
    "-cultures:en-US",
    "-o", $outputMsi,
    "$BuildDir\LackyVault.wixobj"
)

$process = Start-Process -FilePath "light.exe" -ArgumentList $lightArgs -Wait -PassThru -NoNewWindow
if ($process.ExitCode -ne 0) {
    Write-BuildLog "ERROR: Failed to link MSI package" "Error"
    exit 1
}

Write-BuildLog "MSI package linked successfully." "Success"

# Sign the MSI if requested
if ($Sign -and $CertificateThumbprint) {
    Write-BuildLog "Signing MSI package..."
    $signArgs = @(
        "sign",
        "/sha1", $CertificateThumbprint,
        "/fd", "SHA256",
        "/t", "http://timestamp.digicert.com",
        "/d", $ProductName,
        "/du", "https://lackyvault.com",
        $outputMsi
    )
    
    $process = Start-Process -FilePath "signtool.exe" -ArgumentList $signArgs -Wait -PassThru -NoNewWindow
    if ($process.ExitCode -ne 0) {
        Write-BuildLog "WARNING: Failed to sign MSI package" "Warning"
    } else {
        Write-BuildLog "MSI package signed successfully." "Success"
    }
}

# Create additional packages
Write-BuildLog "Creating additional packages..."

# Create portable ZIP
$portableZip = Join-Path $OutputDir "LackyVault-Portable.zip"
Compress-Archive -Path "$BuildDir\*" -DestinationPath $portableZip -Force

# Generate checksums
$msiHash = Get-FileHash $outputMsi -Algorithm SHA256
$zipHash = Get-FileHash $portableZip -Algorithm SHA256

$msiHash.Hash | Out-File -FilePath "$outputMsi.sha256" -Encoding ASCII
$zipHash.Hash | Out-File -FilePath "$portableZip.sha256" -Encoding ASCII

# Create installation script
$installScript = @"
@echo off
echo Installing LackyVault...
msiexec /i "$([System.IO.Path]::GetFileName($outputMsi))" /quiet /norestart
echo Installation complete.
pause
"@

$installScript | Out-File -FilePath (Join-Path $OutputDir "Install.bat") -Encoding ASCII

# Create uninstall script
$uninstallScript = @"
@echo off
echo Uninstalling LackyVault...
wmic product where name="LackyVault - Crypto Wallet" call uninstall /nointeractive
echo Uninstall complete.
pause
"@

$uninstallScript | Out-File -FilePath (Join-Path $OutputDir "Uninstall.bat") -Encoding ASCII

# Generate build report
$msiSize = (Get-Item $outputMsi).Length
$zipSize = (Get-Item $portableZip).Length

$buildReport = @"
====================================
LackyVault Build Report
====================================
Build Time: $(Get-Date)
Configuration: $Configuration
Platform: $Platform
Version: $Version

Output Files:
- MSI Installer: $outputMsi ($([math]::Round($msiSize/1MB, 2)) MB)
- Portable ZIP: $portableZip ($([math]::Round($zipSize/1MB, 2)) MB)
- Checksums: *.sha256 files

Features Included:
✓ Core wallet functionality
✓ Privacy extensions (Tor, Steganography)
✓ Hardware wallet support
✓ Custom themes (Cosmic, Cyber)
✓ Configurable security settings
✓ Windows integration
✓ Secure uninstall capabilities

Installation:
- Run $([System.IO.Path]::GetFileName($outputMsi)) as Administrator
- Or use Install.bat for silent installation

Testing:
msiexec /i "$([System.IO.Path]::GetFileName($outputMsi))" /l*v install.log

Uninstalling:
- Use Windows Add/Remove Programs
- Or run Uninstall.bat
- Or: msiexec /x {ProductCode}

SHA256 Checksums:
MSI: $($msiHash.Hash)
ZIP: $($zipHash.Hash)
====================================
"@

$buildReport | Out-File -FilePath (Join-Path $OutputDir "BuildReport.txt") -Encoding UTF8

Write-Host ""
Write-Host "=====================================" -ForegroundColor Green
Write-Host "Build Complete!" -ForegroundColor Green
Write-Host "=====================================" -ForegroundColor Green
Write-Host ""
Write-Host "Output Directory: $OutputDir" -ForegroundColor Yellow
Write-Host "MSI Installer: $([System.IO.Path]::GetFileName($outputMsi)) ($([math]::Round($msiSize/1MB, 2)) MB)" -ForegroundColor Cyan
Write-Host "Portable ZIP: $([System.IO.Path]::GetFileName($portableZip)) ($([math]::Round($zipSize/1MB, 2)) MB)" -ForegroundColor Cyan
Write-Host ""
Write-Host "To install: Run $([System.IO.Path]::GetFileName($outputMsi)) as Administrator" -ForegroundColor Green
Write-Host "To test: msiexec /i `"$outputMsi`" /l*v install.log" -ForegroundColor Yellow
Write-Host ""

# Open output directory
if (Test-Path $OutputDir) {
    Start-Process -FilePath "explorer.exe" -ArgumentList $OutputDir
}
