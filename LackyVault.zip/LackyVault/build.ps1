# LackyVault PowerShell Build Script
# Lackadaisical Security

param(
    [Parameter(Position=0)]
    [ValidateSet("debug", "release", "test", "clean", "help", "install-deps", "installer", "package")]
    [string]$Target = "release",
    
    [switch]$DebugMode,
    [switch]$VerboseOutput,
    [switch]$Force
)

# Script configuration
$ProjectName = "LackyVault"
$Version = "1.0.0"
$BuildDir = "build"

# Color output functions
function Write-Header($Message) {
    Write-Host "===========================================" -ForegroundColor Cyan
    Write-Host $Message -ForegroundColor Yellow
    Write-Host "===========================================" -ForegroundColor Cyan
    Write-Host ""
}

function Write-Success($Message) {
    Write-Host $Message -ForegroundColor Green
}

function Write-Error($Message) {
    Write-Host $Message -ForegroundColor Red
}

function Write-Warning($Message) {
    Write-Host $Message -ForegroundColor Yellow
}

function Write-Info($Message) {
    Write-Host $Message -ForegroundColor Cyan
}

# Check prerequisites
function Test-Prerequisites {
    Write-Info "Checking build prerequisites..."
    
    $missing = @()
    
    # Check for make
    if (-not (Get-Command "make" -ErrorAction SilentlyContinue)) {
        $missing += "GNU Make (install MSYS2)"
    }
    
    # Check for GCC
    if (-not (Get-Command "gcc" -ErrorAction SilentlyContinue)) {
        $missing += "GCC (install MinGW-w64 via MSYS2)"
    }
    
    # Check for NASM
    if (-not (Get-Command "nasm" -ErrorAction SilentlyContinue)) {
        $missing += "NASM Assembler"
    }
    
    if ($Target -eq "installer") {
        # Check for WiX
        if (-not (Get-Command "candle" -ErrorAction SilentlyContinue)) {
            $missing += "WiX Toolset"
        }
    }
    
    if ($missing.Count -gt 0) {
        Write-Error "Missing prerequisites:"
        foreach ($tool in $missing) {
            Write-Host "  - $tool" -ForegroundColor Red
        }
        Write-Host ""
        Write-Info "Run: .\build.ps1 install-deps"
        return $false
    }
    
    Write-Success "All prerequisites found!"
    return $true
}

# Install dependencies
function Install-Dependencies {
    Write-Header "Installing Build Dependencies"
    
    if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
        Write-Warning "Requesting administrator privileges..."
        Start-Process powershell -ArgumentList "-File `"$PSCommandPath`" install-deps" -Verb RunAs
        return
    }
    
    Write-Info "Installing NASM..."
    try { winget install NASM.NASM } catch { Write-Warning "Failed to install NASM" }
    
    Write-Info "Installing MSYS2..."
    try { winget install msys2.msys2 } catch { Write-Warning "Failed to install MSYS2" }
    
    Write-Info "Installing WiX Toolset..."
    try { winget install WiXToolset.WiX } catch { Write-Warning "Failed to install WiX" }
    
    Write-Success "Installation complete!"
    Write-Info "Please restart your terminal and run the following in MSYS2:"
    Write-Host "  pacman -S mingw-w64-x86_64-gcc mingw-w64-x86_64-make" -ForegroundColor Yellow
    Write-Host ""
    Write-Info "Then add these to your PATH:"
    Write-Host "  C:\Program Files\NASM" -ForegroundColor Yellow
    Write-Host "  C:\msys64\mingw64\bin" -ForegroundColor Yellow
    Write-Host "  C:\Program Files (x86)\WiX Toolset v3.11\bin" -ForegroundColor Yellow
}

# Main build function
function Invoke-Build {
    param($BuildTarget, $BuildType)
    
    Write-Header "$ProjectName Build System v$Version"
    Write-Info "Target: $BuildTarget"
    Write-Info "Type: $BuildType"
    Write-Host ""
    
    # Check prerequisites unless we're installing deps
    if ($BuildTarget -ne "install-deps" -and -not (Test-Prerequisites)) {
        exit 1
    }
    
    # Handle special targets
    switch ($BuildTarget) {
        "install-deps" {
            Install-Dependencies
            return
        }
        "help" {
            Show-Help
            return
        }
    }
    
    # Prepare make command
    $makeArgs = @()
    if ($BuildType -eq "debug") {
        $makeArgs += "DEBUG=1"
    }
    $makeArgs += $BuildTarget
    
    # Run make
    Write-Info "Running: make $($makeArgs -join ' ')"
    Write-Host ""
    
    $process = Start-Process -FilePath "make" -ArgumentList $makeArgs -NoNewWindow -Wait -PassThru
    
    if ($process.ExitCode -eq 0) {
        Write-Host ""
        Write-Header "Build Completed Successfully!"
        
        # Show output information
        switch ($BuildTarget) {
            "all" {
                $exePath = Join-Path $BuildDir "$ProjectName.exe"
                if (Test-Path $exePath) {
                    Write-Success "Output: $exePath"
                    $fileInfo = Get-Item $exePath
                    Write-Info "Size: $([math]::Round($fileInfo.Length / 1KB, 2)) KB"
                    Write-Info "Modified: $($fileInfo.LastWriteTime)"
                }
            }
            "package" {
                $packageDir = Join-Path $BuildDir "package"
                if (Test-Path $packageDir) {
                    Write-Success "Package created: $packageDir"
                    Get-ChildItem $packageDir | ForEach-Object {
                        Write-Host "  - $($_.Name)" -ForegroundColor Gray
                    }
                }
            }
            "test" {
                Write-Success "Tests completed!"
            }
        }
    } else {
        Write-Host ""
        Write-Error "Build failed with exit code $($process.ExitCode)"
        exit $process.ExitCode
    }
}

# Show help
function Show-Help {
    Write-Header "$ProjectName Build System"
    Write-Host "Usage: .\build.ps1 [target] [options]" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Targets:" -ForegroundColor Cyan
    Write-Host "  release      Build optimized release version (default)" -ForegroundColor Gray
    Write-Host "  debug        Build with debug symbols and logging" -ForegroundColor Gray
    Write-Host "  test         Build and run tests" -ForegroundColor Gray
    Write-Host "  clean        Remove all build artifacts" -ForegroundColor Gray
    Write-Host "  installer    Create MSI installer" -ForegroundColor Gray
    Write-Host "  package      Create distribution package" -ForegroundColor Gray
    Write-Host "  install-deps Install build dependencies (requires admin)" -ForegroundColor Gray
    Write-Host "  help         Show this help message" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Options:" -ForegroundColor Cyan
    Write-Host "  -Debug       Force debug build" -ForegroundColor Gray
    Write-Host "  -Verbose     Enable verbose output" -ForegroundColor Gray
    Write-Host "  -Force       Force rebuild" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Examples:" -ForegroundColor Cyan
    Write-Host "  .\build.ps1 debug" -ForegroundColor Yellow
    Write-Host "  .\build.ps1 test" -ForegroundColor Yellow
    Write-Host "  .\build.ps1 package" -ForegroundColor Yellow
}

# Main execution
try {
    # Determine build type
    $buildType = if ($DebugMode -or $Target -eq "debug") { "debug" } else { "release" }
    
    # Handle force clean
    if ($Force -and $Target -ne "clean") {
        Write-Info "Force rebuild requested, cleaning first..."
        Invoke-Build "clean" $buildType
    }
    
    # Run the build
    Invoke-Build $Target $buildType
    
} catch {
    Write-Error "Build script failed: $($_.Exception.Message)"
    if ($VerboseOutput) {
        Write-Host $_.Exception.StackTrace -ForegroundColor Red
    }
    exit 1
}
