# LackyVault Installation Guide

## System Requirements

- Windows 10/11 (x64)
- 500 MB free disk space
- Administrator privileges for MSI installation

## Installation Options

### Option 1: MSI Installer (Recommended)

1. Download `LackyVault.msi`
2. Right-click and select "Run as administrator"
3. Follow the installation wizard
4. Launch from Start Menu or Desktop shortcut

### Option 2: Portable Version

1. Download `LackyVault-Portable.zip`
2. Extract to any folder
3. Run `LackyVault.exe` directly

## Building from Source

### Prerequisites

- MinGW-w64 GCC compiler
- NASM assembler
- WiX Toolset 3.11+ (for MSI installer)

### Build Steps

1. Clone the repository
2. Open Command Prompt as Administrator
3. Run: `build_full_mingw.bat`

This will create:
- `output\LackyVault.msi` - MSI installer
- `output\LackyVault-Portable.zip` - Portable package

## Features

- **Zero Dependencies**: Self-contained executable
- **8 Themes**: Light, Dark, 80s Retro, 90s Psychedelic, Matrix, Terminal, Cyber, Cosmic
- **Security Features**: Anti-debug, secure memory, panic mode
- **Cryptocurrency Support**: Bitcoin, Ethereum, Monero wallet functionality
- **Privacy Features**: Tor integration, steganographic communications

## Theme Selection

Access themes via:
- Menu: View → Themes
- Hotkeys: F1-F8 for each theme
- Settings screen

## Security Hotkeys

- **F12**: Panic mode (emergency shutdown)
- **F11**: Stealth mode (disguise as Windows update)
- **F9**: Security status display
- **F8**: Advanced security mode

## Uninstalling

### MSI Installation
- Use Windows Add/Remove Programs
- Or run: `Uninstall.bat`
- Or: `msiexec /x {ProductCode}`

### Portable Version
- Simply delete the folder

## Support

For issues or questions, refer to the project documentation or GitHub repository.

## License

Licensed under BSD 3-Clause License. See LICENSE file for details. 