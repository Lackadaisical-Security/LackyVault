/**
 * LackyVault Test Suite
 * Lackadaisical Security
 * 
 * Basic unit tests and integration tests
 */

#include "../include/lacky_vault.h"
#include "../include/lacky_crypto.h"
#include <stdio.h>
#include <string.h>
#include <assert.h>

/* Test framework macros */
#define TEST_ASSERT(condition, message) \
    do { \
        if (!(condition)) { \
            printf("FAIL: %s - %s\n", __func__, message); \
            return 0; \
        } \
    } while(0)

#define TEST_PASS() \
    do { \
        printf("PASS: %s\n", __func__); \
        return 1; \
    } while(0)

/* Test counters */
static int tests_run = 0;
static int tests_passed = 0;

/* Run a test function */
#define RUN_TEST(test_func) \
    do { \
        tests_run++; \
        if (test_func()) tests_passed++; \
    } while(0)

/* Forward declarations */
static int test_lacky_app_init(void);
static int test_lacky_state_transitions(void);
static int test_lacky_security_functions(void);
static int test_lacky_crypto_primitives(void);
static int test_lacky_memory_operations(void);

/**
 * Test application initialization
 */
static int test_lacky_app_init(void) {
    lacky_app_t app = {0};
    lacky_error_t result;
    
    /* Test basic initialization */
    result = lacky_app_init(&app, GetModuleHandle(NULL));
    TEST_ASSERT(result == LACKY_SUCCESS, "App initialization failed");
    
    /* Verify app state */
    TEST_ASSERT(app.state == LACKY_STATE_INIT, "Initial state incorrect");
    TEST_ASSERT(app.hinstance != NULL, "Instance handle not set");
    
    /* Test cleanup */
    lacky_app_cleanup(&app);
    
    TEST_PASS();
}

/**
 * Test state machine transitions
 */
static int test_lacky_state_transitions(void) {
    lacky_app_t app = {0};
    lacky_error_t result;
    
    /* Initialize app */
    result = lacky_app_init(&app, GetModuleHandle(NULL));
    TEST_ASSERT(result == LACKY_SUCCESS, "App initialization failed");
    
    /* Test state transitions */
    TEST_ASSERT(app.state == LACKY_STATE_INIT, "Initial state incorrect");
    
    /* Simulate authentication */
    lacky_state_transition(&app, LACKY_STATE_AUTH);
    TEST_ASSERT(app.state == LACKY_STATE_AUTH, "Auth state transition failed");
    
    /* Simulate main state */
    lacky_state_transition(&app, LACKY_STATE_MAIN);
    TEST_ASSERT(app.state == LACKY_STATE_MAIN, "Main state transition failed");
    
    /* Test panic mode */
    lacky_state_transition(&app, LACKY_STATE_PANIC);
    TEST_ASSERT(app.state == LACKY_STATE_PANIC, "Panic state transition failed");
    
    lacky_app_cleanup(&app);
    TEST_PASS();
}

/**
 * Test security functions
 */
static int test_lacky_security_functions(void) {
    lacky_app_t app = {0};
    
    /* Test integrity check */
    int integrity_result = lacky_security_check_integrity(&app);
    TEST_ASSERT(integrity_result == 1, "Integrity check failed");
    
    /* Test anti-debug detection */
    int debug_result = lacky_security_detect_debugger(&app);
    TEST_ASSERT(debug_result >= 0, "Debug detection failed");
    
    /* Test VM detection */
    int vm_result = lacky_security_detect_vm(&app);
    TEST_ASSERT(vm_result >= 0, "VM detection failed");
    
    TEST_PASS();
}

/**
 * Test cryptographic primitives (basic functionality)
 */
static int test_lacky_crypto_primitives(void) {
    /* Test basic crypto structure initialization */
    lacky_crypto_context_t ctx = {0};
    lacky_error_t result;
    
    result = lacky_crypto_init(&ctx);
    TEST_ASSERT(result == LACKY_SUCCESS, "Crypto initialization failed");
    
    /* Test random number generation */
    uint8_t random_data[32] = {0};
    result = lacky_crypto_random(random_data, sizeof(random_data));
    TEST_ASSERT(result == LACKY_SUCCESS, "Random generation failed");
    
    /* Verify randomness (basic check - not all zeros) */
    int all_zero = 1;
    for (size_t i = 0; i < sizeof(random_data); i++) {
        if (random_data[i] != 0) {
            all_zero = 0;
            break;
        }
    }
    TEST_ASSERT(!all_zero, "Random data appears to be all zeros");
    
    lacky_crypto_cleanup(&ctx);
    TEST_PASS();
}

/**
 * Test memory operations
 */
static int test_lacky_memory_operations(void) {
    /* Test secure memory allocation */
    size_t test_size = 1024;
    void* secure_mem = lacky_secure_alloc(test_size);
    TEST_ASSERT(secure_mem != NULL, "Secure allocation failed");
    
    /* Test memory write and read */
    memset(secure_mem, 0xAA, test_size);
    uint8_t* mem_bytes = (uint8_t*)secure_mem;
    TEST_ASSERT(mem_bytes[0] == 0xAA, "Memory write/read failed");
    TEST_ASSERT(mem_bytes[test_size-1] == 0xAA, "Memory boundary check failed");
    
    /* Test secure free */
    lacky_secure_free(secure_mem, test_size);
    
    TEST_PASS();
}

/**
 * Main test runner
 */
int main(void) {
    printf("LackyVault Test Suite\n");
    printf("====================\n\n");
    
    /* Initialize test environment */
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleMode(hConsole, ENABLE_PROCESSED_OUTPUT | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
    
    printf("Running tests...\n\n");
    
    /* Run all tests */
    RUN_TEST(test_lacky_app_init);
    RUN_TEST(test_lacky_state_transitions);
    RUN_TEST(test_lacky_security_functions);
    RUN_TEST(test_lacky_crypto_primitives);
    RUN_TEST(test_lacky_memory_operations);
    
    /* Print results */
    printf("\n====================\n");
    printf("Test Results: %d/%d passed\n", tests_passed, tests_run);
    
    if (tests_passed == tests_run) {
        printf("\x1b[32mAll tests passed!\x1b[0m\n");
        return 0;
    } else {
        printf("\x1b[31m%d tests failed!\x1b[0m\n", tests_run - tests_passed);
        return 1;
    }
}
