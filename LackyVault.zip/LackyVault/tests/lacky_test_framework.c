/**
 * @file lacky_test_framework.c
 * @brief Comprehensive Testing Framework - LackyVault
 * 
 * Test framework features:
 * - Unit tests for all cryptographic primitives
 * - Performance benchmarks for critical operations
 * - Memory leak detection and validation
 * - Stress testing for security-critical code
 * 
 * Copyright (c) 2024 Lackadaisical Security
 * Zero dependencies, maximum paranoia
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <time.h>
#include "../include/lacky_vault.h"
#include "../include/lacky_crypto.h"

/* Test Framework Constants */
#define TEST_MAX_CASES 256
#define TEST_NAME_MAX_LEN 64
#define TEST_OUTPUT_BUFFER 1024
#define BENCHMARK_ITERATIONS 10000
#define STRESS_TEST_THREADS 4
#define STRESS_TEST_DURATION 5000 // milliseconds

/* Memory Tracking */
#define MEM_TRACK_MAX_ALLOCS 1024
#define MEM_MAGIC_HEADER 0xDEADBEEF
#define MEM_MAGIC_FOOTER 0xCAFEBABE

/* Test Status Enums */
typedef enum {
    TEST_STATUS_PASS = 0,
    TEST_STATUS_FAIL = 1,
    TEST_STATUS_SKIP = 2
} test_status_t;

/* Memory Tracking Structure */
typedef struct {
    void* ptr;
    size_t size;
    char location[TEST_NAME_MAX_LEN];
    bool freed;
} mem_alloc_info_t;

/* Test Case Structure */
typedef struct {
    char name[TEST_NAME_MAX_LEN];
    test_status_t (*test_func)(void);
    test_status_t status;
    DWORD execution_time;
    char output[TEST_OUTPUT_BUFFER];
} test_case_t;

/* Memory Header/Footer for Leak Detection */
typedef struct {
    uint32_t magic;
    size_t size;
    char location[TEST_NAME_MAX_LEN];
} mem_header_t;

/* Global Test State */
static struct {
    test_case_t test_cases[TEST_MAX_CASES];
    uint32_t test_count;
    uint32_t pass_count;
    uint32_t fail_count;
    uint32_t skip_count;
    bool verbose_output;
    char current_test[TEST_NAME_MAX_LEN];
    
    /* Memory tracking */
    mem_alloc_info_t allocations[MEM_TRACK_MAX_ALLOCS];
    uint32_t alloc_count;
    bool track_memory;
    
    /* Benchmark results */
    DWORD benchmark_results[TEST_MAX_CASES];
} g_test_state;

/* Forward declarations */
static void* test_malloc(size_t size);
static void test_free(void* ptr);
static void start_memory_tracking(void);
static bool check_memory_leaks(void);
static void print_test_summary(void);

/**
 * Register a test case with the framework
 */
void register_test(const char* name, test_status_t (*test_func)(void)) {
    if (g_test_state.test_count >= TEST_MAX_CASES) {
        printf("ERROR: Too many test cases registered\n");
        return;
    }
    
    test_case_t* test = &g_test_state.test_cases[g_test_state.test_count++];
    strncpy(test->name, name, TEST_NAME_MAX_LEN - 1);
    test->name[TEST_NAME_MAX_LEN - 1] = '\0';
    test->test_func = test_func;
    test->status = TEST_STATUS_SKIP;
    test->execution_time = 0;
    memset(test->output, 0, TEST_OUTPUT_BUFFER);
}

/**
 * Initialize the test framework
 */
void test_framework_init(bool verbose) {
    memset(&g_test_state, 0, sizeof(g_test_state));
    g_test_state.verbose_output = verbose;
    
    printf("┌───────────────────────────────────────────┐\n");
    printf("│      LackyVault Test Framework v1.0       │\n");
    printf("│   Zero Dependencies, Maximum Coverage     │\n");
    printf("└───────────────────────────────────────────┘\n\n");
}

/**
 * Run all registered test cases
 */
bool run_all_tests(void) {
    uint32_t i;
    DWORD start_time, end_time;
    
    for (i = 0; i < g_test_state.test_count; i++) {
        test_case_t* test = &g_test_state.test_cases[i];
        
        // Update current test name for memory tracking
        strncpy(g_test_state.current_test, test->name, TEST_NAME_MAX_LEN - 1);
        g_test_state.current_test[TEST_NAME_MAX_LEN - 1] = '\0';
        
        // Start memory tracking for this test
        start_memory_tracking();
        
        printf("Running test: %s...", test->name);
        fflush(stdout);
        
        // Measure execution time
        start_time = GetTickCount();
        test->status = test->test_func();
        end_time = GetTickCount();
        test->execution_time = end_time - start_time;
        
        // Check for memory leaks
        bool has_leaks = !check_memory_leaks();
        
        // Update counters
        switch (test->status) {
            case TEST_STATUS_PASS:
                if (has_leaks) {
                    test->status = TEST_STATUS_FAIL;
                    g_test_state.fail_count++;
                    printf("FAIL (Memory Leak)\n");
                } else {
                    g_test_state.pass_count++;
                    printf("PASS (%ums)\n", test->execution_time);
                }
                break;
                
            case TEST_STATUS_FAIL:
                g_test_state.fail_count++;
                printf("FAIL (%ums)\n", test->execution_time);
                break;
                
            case TEST_STATUS_SKIP:
                g_test_state.skip_count++;
                printf("SKIP\n");
                break;
        }
        
        if (g_test_state.verbose_output && test->output[0] != '\0') {
            printf("  Output: %s\n", test->output);
        }
    }
    
    // Print summary
    print_test_summary();
    
    return g_test_state.fail_count == 0;
}

/**
 * Run benchmarks for performance-critical operations
 */
void run_benchmarks(void) {
    printf("\n┌───────────────────────────────────────────┐\n");
    printf("│           Performance Benchmarks           │\n");
    printf("└───────────────────────────────────────────┘\n\n");
    
    // Benchmark: SHA-256
    printf("Benchmarking SHA-256... ");
    fflush(stdout);
    
    uint8_t data[1024];
    uint8_t hash[32];
    DWORD start_time, end_time;
    
    // Initialize test data
    for (int i = 0; i < sizeof(data); i++) {
        data[i] = (uint8_t)i;
    }
    
    // Warm-up
    lacky_sha256(data, sizeof(data), hash);
    
    // Benchmark
    start_time = GetTickCount();
    for (int i = 0; i < BENCHMARK_ITERATIONS; i++) {
        data[0] = (uint8_t)i; // Change input slightly
        lacky_sha256(data, sizeof(data), hash);
    }
    end_time = GetTickCount();
    
    double ops_per_sec = BENCHMARK_ITERATIONS * 1000.0 / (end_time - start_time);
    printf("%.2f ops/sec\n", ops_per_sec);
    
    // Benchmark: AES-256
    printf("Benchmarking AES-256... ");
    fflush(stdout);
    
    uint8_t key[32];
    uint8_t iv[16];
    uint8_t ciphertext[1024];
    
    // Initialize key and IV
    for (int i = 0; i < sizeof(key); i++) {
        key[i] = (uint8_t)(i * 2);
    }
    for (int i = 0; i < sizeof(iv); i++) {
        iv[i] = (uint8_t)(i * 3);
    }
    
    // Warm-up
    lacky_aes256_encrypt_cbc(key, iv, data, sizeof(data), ciphertext);
    
    // Benchmark
    start_time = GetTickCount();
    for (int i = 0; i < BENCHMARK_ITERATIONS; i++) {
        data[0] = (uint8_t)i; // Change input slightly
        lacky_aes256_encrypt_cbc(key, iv, data, sizeof(data), ciphertext);
    }
    end_time = GetTickCount();
    
    ops_per_sec = BENCHMARK_ITERATIONS * 1000.0 / (end_time - start_time);
    printf("%.2f ops/sec\n", ops_per_sec);
    
    // Additional benchmarks would be added here
}

/**
 * Memory leak detection functions
 */
static void* test_malloc(size_t size) {
    if (!g_test_state.track_memory) {
        return malloc(size);
    }
    
    // Allocate extra space for header and footer
    size_t total_size = size + sizeof(mem_header_t) + sizeof(uint32_t);
    uint8_t* mem = (uint8_t*)malloc(total_size);
    if (!mem) return NULL;
    
    // Set up header
    mem_header_t* header = (mem_header_t*)mem;
    header->magic = MEM_MAGIC_HEADER;
    header->size = size;
    strncpy(header->location, g_test_state.current_test, TEST_NAME_MAX_LEN - 1);
    header->location[TEST_NAME_MAX_LEN - 1] = '\0';
    
    // Set up footer
    uint32_t* footer = (uint32_t*)(mem + sizeof(mem_header_t) + size);
    *footer = MEM_MAGIC_FOOTER;
    
    // Record allocation
    if (g_test_state.alloc_count < MEM_TRACK_MAX_ALLOCS) {
        mem_alloc_info_t* info = &g_test_state.allocations[g_test_state.alloc_count++];
        info->ptr = mem + sizeof(mem_header_t);
        info->size = size;
        strncpy(info->location, g_test_state.current_test, TEST_NAME_MAX_LEN - 1);
        info->location[TEST_NAME_MAX_LEN - 1] = '\0';
        info->freed = false;
    }
    
    return mem + sizeof(mem_header_t);
}

static void test_free(void* ptr) {
    if (!ptr) return;
    if (!g_test_state.track_memory) {
        free(ptr);
        return;
    }
    
    // Get the real beginning of the allocation
    uint8_t* real_ptr = (uint8_t*)ptr - sizeof(mem_header_t);
    
    // Verify header
    mem_header_t* header = (mem_header_t*)real_ptr;
    if (header->magic != MEM_MAGIC_HEADER) {
        printf("ERROR: Memory corruption detected in header for allocation in %s\n", 
               g_test_state.current_test);
        return;
    }
    
    // Verify footer
    uint32_t* footer = (uint32_t*)(real_ptr + sizeof(mem_header_t) + header->size);
    if (*footer != MEM_MAGIC_FOOTER) {
        printf("ERROR: Memory corruption detected in footer for allocation in %s\n", 
               header->location);
        return;
    }
    
    // Mark as freed in our tracking
    for (uint32_t i = 0; i < g_test_state.alloc_count; i++) {
        if (g_test_state.allocations[i].ptr == ptr) {
            g_test_state.allocations[i].freed = true;
            break;
        }
    }
    
    // Zero memory before freeing
    memset(real_ptr, 0, sizeof(mem_header_t) + header->size + sizeof(uint32_t));
    
    // Actually free
    free(real_ptr);
}

/**
 * Start memory tracking for a test
 */
static void start_memory_tracking(void) {
    g_test_state.track_memory = true;
    g_test_state.alloc_count = 0;
    
    for (uint32_t i = 0; i < MEM_TRACK_MAX_ALLOCS; i++) {
        g_test_state.allocations[i].ptr = NULL;
        g_test_state.allocations[i].size = 0;
        g_test_state.allocations[i].location[0] = '\0';
        g_test_state.allocations[i].freed = true;
    }
}

/**
 * Check for memory leaks after a test
 */
static bool check_memory_leaks(void) {
    g_test_state.track_memory = false;
    
    bool all_freed = true;
    
    for (uint32_t i = 0; i < g_test_state.alloc_count; i++) {
        if (!g_test_state.allocations[i].freed && g_test_state.allocations[i].ptr != NULL) {
            all_freed = false;
            
            if (g_test_state.verbose_output) {
                printf("\nMEMORY LEAK: %zu bytes allocated in %s not freed\n",
                       g_test_state.allocations[i].size,
                       g_test_state.allocations[i].location);
            }
        }
    }
    
    return all_freed;
}

/**
 * Print test summary
 */
static void print_test_summary(void) {
    printf("\n┌───────────────────────────────────────────┐\n");
    printf("│               Test Summary                │\n");
    printf("├───────────────────────────────────────────┤\n");
    printf("│ Total Tests: %-29u │\n", g_test_state.test_count);
    printf("│ Passed:      %-29u │\n", g_test_state.pass_count);
    printf("│ Failed:      %-29u │\n", g_test_state.fail_count);
    printf("│ Skipped:     %-29u │\n", g_test_state.skip_count);
    printf("└───────────────────────────────────────────┘\n\n");
}

/**
 * Example unit test for SHA-256
 */
test_status_t test_sha256(void) {
    const uint8_t input[] = "abc";
    const uint8_t expected[] = {
        0xba, 0x78, 0x16, 0xbf, 0x8f, 0x01, 0xcf, 0xea,
        0x41, 0x41, 0x40, 0xde, 0x5d, 0xae, 0x22, 0x23,
        0xb0, 0x03, 0x61, 0xa3, 0x96, 0x17, 0x7a, 0x9c,
        0xb4, 0x10, 0xff, 0x61, 0xf2, 0x00, 0x15, 0xad
    };
    
    uint8_t output[32];
    lacky_sha256(input, 3, output);
    
    if (memcmp(output, expected, 32) != 0) {
        return TEST_STATUS_FAIL;
    }
    
    return TEST_STATUS_PASS;
}

/**
 * Example unit test for AES-256
 */
test_status_t test_aes256(void) {
    const uint8_t key[32] = {
        0x60, 0x3d, 0xeb, 0x10, 0x15, 0xca, 0x71, 0xbe,
        0x2b, 0x73, 0xae, 0xf0, 0x85, 0x7d, 0x77, 0x81,
        0x1f, 0x35, 0x2c, 0x07, 0x3b, 0x61, 0x08, 0xd7,
        0x2d, 0x98, 0x10, 0xa3, 0x09, 0x14, 0xdf, 0xf4
    };
    
    const uint8_t iv[16] = {
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
        0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f
    };
    
    const uint8_t plaintext[] = "The quick brown fox jumps over the lazy dog";
    const size_t plaintext_len = 43;
    
    uint8_t ciphertext[64];
    uint8_t decrypted[64];
    
    // Encrypt
    lacky_aes256_encrypt_cbc(key, iv, plaintext, plaintext_len, ciphertext);
    
    // Decrypt
    lacky_aes256_decrypt_cbc(key, iv, ciphertext, plaintext_len, decrypted);
    
    // Verify decryption matches original
    if (memcmp(plaintext, decrypted, plaintext_len) != 0) {
        return TEST_STATUS_FAIL;
    }
    
    return TEST_STATUS_PASS;
}

/**
 * Stress test for concurrent cryptographic operations
 */
test_status_t test_crypto_stress(void) {
    HANDLE threads[STRESS_TEST_THREADS];
    DWORD thread_ids[STRESS_TEST_THREADS];
    
    // Create multiple threads performing crypto operations
    for (int i = 0; i < STRESS_TEST_THREADS; i++) {
        threads[i] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)test_sha256, NULL, 0, &thread_ids[i]);
        if (!threads[i]) {
            return TEST_STATUS_FAIL;
        }
    }
    
    // Wait for all threads
    WaitForMultipleObjects(STRESS_TEST_THREADS, threads, TRUE, STRESS_TEST_DURATION);
    
    // Clean up
    for (int i = 0; i < STRESS_TEST_THREADS; i++) {
        if (threads[i]) {
            CloseHandle(threads[i]);
        }
    }
    
    return TEST_STATUS_PASS;
}

/**
 * Test for memory usage and limits
 */
test_status_t test_memory_limits(void) {
    // Allocate increasingly large buffers until failure
    size_t allocation_size = 1024;
    size_t total_allocated = 0;
    void* allocations[100] = {NULL};
    int count = 0;
    
    while (count < 100) {
        void* ptr = test_malloc(allocation_size);
        if (!ptr) break;
        
        allocations[count++] = ptr;
        total_allocated += allocation_size;
        allocation_size *= 2;
    }
    
    // Free all allocations
    for (int i = 0; i < count; i++) {
        if (allocations[i]) {
            test_free(allocations[i]);
        }
    }
    
    // Make sure we could allocate at least a reasonable amount
    if (total_allocated < 1024 * 1024) {
        return TEST_STATUS_FAIL;
    }
    
    return TEST_STATUS_PASS;
}

/**
 * Main entry point for test framework
 */
int main(int argc, char** argv) {
    bool verbose = false;
    bool run_benchmark = false;
    
    // Parse command line arguments
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--verbose") == 0 || strcmp(argv[i], "-v") == 0) {
            verbose = true;
        } else if (strcmp(argv[i], "--benchmark") == 0 || strcmp(argv[i], "-b") == 0) {
            run_benchmark = true;
        }
    }
    
    // Initialize framework
    test_framework_init(verbose);
    
    // Register tests
    register_test("SHA-256 Implementation", test_sha256);
    register_test("AES-256 CBC Mode", test_aes256);
    register_test("Crypto Stress Test", test_crypto_stress);
    register_test("Memory Limits Test", test_memory_limits);
    
    // Run tests
    bool all_passed = run_all_tests();
    
    // Run benchmarks if requested
    if (run_benchmark) {
        run_benchmarks();
    }
    
    return all_passed ? 0 : 1;
} 