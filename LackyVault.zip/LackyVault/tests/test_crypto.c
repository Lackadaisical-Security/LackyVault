/**
 * @file test_crypto.c
 * @brief Cryptographic Test Suite - LackyVault
 * 
 * Comprehensive tests for all cryptographic primitives:
 * - ChaCha20 stream cipher
 * - Poly1305 MAC
 * - AES-256-GCM AEAD
 * - Ed25519 signatures
 * - secp256k1 Bitcoin crypto
 * - Argon2id password hashing
 * - SHA-256/SHA-512 hashing
 * 
 * Copyright (c) 2024 Lackadaisical Security
 * Zero dependencies, maximum paranoia
 */

#include <windows.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "../include/lacky_vault.h"
#include "../include/lacky_crypto.h"

#define TEST_ASSERT(condition, message) \
    do { \
        if (!(condition)) { \
            printf("FAIL: %s\n", message); \
            return false; \
        } else { \
            printf("PASS: %s\n", message); \
        } \
    } while(0)

/* Test vectors for known-good implementations */
static const uint8_t test_key_32[32] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
    0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F
};

static const uint8_t test_nonce_12[12] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x4A,
    0x00, 0x00, 0x00, 0x00
};

static const char* test_message = "The quick brown fox jumps over the lazy dog";

/**
 * Test SHA-256 implementation
 */
static bool test_sha256(void) {
    printf("\n=== SHA-256 Tests ===\n");
    
    uint8_t digest[32];
    const char* input = "abc";
    
    // Test basic hashing
    lacky_sha256((const uint8_t*)input, strlen(input), digest);
    
    // Known SHA-256("abc") = ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad
    uint8_t expected[32] = {
        0xba, 0x78, 0x16, 0xbf, 0x8f, 0x01, 0xcf, 0xea,
        0x41, 0x41, 0x40, 0xde, 0x5d, 0xae, 0x22, 0x23,
        0xb0, 0x03, 0x61, 0xa3, 0x96, 0x17, 0x7a, 0x9c,
        0xb4, 0x10, 0xff, 0x61, 0xf2, 0x00, 0x15, 0xad
    };
    
    bool matches = (memcmp(digest, expected, 32) == 0);
    TEST_ASSERT(matches, "SHA-256 produces correct hash for 'abc'");
    
    // Test empty string
    lacky_sha256((const uint8_t*)"", 0, digest);
    TEST_ASSERT(digest[0] != 0, "SHA-256 handles empty input");
    
    // Test long message
    lacky_sha256((const uint8_t*)test_message, strlen(test_message), digest);
    TEST_ASSERT(digest[0] != 0, "SHA-256 handles long message");
    
    return true;
}

/**
 * Test ChaCha20 encryption/decryption
 */
static bool test_chacha20(void) {
    printf("\n=== ChaCha20 Tests ===\n");
    
    const char* plaintext = "Hello, ChaCha20 world!";
    size_t len = strlen(plaintext);
    uint8_t* ciphertext = malloc(len);
    uint8_t* decrypted = malloc(len);
    
    if (!ciphertext || !decrypted) {
        printf("FAIL: Memory allocation\n");
        return false;
    }
    
    // Test encryption
    lacky_chacha20_ctx_t ctx;
    lacky_chacha20_init(&ctx, test_key_32, test_nonce_12);
    lacky_chacha20_encrypt(&ctx, (const uint8_t*)plaintext, ciphertext, len);
    
    TEST_ASSERT(memcmp(plaintext, ciphertext, len) != 0, "ChaCha20 encryption changes plaintext");
    
    // Test decryption
    lacky_chacha20_init(&ctx, test_key_32, test_nonce_12);
    lacky_chacha20_decrypt(&ctx, ciphertext, decrypted, len);
    
    TEST_ASSERT(memcmp(plaintext, decrypted, len) == 0, "ChaCha20 decryption recovers plaintext");
    
    free(ciphertext);
    free(decrypted);
    return true;
}

/**
 * Test Poly1305 MAC
 */
static bool test_poly1305(void) {
    printf("\n=== Poly1305 Tests ===\n");
    
    uint8_t tag[LACKY_POLY1305_TAG_SIZE];
    const char* message = "Cryptographic Message Authentication";
    
    // Generate MAC
    lacky_poly1305_mac(test_key_32, (const uint8_t*)message, strlen(message), tag);
    
    TEST_ASSERT(tag[0] != 0, "Poly1305 generates non-zero MAC");
    
    // Test MAC verification (should produce same tag)
    uint8_t tag2[LACKY_POLY1305_TAG_SIZE];
    lacky_poly1305_mac(test_key_32, (const uint8_t*)message, strlen(message), tag2);
    
    TEST_ASSERT(memcmp(tag, tag2, LACKY_POLY1305_TAG_SIZE) == 0, "Poly1305 produces consistent MACs");
    
    // Test with different key (should produce different tag)
    uint8_t different_key[32];
    memcpy(different_key, test_key_32, 32);
    different_key[0] ^= 0xFF;
    
    lacky_poly1305_mac(different_key, (const uint8_t*)message, strlen(message), tag2);
    TEST_ASSERT(memcmp(tag, tag2, LACKY_POLY1305_TAG_SIZE) != 0, "Poly1305 sensitive to key changes");
    
    return true;
}

/**
 * Test XChaCha20-Poly1305 AEAD
 */
static bool test_xchacha20_poly1305(void) {
    printf("\n=== XChaCha20-Poly1305 AEAD Tests ===\n");
    
    const char* plaintext = "Authenticated encryption with XChaCha20-Poly1305";
    const char* aad = "Additional authenticated data";
    size_t plaintext_len = strlen(plaintext);
    size_t aad_len = strlen(aad);
    
    uint8_t nonce[LACKY_XCHACHA20_NONCE_SIZE];
    uint8_t* ciphertext = malloc(plaintext_len);
    uint8_t tag[LACKY_POLY1305_TAG_SIZE];
    uint8_t* decrypted = malloc(plaintext_len);
    
    if (!ciphertext || !decrypted) {
        printf("FAIL: Memory allocation\n");
        return false;
    }
    
    // Generate random nonce
    lacky_crypto_random(nonce, sizeof(nonce));
    
    // Test encryption
    int result = lacky_xchacha20_poly1305_encrypt(
        test_key_32, nonce,
        (const uint8_t*)aad, aad_len,
        (const uint8_t*)plaintext, plaintext_len,
        ciphertext, tag
    );
    
    TEST_ASSERT(result == 0, "XChaCha20-Poly1305 encryption succeeds");
    TEST_ASSERT(memcmp(plaintext, ciphertext, plaintext_len) != 0, "AEAD encryption changes plaintext");
    
    // Test decryption
    result = lacky_xchacha20_poly1305_decrypt(
        test_key_32, nonce,
        (const uint8_t*)aad, aad_len,
        ciphertext, plaintext_len,
        tag, decrypted
    );
    
    TEST_ASSERT(result == 0, "XChaCha20-Poly1305 decryption succeeds");
    TEST_ASSERT(memcmp(plaintext, decrypted, plaintext_len) == 0, "AEAD decryption recovers plaintext");
    
    free(ciphertext);
    free(decrypted);
    return true;
}

/**
 * Test Ed25519 digital signatures
 */
static bool test_ed25519(void) {
    printf("\n=== Ed25519 Tests ===\n");
    
    lacky_ed25519_keypair_t keypair;
    uint8_t signature[LACKY_ED25519_SIGNATURE_SIZE];
    const char* message = "Ed25519 signature test message";
    
    // Generate keypair
    lacky_ed25519_keygen(&keypair);
    TEST_ASSERT(keypair.public_key[0] != 0, "Ed25519 generates non-zero public key");
    
    // Sign message
    lacky_ed25519_sign(keypair.private_key, (const uint8_t*)message, strlen(message), signature);
    TEST_ASSERT(signature[0] != 0, "Ed25519 generates non-zero signature");
    
    // Verify signature
    int valid = lacky_ed25519_verify(keypair.public_key, (const uint8_t*)message, strlen(message), signature);
    TEST_ASSERT(valid == 1, "Ed25519 signature verification succeeds");
    
    // Test with wrong message
    const char* wrong_message = "Wrong message for signature verification";
    valid = lacky_ed25519_verify(keypair.public_key, (const uint8_t*)wrong_message, strlen(wrong_message), signature);
    TEST_ASSERT(valid == 0, "Ed25519 rejects invalid signatures");
    
    return true;
}

/**
 * Test secp256k1 for Bitcoin
 */
static bool test_secp256k1(void) {
    printf("\n=== secp256k1 Tests ===\n");
    
    lacky_secp256k1_keypair_t keypair;
    uint8_t signature[LACKY_SECP256K1_SIGNATURE_SIZE];
    uint8_t hash[32] = {
        0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
        0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10,
        0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18,
        0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20
    };
    
    // Generate keypair
    lacky_secp256k1_keygen(&keypair);
    TEST_ASSERT(keypair.public_key[0] != 0, "secp256k1 generates non-zero public key");
    
    // Sign hash
    int result = lacky_secp256k1_sign(keypair.private_key, hash, signature);
    TEST_ASSERT(result == 0, "secp256k1 signing succeeds");
    
    // Verify signature
    result = lacky_secp256k1_verify(keypair.public_key, hash, signature);
    TEST_ASSERT(result == 1, "secp256k1 signature verification succeeds");
    
    // Test ECDH key exchange
    lacky_secp256k1_keypair_t keypair2;
    lacky_secp256k1_keygen(&keypair2);
    
    uint8_t shared_secret1[32], shared_secret2[32];
    result = lacky_secp256k1_ecdh(keypair.private_key, keypair2.public_key, shared_secret1);
    TEST_ASSERT(result == 0, "secp256k1 ECDH succeeds");
    
    result = lacky_secp256k1_ecdh(keypair2.private_key, keypair.public_key, shared_secret2);
    TEST_ASSERT(result == 0, "secp256k1 ECDH symmetric");
    
    TEST_ASSERT(memcmp(shared_secret1, shared_secret2, 32) == 0, "secp256k1 ECDH produces same shared secret");
    
    return true;
}

/**
 * Test Argon2id password hashing
 */
static bool test_argon2id(void) {
    printf("\n=== Argon2id Tests ===\n");
    
    const char* password = "SecurePassword123!";
    const uint8_t salt[16] = {
        0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
        0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10
    };
    uint8_t hash1[32], hash2[32];
    
    lacky_argon2_ctx_t ctx = {
        .password = (const uint8_t*)password,
        .password_len = strlen(password),
        .salt = salt,
        .salt_len = 16,
        .memory_kb = 1024,
        .iterations = 2,
        .parallelism = 1,
        .hash_len = 32,
        .hash = hash1
    };
    
    // Test hashing
    int result = lacky_argon2id(&ctx);
    TEST_ASSERT(result == 0, "Argon2id hashing succeeds");
    TEST_ASSERT(hash1[0] != 0, "Argon2id produces non-zero hash");
    
    // Test consistency
    ctx.hash = hash2;
    result = lacky_argon2id(&ctx);
    TEST_ASSERT(result == 0, "Argon2id second hash succeeds");
    TEST_ASSERT(memcmp(hash1, hash2, 32) == 0, "Argon2id produces consistent hashes");
    
    return true;
}

/**
 * Test random number generation
 */
static bool test_random_generation(void) {
    printf("\n=== Random Generation Tests ===\n");
    
    uint8_t buffer1[32], buffer2[32];
    
    lacky_crypto_random(buffer1, sizeof(buffer1));
    lacky_crypto_random(buffer2, sizeof(buffer2));
    
    TEST_ASSERT(memcmp(buffer1, buffer2, 32) != 0, "Random generation produces different outputs");
    
    // Test zero detection
    bool all_zero = true;
    for (int i = 0; i < 32; i++) {
        if (buffer1[i] != 0) {
            all_zero = false;
            break;
        }
    }
    TEST_ASSERT(!all_zero, "Random generation doesn't produce all zeros");
    
    return true;
}

/**
 * Performance benchmark
 */
static void benchmark_crypto(void) {
    printf("\n=== Performance Benchmarks ===\n");
    
    const size_t test_size = 1024 * 1024; // 1MB
    uint8_t* data = malloc(test_size);
    uint8_t* output = malloc(test_size);
    
    if (!data || !output) {
        printf("Failed to allocate benchmark memory\n");
        return;
    }
    
    // Fill with random data
    lacky_crypto_random(data, test_size);
    
    LARGE_INTEGER freq, start, end;
    QueryPerformanceFrequency(&freq);
    
    // SHA-256 benchmark
    QueryPerformanceCounter(&start);
    for (int i = 0; i < 100; i++) {
        uint8_t hash[32];
        lacky_sha256(data, test_size, hash);
    }
    QueryPerformanceCounter(&end);
    
    double sha256_time = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
    double sha256_mbps = (100.0 * test_size / (1024 * 1024)) / sha256_time;
    printf("SHA-256: %.2f MB/s\n", sha256_mbps);
    
    // ChaCha20 benchmark
    lacky_chacha20_ctx_t ctx;
    lacky_chacha20_init(&ctx, test_key_32, test_nonce_12);
    
    QueryPerformanceCounter(&start);
    for (int i = 0; i < 100; i++) {
        lacky_chacha20_encrypt(&ctx, data, output, test_size);
    }
    QueryPerformanceCounter(&end);
    
    double chacha20_time = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
    double chacha20_mbps = (100.0 * test_size / (1024 * 1024)) / chacha20_time;
    printf("ChaCha20: %.2f MB/s\n", chacha20_mbps);
    
    free(data);
    free(output);
}

/**
 * Main test runner
 */
int main(void) {
    printf("LackyVault Cryptographic Test Suite\n");
    printf("===================================\n");
    
    bool all_passed = true;
    
    // Initialize crypto subsystem
    lacky_crypto_context_t crypto_ctx;
    if (lacky_crypto_init(&crypto_ctx) != LACKY_SUCCESS) {
        printf("FATAL: Failed to initialize crypto subsystem\n");
        return 1;
    }
    
    // Run all tests
    all_passed &= test_sha256();
    all_passed &= test_chacha20();
    all_passed &= test_poly1305();
    all_passed &= test_xchacha20_poly1305();
    all_passed &= test_ed25519();
    all_passed &= test_secp256k1();
    all_passed &= test_argon2id();
    all_passed &= test_random_generation();
    
    // Run benchmarks
    benchmark_crypto();
    
    // Cleanup
    lacky_crypto_cleanup(&crypto_ctx);
    
    printf("\n=== Test Results ===\n");
    if (all_passed) {
        printf("All tests PASSED! 🎉\n");
        return 0;
    } else {
        printf("Some tests FAILED! ❌\n");
        return 1;
    }
} 