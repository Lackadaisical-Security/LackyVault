# =====================================================
# LackyVault Production Build System
# Complete Windows build without GNU Make dependency
# Supports: NASM + MinGW-w64 + WiX Toolset
# =====================================================

param(
    [ValidateSet("debug", "release", "test", "installer", "package", "clean", "help")]
    [string]$Target = "release",
    [switch]$Force = $false,
    [switch]$Verbose = $false,
    [switch]$InstallDeps = $false
)

# =====================================================
# CONFIGURATION
# =====================================================

$ProjectName = "LackyVault"
$Version = "2.0.0"
$BuildDir = "build"
$SrcDir = "src"
$IncludeDir = "include"
$OutputDir = "output"
$InstallerDir = "installer"

# Tool paths - will be auto-detected
$Tools = @{
    NASM = ""
    GCC = ""
    Windres = ""
    Candle = ""
    Light = ""
}

# Compiler flags
$NasmFlags = "-f win64 -g -F dwarf"
$GccFlags = "-std=c11 -Wall -Wextra -I$IncludeDir -DUNICODE -D_UNICODE -DWIN32_LEAN_AND_MEAN -D_WIN32_WINNT=0x0601"
$DebugFlags = "-g -O0 -DDEBUG -DLACKY_DEBUG_ENABLED"
$ReleaseFlags = "-O2 -DNDEBUG -ffunction-sections -fdata-sections"
$LinkerFlags = "-static-libgcc -static-libstdc++ -Wl,--subsystem,windows -Wl,--gc-sections"
$Libraries = "-luser32 -lkernel32 -lgdi32 -lcomctl32 -lcomdlg32 -ladvapi32 -lshell32 -lole32 -loleaut32 -luuid -lwininet -lws2_32 -lcrypt32 -lbcrypt"

# =====================================================
# UTILITY FUNCTIONS
# =====================================================

function Write-Banner {
    param([string]$Message)
    
    Write-Host ""
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host "  $Message" -ForegroundColor Yellow
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host ""
}

function Write-Step {
    param([string]$Message)
    Write-Host "[STEP] $Message" -ForegroundColor Green
}

function Write-Info {
    param([string]$Message)
    Write-Host "[INFO] $Message" -ForegroundColor White
}

function Write-Warning {
    param([string]$Message)
    Write-Host "[WARN] $Message" -ForegroundColor Yellow
}

function Write-Error-Custom {
    param([string]$Message)
    Write-Host "[ERROR] $Message" -ForegroundColor Red
}

function Write-Success {
    param([string]$Message)
    Write-Host "[SUCCESS] $Message" -ForegroundColor Green
}

# =====================================================
# TOOL DETECTION
# =====================================================

function Find-Tools {
    Write-Step "Detecting build tools..."
    
    # NASM Detection
    $nasmPaths = @(
        "nasm.exe",
        "C:\Program Files\NASM\nasm.exe",
        "C:\nasm\nasm.exe"
    )
    
    foreach ($path in $nasmPaths) {
        try {
            $result = Get-Command $path -ErrorAction SilentlyContinue
            if ($result) {
                $Tools.NASM = $result.Source
                Write-Info "✓ NASM found: $($Tools.NASM)"
                break
            }
        } catch { }
    }
    
    # GCC Detection
    $gccPaths = @(
        "gcc.exe",
        "C:\mingw-w64\x86_64-8.1.0-win32-seh-rt_v6-rev0\mingw64\bin\gcc.exe",
        "C:\msys64\mingw64\bin\gcc.exe",
        "C:\MinGW\bin\gcc.exe"
    )
    
    foreach ($path in $gccPaths) {
        try {
            $result = Get-Command $path -ErrorAction SilentlyContinue
            if ($result) {
                $Tools.GCC = $result.Source
                Write-Info "✓ GCC found: $($Tools.GCC)"
                
                # Also find windres in the same directory
                $windresPath = Join-Path (Split-Path $Tools.GCC) "windres.exe"
                if (Test-Path $windresPath) {
                    $Tools.Windres = $windresPath
                    Write-Info "✓ Windres found: $($Tools.Windres)"
                }
                break
            }
        } catch { }
    }
    
    # WiX Detection
    $wixPaths = @(
        "C:\Program Files (x86)\WiX Toolset v3.14\bin",
        "C:\Program Files (x86)\WiX Toolset v3.11\bin",
        "C:\WiX\bin"
    )
    
    foreach ($path in $wixPaths) {
        $candlePath = Join-Path $path "candle.exe"
        $lightPath = Join-Path $path "light.exe"
        
        if ((Test-Path $candlePath) -and (Test-Path $lightPath)) {
            $Tools.Candle = $candlePath
            $Tools.Light = $lightPath
            Write-Info "✓ WiX Toolset found: $path"
            break
        }
    }
    
    # Check required tools
    $missing = @()
    if (-not $Tools.NASM) { $missing += "NASM" }
    if (-not $Tools.GCC) { $missing += "GCC/MinGW-w64" }
    
    if ($missing.Count -gt 0) {
        Write-Warning "Missing required tools: $($missing -join ', ')"
        if ($InstallDeps) {
            Install-Dependencies
        } else {
            Write-Info "Run with -InstallDeps to automatically install missing tools"
            return $false
        }
    }
    
    return $true
}

# =====================================================
# DEPENDENCY INSTALLATION
# =====================================================

function Install-Dependencies {
    Write-Banner "Installing Build Dependencies"
    
    if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
        Write-Warning "Administrator privileges required for dependency installation"
        Write-Info "Requesting elevation..."
        
        $arguments = "-ExecutionPolicy Bypass -File `"$PSCommandPath`" -Target $Target -InstallDeps"
        Start-Process powershell -ArgumentList $arguments -Verb RunAs
        exit
    }
    
    Write-Step "Installing dependencies via winget..."
    
    try {
        Write-Info "Installing NASM..."
        winget install NASM.NASM --accept-package-agreements --accept-source-agreements
        
        Write-Info "Installing MSYS2 (for MinGW-w64)..."
        winget install msys2.msys2 --accept-package-agreements --accept-source-agreements
        
        Write-Info "Installing WiX Toolset..."
        winget install WiXToolset.WiX --accept-package-agreements --accept-source-agreements
        
        Write-Success "Dependencies installed successfully!"
        Write-Info "Please restart your terminal and run the following in MSYS2:"
        Write-Host "  pacman -S mingw-w64-x86_64-gcc mingw-w64-x86_64-make" -ForegroundColor Yellow
        Write-Host ""
        Write-Info "Then add these to your PATH:"
        Write-Host "  C:\Program Files\NASM" -ForegroundColor Yellow
        Write-Host "  C:\msys64\mingw64\bin" -ForegroundColor Yellow
        Write-Host "  C:\Program Files (x86)\WiX Toolset v3.11\bin" -ForegroundColor Yellow
        
    } catch {
        Write-Error-Custom "Failed to install dependencies: $($_.Exception.Message)"
    }
}

# =====================================================
# DIRECTORY MANAGEMENT
# =====================================================

function Initialize-Directories {
    Write-Step "Creating build directories..."
    
    $dirs = @(
        $BuildDir,
        "$BuildDir\obj",
        "$BuildDir\obj\core",
        "$BuildDir\obj\ui", 
        "$BuildDir\obj\crypto",
        "$BuildDir\obj\network",
        "$BuildDir\obj\storage",
        "$BuildDir\obj\blockchain",
        "$BuildDir\obj\security",
        "$BuildDir\obj\asm",
        "$BuildDir\resources",
        $OutputDir
    )
    
    foreach ($dir in $dirs) {
        if (-not (Test-Path $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
            if ($Verbose) { Write-Info "Created directory: $dir" }
        }
    }
}

function Clean-Build {
    Write-Step "Cleaning build artifacts..."
    
    if (Test-Path $BuildDir) {
        Remove-Item -Path $BuildDir -Recurse -Force
        Write-Info "Removed build directory"
    }
    
    if (Test-Path $OutputDir) {
        Remove-Item -Path $OutputDir -Recurse -Force  
        Write-Info "Removed output directory"
    }
    
    # Clean WiX artifacts
    Get-ChildItem -Path $InstallerDir -Filter "*.wixobj" -ErrorAction SilentlyContinue | Remove-Item -Force
    Get-ChildItem -Path $InstallerDir -Filter "*.wixpdb" -ErrorAction SilentlyContinue | Remove-Item -Force
}

# =====================================================
# COMPILATION FUNCTIONS
# =====================================================

function Compile-Assembly {
    Write-Step "Compiling assembly files..."
    
    $asmFiles = Get-ChildItem -Path "$SrcDir\asm" -Filter "*.asm" -Recurse
    $compiled = 0
    $failed = 0
    
    foreach ($file in $asmFiles) {
        $objFile = "$BuildDir\obj\asm\$($file.BaseName).obj"
        
        if ($Verbose) { Write-Info "Assembling $($file.Name)..." }
        
        $arguments = "$NasmFlags -o `"$objFile`" `"$($file.FullName)`""
        
        try {
            $process = Start-Process -FilePath $Tools.NASM -ArgumentList $arguments -Wait -PassThru -NoNewWindow -RedirectStandardError "$BuildDir\nasm_error.log"
            
            if ($process.ExitCode -eq 0) {
                $compiled++
                if ($Verbose) { Write-Info "✓ $($file.Name)" }
            } else {
                $failed++
                Write-Warning "✗ Failed to assemble $($file.Name)"
                if (Test-Path "$BuildDir\nasm_error.log") {
                    $errorContent = Get-Content "$BuildDir\nasm_error.log" -Raw
                    if ($errorContent.Trim()) {
                        Write-Info "Error details: $errorContent"
                    }
                }
            }
        } catch {
            $failed++
            Write-Warning "✗ Exception assembling $($file.Name): $($_.Exception.Message)"
        }
    }
    
    Write-Info "Assembly compilation: $compiled compiled, $failed failed"
    return $failed -eq 0
}

function Compile-C-Sources {
    param([string]$BuildType)
    
    Write-Step "Compiling C source files ($BuildType)..."
    
    $flags = $GccFlags
    if ($BuildType -eq "debug") {
        $flags += " $DebugFlags"
    } else {
        $flags += " $ReleaseFlags"
    }
    
    # Define source file groups
    $sourceGroups = @{
        "core" = Get-ChildItem -Path "$SrcDir\c\core" -Filter "*.c"
        "ui" = Get-ChildItem -Path "$SrcDir\c\ui" -Filter "*.c"
        "crypto" = Get-ChildItem -Path "$SrcDir\c\crypto" -Filter "*.c"
        "network" = Get-ChildItem -Path "$SrcDir\c\network" -Filter "*.c"
        "storage" = Get-ChildItem -Path "$SrcDir\c\storage" -Filter "*.c"
        "blockchain" = Get-ChildItem -Path "$SrcDir\c\blockchain" -Filter "*.c"
        "security" = Get-ChildItem -Path "$SrcDir\c\security" -Filter "*.c"
    }
    
    $compiled = 0
    $failed = 0
    
    foreach ($group in $sourceGroups.GetEnumerator()) {
        foreach ($file in $group.Value) {
            $objFile = "$BuildDir\obj\$($group.Key)\$($file.BaseName).obj"
            
            if ($Verbose) { Write-Info "Compiling $($group.Key)/$($file.Name)..." }
            
            $arguments = "$flags -c -o `"$objFile`" `"$($file.FullName)`""
            
            try {
                $process = Start-Process -FilePath $Tools.GCC -ArgumentList $arguments -Wait -PassThru -NoNewWindow -RedirectStandardError "$BuildDir\gcc_error.log"
                
                if ($process.ExitCode -eq 0) {
                    $compiled++
                    if ($Verbose) { Write-Info "✓ $($group.Key)/$($file.Name)" }
                } else {
                    $failed++
                    Write-Warning "✗ Failed to compile $($group.Key)/$($file.Name)"
                    if (Test-Path "$BuildDir\gcc_error.log") {
                        $errorContent = Get-Content "$BuildDir\gcc_error.log" -Raw
                        if ($errorContent.Trim()) {
                            Write-Info "Error details: $errorContent"
                        }
                    }
                }
            } catch {
                $failed++
                Write-Warning "✗ Exception compiling $($group.Key)/$($file.Name): $($_.Exception.Message)"
            }
        }
    }
    
    Write-Info "C compilation: $compiled compiled, $failed failed"
    return $failed -eq 0
}

function Compile-Resources {
    Write-Step "Compiling resources..."
    
    $rcFile = "$SrcDir\resources\lacky_vault.rc"
    $resFile = "$BuildDir\resources\lacky_vault.res"
    
    if (-not (Test-Path $rcFile)) {
        Write-Warning "Resource file not found: $rcFile"
        return $true # Not critical
    }
    
    if (-not $Tools.Windres) {
        Write-Warning "Windres not found, skipping resource compilation"
        return $true # Not critical
    }
    
    try {
        $arguments = "-i `"$rcFile`" -o `"$resFile`""
        $process = Start-Process -FilePath $Tools.Windres -ArgumentList $arguments -Wait -PassThru -NoNewWindow
        
        if ($process.ExitCode -eq 0) {
            Write-Info "✓ Resources compiled successfully"
            return $true
        } else {
            Write-Warning "✗ Resource compilation failed"
            return $false
        }
    } catch {
        Write-Warning "✗ Exception compiling resources: $($_.Exception.Message)"
        return $false
    }
}

function Link-Executable {
    param([string]$BuildType)
    
    Write-Step "Linking executable ($BuildType)..."
    
    $exeName = if ($BuildType -eq "debug") { "$ProjectName-debug.exe" } else { "$ProjectName.exe" }
    $exePath = "$BuildDir\$exeName"
    
    # Collect all object files
    $objFiles = @()
    $objFiles += Get-ChildItem -Path "$BuildDir\obj" -Filter "*.obj" -Recurse | ForEach-Object { "`"$($_.FullName)`"" }
    
    # Add resource file if it exists
    $resFile = "$BuildDir\resources\lacky_vault.res"
    if (Test-Path $resFile) {
        $objFiles += "`"$resFile`""
    }
    
    if ($objFiles.Count -eq 0) {
        Write-Error-Custom "No object files found for linking"
        return $false
    }
    
    $arguments = "$LinkerFlags -o `"$exePath`" $($objFiles -join ' ') $Libraries"
    
    try {
        $process = Start-Process -FilePath $Tools.GCC -ArgumentList $arguments -Wait -PassThru -NoNewWindow -RedirectStandardError "$BuildDir\link_error.log"
        
        if ($process.ExitCode -eq 0) {
            Write-Success "✓ Executable linked successfully: $exePath"
            
            # Copy to output directory
            if (-not (Test-Path $OutputDir)) {
                New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
            }
            Copy-Item -Path $exePath -Destination "$OutputDir\$exeName" -Force
            
            # Show file info
            $fileInfo = Get-Item $exePath
            Write-Info "File size: $([math]::Round($fileInfo.Length / 1KB, 2)) KB"
            
            return $true
        } else {
            Write-Error-Custom "✗ Linking failed"
            if (Test-Path "$BuildDir\link_error.log") {
                $errorContent = Get-Content "$BuildDir\link_error.log" -Raw
                if ($errorContent.Trim()) {
                    Write-Info "Error details: $errorContent"
                }
            }
            return $false
        }
    } catch {
        Write-Error-Custom "✗ Exception during linking: $($_.Exception.Message)"
        return $false
    }
}

# =====================================================
# MSI INSTALLER CREATION
# =====================================================

function Build-Installer {
    Write-Step "Building MSI installer..."
    
    if (-not $Tools.Candle -or -not $Tools.Light) {
        Write-Warning "WiX Toolset not found, cannot build installer"
        return $false
    }
    
    $exePath = "$OutputDir\$ProjectName.exe"
    if (-not (Test-Path $exePath)) {
        Write-Warning "Release executable not found, building it first..."
        if (-not (Build-Project "release")) {
            return $false
        }
    }
    
    # Update WiX file with correct paths
    $wxsFile = "$InstallerDir\LackyVault.wxs"
    $wixObjFile = "$InstallerDir\LackyVault.wixobj"
    $msiFile = "$OutputDir\$ProjectName-$Version.msi"
    
    Write-Info "Compiling WiX source..."
    $arguments = "-nologo -ext WixUtilExtension -dBuildDir=`"$OutputDir`" -out `"$wixObjFile`" `"$wxsFile`""
    
    try {
        $process = Start-Process -FilePath $Tools.Candle -ArgumentList $arguments -Wait -PassThru -NoNewWindow
        
        if ($process.ExitCode -ne 0) {
            Write-Error-Custom "WiX compilation failed"
            return $false
        }
        
        Write-Info "Linking MSI..."
        $arguments = "-nologo -ext WixUIExtension -ext WixUtilExtension -out `"$msiFile`" `"$wixObjFile`""
        
        $process = Start-Process -FilePath $Tools.Light -ArgumentList $arguments -Wait -PassThru -NoNewWindow
        
        if ($process.ExitCode -eq 0) {
            Write-Success "✓ MSI installer created: $msiFile"
            
            $fileInfo = Get-Item $msiFile
            Write-Info "MSI size: $([math]::Round($fileInfo.Length / 1KB, 2)) KB"
            
            return $true
        } else {
            Write-Error-Custom "MSI linking failed"
            return $false
        }
    } catch {
        Write-Error-Custom "Exception building installer: $($_.Exception.Message)"
        return $false
    }
}

# =====================================================
# MAIN BUILD FUNCTIONS
# =====================================================

function Build-Project {
    param([string]$BuildType)
    
    Write-Banner "Building $ProjectName v$Version ($BuildType)"
    
    if (-not (Find-Tools)) {
        return $false
    }
    
    Initialize-Directories
    
    # Compile assembly files
    if (-not (Compile-Assembly)) {
        Write-Error-Custom "Assembly compilation failed"
        return $false
    }
    
    # Compile C sources
    if (-not (Compile-C-Sources $BuildType)) {
        Write-Error-Custom "C compilation failed"
        return $false
    }
    
    # Compile resources
    Compile-Resources | Out-Null
    
    # Link executable
    if (-not (Link-Executable $BuildType)) {
        Write-Error-Custom "Linking failed"
        return $false
    }
    
    Write-Success "Build completed successfully!"
    return $true
}

function Build-Test {
    Write-Banner "Building and Running Tests"
    
    # Build debug version first
    if (-not (Build-Project "debug")) {
        return $false
    }
    
    $testExe = "$OutputDir\$ProjectName-debug.exe"
    if (Test-Path $testExe) {
        Write-Step "Running tests..."
        try {
            & $testExe --test
            Write-Success "Tests completed"
        } catch {
            Write-Warning "Test execution failed: $($_.Exception.Message)"
        }
    }
}

function Build-Package {
    Write-Banner "Creating Distribution Package"
    
    # Build release version
    if (-not (Build-Project "release")) {
        return $false
    }
    
    # Build installer
    Build-Installer | Out-Null
    
    # Create package directory
    $packageDir = "$OutputDir\$ProjectName-Complete"
    if (Test-Path $packageDir) {
        Remove-Item -Path $packageDir -Recurse -Force
    }
    New-Item -ItemType Directory -Path $packageDir -Force | Out-Null
    
    # Copy files
    $items = @(
        @{ Source = "$OutputDir\$ProjectName.exe"; Dest = "$packageDir\$ProjectName-Portable.exe" }
        @{ Source = "README.md"; Dest = "$packageDir\README.md" }
        @{ Source = "README-Installation.md"; Dest = "$packageDir\README-Installation.md" }  
        @{ Source = "LICENSE"; Dest = "$packageDir\LICENSE" }
    )
    
    foreach ($item in $items) {
        if (Test-Path $item.Source) {
            Copy-Item -Path $item.Source -Destination $item.Dest -Force
            Write-Info "Copied: $(Split-Path $item.Dest -Leaf)"
        }
    }
    
    # Copy MSI if it exists
    $msiFile = "$OutputDir\$ProjectName-$Version.msi"
    if (Test-Path $msiFile) {
        Copy-Item -Path $msiFile -Destination "$packageDir\$ProjectName.msi" -Force
        Write-Info "Copied: $ProjectName.msi"
    }
    
    # Create installation scripts
    @"
@echo off
echo Installing LackyVault...
msiexec /i LackyVault.msi /quiet
echo Installation complete!
pause
"@ | Out-File -FilePath "$packageDir\Install.bat" -Encoding ASCII
    
    @"
@echo off
echo Uninstalling LackyVault...
wmic product where name="LackyVault - Crypto Wallet" call uninstall /nointeractive
echo Uninstallation complete!
pause
"@ | Out-File -FilePath "$packageDir\Uninstall.bat" -Encoding ASCII
    
    Write-Success "Distribution package created: $packageDir"
}

function Show-Help {
    Write-Banner "$ProjectName Build System v$Version"
    
    Write-Host "Usage: .\build_production.ps1 [options]" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Targets:" -ForegroundColor Cyan
    Write-Host "  release      Build optimized release version (default)" -ForegroundColor Gray
    Write-Host "  debug        Build with debug symbols and logging" -ForegroundColor Gray
    Write-Host "  test         Build and run tests" -ForegroundColor Gray
    Write-Host "  installer    Create MSI installer" -ForegroundColor Gray
    Write-Host "  package      Create complete distribution package" -ForegroundColor Gray
    Write-Host "  clean        Remove all build artifacts" -ForegroundColor Gray
    Write-Host "  help         Show this help message" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Options:" -ForegroundColor Cyan
    Write-Host "  -Force       Force rebuild (clean first)" -ForegroundColor Gray
    Write-Host "  -Verbose     Enable verbose output" -ForegroundColor Gray
    Write-Host "  -InstallDeps Install build dependencies" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Examples:" -ForegroundColor Cyan
    Write-Host "  .\build_production.ps1 debug" -ForegroundColor Yellow
    Write-Host "  .\build_production.ps1 package -Verbose" -ForegroundColor Yellow
    Write-Host "  .\build_production.ps1 -InstallDeps" -ForegroundColor Yellow
}

# =====================================================
# MAIN EXECUTION
# =====================================================

# Handle dependency installation
if ($InstallDeps) {
    Install-Dependencies
    exit
}

# Handle force rebuild
if ($Force -and $Target -ne "clean") {
    Clean-Build
}

# Execute based on target
switch ($Target) {
    "clean" {
        Clean-Build
    }
    "debug" {
        Build-Project "debug"
    }
    "release" {
        Build-Project "release"  
    }
    "test" {
        Build-Test
    }
    "installer" {
        if (-not (Build-Project "release")) {
            exit 1
        }
        Build-Installer
    }
    "package" {
        Build-Package
    }
    "help" {
        Show-Help
    }
    default {
        Build-Project "release"
    }
}

Write-Host ""
Write-Success "Build process completed!" 