/**
 * LackyVault - Cryptographic Primitives Header
 * Lackadaisical Security
 * 
 * Custom crypto implementations in ASM and C
 */

#ifndef LACKY_CRYPTO_H
#define LACKY_CRYPTO_H

#include <stdint.h>
#include <stdbool.h>

/* Error Codes */
typedef enum {
    LACKY_SUCCESS = 0,
    LACKY_ERROR_INVALID_PARAM = -1,
    LACKY_ERROR_OUT_OF_MEMORY = -2,
    LACKY_ERROR_CRYPTO_FAIL = -3,
    LACKY_ERROR_NETWORK_FAIL = -4,
    LACKY_ERROR_AUTH_FAIL = -5,
    LACKY_ERROR_FILE_IO = -6,
    LACKY_ERROR_PANIC_MODE = -7,
    LACKY_ERROR_BUFFER_TOO_SMALL = -8,
    LACKY_ERROR_NETWORK_INIT = -20,
    LACKY_ERROR_NETWORK_OFFLINE = -21,
    LACKY_ERROR_STORAGE_INIT = -22,
    LACKY_ERROR_STORAGE_CREATE = -23,
    LACKY_ERROR_STORAGE_READ = -24,
    LACKY_ERROR_STORAGE_WRITE = -25,
    LACKY_ERROR_STORAGE_DELETE = -26,
    LACKY_ERROR_STORAGE_NOT_FOUND = -27,
    LACKY_ERROR_STORAGE_TOO_LARGE = -28,
    LACKY_ERROR_MEMORY = -29,
    LACKY_ERROR_CRYPTO_INIT = -50,
    LACKY_ERROR_CRYPTO_INVALID_KEY = -51,
    LACKY_ERROR_CRYPTO_INVALID_NONCE = -52,
    LACKY_ERROR_CRYPTO_VERIFY_FAIL = -53,
    LACKY_ERROR_CRYPTO_KDF = -54,
    LACKY_ERROR_CRYPTO_RANDOM = -55,
    LACKY_ERROR_CRYPTO_HASH = -56,
    LACKY_ERROR_NOT_IMPLEMENTED = -100
} lacky_error_t;

/* Crypto Constants */
#define LACKY_CHACHA20_KEY_SIZE 32
#define LACKY_CHACHA20_NONCE_SIZE 12
#define LACKY_XCHACHA20_NONCE_SIZE 24
#define LACKY_POLY1305_KEY_SIZE 32
#define LACKY_POLY1305_TAG_SIZE 16

#define LACKY_AES_KEY_SIZE 32
#define LACKY_AES_BLOCK_SIZE 16
#define LACKY_AES_GCM_IV_SIZE 12
#define LACKY_AES_GCM_TAG_SIZE 16

#define LACKY_CURVE25519_KEY_SIZE 32
#define LACKY_ED25519_SIGNATURE_SIZE 64
#define LACKY_ED25519_PUBLIC_KEY_SIZE 32
#define LACKY_ED25519_PRIVATE_KEY_SIZE 32

#define LACKY_SECP256K1_PRIVATE_KEY_SIZE 32
#define LACKY_SECP256K1_PUBLIC_KEY_SIZE 33  // Compressed
#define LACKY_SECP256K1_SIGNATURE_SIZE 64

#define LACKY_SHA256_DIGEST_SIZE 32
#define LACKY_SHA512_DIGEST_SIZE 64
#define LACKY_BLAKE2B_DIGEST_SIZE 64

/* Argon2 Parameters */
#define LACKY_ARGON2_SALT_SIZE 16
#define LACKY_ARGON2_HASH_SIZE 32
#define LACKY_ARGON2_MIN_MEMORY 1024      // 1MB minimum
#define LACKY_ARGON2_MAX_MEMORY 1048576   // 1GB maximum
#define LACKY_ARGON2_MIN_TIME 1
#define LACKY_ARGON2_MAX_TIME 10

/* Crypto Context Structures */
typedef struct {
    uint32_t state[16];
    uint64_t counter;
} lacky_chacha20_ctx_t;

typedef struct {
    uint32_t r[5];
    uint32_t h[5];
    uint8_t buffer[16];
    size_t leftover;
} lacky_poly1305_ctx_t;

typedef struct {
    uint8_t key[LACKY_AES_KEY_SIZE];
    uint8_t round_keys[240];  // 14 rounds * 16 bytes + original key
    uint32_t rounds;
} lacky_aes_ctx_t;

typedef struct {
    lacky_aes_ctx_t aes_ctx;
    uint8_t iv[LACKY_AES_GCM_IV_SIZE];
    uint8_t h[16];            // Hash subkey
    uint8_t j0[16];           // Initial counter block
    uint64_t aad_len;
    uint64_t text_len;
} lacky_aes_gcm_ctx_t;

typedef struct {
    uint32_t h[8];
    uint32_t total_len;
    uint8_t buffer[64];
    size_t buffer_len;
} lacky_sha256_ctx_t;

typedef struct {
    uint64_t h[8];
    uint64_t total_len;
    uint8_t buffer[128];
    size_t buffer_len;
} lacky_sha512_ctx_t;

typedef struct {
    uint64_t h[8];
    uint64_t t[2];
    uint64_t f[2];
    uint8_t buffer[128];
    size_t buffer_len;
    uint8_t last_node;
} lacky_blake2b_ctx_t;

/* Argon2 Context */
typedef struct {
    uint32_t memory_kb;
    uint32_t iterations;
    uint32_t parallelism;
    uint32_t hash_len;
    uint32_t salt_len;
    uint32_t secret_len;
    uint32_t ad_len;
    const uint8_t* password;
    uint32_t password_len;
    const uint8_t* salt;
    const uint8_t* secret;
    const uint8_t* ad;
    uint8_t* hash;
} lacky_argon2_ctx_t;

/* AEAD Envelope Structure */
typedef struct {
    uint8_t nonce[LACKY_XCHACHA20_NONCE_SIZE];
    uint8_t tag[LACKY_POLY1305_TAG_SIZE];
    uint8_t ciphertext[];
} lacky_envelope_t;

/* Public Key Structures */
typedef struct {
    uint8_t public_key[LACKY_CURVE25519_KEY_SIZE];
    uint8_t private_key[LACKY_CURVE25519_KEY_SIZE];
} lacky_curve25519_keypair_t;

typedef struct {
    uint8_t public_key[LACKY_ED25519_PUBLIC_KEY_SIZE];
    uint8_t private_key[LACKY_ED25519_PRIVATE_KEY_SIZE];
} lacky_ed25519_keypair_t;

typedef struct {
    uint8_t public_key[LACKY_SECP256K1_PUBLIC_KEY_SIZE];
    uint8_t private_key[LACKY_SECP256K1_PRIVATE_KEY_SIZE];
} lacky_secp256k1_keypair_t;

/* Main Crypto Context */
typedef struct {
    int initialized;
    void* rng_handle;  // Platform-specific RNG handle
    lacky_chacha20_ctx_t chacha20_ctx;
    lacky_poly1305_ctx_t poly1305_ctx;
    lacky_aes_gcm_ctx_t aes_gcm_ctx;
    lacky_sha256_ctx_t sha256_ctx;
    lacky_sha512_ctx_t sha512_ctx;
    lacky_blake2b_ctx_t blake2b_ctx;
} lacky_crypto_context_t;

/* Core Cryptographic Functions */

/* ChaCha20 Stream Cipher */
void lacky_chacha20_init(lacky_chacha20_ctx_t* ctx, const uint8_t* key, const uint8_t* nonce);
void lacky_chacha20_encrypt(lacky_chacha20_ctx_t* ctx, const uint8_t* plaintext, uint8_t* ciphertext, size_t len);
void lacky_chacha20_decrypt(lacky_chacha20_ctx_t* ctx, const uint8_t* ciphertext, uint8_t* plaintext, size_t len);

/* XChaCha20 Extended Nonce Variant */
void lacky_xchacha20_encrypt(const uint8_t* key, const uint8_t* nonce, const uint8_t* plaintext, uint8_t* ciphertext, size_t len);
void lacky_xchacha20_decrypt(const uint8_t* key, const uint8_t* nonce, const uint8_t* ciphertext, uint8_t* plaintext, size_t len);

/* Poly1305 MAC */
void lacky_poly1305_init(lacky_poly1305_ctx_t* ctx, const uint8_t* key);
void lacky_poly1305_update(lacky_poly1305_ctx_t* ctx, const uint8_t* data, size_t len);
void lacky_poly1305_finish(lacky_poly1305_ctx_t* ctx, uint8_t* tag);
void lacky_poly1305_mac(const uint8_t* key, const uint8_t* data, size_t len, uint8_t* tag);

/* XChaCha20-Poly1305 AEAD */
int lacky_xchacha20_poly1305_encrypt(const uint8_t* key, const uint8_t* nonce, 
                                     const uint8_t* aad, size_t aad_len,
                                     const uint8_t* plaintext, size_t plaintext_len,
                                     uint8_t* ciphertext, uint8_t* tag);

int lacky_xchacha20_poly1305_decrypt(const uint8_t* key, const uint8_t* nonce,
                                     const uint8_t* aad, size_t aad_len,
                                     const uint8_t* ciphertext, size_t ciphertext_len,
                                     const uint8_t* tag, uint8_t* plaintext);

/* AES Implementation */
void lacky_aes_key_schedule(lacky_aes_ctx_t* ctx, const uint8_t* key, uint32_t key_bits);
void lacky_aes_encrypt_block(const lacky_aes_ctx_t* ctx, const uint8_t* plaintext, uint8_t* ciphertext);
void lacky_aes_decrypt_block(const lacky_aes_ctx_t* ctx, const uint8_t* ciphertext, uint8_t* plaintext);

/* AES-GCM AEAD */
void lacky_aes_gcm_init(lacky_aes_gcm_ctx_t* ctx, const uint8_t* key, const uint8_t* iv);
void lacky_aes_gcm_update_aad(lacky_aes_gcm_ctx_t* ctx, const uint8_t* aad, size_t aad_len);
void lacky_aes_gcm_encrypt_update(lacky_aes_gcm_ctx_t* ctx, const uint8_t* plaintext, uint8_t* ciphertext, size_t len);
void lacky_aes_gcm_decrypt_update(lacky_aes_gcm_ctx_t* ctx, const uint8_t* ciphertext, uint8_t* plaintext, size_t len);
int lacky_aes_gcm_finish(lacky_aes_gcm_ctx_t* ctx, uint8_t* tag);
int lacky_aes_gcm_verify(lacky_aes_gcm_ctx_t* ctx, const uint8_t* tag);

/* Hash Functions */
void lacky_sha256_init(lacky_sha256_ctx_t* ctx);
void lacky_sha256_update(lacky_sha256_ctx_t* ctx, const uint8_t* data, size_t len);
void lacky_sha256_finish(lacky_sha256_ctx_t* ctx, uint8_t* digest);
void lacky_sha256(const uint8_t* data, size_t len, uint8_t* digest);

void lacky_sha512_init(lacky_sha512_ctx_t* ctx);
void lacky_sha512_update(lacky_sha512_ctx_t* ctx, const uint8_t* data, size_t len);
void lacky_sha512_finish(lacky_sha512_ctx_t* ctx, uint8_t* digest);
void lacky_sha512(const uint8_t* data, size_t len, uint8_t* digest);

void lacky_blake2b_init(lacky_blake2b_ctx_t* ctx, size_t hash_len);
void lacky_blake2b_update(lacky_blake2b_ctx_t* ctx, const uint8_t* data, size_t len);
void lacky_blake2b_finish(lacky_blake2b_ctx_t* ctx, uint8_t* digest);
void lacky_blake2b(const uint8_t* data, size_t len, uint8_t* digest, size_t digest_len);

/* Key Derivation Functions */
int lacky_argon2id(const lacky_argon2_ctx_t* ctx);
int lacky_pbkdf2_sha256(const uint8_t* password, size_t password_len,
                        const uint8_t* salt, size_t salt_len,
                        uint32_t iterations,
                        uint8_t* derived_key, size_t key_len);

/* Elliptic Curve Cryptography */

/* Curve25519 (X25519) */
void lacky_curve25519_scalarmult_base(uint8_t* public_key, const uint8_t* private_key);
void lacky_curve25519_scalarmult(uint8_t* shared_secret, const uint8_t* private_key, const uint8_t* public_key);
void lacky_curve25519_keygen(lacky_curve25519_keypair_t* keypair);

/* Ed25519 Digital Signatures */
void lacky_ed25519_keygen(lacky_ed25519_keypair_t* keypair);
void lacky_ed25519_sign(const uint8_t* private_key, const uint8_t* message, size_t message_len, uint8_t* signature);
int lacky_ed25519_verify(const uint8_t* public_key, const uint8_t* message, size_t message_len, const uint8_t* signature);

/* secp256k1 for Bitcoin/Ethereum */
void lacky_secp256k1_keygen(lacky_secp256k1_keypair_t* keypair);
void lacky_secp256k1_pubkey_from_private(const uint8_t* private_key, uint8_t* public_key, bool compressed);
int lacky_secp256k1_sign(const uint8_t* private_key, const uint8_t* hash, uint8_t* signature);
int lacky_secp256k1_verify(const uint8_t* public_key, const uint8_t* hash, const uint8_t* signature);

/* ECDH */
int lacky_secp256k1_ecdh(const uint8_t* private_key, const uint8_t* public_key, uint8_t* shared_secret);

/* Utility Functions */
int lacky_crypto_secure_compare(const uint8_t* a, const uint8_t* b, size_t len);
void lacky_crypto_zeroize(void* ptr, size_t len);

/* High-Level Envelope Encryption */
size_t lacky_envelope_encrypt_size(size_t plaintext_len);
int lacky_envelope_encrypt(const uint8_t* key, const uint8_t* plaintext, size_t plaintext_len,
                          lacky_envelope_t* envelope, size_t envelope_size);
int lacky_envelope_decrypt(const uint8_t* key, const lacky_envelope_t* envelope, size_t envelope_size,
                          uint8_t* plaintext, size_t* plaintext_len);

/* Additional Function Declarations */
void lacky_crypto_random(uint8_t* buffer, size_t len);
lacky_error_t lacky_crypto_hash_sha256(const uint8_t* input, size_t input_size, uint8_t output[32]);
lacky_error_t lacky_crypto_derive_key(const char* password, size_t password_len,
                                     const uint8_t* salt, size_t salt_len,
                                     uint8_t* output, size_t output_len);

/* Constant-Time Implementations (ASM) */
extern void lacky_asm_chacha20_block(uint32_t* state, uint8_t* output);
extern void lacky_asm_poly1305_block(uint32_t* h, const uint8_t* block, uint32_t* r);
extern void lacky_asm_aes_encrypt_block(const uint8_t* round_keys, const uint8_t* plaintext, uint8_t* ciphertext);
extern void lacky_asm_aes_decrypt_block(const uint8_t* round_keys, const uint8_t* ciphertext, uint8_t* plaintext);
extern void lacky_asm_curve25519_scalarmult_base(uint8_t* result, const uint8_t* scalar);
extern void lacky_asm_curve25519_scalarmult(uint8_t* result, const uint8_t* scalar, const uint8_t* point);
extern void lacky_asm_secp256k1_point_mul(const uint8_t* scalar, const uint8_t* point, uint8_t* result);

/* Memory-Hard Functions (Argon2) */
extern void lacky_asm_argon2_fill_block(const uint8_t* prev_block, const uint8_t* ref_block, 
                                       uint8_t* next_block, bool with_xor);
extern void lacky_asm_blake2b_compress(lacky_blake2b_ctx_t* ctx, const uint8_t* block, bool last);

/* Side-Channel Resistant Operations */
extern void lacky_asm_conditional_swap(uint8_t* a, uint8_t* b, size_t len, uint8_t condition);
extern void lacky_asm_scalar_mult_ladder(uint8_t* result, const uint8_t* scalar, const uint8_t* point);

/* Additional ASM Security Functions */
extern void lacky_asm_anti_debug_checks(void);
extern void lacky_aes256_encrypt_quantum(const uint8_t* key, const uint8_t* plaintext, uint8_t* ciphertext);
extern void lacky_ed25519_sign_protected(const uint8_t* private_key, const uint8_t* message, size_t message_len, uint8_t* signature);
extern void lacky_secp256k1_multiply_secure(const uint8_t* scalar, const uint8_t* point, uint8_t* result);
extern void lacky_argon2_derive_consciousness(const uint8_t* password, size_t password_len, const uint8_t* salt, uint8_t* output);

/* Crypto Context Management */
int lacky_crypto_init(lacky_crypto_context_t* ctx);
void lacky_crypto_cleanup(lacky_crypto_context_t* ctx);
int lacky_crypto_random_bytes(lacky_crypto_context_t* ctx, uint8_t* buffer, size_t len);

/* Hardware Acceleration Detection */
bool lacky_crypto_has_aes_ni(void);
bool lacky_crypto_has_avx2(void);
bool lacky_crypto_has_rdrand(void);

/* Secure Memory Operations */
void lacky_secure_zero(void* ptr, size_t size);

/* Random Number Generation */
int lacky_random_bytes(uint8_t* buffer, size_t len);

/* Performance Testing */
typedef struct {
    uint64_t cycles_per_byte;
    double mbytes_per_second;
    uint64_t total_cycles;
    uint64_t total_bytes;
} lacky_crypto_benchmark_t;

void lacky_crypto_benchmark_start(lacky_crypto_benchmark_t* bench);
void lacky_crypto_benchmark_end(lacky_crypto_benchmark_t* bench, size_t bytes_processed);

#endif /* LACKY_CRYPTO_H */
