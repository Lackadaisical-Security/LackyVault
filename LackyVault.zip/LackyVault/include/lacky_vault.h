/**
 * LackyVault - Main Header
 * Lackadaisical Security
 * 
 * Zero-trust crypto wallet with custom primitives
 * No external dependencies - Windows SDK only
 */

#ifndef LACKY_VAULT_H
#define LACKY_VAULT_H

#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lacky_crypto.h"

/* Version Information */
#define LACKY_VERSION_MAJOR 1
#define LACKY_VERSION_MINOR 0
#define LACKY_VERSION_PATCH 0
#define LACKY_VERSION_STRING "1.0.0"

/* Security Constants */
#define LACKY_MAX_PASSWORD_LEN 1024
#define LACKY_SALT_SIZE 32
#define LACKY_KEY_SIZE 32
#define LACKY_NONCE_SIZE 24
#define LACKY_MAC_SIZE 16
#define LACKY_ARGON2_MEMORY_KB 65536  // 64MB
#define LACKY_ARGON2_ITERATIONS 3
#define LACKY_ARGON2_PARALLELISM 1

/* UI Constants */
#define LACKY_WINDOW_WIDTH 1200
#define LACKY_WINDOW_HEIGHT 800
#define LACKY_MIN_WINDOW_WIDTH 800
#define LACKY_MIN_WINDOW_HEIGHT 600

/* Network Constants */
#define LACKY_MAX_PROXY_CHAIN 5
#define LACKY_DEFAULT_TIMEOUT 30000  // 30 seconds
#define LACKY_MAX_PACKET_SIZE 8192

/* Storage Constants */
#define LACKY_MAX_WALLET_SIZE (1024 * 1024)  // 1MB max wallet file
#define LACKY_MAX_WALLET_NAME 256

/* Resource IDs */
#define IDR_MAIN_MENU 100
#define IDR_MAIN_ACCEL 101
#define IDD_AUTH_DIALOG 200
#define IDD_CREATE_WALLET_DIALOG 201
#define IDD_TRANSACTION_DIALOG 202
#define IDD_SETTINGS_DIALOG 203
#define IDD_ABOUT_DIALOG 204

/* String Resource IDs */
#define IDS_APP_TITLE 1000
#define IDS_APP_DESCRIPTION 1001
#define IDS_PANIC_TITLE 1002
#define IDS_PANIC_MESSAGE 1003
#define IDS_ERROR_TITLE 1004
#define IDS_WARNING_TITLE 1005
#define IDS_INFO_TITLE 1006
#define IDS_CONFIRM_TITLE 1007
#define IDS_AUTH_TITLE 1008
#define IDS_WALLET_TITLE 1009
#define IDS_TRANSACTION_TITLE 1010
#define IDS_SETTINGS_TITLE 1011
#define IDS_ABOUT_TITLE 1012

/* Menu Command IDs */
#define ID_FILE_NEW_WALLET 2000
#define ID_FILE_OPEN_WALLET 2001
#define ID_FILE_CLOSE_WALLET 2002
#define ID_FILE_IMPORT 2003
#define ID_FILE_EXPORT 2004
#define ID_FILE_EXIT 2005
#define ID_WALLET_SEND 2010
#define ID_WALLET_RECEIVE 2011
#define ID_WALLET_BALANCE 2012
#define ID_WALLET_HISTORY 2013
#define ID_WALLET_BACKUP 2014
#define ID_WALLET_RESTORE 2015
#define ID_SECURITY_LOCK 2020
#define ID_SECURITY_CHANGE_PASSWORD 2021
#define ID_SECURITY_PANIC 2022
#define ID_SECURITY_DISTRESS 2023
#define ID_TOOLS_SETTINGS 2030
#define ID_TOOLS_NETWORK 2031
#define ID_TOOLS_HARDWARE_WALLET 2032
#define ID_TOOLS_ADDRESS_BOOK 2033
#define ID_VIEW_FULLSCREEN 2040
#define ID_VIEW_THEME_CYBER 2041
#define ID_VIEW_THEME_COSMIC 2042
#define ID_VIEW_THEME_LIGHT 2043
#define ID_VIEW_THEME_DARK 2044
#define ID_VIEW_THEME_RETRO_80S 2045
#define ID_VIEW_THEME_RETRO_90S 2046
#define ID_VIEW_THEME_MATRIX 2047
#define ID_VIEW_THEME_TERMINAL 2048
#define ID_HELP_USER_GUIDE 2050
#define ID_HELP_SECURITY 2051
#define ID_HELP_ABOUT 2052

/* Dialog Control IDs */
#define IDC_AUTH_PASSWORD 3000
#define IDC_AUTH_REMEMBER 3001
#define IDC_AUTH_WALLET_NAME 3002
#define IDC_AUTH_LAST_ACCESS 3003
#define IDC_AUTH_SECURITY_STATUS 3004
#define IDC_CREATE_WALLET_NAME 3010
#define IDC_CREATE_PASSWORD 3011
#define IDC_CONFIRM_PASSWORD 3012
#define IDC_RECOVERY_PHRASE 3013
#define IDC_GENERATE_PHRASE 3014
#define IDC_COPY_PHRASE 3015
#define IDC_BACKUP_CONFIRMED 3016
#define IDC_RISKS_UNDERSTOOD 3017
#define IDC_TX_TO_ADDRESS 3020
#define IDC_TX_ADDRESS_BOOK 3021
#define IDC_TX_SCAN_QR 3022
#define IDC_TX_AMOUNT 3023
#define IDC_TX_CURRENCY 3024
#define IDC_TX_FEE_LEVEL 3025
#define IDC_TX_FEE_DESCRIPTION 3026
#define IDC_TX_FROM_WALLET 3027
#define IDC_TX_AVAILABLE_BALANCE 3028
#define IDC_TX_ESTIMATED_FEE 3029
#define IDC_TX_TOTAL_AMOUNT 3030
#define IDC_TX_REMAINING_BALANCE 3031
#define IDC_TX_DETAILS 3032
#define IDC_TX_PRIVACY 3033
#define IDC_TX_TOR 3034
#define IDC_TX_DELETE_DATA 3035
#define IDC_TX_PREVIEW 3036
#define IDC_SETTINGS_TAB 3040
#define IDC_SETTINGS_APPLY 3041

/* Application States */
typedef enum {
    LACKY_STATE_INIT = 0,
    LACKY_STATE_SPLASH,
    LACKY_STATE_AUTH,
    LACKY_STATE_MAIN,
    LACKY_STATE_TRANSACTION,
    LACKY_STATE_SETTINGS,
    LACKY_STATE_PANIC,
    LACKY_STATE_SHUTDOWN,
    LACKY_STATE_EXIT
} lacky_state_t;

/* Theme Types */
typedef enum {
    LACKY_THEME_CYBER = 0,
    LACKY_THEME_COSMIC,
    LACKY_THEME_LIGHT,
    LACKY_THEME_DARK,
    LACKY_THEME_RETRO_80S,
    LACKY_THEME_RETRO_90S,
    LACKY_THEME_MATRIX,
    LACKY_THEME_TERMINAL
} lacky_theme_t;

/* Cryptographic Algorithms */
typedef enum {
    LACKY_CRYPTO_CHACHA20_POLY1305 = 0,
    LACKY_CRYPTO_AES_256_GCM,
    LACKY_CRYPTO_XCHACHA20_POLY1305
} lacky_crypto_algo_t;

/* Forward Declarations */
typedef struct lacky_network lacky_network_t;
typedef struct lacky_wallet lacky_wallet_t;
typedef struct lacky_config lacky_config_t;
typedef struct lacky_app lacky_app_t;

/* Network Structure */
typedef struct lacky_network {
    int initialized;
    void* wininet_handle;
    char proxy_host[256];
    uint16_t proxy_port;
    int proxy_enabled;
    int tor_enabled;
    uint32_t timeout_ms;
} lacky_network_t;

/* Wallet Structure */
typedef struct lacky_wallet {
    int initialized;
    char name[LACKY_MAX_WALLET_NAME];
    char filepath[MAX_PATH];
    uint8_t master_seed[LACKY_KEY_SIZE];
    uint8_t public_key[LACKY_KEY_SIZE];
    uint32_t account_index;
    uint32_t address_index;
    uint64_t balance;
    int locked;
} lacky_wallet_t;

/* Storage Context */
typedef struct {
    int initialized;
    char data_directory[MAX_PATH];
} lacky_storage_ctx_t;

/* Error codes are now defined in lacky_crypto.h */

/* Event System */
typedef enum {
    LACKY_EVENT_UI_UPDATE = 1,
    LACKY_EVENT_CRYPTO_REQUEST,
    LACKY_EVENT_CRYPTO_COMPLETE,
    LACKY_EVENT_NETWORK_REQUEST,
    LACKY_EVENT_NETWORK_RESPONSE,
    LACKY_EVENT_PANIC_TRIGGER,
    LACKY_EVENT_KEY_ZEROIZE,
    LACKY_EVENT_STATE_CHANGE
} lacky_event_type_t;

/* Crypto Operation Types */
typedef enum {
    LACKY_CRYPTO_OP_DERIVE_KEY = 1,
    LACKY_CRYPTO_OP_ENCRYPT,
    LACKY_CRYPTO_OP_DECRYPT,
    LACKY_CRYPTO_OP_SIGN,
    LACKY_CRYPTO_OP_VERIFY,
    LACKY_CRYPTO_OP_HASH,
    LACKY_CRYPTO_OP_KEYGEN
} lacky_crypto_op_t;

/* Network Operation Types */
typedef enum {
    LACKY_NETWORK_OP_RPC_CALL = 1,
    LACKY_NETWORK_OP_BALANCE_CHECK,
    LACKY_NETWORK_OP_SEND_TX,
    LACKY_NETWORK_OP_GET_BLOCK,
    LACKY_NETWORK_OP_GET_HEIGHT,
    LACKY_NETWORK_OP_PROXY_ROTATE
} lacky_network_op_t;

typedef struct {
    lacky_event_type_t type;
    uint32_t data_size;
    uint8_t data[256];
    volatile uint32_t processed;
} lacky_event_t;

/* Security Context */
typedef struct {
    uint8_t master_key[LACKY_KEY_SIZE];
    uint8_t session_key[LACKY_KEY_SIZE];
    uint8_t salt[LACKY_SALT_SIZE];
    uint32_t derivation_rounds;
    bool authenticated;
    bool panic_mode;
    LARGE_INTEGER last_activity;
} lacky_security_ctx_t;

/* Configuration Structure */
typedef struct lacky_config {
    lacky_theme_t theme;
    lacky_crypto_algo_t crypto_algo;
    char proxy_list[LACKY_MAX_PROXY_CHAIN][256];
    uint32_t proxy_count;
    uint32_t auto_lock_timeout;
    bool enable_panic_hotkey;
    bool enable_decoy_wallets;
    bool enable_tor_proxy;
    char data_directory[MAX_PATH];
} lacky_config_t;

/* Main Application Structure */
typedef struct lacky_app {
    HINSTANCE hinstance;
    HWND main_window;
    lacky_state_t current_state;
    lacky_config_t config;
    lacky_security_ctx_t security;
    lacky_storage_ctx_t storage;
    lacky_crypto_context_t crypto_ctx;
    lacky_wallet_t* active_wallet;
    lacky_network_t* network;
    
    /* Threading */
    HANDLE ui_thread;
    HANDLE crypto_thread;
    HANDLE network_thread;
    HANDLE security_thread;
    
    /* Event Queue */
    lacky_event_t event_queue[256];
    volatile uint32_t event_head;
    volatile uint32_t event_tail;
    CRITICAL_SECTION event_lock;
    
    /* UI Resources */
    HFONT fonts[4];  // Various sizes
    HBRUSH brushes[8];  // Theme colors
    HPEN pens[8];    // Drawing pens
      /* Security flags */
    volatile bool shutdown_requested;
    volatile bool panic_triggered;
} lacky_app_t;

/* Global Function Declarations */

/* Core System */
extern lacky_error_t lacky_init(lacky_app_t* app, HINSTANCE hinstance);
extern void lacky_cleanup(lacky_app_t* app);
extern lacky_error_t lacky_run(lacky_app_t* app);

/* Security Functions */
extern void lacky_zeroize_memory(void* ptr, size_t size);
extern lacky_error_t lacky_derive_key(const char* password, const uint8_t* salt, uint8_t* key);
extern bool lacky_verify_integrity(void);
extern void lacky_panic_mode(lacky_app_t* app);
extern int lacky_secure_memcmp(const void* a, const void* b, size_t len);

/* Secure Memory Functions */
extern void* lacky_secure_alloc(size_t size);
extern void lacky_secure_free(void* ptr, size_t size);
extern void lacky_secure_zero(void* ptr, size_t size);

/* Event System */
extern lacky_error_t lacky_event_post(lacky_app_t* app, lacky_event_type_t type, const void* data, uint32_t size);
extern lacky_error_t lacky_event_poll(lacky_app_t* app, lacky_event_t* event);

/* State Management */
extern lacky_error_t lacky_state_transition(lacky_app_t* app, lacky_state_t new_state);
extern const char* lacky_state_name(lacky_state_t state);

/* Utility Macros */
#define LACKY_ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))
#define LACKY_ALIGN(x, a) (((x) + (a) - 1) & ~((a) - 1))
#define LACKY_MIN(a, b) ((a) < (b) ? (a) : (b))
#define LACKY_MAX(a, b) ((a) > (b) ? (a) : (b))
#define LACKY_UNUSED(x) ((void)(x))

/* Security Macros */
#define LACKY_ZEROIZE(ptr) lacky_zeroize_memory((ptr), sizeof(*(ptr)))
#define LACKY_SECURE_COMPARE(a, b, len) lacky_secure_memcmp((a), (b), (len))

/* Debug Macros */
#ifdef DEBUG
#define LACKY_DEBUG(fmt, ...) printf("[DEBUG] " fmt "\n", ##__VA_ARGS__)
#define LACKY_ASSERT(cond) do { if (!(cond)) { printf("ASSERT FAILED: %s:%d\n", __FILE__, __LINE__); abort(); } } while(0)
#else
#define LACKY_DEBUG(fmt, ...)
#define LACKY_ASSERT(cond)
#endif

/* Assembly Function Declarations */
extern void lacky_asm_zeroize(void* ptr, size_t size);
extern int lacky_asm_secure_memcmp(const void* a, const void* b, size_t len);
extern void lacky_asm_check_debugger(void);
extern void lacky_asm_anti_vm_checks(void);
extern uint64_t lacky_asm_rdtsc(void);

/* Crypto Assembly Functions */
extern void lacky_asm_chacha20_encrypt(const uint8_t* key, const uint8_t* nonce, const uint8_t* plaintext, uint8_t* ciphertext, size_t len);
extern void lacky_asm_poly1305_mac(const uint8_t* key, const uint8_t* data, size_t len, uint8_t* mac);
extern void lacky_asm_curve25519_scalarmult(uint8_t* result, const uint8_t* scalar, const uint8_t* point);
extern void lacky_asm_aes_gcm_encrypt(const uint8_t* key, const uint8_t* iv, const uint8_t* plaintext, uint8_t* ciphertext, size_t len, uint8_t* tag);

/* Network Functions */
extern lacky_error_t lacky_network_init(lacky_network_t** network);
extern void lacky_network_cleanup(lacky_network_t* network);
extern lacky_error_t lacky_network_connect(lacky_network_t* network, const char* host, uint16_t port);
extern lacky_error_t lacky_network_send(lacky_network_t* network, const void* data, size_t len);
extern lacky_error_t lacky_network_recv(lacky_network_t* network, void* buffer, size_t* len);
extern lacky_error_t lacky_network_check_connectivity(lacky_network_t* network);
extern lacky_error_t lacky_network_get_balance(lacky_network_t* network, const char* address, uint64_t* balance);

/* UI Window Functions */
extern lacky_error_t lacky_window_register_class(HINSTANCE hinstance);
extern lacky_error_t lacky_window_create(lacky_app_t* app);
extern void lacky_window_toggle_fullscreen(HWND hwnd);
extern void lacky_show_about_dialog(HWND parent);

/* UI Theme Functions */
extern lacky_error_t lacky_theme_init(lacky_app_t* app);
extern void lacky_theme_cleanup(lacky_app_t* app);
extern void lacky_theme_update_layout(lacky_app_t* app, int width, int height);
extern void lacky_theme_render_splash(HDC hdc, RECT* rect, lacky_app_t* app);
extern void lacky_theme_render_auth_screen(HDC hdc, RECT* rect, lacky_app_t* app);
extern void lacky_theme_render_main_interface(HDC hdc, RECT* rect, lacky_app_t* app);
extern void lacky_theme_render_transaction_screen(HDC hdc, RECT* rect, lacky_app_t* app);
extern void lacky_theme_render_settings_screen(HDC hdc, RECT* rect, lacky_app_t* app);
extern void lacky_theme_render_fake_windows_update(HDC hdc, RECT* rect, lacky_app_t* app);

/* UI Controls Functions */
extern void lacky_controls_create_for_state(HWND parent, lacky_state_t state);
extern void lacky_controls_resize_for_state(HWND parent, lacky_state_t state, int width, int height);
extern void lacky_controls_create_auth(HWND parent);
extern void lacky_controls_create_main(HWND parent);
extern void lacky_controls_create_transaction(HWND parent);
extern void lacky_controls_create_settings(HWND parent);
extern void lacky_controls_resize_auth(HWND parent, int width, int height);
extern void lacky_controls_resize_main(HWND parent, int width, int height);
extern void lacky_controls_resize_transaction(HWND parent, int width, int height);
extern void lacky_controls_resize_settings(HWND parent, int width, int height);

/* UI Dialog Functions */
extern LRESULT lacky_auth_handle_command(lacky_app_t* app, WORD command_id, WORD notification, HWND control_hwnd);
extern LRESULT lacky_main_handle_command(lacky_app_t* app, WORD command_id, WORD notification, HWND control_hwnd);
extern LRESULT lacky_transaction_handle_command(lacky_app_t* app, WORD command_id, WORD notification, HWND control_hwnd);
extern LRESULT lacky_settings_handle_command(lacky_app_t* app, WORD command_id, WORD notification, HWND control_hwnd);
extern INT_PTR lacky_show_auth_dialog(HWND parent, lacky_app_t* app);
extern INT_PTR lacky_show_create_wallet_dialog(HWND parent, lacky_app_t* app);
extern INT_PTR lacky_show_import_wallet_dialog(HWND parent, lacky_app_t* app);
extern INT_PTR lacky_show_send_confirm_dialog(HWND parent, lacky_app_t* app);
extern INT_PTR lacky_show_receive_dialog(HWND parent, lacky_app_t* app);
extern INT_PTR lacky_show_mnemonic_dialog(HWND parent, lacky_app_t* app);
extern INT_PTR lacky_show_backup_warning_dialog(HWND parent, lacky_app_t* app);

/* Configuration Functions */
extern lacky_error_t lacky_config_load(lacky_config_t* config, const char* filename);
extern lacky_error_t lacky_config_save(const lacky_config_t* config, const char* filename);
extern void lacky_config_set_defaults(lacky_config_t* config);

/* Wallet Functions */
extern lacky_error_t lacky_storage_init(lacky_storage_ctx_t* storage);
extern void lacky_storage_cleanup(lacky_storage_ctx_t* storage);
extern lacky_error_t lacky_wallet_create(lacky_wallet_t** wallet, const char* password);
extern lacky_error_t lacky_wallet_load(lacky_wallet_t** wallet, const char* filename, const char* password);
extern lacky_error_t lacky_wallet_save(lacky_wallet_t* wallet, const char* filename);
extern void lacky_wallet_cleanup(lacky_wallet_t* wallet);
extern lacky_error_t lacky_wallet_lock(lacky_wallet_t* wallet, const char* password);
extern lacky_error_t lacky_wallet_unlock(lacky_wallet_t* wallet, const char* password);
extern uint64_t lacky_wallet_get_balance(lacky_wallet_t* wallet);
extern void lacky_wallet_set_balance(lacky_wallet_t* wallet, uint64_t balance);
extern lacky_error_t lacky_wallet_get_address(lacky_wallet_t* wallet, char* address, size_t address_len);

/* All crypto functions are declared in lacky_crypto.h */

/* Compiler Attributes */
#ifdef __GNUC__
#define LACKY_NORETURN __attribute__((noreturn))
#define LACKY_PACKED __attribute__((packed))
#define LACKY_ALIGN_16 __attribute__((aligned(16)))
#define LACKY_NOINLINE __attribute__((noinline))
#define LACKY_ALWAYS_INLINE __attribute__((always_inline))
#else
#define LACKY_NORETURN __declspec(noreturn)
#define LACKY_PACKED
#define LACKY_ALIGN_16 __declspec(align(16))
#define LACKY_NOINLINE __declspec(noinline)
#define LACKY_ALWAYS_INLINE __forceinline
#endif

#endif /* LACKY_VAULT_H */
